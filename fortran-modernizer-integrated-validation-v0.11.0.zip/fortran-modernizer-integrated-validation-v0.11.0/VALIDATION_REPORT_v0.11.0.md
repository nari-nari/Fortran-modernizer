# v0.11.0 validation report

Validation was performed on Linux x86_64 with Python 3.13.5, fparser 0.2.4, findent 4.3.6, NumPy 2.3.5, Cython 3.2.4, jsonschema 4.26.0, and gfortran 14.2.0.

## Completed

| Test group | Result |
|---|---:|
| New integrated setup/doctor/layout tests | 3 passed |
| Dependency-aware workflow tests | 6 passed |
| Human approval and Hook tests | 5 passed |
| Compatibility/distribution/runtime/selection/regression tests | 15 passed |
| Refactor apply/IMPLICIT NONE/COMMON/interface/suggestion tests | 12 passed |
| Python migrator non-integration suite | 76 passed, 1 skipped, 31 deselected |
| Vertical Python generation smoke | 1 passed |
| Stateless native Cython generation smoke | 1 passed |
| Bootstrap setup/doctor without fparser/jsonschema/NumPy/Cython | behaved as designed: setup ran; doctor reported missing dependencies as BLOCKED |

The integrated bundle static validator passed. In the fully provisioned validation environment, `doctor` reported 11 PASS, 3 REVIEW_REQUIRED, and 0 BLOCKED; the review items were expected because no confidential legacy source, legacy compiler command, or regression baseline is included in the distribution.

## Limits

- A full rerun of all 232 refactor-tool tests did not complete within the external execution time limit; targeted tests covering the changed safety paths passed.
- Some compiler-heavy pipeline tests exhibit long process termination behavior in this host. Two pipeline smoke tests completed; no claim is made that every heavy test was rerun for v0.11.0.
- Windows native execution and live VS Code/Copilot custom-agent/Hook activation were not available in this Linux environment. Static configuration was validated, but runtime activation is intentionally reported as `UNKNOWN`.
- The confidential production Fortran code has not been supplied or tested.
