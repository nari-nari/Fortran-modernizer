# Release notes — v0.11.0

## User-facing integration

v0.11.0 is distributed as a single VS Code workspace containing the deterministic refactoring/Python-migration engines and the GitHub Copilot custom agent, skills, and policy Hook.

## New commands

- `setup-project`: creates the integrated directory layout, concise Copilot configuration, project/policy configuration, CLI-only documentation, and optional immutable source copy.
- `doctor`: diagnoses required Python modules, compilers, source presence, static Copilot files, Hook syntax, and unresolved human configuration.
- `validate-integrated-project`: checks the static all-in-one distribution layout.

The root Bash launcher and PowerShell launcher make bootstrap commands available before the complete numerical dependencies are installed.

## Copilot integration

- `Fortran Modernizer` custom agent is present at the workspace root.
- Seven skills cover setup, intake, scheduling, automatic refactoring, human approval, validation, and Python migration.
- PreToolUse Hook continues to deny direct source edits, human-only approval commands, stale schedules, and obsolete apply paths.
- Live agent/Hook activation is never inferred from file presence; it remains `UNKNOWN` until observed in VS Code.

## Compatibility

The deterministic v0.10.0 dependency scheduler and human approval records remain authoritative. CLI-only use is fully supported when Copilot or Preview Hooks are unavailable.
