# v0.11.0 implementation summary

v0.11.0 turns the v0.10.0 components into one user-facing VS Code workspace while retaining internal separation between the deterministic core and Copilot navigation.

## Added

- root-level `.github` Copilot custom agent, seven skills, concise instructions, and PreToolUse policy Hook;
- `setup-project` bootstrap command that works before the full numerical dependencies are installed;
- `doctor` for Python modules, compilers, project configuration, source presence, Copilot static files, and CLI fallback;
- `validate-integrated-project` for distribution-layout checks;
- root `config/project.json` and `config/workflow-policy.json` templates;
- immutable `legacy-original`, staged `work`, `build`, `approvals`, and `reports` directories;
- `README_FIRST.md`, CLI-only procedure, VS Code extension recommendations, Bash and PowerShell launchers;
- source-copy intake that refuses to overwrite existing legacy files;
- explicit `UNKNOWN` reporting for live VS Code custom-agent/Hook activation rather than claiming static validation proves activation.

## Safety architecture

Copilot may navigate and invoke commands, but the deterministic core remains authoritative for phase ordering, candidate readiness, source/plan hashes, human approvals, compilation, regression evidence, and migration gates. If Copilot or Hooks are unavailable, the same workflow continues in CLI-only mode.
