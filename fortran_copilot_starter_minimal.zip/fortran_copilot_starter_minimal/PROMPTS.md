# Prompts

以下は、実際に使う可能性が高いものだけを残しています。

---

## 1. 最初の事前調査

```text
まだFortranコードを変更しないでください。

このコードを安全にgfortranへ移植し、その後リファクタリング・Python化するための事前調査を行ってください。

可能な限り決定論的・再現可能に調査してください。
必要ならPython解析script、pytest、CSV/JSONレポート生成toolを自分で作成して使用してください。

少なくとも以下を確認してください。

- 現在のbuild方法
- source file一覧
- encoding
- fixed/free form
- INCLUDE
- program unit
- fparser parse coverage
- COMMON
- implicit typing
- procedure call / interface
- module/global state
- read/write
- gfortran diagnostics
- baseline取得可能性

fparserで解析できない箇所があっても全体を止めず、fallback方法を考えてください。

この段階では問題を発見しても修正せず、
confirmed facts / suspected issues / unknowns
を分けて報告してください。

調査完了後、作成したtool、主要な調査結果、未解決事項をまとめてください。
```

---

## 2. 調査後にROADMAPを作る

```text
これまでの事前調査結果、baseline、compiler diagnostics、静的解析結果、実ソースを参照してください。

このコード専用の
「Absoft → gfortran移植 → 必要最小限のFortran安定化 → Python移行 → parity確認」
のROADMAPを作成してください。

既知の問題だけに過適合せず、調査結果から優先順位を決めてください。

各Phaseには最低限、
- objective
- main tasks
- deliverables
- completion criteria
- stop / human-decision conditions
を定義してください。

Python化前のFortran修正は、全面modernizationではなく、
意味の確定、未定義挙動の除去、移植容易化、最低限の保守性確保
に必要な範囲を優先してください。

まだ実装は開始しないでください。
```

---

## 3. 次Phaseの実装計画を作る

```text
ROADMAP.mdを参照し、未完了の最初のPhaseについて実装計画を作成してください。

既存の調査結果・test・reportsを再利用し、不要な再調査を避けてください。

計画には、
- 変更対象
- 実装手順
- 検証方法
- completion criteria
- rollback / stop条件
だけを簡潔に含めてください。

このチャットではまだ実装しないでください。
```

---

## 4. 別チャットで計画を実装する

```text
リポジトリ内のROADMAP.mdと、直前に作成された最新の実装計画を参照してください。

その計画を実装し、必要なtest / build / numerical comparisonまで実施してください。

completion criteriaを満たしたら、
- 実施内容
- 検証結果
- 残ったrisk
を簡潔に報告し、ROADMAPの進捗を更新してください。

計画外の大規模リファクタリングは行わないでください。
```

---

## 5. 成功した手順をskill候補にする

```text
今回完了したPhaseについて、別のFortranコードでも再利用できる手順があるか確認してください。

コード固有の名前・COMMON名・subroutine名・directory構造に依存しない部分だけをskill候補として抽出してください。

まだ汎用性が確認できない手順はskill化せず、候補として記録するだけにしてください。
```
