# Fortran Modernization Starter

GitHub Copilot + Superpowers でレガシーFortranを安全に調査・gfortran移植・Python化するための最小構成です。

最初から詳細な `ROADMAP.md` は置きません。事前調査とbaseline取得後、その実コードの調査結果に基づいてROADMAPを作成させます。

## Files

- `PROJECT_BRIEF.md` — 目的と初期方針
- `.github/copilot-instructions.md` — Copilotが常に守る最小ルール
- `PROMPTS.md` — 実際に使う可能性が高いプロンプト

Superpowersは普段使うskillとして別途導入しておく想定です。
