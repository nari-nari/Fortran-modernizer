# Project Brief

## Goal

このプロジェクトの目的は、既存Fortranコードを安全に調査し、

1. Absoft Pro Fortranで得られている現行結果を基準として保存する
2. gfortranで再現可能にする
3. Python化に必要な範囲だけFortranを安定化・整理する
4. Fortranとの数値parityを確認しながらPythonへ段階的に移行する
5. 実際に有効だった手順を、必要に応じて再利用可能なskillへ整理する

ことです。

## Initial policy

- 最初から全面的なmodern Fortran化はしない
- Python化前のFortran修正は、意味の確定・未定義挙動の除去・移植容易化に必要な範囲を優先する
- COMMON、implicit typing、procedure interface等は重要な調査対象だが、問題があると事前に決めつけない
- 最終的には共通テスト・基準ケースでFortranとPythonの両方を検証できる状態を目指す

## Known characteristics

実コードには以下が含まれる可能性があります。

- fixed-form Fortran
- UTF-8 / Shift-JIS(CP932)混在
- INCLUDE
- COMMON
- implicit typing
- vendor-specific behavior
- module/global state
- 引数をほとんど取らないsolver
- 実行ディレクトリ依存の入出力

これらは調査対象であり、現時点では欠陥と断定しません。
