# Copilot Instructions

- 変更前に、現在のビルド方法・入力・出力・数値結果を可能な限り再現可能にする。
- 調査段階ではFortranソースを勝手に修正しない。
- fparser、gfortran diagnostics、pytest、比較script等の決定論的手段を優先する。
- 必要なら調査用Python scriptを作成してよい。原則read-only、小さな単一目的toolとする。
- UTF-8 / Shift-JIS(CP932)、fixed/free formを勝手に統一しない。
- compiler migration、リファクタリング、Python移行、性能改善を同じ変更に混在させない。
- 数値結果が変わった場合は、原因を説明できるまでbaselineを更新しない。
- COMMONを自動的にMODULEへ置換しない。まず宣言・型・順序・shape・利用箇所を確認する。
- LLMの推測だけで型や物理的意味を決めない。
- 小さな変更と回帰テストを優先する。
- 調査結果が揃った後、その実コード専用のROADMAPを作成する。事前に固定的な修正順序を決めない。
