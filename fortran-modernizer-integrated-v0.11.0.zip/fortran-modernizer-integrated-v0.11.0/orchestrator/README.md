# fortran-modernize orchestrator v0.11.0

The orchestrator connects Fortran Refactor Tool v0.50.0 and Fortran Python Migrator Milestone 23. v0.11.0 adds all-in-one project bootstrap and diagnostics while preserving the v0.10.0 dependency-aware human approval scheduler.

Bootstrap commands (`setup-project`, `doctor`, and `validate-integrated-project`) are available before the complete numerical Python environment is installed when invoked through the root launcher. All source-changing and migration commands require the full dependencies.
