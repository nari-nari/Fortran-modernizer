from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from .integration import (
    IntegratedProjectError,
    diagnose_integrated_project,
    setup_integrated_project,
    validate_integrated_project,
)


def parser() -> argparse.ArgumentParser:
    root = argparse.ArgumentParser(prog="fortran-modernize")
    commands = root.add_subparsers(dest="command", required=True)
    setup = commands.add_parser("setup-project")
    setup.add_argument("target_repository", nargs="?", default=".")
    setup.add_argument("--source")
    setup.add_argument("-I", "--include-dir", action="append", default=[])
    setup.add_argument("--legacy-compiler")
    setup.add_argument("--build-command")
    setup.add_argument("--run-command")
    setup.add_argument("--mode", choices=("auto", "copilot", "cli-only"), default="auto")
    setup.add_argument("--overwrite", action="store_true")
    doctor = commands.add_parser("doctor")
    doctor.add_argument("--project-root", default=".")
    doctor.add_argument("--output")
    validate = commands.add_parser("validate-integrated-project")
    validate.add_argument("project_root", nargs="?", default=".")
    return root


def main(argv: list[str] | None = None) -> int:
    args = parser().parse_args(argv)
    try:
        if args.command == "setup-project":
            result = setup_integrated_project(
                args.target_repository,
                source=args.source,
                include_dirs=args.include_dir,
                legacy_compiler=args.legacy_compiler,
                build_command=args.build_command,
                run_command=args.run_command,
                integration_mode=args.mode,
                overwrite=args.overwrite,
            )
            print(json.dumps({
                "status": result.status,
                "project_root": str(result.project_root),
                "project_config": str(result.project_config),
                "workflow_policy": str(result.policy_config),
                "manifest": str(result.installation_manifest),
                "copied_sources": list(result.copied_sources),
                "warnings": list(result.warnings),
            }, ensure_ascii=False, indent=2))
            return 0 if result.status == "PASS" else 1
        if args.command == "doctor":
            result = diagnose_integrated_project(args.project_root, output=args.output)
            print(json.dumps({"status": result.status, "report": str(result.report), "summary": result.summary}, ensure_ascii=False, indent=2))
            return 2 if result.status == "BLOCKED" else (1 if result.status == "REVIEW_REQUIRED" else 0)
        errors = validate_integrated_project(args.project_root)
        if errors:
            print(json.dumps({"status": "BLOCKED", "errors": errors}, ensure_ascii=False, indent=2), file=sys.stderr)
            return 2
        print(json.dumps({"status": "PASS", "project_root": str(Path(args.project_root).expanduser().resolve())}, ensure_ascii=False, indent=2))
        return 0
    except IntegratedProjectError as exc:
        print(json.dumps({"status": "BLOCKED", "error": str(exc)}, ensure_ascii=False, indent=2), file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
