from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path


def _bootstrap() -> Path:
    root = Path(__file__).resolve().parents[3]
    candidates = (
        root / "packages" / "fortran-refactor-tool" / "src",
        root / "packages" / "fortran-python-migrator" / "src",
    )
    for candidate in reversed(candidates):
        if candidate.is_dir():
            sys.path.insert(0, str(candidate))
    return root


_BUNDLE_ROOT = _bootstrap()

from fortran_refactor.diagnostics import build_analysis_result  # noqa: E402
from fortran_refactor.extract import analyze_unit  # noqa: E402
from fortran_refactor.python_handoff import PythonHandoffError, write_python_handoff  # noqa: E402
from fortran_refactor.source import discover_fortran_files, split_program_units  # noqa: E402
from fpy_migrate.intake import validate_refactor_report  # noqa: E402
from fpy_migrate.refactor_bridge import RefactorBridgeError, verify_refactor_connection  # noqa: E402
from .pipeline import ProcedureMigrationError, run_procedure_migration  # noqa: E402
from .regression import NumericalRegressionError, run_numerical_regression  # noqa: E402
from .selection import KernelSelectionError, run_kernel_selection  # noqa: E402
from .runtime import (  # noqa: E402
    RuntimeBundleError,
    build_runtime_bundle,
    run_runtime_bundle,
)
from .distribution import (  # noqa: E402
    DistributionBundleError,
    build_distribution_bundle,
    validate_distribution_bundle,
)
from .compatibility import (  # noqa: E402
    CompatibilitySuiteError,
    build_compatibility_suite,
    summarize_compatibility_results,
    validate_compatibility_suite,
)
from .approval import (  # noqa: E402
    APPROVAL_CONFIRMATION,
    ApprovalWorkflowError,
    apply_approved_plan,
    classify_plan,
    create_approval,
    install_copilot_workflow,
    validate_approval,
)

from .integration import (  # noqa: E402
    IntegratedProjectError,
    diagnose_integrated_project,
    setup_integrated_project,
    validate_integrated_project,
)

from .workflow import (  # noqa: E402
    WORKFLOW_CONFIRMATION,
    WorkflowError,
    advance_workflow_state,
    apply_ready_workflow,
    create_ready_approval,
    initialize_workflow_state,
    record_workflow_gate,
    schedule_workflow,
    validate_ready_approval,
)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="fortran-modernize",
        description=(
            "Connect fortran-refactor-tool v0.50.0 to fortran-python-migrator "
            "as an integrated VS Code/Copilot or CLI-only project with dependency-aware human approval, native Cython, numerical, determinism, performance, kernel-selection, and runtime fallback gates."
        ),
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    setup = subparsers.add_parser(
        "setup-project",
        help="initialize an all-in-one Fortran Modernizer VS Code/CLI project",
    )
    setup.add_argument("target_repository", nargs="?", default=".")
    setup.add_argument("--source", help="optional legacy Fortran file or directory copied into legacy-original")
    setup.add_argument("-I", "--include-dir", action="append", default=[])
    setup.add_argument("--legacy-compiler", help="legacy compiler name, for example Absoft")
    setup.add_argument("--build-command", help="review candidate only; not executed by setup-project")
    setup.add_argument("--run-command", help="review candidate only; not executed by setup-project")
    setup.add_argument("--mode", choices=("auto", "copilot", "cli-only"), default="auto")
    setup.add_argument("--overwrite", action="store_true")

    doctor = subparsers.add_parser(
        "doctor",
        help="diagnose the integrated project, dependencies, Copilot files, and CLI fallback",
    )
    doctor.add_argument("--project-root", default=".")
    doctor.add_argument("--output")

    integrated_validate = subparsers.add_parser(
        "validate-integrated-project",
        help="validate the static all-in-one project layout",
    )
    integrated_validate.add_argument("project_root", nargs="?", default=".")

    export = subparsers.add_parser(
        "export-handoff",
        help="analyze Fortran and generate a canonical schema-1.1 migration handoff",
    )
    _add_source_arguments(export)
    export.add_argument("--output", required=True, help="handoff JSON path")

    prepare = subparsers.add_parser(
        "prepare-migration",
        help="export a handoff and verify it against the Python migrator's Migration IR",
    )
    _add_source_arguments(prepare)
    prepare.add_argument("--procedure", help="root subroutine for dependency-scoped verification")
    prepare.add_argument("--output-directory", required=True)
    prepare.add_argument("--fail-on-blocked", action="store_true")

    migrate = subparsers.add_parser(
        "migrate-procedure",
        help="run the reviewed-Fortran to Python generation pipeline for one procedure closure",
    )
    _add_source_arguments(migrate)
    migrate.add_argument("--procedure", required=True, help="root subroutine to migrate")
    migrate.add_argument("--legacy-source", help="optional original source retained for analysis evidence")
    migrate.add_argument(
        "--legacy-include-dir",
        action="append",
        default=[],
        help="INCLUDE directory used only for the original legacy source",
    )
    migrate.add_argument("--output-directory", required=True)
    migrate.add_argument(
        "--cython",
        action="append",
        choices=("safe", "optimized"),
        default=[],
        help="generate and compile a native Cython extension; repeat for both modes",
    )
    migrate.add_argument(
        "--state-kernel",
        action="append",
        default=[],
        help="extract and compile a stateful numerical procedure as safe/optimized Cython; repeatable",
    )
    migrate.add_argument(
        "--auto-state-kernels",
        action="store_true",
        help="discover and build every safely extractable stateful loop procedure in the selected closure",
    )
    migrate.add_argument(
        "--allow-review-required",
        action="store_true",
        help="continue only after the connection report's review items have been examined",
    )
    migrate.add_argument(
        "--regression-config",
        help="JSON specification for project-specific Fortran-vs-generated-Python regression",
    )
    migrate.add_argument(
        "--no-runtime-package",
        action="store_true",
        help="skip packaging the selected backends into 12_runtime",
    )
    migrate.add_argument(
        "--strict-runtime",
        action="store_true",
        help="fail if the reviewed selected backend cannot be packaged exactly",
    )
    migrate.add_argument("--overwrite", action="store_true")

    regression = subparsers.add_parser(
        "verify-regression",
        help="run numerical, determinism, and optional performance gates across configured backends",
    )
    regression.add_argument("--config", required=True)
    regression.add_argument("--source", required=True, help="reviewed Fortran source or project")
    regression.add_argument("--generated-python", required=True)
    regression.add_argument("--legacy-source")
    regression.add_argument("--output-directory", required=True)
    regression.add_argument(
        "--artifact",
        action="append",
        default=[],
        metavar="NAME=VALUE",
        help="extra command placeholder, for example cython_extension=/path/module.so",
    )
    regression.add_argument("--overwrite", action="store_true")

    selection = subparsers.add_parser(
        "select-kernels",
        help="select deployable Cython backends from an existing regression/performance report",
    )
    selection.add_argument("--regression-report", required=True)
    selection.add_argument("--config", required=True)
    selection.add_argument("--output-directory", required=True)
    selection.add_argument(
        "--artifact", action="append", default=[], metavar="NAME=VALUE",
        help="build-report or generated-artifact mapping referenced by kernel_selection",
    )
    selection.add_argument("--overwrite", action="store_true")


    runtime = subparsers.add_parser(
        "package-runtime",
        help="package selected Python/Cython/Fortran backends into a relocatable runtime",
    )
    runtime.add_argument("migration_directory")
    runtime.add_argument("--output-directory", required=True)
    runtime.add_argument("--strict-selected", action="store_true")
    runtime.add_argument("--exclude-fortran", action="store_true")
    runtime.add_argument("--skip-validation", action="store_true")
    runtime.add_argument("--overwrite", action="store_true")

    runtime_run = subparsers.add_parser(
        "run-runtime",
        help="execute a packaged runtime with evidence-preserving backend fallback",
    )
    runtime_run.add_argument("bundle_directory")
    runtime_run.add_argument("--backend", default="auto")
    runtime_run.add_argument("--case")
    runtime_run.add_argument("--snapshot")
    runtime_run.add_argument("--report")
    runtime_run.add_argument("--strict", action="store_true")
    runtime_run.add_argument(
        "--variable", action="append", default=[], metavar="NAME=VALUE",
        help="override a runtime command placeholder",
    )

    distribution = subparsers.add_parser(
        "package-distribution",
        help="create a source-only Windows/WSL target rebuild kit from a PASS migration",
    )
    distribution.add_argument("migration_directory")
    distribution.add_argument("--output-directory", required=True)
    distribution.add_argument("--target", choices=("linux-wsl", "windows-native"), required=True)
    distribution.add_argument("--app-name", default="fortran-modernized-app")
    distribution.add_argument("--wheelhouse")
    distribution.add_argument("--exclude-fortran", action="store_true")
    distribution.add_argument("--overwrite", action="store_true")

    distribution_validate = subparsers.add_parser(
        "validate-distribution", help="validate a source-only target rebuild kit"
    )
    distribution_validate.add_argument("bundle_directory")

    compatibility = subparsers.add_parser(
        "package-compatibility-ci",
        help="package Linux/WSL and Windows rebuild kits with a GitHub Actions compatibility matrix",
    )
    compatibility.add_argument("--linux-kit", required=True)
    compatibility.add_argument("--windows-kit", required=True)
    compatibility.add_argument("--output-directory", required=True)
    compatibility.add_argument(
        "--python-version", action="append", default=[],
        help="Python MAJOR.MINOR matrix entry; repeatable (default: 3.11, 3.12, 3.13, 3.14)",
    )
    compatibility.add_argument("--overwrite", action="store_true")

    compatibility_validate = subparsers.add_parser(
        "validate-compatibility-ci", help="validate a compatibility CI suite"
    )
    compatibility_validate.add_argument("suite_directory")

    compatibility_summary = subparsers.add_parser(
        "summarize-compatibility",
        help="merge per-cell compatibility evidence into JSON, CSV, and Markdown matrices",
    )
    compatibility_summary.add_argument("--suite-manifest", required=True)
    compatibility_summary.add_argument("--results-directory", required=True)
    compatibility_summary.add_argument("--output-directory", required=True)
    compatibility_summary.add_argument("--overwrite", action="store_true")

    workflow_init = subparsers.add_parser(
        "init-workflow-state",
        help="create a gate and candidate state file bound to a refactoring plan and source tree",
    )
    workflow_init.add_argument("plan_directory")
    workflow_init.add_argument("--output", required=True)
    workflow_init.add_argument("--overwrite", action="store_true")

    workflow_gate = subparsers.add_parser(
        "record-workflow-gate",
        help="record tool or human evidence for a prerequisite workflow gate",
    )
    workflow_gate.add_argument("state_file")
    workflow_gate.add_argument("--gate", required=True)
    workflow_gate.add_argument("--status", required=True, choices=("PASS", "FAILED", "REVIEW_REQUIRED", "NOT_RUN"))
    workflow_gate.add_argument("--actor-kind", required=True, choices=("human", "tool"))
    workflow_gate.add_argument("--recorded-by", required=True)
    workflow_gate.add_argument("--evidence", action="append", default=[])
    workflow_gate.add_argument("--confirm", help=f'exact phrase for human-required PASS gates: {WORKFLOW_CONFIRMATION}')
    workflow_gate.add_argument("--note")
    workflow_gate.add_argument("--output")

    workflow_schedule = subparsers.add_parser(
        "schedule-workflow",
        help="compute dependency-aware READY/WAITING candidates and the next safe action",
    )
    workflow_schedule.add_argument("plan_directory")
    workflow_schedule.add_argument("--state", required=True)
    workflow_schedule.add_argument("--output-directory", required=True)
    workflow_schedule.add_argument("--overwrite", action="store_true")

    approve_ready = subparsers.add_parser(
        "approve-ready",
        help="HUMAN-ONLY: approve only candidates currently marked READY_APPROVAL",
    )
    approve_ready.add_argument("plan_directory")
    approve_ready.add_argument("--workflow", required=True)
    approve_ready.add_argument("--id", action="append", default=[])
    approve_ready.add_argument("--reject-id", action="append", default=[])
    approve_ready.add_argument("--approved-by", required=True)
    approve_ready.add_argument("--confirm", required=True, help=f'exact phrase: {APPROVAL_CONFIRMATION}')
    approve_ready.add_argument("--note")
    approve_ready.add_argument("--output", required=True)

    validate_ready = subparsers.add_parser(
        "validate-ready-approval",
        help="validate a workflow-bound human approval against current READY_APPROVAL candidates",
    )
    validate_ready.add_argument("plan_directory")
    validate_ready.add_argument("--workflow", required=True)
    validate_ready.add_argument("--approval", required=True)

    apply_ready = subparsers.add_parser(
        "apply-ready",
        help="apply only the automatic/approved candidates exposed by the current workflow schedule",
    )
    apply_ready.add_argument("plan_directory")
    apply_ready.add_argument("--workflow", required=True)
    apply_ready.add_argument("--approval")
    apply_ready.add_argument("-I", "--include-dir", action="append", default=[])
    apply_ready.add_argument("--compile-check", action="store_true")
    apply_ready.add_argument("--output-directory", required=True)

    advance_state = subparsers.add_parser(
        "advance-workflow-state",
        help="record a PASS workflow application receipt into the workflow state",
    )
    advance_state.add_argument("state_file")
    advance_state.add_argument("--workflow", required=True)
    advance_state.add_argument("--receipt", required=True)
    advance_state.add_argument("--approval")
    advance_state.add_argument("--output")

    classify = subparsers.add_parser(
        "classify-plan",
        help="classify a refactoring plan into automatic, approval-required, manual, and blocked candidates",
    )
    classify.add_argument("plan_directory")
    classify.add_argument("--output-directory", required=True)
    classify.add_argument("--overwrite", action="store_true")

    approve = subparsers.add_parser(
        "approve-plan",
        help="HUMAN-ONLY: create a hash-bound approval record for reviewed candidate IDs",
    )
    approve.add_argument("plan_directory")
    approve.add_argument("--id", action="append", default=[], help="approval-required candidate ID; repeatable")
    approve.add_argument("--reject-id", action="append", default=[], help="candidate ID explicitly rejected; repeatable")
    approve.add_argument("--approved-by", required=True, help="human reviewer's name or identifier")
    approve.add_argument("--confirm", required=True, help=f'exact confirmation phrase: {APPROVAL_CONFIRMATION}')
    approve.add_argument("--note")
    approve.add_argument("--output", required=True)

    approval_validate = subparsers.add_parser(
        "validate-approval",
        help="validate that an approval still matches its plan, candidates, and source tree",
    )
    approval_validate.add_argument("plan_directory")
    approval_validate.add_argument("approval_file")

    approved_apply = subparsers.add_parser(
        "apply-approved",
        help="apply automatic candidates and/or exactly the candidates authorized by approval.json",
    )
    approved_apply.add_argument("plan_directory")
    approved_apply.add_argument("--approval", help="human-generated approval.json")
    approved_apply.add_argument("--all-automatic", action="store_true")
    approved_apply.add_argument("-I", "--include-dir", action="append", default=[])
    approved_apply.add_argument("--compile-check", action="store_true")
    approved_apply.add_argument("--output-directory", required=True)

    install_copilot = subparsers.add_parser(
        "install-copilot-workflow",
        help="install the Fortran Modernizer agent, skills, hooks, and concise instructions into a repository",
    )
    install_copilot.add_argument("target_repository")
    install_copilot.add_argument("--overwrite", action="store_true")

    validate = subparsers.add_parser("validate-handoff", help="validate a canonical handoff")
    validate.add_argument("report")
    return parser


def _parse_artifacts(values: list[str]) -> dict[str, str]:
    artifacts: dict[str, str] = {}
    for value in values:
        if "=" not in value:
            raise NumericalRegressionError(
                f"artifact must use NAME=VALUE syntax: {value!r}"
            )
        name, item = value.split("=", 1)
        if not name or not item:
            raise NumericalRegressionError(
                f"artifact must use non-empty NAME=VALUE syntax: {value!r}"
            )
        artifacts[name] = item
    return artifacts


def _add_source_arguments(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("source", help="Fortran source file or project directory")
    parser.add_argument("-I", "--include-dir", action="append", default=[])
    parser.add_argument("--source-root")
    parser.add_argument("--storage-overlay-report", action="append", default=[])
    parser.add_argument("--regression-report", action="append", default=[])


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    if args.command == "setup-project":
        try:
            result = setup_integrated_project(
                args.target_repository,
                source=args.source,
                include_dirs=args.include_dir,
                legacy_compiler=args.legacy_compiler,
                build_command=args.build_command,
                run_command=args.run_command,
                integration_mode=args.mode,
                overwrite=args.overwrite,
            )
        except IntegratedProjectError as exc:
            print(json.dumps({"status": "BLOCKED", "error": str(exc)}, ensure_ascii=False, indent=2), file=sys.stderr)
            return 2
        print(json.dumps({
            "status": result.status,
            "project_root": str(result.project_root),
            "project_config": str(result.project_config),
            "workflow_policy": str(result.policy_config),
            "manifest": str(result.installation_manifest),
            "copied_sources": list(result.copied_sources),
            "warnings": list(result.warnings),
        }, ensure_ascii=False, indent=2))
        return 0 if result.status == "PASS" else 1
    if args.command == "doctor":
        try:
            result = diagnose_integrated_project(args.project_root, output=args.output)
        except IntegratedProjectError as exc:
            print(json.dumps({"status": "BLOCKED", "error": str(exc)}, ensure_ascii=False, indent=2), file=sys.stderr)
            return 2
        print(json.dumps({
            "status": result.status,
            "report": str(result.report),
            "summary": result.summary,
        }, ensure_ascii=False, indent=2))
        return 2 if result.status == "BLOCKED" else (1 if result.status == "REVIEW_REQUIRED" else 0)
    if args.command == "validate-integrated-project":
        errors = validate_integrated_project(args.project_root)
        if errors:
            print(json.dumps({"status": "BLOCKED", "errors": errors}, ensure_ascii=False, indent=2), file=sys.stderr)
            return 2
        print(json.dumps({"status": "PASS", "project_root": str(Path(args.project_root).expanduser().resolve())}, ensure_ascii=False, indent=2))
        return 0
    if args.command == "init-workflow-state":
        try:
            path = initialize_workflow_state(args.plan_directory, output=args.output, overwrite=args.overwrite)
        except (WorkflowError, ApprovalWorkflowError) as exc:
            print(json.dumps({"status": "BLOCKED", "error": str(exc)}, ensure_ascii=False, indent=2), file=sys.stderr)
            return 2
        print(json.dumps({"status": "PASS", "state_file": str(path)}, ensure_ascii=False, indent=2))
        return 0
    if args.command == "record-workflow-gate":
        try:
            path = record_workflow_gate(
                args.state_file, gate_id=args.gate, status=args.status, actor_kind=args.actor_kind,
                recorded_by=args.recorded_by, evidence=args.evidence, output=args.output,
                confirmation=args.confirm, note=args.note,
            )
        except WorkflowError as exc:
            print(json.dumps({"status": "BLOCKED", "error": str(exc)}, ensure_ascii=False, indent=2), file=sys.stderr)
            return 2
        print(json.dumps({"status": "PASS", "state_file": str(path)}, ensure_ascii=False, indent=2))
        return 0
    if args.command == "schedule-workflow":
        try:
            result = schedule_workflow(
                args.plan_directory, state_file=args.state, output_directory=args.output_directory, overwrite=args.overwrite
            )
        except (WorkflowError, ApprovalWorkflowError) as exc:
            print(json.dumps({"status": "BLOCKED", "error": str(exc)}, ensure_ascii=False, indent=2), file=sys.stderr)
            return 2
        print(json.dumps({
            "status": result.status, "workflow": str(result.workflow), "summary_csv": str(result.summary_csv),
            "next_action": str(result.next_action), "ready_automatic_ids": list(result.ready_automatic_ids),
            "ready_approval_ids": list(result.ready_approval_ids),
        }, ensure_ascii=False, indent=2))
        return 0 if result.status in {"PASS", "READY", "REVIEW_REQUIRED", "WAITING"} else 2
    if args.command == "approve-ready":
        try:
            path = create_ready_approval(
                args.plan_directory, workflow_file=args.workflow, approved_ids=args.id, rejected_ids=args.reject_id,
                approved_by=args.approved_by, output=args.output, confirmation=args.confirm, note=args.note,
            )
        except (WorkflowError, ApprovalWorkflowError) as exc:
            print(json.dumps({"status": "BLOCKED", "error": str(exc)}, ensure_ascii=False, indent=2), file=sys.stderr)
            return 2
        print(json.dumps({"status": "APPROVED", "approval": str(path)}, ensure_ascii=False, indent=2))
        return 0
    if args.command == "validate-ready-approval":
        errors = validate_ready_approval(args.plan_directory, args.workflow, args.approval)
        if errors:
            print(json.dumps({"status": "BLOCKED", "errors": errors}, ensure_ascii=False, indent=2), file=sys.stderr)
            return 2
        print(json.dumps({"status": "PASS", "workflow": str(Path(args.workflow).resolve()), "approval": str(Path(args.approval).resolve())}, ensure_ascii=False, indent=2))
        return 0
    if args.command == "apply-ready":
        try:
            result = apply_ready_workflow(
                args.plan_directory, workflow_file=args.workflow, output_directory=args.output_directory,
                approval_file=args.approval, include_dirs=args.include_dir, compile_check=args.compile_check,
            )
        except (WorkflowError, ApprovalWorkflowError) as exc:
            print(json.dumps({"status": "BLOCKED", "error": str(exc)}, ensure_ascii=False, indent=2), file=sys.stderr)
            return 2
        print(json.dumps({"status": result.status, "receipt": str(result.receipt), "applied_ids": list(result.applied_ids), "transformed_root": str(result.transformed_root)}, ensure_ascii=False, indent=2))
        return 0
    if args.command == "advance-workflow-state":
        try:
            path = advance_workflow_state(
                args.state_file, workflow_file=args.workflow, receipt_file=args.receipt,
                approval_file=args.approval, output=args.output,
            )
        except WorkflowError as exc:
            print(json.dumps({"status": "BLOCKED", "error": str(exc)}, ensure_ascii=False, indent=2), file=sys.stderr)
            return 2
        print(json.dumps({"status": "PASS", "state_file": str(path)}, ensure_ascii=False, indent=2))
        return 0
    if args.command == "classify-plan":
        try:
            result = classify_plan(
                args.plan_directory,
                output_directory=args.output_directory,
                overwrite=args.overwrite,
            )
        except ApprovalWorkflowError as exc:
            print(json.dumps({"status": "BLOCKED", "error": str(exc)}, ensure_ascii=False, indent=2), file=sys.stderr)
            return 2
        print(json.dumps({
            "status": result.status,
            "output_directory": str(result.output_directory),
            "catalog": str(result.catalog),
            "review_queue": str(result.review_queue),
            "summary_csv": str(result.summary_csv),
            "approval_template": str(result.approval_template),
            "counts": result.counts,
        }, ensure_ascii=False, indent=2))
        return 0
    if args.command == "approve-plan":
        try:
            result = create_approval(
                args.plan_directory,
                approved_ids=args.id,
                rejected_ids=args.reject_id,
                approved_by=args.approved_by,
                output=args.output,
                confirmation=args.confirm,
                note=args.note,
            )
        except ApprovalWorkflowError as exc:
            print(json.dumps({"status": "BLOCKED", "error": str(exc)}, ensure_ascii=False, indent=2), file=sys.stderr)
            return 2
        print(json.dumps({
            "status": result.status,
            "approval": str(result.approval),
            "approved_ids": list(result.approved_ids),
            "rejected_ids": list(result.rejected_ids),
        }, ensure_ascii=False, indent=2))
        return 0
    if args.command == "validate-approval":
        errors = validate_approval(args.plan_directory, args.approval_file)
        if errors:
            print(json.dumps({"status": "BLOCKED", "errors": errors}, ensure_ascii=False, indent=2), file=sys.stderr)
            return 2
        print(json.dumps({
            "status": "PASS",
            "plan_directory": str(Path(args.plan_directory).expanduser().resolve()),
            "approval_file": str(Path(args.approval_file).expanduser().resolve()),
        }, ensure_ascii=False, indent=2))
        return 0
    if args.command == "apply-approved":
        try:
            result = apply_approved_plan(
                args.plan_directory,
                output_directory=args.output_directory,
                approval_file=args.approval,
                all_automatic=args.all_automatic,
                include_dirs=args.include_dir,
                compile_check=args.compile_check,
            )
        except ApprovalWorkflowError as exc:
            print(json.dumps({"status": "BLOCKED", "error": str(exc)}, ensure_ascii=False, indent=2), file=sys.stderr)
            return 2
        print(json.dumps({
            "status": result.status,
            "output_directory": str(result.output_directory),
            "receipt": str(result.receipt),
            "applied_ids": list(result.applied_ids),
            "transformed_root": str(result.transformed_root),
        }, ensure_ascii=False, indent=2))
        return 0
    if args.command == "install-copilot-workflow":
        try:
            result = install_copilot_workflow(
                args.target_repository,
                overwrite=args.overwrite,
            )
        except ApprovalWorkflowError as exc:
            print(json.dumps({"status": "BLOCKED", "error": str(exc)}, ensure_ascii=False, indent=2), file=sys.stderr)
            return 2
        print(json.dumps({
            "status": result["status"],
            "manifest": str(result["manifest"]),
            "copied": result["copied"],
            "skipped": result["skipped"],
        }, ensure_ascii=False, indent=2))
        return 0
    if args.command == "package-compatibility-ci":
        try:
            result = build_compatibility_suite(
                linux_kit=args.linux_kit,
                windows_kit=args.windows_kit,
                output_directory=args.output_directory,
                python_versions=args.python_version or ("3.11", "3.12", "3.13", "3.14"),
                overwrite=args.overwrite,
            )
        except CompatibilitySuiteError as exc:
            payload = {"status": "BLOCKED", "error": str(exc)}
            if exc.manifest is not None:
                payload["manifest"] = str(exc.manifest)
            print(json.dumps(payload, ensure_ascii=False, indent=2), file=sys.stderr)
            return 2
        print(json.dumps({
            "status": result.status,
            "output_directory": str(result.output_directory),
            "manifest": str(result.manifest),
            "workflow": str(result.workflow),
            "validation_report": str(result.validation_report),
            "initial_summary": str(result.summary),
        }, ensure_ascii=False, indent=2))
        return 0
    if args.command == "validate-compatibility-ci":
        errors = validate_compatibility_suite(args.suite_directory)
        if errors:
            print(json.dumps({"status": "BLOCKED", "errors": errors}, ensure_ascii=False, indent=2), file=sys.stderr)
            return 2
        print(json.dumps({"status": "PASS", "suite_directory": str(Path(args.suite_directory).expanduser().resolve())}, ensure_ascii=False, indent=2))
        return 0
    if args.command == "summarize-compatibility":
        try:
            result = summarize_compatibility_results(
                suite_manifest=args.suite_manifest,
                results_directory=args.results_directory,
                output_directory=args.output_directory,
                overwrite=args.overwrite,
            )
        except CompatibilitySuiteError as exc:
            print(json.dumps({"status": "BLOCKED", "error": str(exc)}, ensure_ascii=False, indent=2), file=sys.stderr)
            return 2
        print(json.dumps({
            "status": result.status,
            "report": str(result.report),
            "csv": str(result.csv),
            "markdown": str(result.markdown),
        }, ensure_ascii=False, indent=2))
        return 0 if result.status == "PASS" else 1
    if args.command == "package-distribution":
        try:
            result = build_distribution_bundle(
                args.migration_directory,
                output_directory=args.output_directory,
                target=args.target,
                app_name=args.app_name,
                wheelhouse=args.wheelhouse,
                include_fortran=not args.exclude_fortran,
                overwrite=args.overwrite,
            )
        except DistributionBundleError as exc:
            payload = {"status": "BLOCKED", "error": str(exc)}
            if exc.manifest is not None:
                payload["manifest"] = str(exc.manifest)
            print(json.dumps(payload, ensure_ascii=False, indent=2), file=sys.stderr)
            return 2
        print(json.dumps({
            "status": result.status,
            "output_directory": str(result.output_directory),
            "manifest": str(result.manifest),
            "environment_probe": str(result.environment_probe),
            "build_script": str(result.build_script),
            "validation_report": str(result.validation_report),
        }, ensure_ascii=False, indent=2))
        return 0
    if args.command == "validate-distribution":
        errors = validate_distribution_bundle(args.bundle_directory)
        if errors:
            print(json.dumps({"status": "BLOCKED", "errors": errors}, ensure_ascii=False, indent=2), file=sys.stderr)
            return 2
        print(json.dumps({"status": "PASS", "bundle_directory": str(Path(args.bundle_directory).expanduser().resolve())}, ensure_ascii=False, indent=2))
        return 0
    if args.command == "package-runtime":
        try:
            result = build_runtime_bundle(
                args.migration_directory,
                output_directory=args.output_directory,
                overwrite=args.overwrite,
                strict_selected=args.strict_selected,
                include_fortran=not args.exclude_fortran,
                validate=not args.skip_validation,
            )
        except RuntimeBundleError as exc:
            payload = {"status": "BLOCKED", "error": str(exc)}
            if exc.report is not None:
                payload["report"] = str(exc.report)
            print(json.dumps(payload, ensure_ascii=False, indent=2), file=sys.stderr)
            return 2
        print(json.dumps({
            "status": result.status,
            "output_directory": str(result.output_directory),
            "manifest": str(result.manifest),
            "config": str(result.config),
            "launcher": str(result.launcher),
            "health_report": str(result.health_report),
            "selected_backends": result.selected_backends,
        }, ensure_ascii=False, indent=2))
        return 0
    if args.command == "run-runtime":
        try:
            result = run_runtime_bundle(
                args.bundle_directory,
                backend=args.backend,
                case=args.case,
                snapshot=args.snapshot,
                report=args.report,
                strict=args.strict,
                extra_variables=_parse_artifacts(args.variable),
            )
        except (RuntimeBundleError, NumericalRegressionError) as exc:
            payload = {"status": "BLOCKED", "error": str(exc)}
            if isinstance(exc, RuntimeBundleError) and exc.report is not None:
                payload["report"] = str(exc.report)
            print(json.dumps(payload, ensure_ascii=False, indent=2), file=sys.stderr)
            return 2
        print(json.dumps({
            "status": result.status,
            "backend": result.backend,
            "snapshot": str(result.snapshot) if result.snapshot else None,
            "report": str(result.report),
            "attempts": list(result.attempts),
        }, ensure_ascii=False, indent=2))
        return 0
    if args.command == "validate-handoff":
        errors = validate_refactor_report(args.report)
        if errors:
            print("Invalid handoff:", file=sys.stderr)
            print("\n".join(errors), file=sys.stderr)
            return 2
        print(f"Valid handoff: {Path(args.report).expanduser().resolve()}")
        return 0
    if args.command == "export-handoff":
        try:
            target = _export(args, Path(args.output))
        except (PythonHandoffError, ValueError, OSError) as exc:
            print(str(exc), file=sys.stderr)
            return 2
        print(f"Handoff: {target}")
        return 0
    if args.command == "migrate-procedure":
        try:
            result = run_procedure_migration(
                args.source,
                procedure=args.procedure,
                output_directory=args.output_directory,
                include_dirs=args.include_dir,
                source_root=args.source_root,
                storage_overlay_reports=args.storage_overlay_report,
                regression_reports=args.regression_report,
                legacy_source=args.legacy_source,
                legacy_include_dirs=args.legacy_include_dir,
                cython_modes=args.cython,
                allow_review_required=args.allow_review_required,
                overwrite=args.overwrite,
                regression_config=args.regression_config,
                state_kernels=args.state_kernel,
                auto_state_kernels=args.auto_state_kernels,
                package_runtime=not args.no_runtime_package,
                strict_runtime=args.strict_runtime,
            )
        except ProcedureMigrationError as exc:
            payload = {"status": "BLOCKED", "error": str(exc)}
            if exc.manifest is not None:
                payload["manifest"] = str(exc.manifest)
            print(json.dumps(payload, ensure_ascii=False, indent=2), file=sys.stderr)
            return 2
        print(json.dumps({
            "status": result.status,
            "manifest": str(result.manifest),
            "output_directory": str(result.output_directory),
            "artifacts": result.artifacts,
        }, ensure_ascii=False, indent=2))
        return 0 if result.status == "PASS" else 1
    if args.command == "select-kernels":
        try:
            result = run_kernel_selection(
                args.regression_report,
                args.config,
                artifacts=_parse_artifacts(args.artifact),
                output_directory=args.output_directory,
                overwrite=args.overwrite,
            )
        except KernelSelectionError as exc:
            print(json.dumps({"status": "BLOCKED", "error": str(exc)}, ensure_ascii=False, indent=2), file=sys.stderr)
            return 2
        print(json.dumps({
            "status": result.status,
            "report": str(result.report),
            "summary_csv": str(result.summary_csv),
            "deployment_plan": str(result.deployment_plan),
            "selected": result.selected,
        }, ensure_ascii=False, indent=2))
        return 0
    if args.command == "verify-regression":
        try:
            result = run_numerical_regression(
                args.config,
                source=args.source,
                legacy_source=args.legacy_source,
                generated_python=args.generated_python,
                output_directory=args.output_directory,
                artifacts=_parse_artifacts(args.artifact),
                overwrite=args.overwrite,
            )
        except NumericalRegressionError as exc:
            payload = {"status": "BLOCKED", "error": str(exc)}
            if exc.report is not None:
                payload["report"] = str(exc.report)
            print(json.dumps(payload, ensure_ascii=False, indent=2), file=sys.stderr)
            return 2
        print(json.dumps({
            "status": result.status,
            "report": str(result.report),
            "summary_csv": str(result.summary_csv),
            "config_copy": str(result.config_copy),
            "cases": result.cases,
            "comparisons": result.comparisons,
            "performance_csv": str(result.performance_csv) if result.performance_csv else None,
        }, ensure_ascii=False, indent=2))
        return 0
    if args.command == "prepare-migration":
        output = Path(args.output_directory).expanduser().resolve()
        output.mkdir(parents=True, exist_ok=True)
        handoff = output / "refactor_handoff.json"
        connection = output / "refactor_connection.json"
        try:
            _export(args, handoff)
            validation = validate_refactor_report(handoff)
            if validation:
                raise RefactorBridgeError("handoff validation failed:\n" + "\n".join(validation))
            verify_refactor_connection(
                args.source,
                handoff,
                connection,
                procedure=args.procedure,
            )
        except (PythonHandoffError, RefactorBridgeError, ValueError, OSError) as exc:
            print(str(exc), file=sys.stderr)
            return 2
        payload = json.loads(connection.read_text(encoding="utf-8"))
        print(json.dumps({
            "handoff": str(handoff),
            "connection": str(connection),
            "status": payload["status"],
            "coverage": payload["coverage"],
        }, ensure_ascii=False, indent=2))
        return 2 if args.fail_on_blocked and payload["status"] == "BLOCKED" else 0
    return 1


def _export(args: argparse.Namespace, output: Path) -> Path:
    files = discover_fortran_files([args.source])
    if not files:
        raise ValueError(f"no Fortran source files found under {args.source}")
    include_dirs = [Path(item).expanduser().resolve() for item in args.include_dir]
    units = []
    for path in files:
        for unit in split_program_units(path, include_dirs):
            units.append(analyze_unit(unit, include_dirs))
    result = build_analysis_result(units)
    source_path = Path(args.source).expanduser().resolve()
    source_root = (
        Path(args.source_root).expanduser().resolve()
        if args.source_root
        else (source_path if source_path.is_dir() else source_path.parent)
    )
    return write_python_handoff(
        result,
        output,
        source_root=source_root,
        storage_overlay_reports=[Path(item) for item in args.storage_overlay_report],
        regression_reports=[Path(item) for item in args.regression_report],
    )


if __name__ == "__main__":
    raise SystemExit(main())
