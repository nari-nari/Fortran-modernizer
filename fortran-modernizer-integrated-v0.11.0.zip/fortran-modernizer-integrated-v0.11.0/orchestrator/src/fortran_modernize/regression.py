from __future__ import annotations

import csv
import hashlib
import json
import math
import os
import re
import shlex
import shutil
import subprocess
import statistics
import sys
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence

import numpy as np

from fpy_migrate.e2e_acceptance import Snapshot, compare_snapshots


class NumericalRegressionError(RuntimeError):
    """Raised when a numerical regression specification or backend run is invalid."""

    def __init__(self, message: str, *, report: Path | None = None):
        super().__init__(message)
        self.report = report


@dataclass(frozen=True)
class NumericalRegressionResult:
    status: str
    report: Path
    summary_csv: Path
    config_copy: Path
    output_directory: Path
    cases: int
    comparisons: int
    performance_csv: Path | None = None


@dataclass(frozen=True)
class _CommandResult:
    command: tuple[str, ...]
    cwd: str
    returncode: int
    elapsed_seconds: float
    stdout: str
    stderr: str

    def to_dict(self) -> dict[str, Any]:
        return {
            "command": list(self.command),
            "command_display": shlex.join(self.command),
            "cwd": self.cwd,
            "returncode": self.returncode,
            "elapsed_seconds": self.elapsed_seconds,
        }


def run_numerical_regression(
    config: str | Path,
    *,
    source: str | Path,
    generated_python: str | Path,
    output_directory: str | Path,
    legacy_source: str | Path | None = None,
    artifacts: Mapping[str, str | Path] | None = None,
    overwrite: bool = False,
) -> NumericalRegressionResult:
    """Run declarative Fortran-vs-generated-backend numerical regression cases.

    Backend commands are defined by a JSON configuration. Each backend must
    produce a standard snapshot either through key/value stdout or a JSON file.
    The function records commands, stdout, stderr, timings, determinism checks,
    and baseline comparisons without modifying any input source.
    """

    config_path = Path(config).expanduser().resolve()
    if not config_path.is_file():
        raise NumericalRegressionError(f"regression config does not exist: {config_path}")
    source_path = Path(source).expanduser().resolve()
    generated_path = Path(generated_python).expanduser().resolve()
    legacy_path = Path(legacy_source).expanduser().resolve() if legacy_source else None
    if not source_path.exists():
        raise NumericalRegressionError(f"reviewed Fortran source does not exist: {source_path}")
    if not generated_path.is_file():
        raise NumericalRegressionError(f"generated Python source does not exist: {generated_path}")
    if legacy_path is not None and not legacy_path.exists():
        raise NumericalRegressionError(f"legacy source does not exist: {legacy_path}")

    output = Path(output_directory).expanduser().resolve()
    if output.exists() and any(output.iterdir()):
        if not overwrite:
            raise NumericalRegressionError(
                f"regression output directory is not empty: {output}; pass overwrite=True"
            )
        shutil.rmtree(output)
    output.mkdir(parents=True, exist_ok=True)
    report_path = output / "regression_report.json"
    summary_path = output / "regression_summary.csv"
    performance_path = output / "performance_summary.csv"
    config_copy = output / "regression_config.json"
    config_bytes = config_path.read_bytes()
    config_copy.write_bytes(config_bytes)

    try:
        payload = json.loads(config_bytes.decode("utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise NumericalRegressionError(f"cannot read regression config: {exc}") from exc
    _validate_config(payload)

    support_dir = output / "support"
    support_records: list[dict[str, str]] = []
    for item in payload.get("support_files", []):
        source_item = Path(str(item)).expanduser()
        if not source_item.is_absolute():
            source_item = (config_path.parent / source_item).resolve()
        if not source_item.is_file():
            raise NumericalRegressionError(
                f"regression support file does not exist: {source_item}"
            )
        support_dir.mkdir(parents=True, exist_ok=True)
        target_item = support_dir / source_item.name
        shutil.copy2(source_item, target_item)
        support_records.append(
            {
                "source": str(source_item),
                "copy": str(target_item.relative_to(output)),
                "sha256": hashlib.sha256(source_item.read_bytes()).hexdigest(),
            }
        )

    defaults = payload.get("defaults", {})
    default_rtol = _nonnegative_float(defaults.get("rtol", 1.0e-12), "defaults.rtol")
    default_atol = _nonnegative_float(defaults.get("atol", 1.0e-13), "defaults.atol")
    default_timeout = _positive_float(
        defaults.get("timeout_seconds", 120.0), "defaults.timeout_seconds"
    )
    default_repeat = _positive_int(defaults.get("repeat", 1), "defaults.repeat")
    det_defaults = payload.get("determinism", {})
    det_rtol = _nonnegative_float(det_defaults.get("rtol", 0.0), "determinism.rtol")
    det_atol = _nonnegative_float(det_defaults.get("atol", 0.0), "determinism.atol")

    backends: Mapping[str, Mapping[str, Any]] = payload["backends"]
    baseline_name = str(payload.get("baseline", "fortran"))
    if baseline_name not in backends:
        raise NumericalRegressionError(
            f"baseline backend {baseline_name!r} is not present in backends"
        )
    candidate_names = payload.get("candidates")
    if candidate_names is None:
        candidates = tuple(name for name in backends if name != baseline_name)
    else:
        if not isinstance(candidate_names, list) or not all(
            isinstance(item, str) for item in candidate_names
        ):
            raise NumericalRegressionError("candidates must be a list of backend names")
        candidates = tuple(candidate_names)
    if not candidates:
        raise NumericalRegressionError("at least one candidate backend is required")
    missing_candidates = [item for item in candidates if item not in backends]
    if missing_candidates:
        raise NumericalRegressionError(
            "candidate backend(s) missing from backends: " + ", ".join(missing_candidates)
        )

    artifact_context: dict[str, str] = {}
    for name, value in (artifacts or {}).items():
        if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", str(name)):
            raise NumericalRegressionError(
                f"artifact placeholder name must be an identifier: {name!r}"
            )
        artifact_context[str(name)] = (
            str(Path(value).expanduser().resolve())
            if isinstance(value, Path)
            else str(value)
        )

    base_context = {
        "python": sys.executable,
        "source": str(source_path),
        "legacy_source": str(legacy_path) if legacy_path else "",
        "generated_python": str(generated_path),
        "output_dir": str(output),
        "config": str(config_path),
        "config_dir": str(config_path.parent),
        "support_dir": str(support_dir),
        **artifact_context,
    }

    report: dict[str, Any] = {
        "schema_version": "1.0",
        "toolchain_version": "0.11.0",
        "status": "BLOCKED",
        "config": {
            "source": str(config_path),
            "copy": str(config_copy.relative_to(output)),
            "sha256": hashlib.sha256(config_bytes).hexdigest(),
        },
        "description": payload.get("description"),
        "support_files": support_records,
        "inputs": {
            "source": str(source_path),
            "legacy_source": str(legacy_path) if legacy_path else None,
            "generated_python": str(generated_path),
            "artifacts": artifact_context,
        },
        "baseline": baseline_name,
        "candidates": list(candidates),
        "defaults": {
            "rtol": default_rtol,
            "atol": default_atol,
            "timeout_seconds": default_timeout,
            "repeat": default_repeat,
            "determinism_rtol": det_rtol,
            "determinism_atol": det_atol,
        },
        "builds": {},
        "cases": [],
        "summary": {},
        "performance": None,
    }

    comparison_rows: list[dict[str, Any]] = []
    total_comparisons = 0
    failed_comparisons = 0
    failed_determinism = 0
    performance_rows: list[dict[str, Any]] = []
    performance_comparisons = 0
    failed_performance_gates = 0

    try:
        # Build each backend once. A backend without build commands is treated as prebuilt.
        for backend_name, backend in backends.items():
            backend_dir = output / "backends" / backend_name
            backend_dir.mkdir(parents=True, exist_ok=True)
            build_context = dict(base_context)
            build_context.update(
                {
                    "backend": backend_name,
                    "backend_dir": str(backend_dir),
                    "executable": str(
                        backend_dir / str(backend.get("executable_name", backend_name))
                    ),
                }
            )
            build_records: list[dict[str, Any]] = []
            for index, command_spec in enumerate(_normalise_build_commands(backend.get("build"))):
                command_dir = backend_dir / "build" / f"command_{index + 1:02d}"
                command_dir.mkdir(parents=True, exist_ok=True)
                result = _run_command(
                    command_spec,
                    context=build_context,
                    default_cwd=config_path.parent,
                    default_timeout=default_timeout,
                )
                _write_command_artifacts(command_dir, result)
                record = result.to_dict()
                record["artifacts"] = {
                    "stdout": str((command_dir / "stdout.txt").relative_to(output)),
                    "stderr": str((command_dir / "stderr.txt").relative_to(output)),
                    "command": str((command_dir / "command.json").relative_to(output)),
                }
                build_records.append(record)
                if result.returncode != 0:
                    raise NumericalRegressionError(
                        f"build command failed for backend {backend_name}: "
                        f"{shlex.join(result.command)}"
                    )
            report["builds"][backend_name] = {
                "status": "PASS",
                "commands": build_records,
            }

        for case_payload in payload["cases"]:
            case_name = str(case_payload["name"])
            case_dir = output / "cases" / _safe_name(case_name)
            case_dir.mkdir(parents=True, exist_ok=True)
            variables = case_payload.get("variables", {})
            if not isinstance(variables, dict):
                raise NumericalRegressionError(
                    f"case {case_name!r}: variables must be an object"
                )
            rtol = _nonnegative_float(case_payload.get("rtol", default_rtol), f"{case_name}.rtol")
            atol = _nonnegative_float(case_payload.get("atol", default_atol), f"{case_name}.atol")
            repeat = _positive_int(case_payload.get("repeat", default_repeat), f"{case_name}.repeat")
            timeout = _positive_float(
                case_payload.get("timeout_seconds", default_timeout),
                f"{case_name}.timeout_seconds",
            )
            case_record: dict[str, Any] = {
                "name": case_name,
                "rtol": rtol,
                "atol": atol,
                "repeat": repeat,
                "variables": variables,
                "backends": {},
                "comparisons": {},
                "passed": True,
            }
            snapshots: dict[str, list[Snapshot]] = {}

            for backend_name, backend in backends.items():
                backend_dir = output / "backends" / backend_name
                executable = backend_dir / str(
                    backend.get("executable_name", backend_name)
                )
                backend_case_dir = case_dir / backend_name
                backend_case_dir.mkdir(parents=True, exist_ok=True)
                backend_runs: list[dict[str, Any]] = []
                snapshots[backend_name] = []
                run_spec = backend.get("run")
                if run_spec is None:
                    raise NumericalRegressionError(
                        f"backend {backend_name!r} is missing run command"
                    )
                snapshot_spec = backend.get("snapshot")
                if not isinstance(snapshot_spec, dict):
                    raise NumericalRegressionError(
                        f"backend {backend_name!r} is missing snapshot object"
                    )

                for repeat_index in range(repeat):
                    run_dir = backend_case_dir / f"run_{repeat_index + 1:02d}"
                    run_dir.mkdir(parents=True, exist_ok=True)
                    snapshot_path = run_dir / "snapshot.json"
                    context = dict(base_context)
                    context.update(
                        {
                            "backend": backend_name,
                            "backend_dir": str(backend_dir),
                            "executable": str(executable),
                            "case_name": case_name,
                            "case_dir": str(case_dir),
                            "run_dir": str(run_dir),
                            "snapshot": str(snapshot_path),
                            "repeat": str(repeat_index + 1),
                        }
                    )
                    context.update({key: str(value) for key, value in variables.items()})
                    result = _run_command(
                        run_spec,
                        context=context,
                        default_cwd=config_path.parent,
                        default_timeout=timeout,
                    )
                    _write_command_artifacts(run_dir, result)
                    if result.returncode != 0:
                        raise NumericalRegressionError(
                            f"backend {backend_name} failed for case {case_name}: "
                            f"{shlex.join(result.command)}"
                        )
                    snapshot = _read_snapshot(
                        snapshot_spec,
                        stdout=result.stdout,
                        context=context,
                        base_directory=run_dir,
                    )
                    canonical_snapshot = run_dir / "canonical_snapshot.json"
                    _write_canonical_snapshot(snapshot, canonical_snapshot, run_dir)
                    snapshots[backend_name].append(snapshot)
                    run_record = result.to_dict()
                    run_record["artifacts"] = {
                        "stdout": str((run_dir / "stdout.txt").relative_to(output)),
                        "stderr": str((run_dir / "stderr.txt").relative_to(output)),
                        "command": str((run_dir / "command.json").relative_to(output)),
                        "snapshot": str(canonical_snapshot.relative_to(output)),
                    }
                    backend_runs.append(run_record)

                determinism: list[dict[str, Any]] = []
                if len(snapshots[backend_name]) > 1:
                    reference = snapshots[backend_name][0]
                    for repeat_index, current in enumerate(snapshots[backend_name][1:], start=2):
                        comparison = compare_snapshots(
                            reference, current, rtol=det_rtol, atol=det_atol
                        )
                        determinism.append(
                            {
                                "reference_run": 1,
                                "candidate_run": repeat_index,
                                **comparison.to_dict(),
                            }
                        )
                        if not comparison.passed:
                            failed_determinism += 1
                            case_record["passed"] = False
                case_record["backends"][backend_name] = {
                    "status": "PASS" if all(item["returncode"] == 0 for item in backend_runs) else "BLOCKED",
                    "runs": backend_runs,
                    "determinism": determinism,
                    "deterministic": all(item["passed"] for item in determinism),
                }

            baseline_snapshot = snapshots[baseline_name][0]
            for candidate_name in candidates:
                comparison = compare_snapshots(
                    baseline_snapshot,
                    snapshots[candidate_name][0],
                    rtol=rtol,
                    atol=atol,
                )
                total_comparisons += 1
                if not comparison.passed:
                    failed_comparisons += 1
                    case_record["passed"] = False
                case_record["comparisons"][candidate_name] = comparison.to_dict()
                max_scalar_abs = max(
                    (
                        float(item.get("absolute_difference", 0.0))
                        for item in comparison.scalar_differences.values()
                        if isinstance(item.get("absolute_difference", 0.0), (int, float))
                    ),
                    default=0.0,
                )
                max_state_abs = max(
                    (
                        float(item.get("max_absolute_difference", 0.0))
                        for item in comparison.state_differences.values()
                    ),
                    default=0.0,
                )
                comparison_rows.append(
                    {
                        "case": case_name,
                        "baseline": baseline_name,
                        "candidate": candidate_name,
                        "passed": comparison.passed,
                        "finite": comparison.finite,
                        "rtol": rtol,
                        "atol": atol,
                        "max_scalar_absolute_difference": max_scalar_abs,
                        "max_state_absolute_difference": max_state_abs,
                    }
                )
            report["cases"].append(case_record)

        performance_spec = payload.get("performance")
        if isinstance(performance_spec, dict) and performance_spec.get("enabled", True):
            perf_baseline = str(performance_spec.get("baseline", "python"))
            if perf_baseline not in backends:
                raise NumericalRegressionError(
                    f"performance baseline backend {perf_baseline!r} is not present"
                )
            raw_perf_candidates = performance_spec.get("candidates")
            if raw_perf_candidates is None:
                perf_candidates = tuple(name for name in backends if name != perf_baseline)
            elif isinstance(raw_perf_candidates, list) and all(isinstance(item, str) for item in raw_perf_candidates):
                perf_candidates = tuple(raw_perf_candidates)
            else:
                raise NumericalRegressionError("performance.candidates must be a list")
            missing_perf = [name for name in perf_candidates if name not in backends]
            if missing_perf:
                raise NumericalRegressionError(
                    "performance candidate backend(s) missing: " + ", ".join(missing_perf)
                )
            warmup_count = _nonnegative_int(
                performance_spec.get("warmup", 1), "performance.warmup"
            )
            measure_count = _positive_int(
                performance_spec.get("repeat", 5), "performance.repeat"
            )
            thresholds = performance_spec.get("minimum_speedup", {})
            if not isinstance(thresholds, dict):
                raise NumericalRegressionError("performance.minimum_speedup must be an object")
            performance_report: dict[str, Any] = {
                "status": "PASS",
                "mode": "process",
                "warning": "Timings include process startup, driver overhead, and snapshot I/O.",
                "baseline": perf_baseline,
                "candidates": list(perf_candidates),
                "warmup": warmup_count,
                "repeat": measure_count,
                "cases": [],
            }
            for case_payload in payload["cases"]:
                case_name = str(case_payload["name"])
                case_dir = output / "performance" / "cases" / _safe_name(case_name)
                case_dir.mkdir(parents=True, exist_ok=True)
                variables = case_payload.get("variables", {})
                timeout = _positive_float(
                    case_payload.get("timeout_seconds", default_timeout),
                    f"{case_name}.timeout_seconds",
                )
                case_perf: dict[str, Any] = {"name": case_name, "backends": {}, "comparisons": {}}
                timings: dict[str, list[float]] = {}
                for backend_name in (perf_baseline, *perf_candidates):
                    backend = backends[backend_name]
                    command_spec = backend.get("benchmark", backend.get("run"))
                    if command_spec is None:
                        raise NumericalRegressionError(
                            f"backend {backend_name!r} is missing benchmark/run command"
                        )
                    backend_dir = output / "backends" / backend_name
                    executable = backend_dir / str(backend.get("executable_name", backend_name))
                    backend_perf_dir = case_dir / backend_name
                    backend_perf_dir.mkdir(parents=True, exist_ok=True)
                    records: list[dict[str, Any]] = []
                    elapsed_values: list[float] = []
                    total_runs = warmup_count + measure_count
                    for index in range(total_runs):
                        measured = index >= warmup_count
                        phase = "measure" if measured else "warmup"
                        phase_index = index - warmup_count + 1 if measured else index + 1
                        run_dir = backend_perf_dir / f"{phase}_{phase_index:02d}"
                        run_dir.mkdir(parents=True, exist_ok=True)
                        context = dict(base_context)
                        context.update(
                            {
                                "backend": backend_name,
                                "backend_dir": str(backend_dir),
                                "executable": str(executable),
                                "case_name": case_name,
                                "case_dir": str(case_dir),
                                "run_dir": str(run_dir),
                                "snapshot": str(run_dir / "snapshot.json"),
                                "benchmark_dir": str(run_dir),
                                "benchmark_iteration": str(phase_index),
                                "repeat": str(phase_index),
                            }
                        )
                        context.update({key: str(value) for key, value in variables.items()})
                        result = _run_command(
                            command_spec,
                            context=context,
                            default_cwd=config_path.parent,
                            default_timeout=timeout,
                        )
                        _write_command_artifacts(run_dir, result)
                        if result.returncode != 0:
                            raise NumericalRegressionError(
                                f"performance command failed for backend {backend_name}, case {case_name}: "
                                f"{shlex.join(result.command)}"
                            )
                        record = result.to_dict()
                        record["phase"] = phase
                        record["iteration"] = phase_index
                        records.append(record)
                        if measured:
                            elapsed_values.append(result.elapsed_seconds)
                    timings[backend_name] = elapsed_values
                    stats = _timing_statistics(elapsed_values)
                    case_perf["backends"][backend_name] = {
                        "statistics": stats,
                        "runs": records,
                    }
                    performance_rows.append(
                        {
                            "case": case_name,
                            "backend": backend_name,
                            **stats,
                            "speedup_vs_baseline": 1.0 if backend_name == perf_baseline else None,
                            "minimum_speedup": None,
                            "passed": True,
                        }
                    )
                baseline_median = _timing_statistics(timings[perf_baseline])["median_seconds"]
                for candidate in perf_candidates:
                    candidate_median = _timing_statistics(timings[candidate])["median_seconds"]
                    speedup = baseline_median / candidate_median if candidate_median > 0.0 else math.inf
                    threshold = _nonnegative_float(
                        thresholds.get(candidate, 0.0),
                        f"performance.minimum_speedup.{candidate}",
                    )
                    passed = speedup >= threshold
                    performance_comparisons += 1
                    if not passed:
                        failed_performance_gates += 1
                        performance_report["status"] = "BLOCKED"
                    comparison = {
                        "baseline": perf_baseline,
                        "candidate": candidate,
                        "baseline_median_seconds": baseline_median,
                        "candidate_median_seconds": candidate_median,
                        "speedup": speedup,
                        "minimum_speedup": threshold,
                        "passed": passed,
                    }
                    case_perf["comparisons"][candidate] = comparison
                    for row in reversed(performance_rows):
                        if row["case"] == case_name and row["backend"] == candidate:
                            row["speedup_vs_baseline"] = speedup
                            row["minimum_speedup"] = threshold
                            row["passed"] = passed
                            break
                performance_report["cases"].append(case_perf)
            report["performance"] = performance_report

        passed_cases = sum(bool(item["passed"]) for item in report["cases"])
        report["summary"] = {
            "case_count": len(report["cases"]),
            "passed_cases": passed_cases,
            "failed_cases": len(report["cases"]) - passed_cases,
            "comparison_count": total_comparisons,
            "failed_comparisons": failed_comparisons,
            "failed_determinism_checks": failed_determinism,
            "performance_comparison_count": performance_comparisons,
            "failed_performance_gates": failed_performance_gates,
        }
        report["status"] = (
            "PASS"
            if failed_comparisons == 0
            and failed_determinism == 0
            and passed_cases == len(report["cases"])
            and failed_performance_gates == 0
            else "BLOCKED"
        )
        _write_summary_csv(summary_path, comparison_rows)
        if performance_rows:
            _write_performance_csv(performance_path, performance_rows)
        _write_report(report_path, report)
        if report["status"] != "PASS":
            raise NumericalRegressionError(
                "numerical regression did not satisfy all comparison, determinism, and performance gates",
                report=report_path,
            )
        return NumericalRegressionResult(
            status="PASS",
            report=report_path,
            summary_csv=summary_path,
            config_copy=config_copy,
            output_directory=output,
            cases=len(report["cases"]),
            comparisons=total_comparisons,
            performance_csv=performance_path if performance_rows else None,
        )
    except NumericalRegressionError as exc:
        report["status"] = "BLOCKED"
        report["error"] = str(exc)
        report.setdefault("summary", {})
        _write_summary_csv(summary_path, comparison_rows)
        if performance_rows:
            _write_performance_csv(performance_path, performance_rows)
        _write_report(report_path, report)
        raise NumericalRegressionError(str(exc), report=report_path) from exc
    except (OSError, subprocess.SubprocessError, ValueError, TypeError) as exc:
        report["status"] = "BLOCKED"
        report["error"] = str(exc)
        _write_summary_csv(summary_path, comparison_rows)
        if performance_rows:
            _write_performance_csv(performance_path, performance_rows)
        _write_report(report_path, report)
        raise NumericalRegressionError(str(exc), report=report_path) from exc


def _validate_config(payload: Any) -> None:
    if not isinstance(payload, dict):
        raise NumericalRegressionError("regression config root must be an object")
    if str(payload.get("schema_version")) not in {"1.0", "1.1", "1.2"}:
        raise NumericalRegressionError("regression config schema_version must be '1.0', '1.1', or '1.2'")
    backends = payload.get("backends")
    if not isinstance(backends, dict) or len(backends) < 2:
        raise NumericalRegressionError("backends must contain at least two backend objects")
    for name, backend in backends.items():
        if not isinstance(name, str) or not name:
            raise NumericalRegressionError("backend names must be non-empty strings")
        if not isinstance(backend, dict):
            raise NumericalRegressionError(f"backend {name!r} must be an object")
    support_files = payload.get("support_files", [])
    if not isinstance(support_files, list) or not all(
        isinstance(item, str) and item for item in support_files
    ):
        raise NumericalRegressionError("support_files must be a list of paths")
    cases = payload.get("cases")
    if not isinstance(cases, list) or not cases:
        raise NumericalRegressionError("cases must be a non-empty list")
    names: set[str] = set()
    for index, case in enumerate(cases):
        if not isinstance(case, dict):
            raise NumericalRegressionError(f"cases[{index}] must be an object")
        name = case.get("name")
        if not isinstance(name, str) or not name.strip():
            raise NumericalRegressionError(f"cases[{index}].name must be a non-empty string")
        if name in names:
            raise NumericalRegressionError(f"duplicate case name: {name}")
        names.add(name)


def _normalise_build_commands(value: Any) -> tuple[Any, ...]:
    if value is None:
        return ()
    if not isinstance(value, list):
        raise NumericalRegressionError("backend build must be a list of commands")
    if not value:
        return ()
    # A single command can be represented as ["tool", "arg"]. Multiple commands
    # are represented as [["tool", "arg"], ["other"]].
    if all(isinstance(item, (str, int, float)) for item in value):
        return (value,)
    return tuple(value)


def _run_command(
    spec: Any,
    *,
    context: Mapping[str, str],
    default_cwd: Path,
    default_timeout: float,
) -> _CommandResult:
    if isinstance(spec, dict):
        command_value = spec.get("command")
        cwd_value = spec.get("cwd")
        env_value = spec.get("env", {})
        timeout = _positive_float(
            spec.get("timeout_seconds", default_timeout), "command.timeout_seconds"
        )
    else:
        command_value = spec
        cwd_value = None
        env_value = {}
        timeout = default_timeout
    command = _render_command(command_value, context)
    cwd = (
        Path(_render_text(str(cwd_value), context)).expanduser().resolve()
        if cwd_value
        else default_cwd
    )
    if not cwd.exists():
        raise NumericalRegressionError(f"command working directory does not exist: {cwd}")
    if not isinstance(env_value, dict):
        raise NumericalRegressionError("command env must be an object")
    env = os.environ.copy()
    env.update(
        {
            str(key): _render_text(str(value), context)
            for key, value in env_value.items()
        }
    )
    started = time.perf_counter()
    try:
        completed = subprocess.run(
            command,
            cwd=cwd,
            env=env,
            capture_output=True,
            text=True,
            timeout=timeout,
            check=False,
        )
    except subprocess.TimeoutExpired as exc:
        elapsed = time.perf_counter() - started
        stdout = exc.stdout.decode() if isinstance(exc.stdout, bytes) else (exc.stdout or "")
        stderr = exc.stderr.decode() if isinstance(exc.stderr, bytes) else (exc.stderr or "")
        return _CommandResult(
            tuple(command),
            str(cwd),
            124,
            elapsed,
            stdout,
            stderr + f"\nTimed out after {timeout} seconds.\n",
        )
    elapsed = time.perf_counter() - started
    return _CommandResult(
        tuple(command),
        str(cwd),
        completed.returncode,
        elapsed,
        completed.stdout,
        completed.stderr,
    )


def _render_command(value: Any, context: Mapping[str, str]) -> list[str]:
    if isinstance(value, str):
        return shlex.split(_render_text(value, context))
    if not isinstance(value, list) or not value:
        raise NumericalRegressionError("command must be a non-empty string or argument list")
    return [_render_text(str(item), context) for item in value]


def _render_text(value: str, context: Mapping[str, str]) -> str:
    try:
        return value.format_map(dict(context))
    except KeyError as exc:
        raise NumericalRegressionError(
            f"unknown command placeholder {{{exc.args[0]}}}"
        ) from exc


def _write_command_artifacts(directory: Path, result: _CommandResult) -> None:
    (directory / "stdout.txt").write_text(result.stdout, encoding="utf-8")
    (directory / "stderr.txt").write_text(result.stderr, encoding="utf-8")
    (directory / "command.json").write_text(
        json.dumps(result.to_dict(), ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )


def _read_snapshot(
    spec: Mapping[str, Any],
    *,
    stdout: str,
    context: Mapping[str, str],
    base_directory: Path,
) -> Snapshot:
    source = str(spec.get("source", "stdout"))
    format_name = str(spec.get("format", "key_value"))
    if source == "stdout":
        if format_name == "key_value":
            return _parse_key_value_snapshot(stdout, spec)
        if format_name == "json":
            return _snapshot_from_payload(json.loads(stdout), base_directory)
        raise NumericalRegressionError(
            f"unsupported stdout snapshot format: {format_name}"
        )
    if source == "file":
        path_value = spec.get("path", "{snapshot}")
        path = Path(_render_text(str(path_value), context)).expanduser()
        if not path.is_absolute():
            path = (base_directory / path).resolve()
        if not path.is_file():
            raise NumericalRegressionError(f"snapshot file was not created: {path}")
        if format_name == "json":
            return _snapshot_from_payload(
                json.loads(path.read_text(encoding="utf-8")), path.parent
            )
        if format_name == "npz":
            with np.load(path, allow_pickle=False) as values:
                scalars: dict[str, int | float | bool] = {}
                states: dict[str, np.ndarray] = {}
                scalar_names = set(spec.get("scalar_names", []))
                for key in values.files:
                    value = np.asarray(values[key])
                    if key in scalar_names or value.ndim == 0:
                        scalars[key] = _numpy_scalar(value)
                    else:
                        states[key] = value.copy()
                return Snapshot(scalars, states)
        raise NumericalRegressionError(f"unsupported file snapshot format: {format_name}")
    raise NumericalRegressionError(f"unsupported snapshot source: {source}")


def _parse_key_value_snapshot(text: str, spec: Mapping[str, Any]) -> Snapshot:
    delimiter = str(spec.get("delimiter", "="))
    fields = spec.get("fields")
    if not isinstance(fields, dict) or not fields:
        raise NumericalRegressionError(
            "key_value snapshot requires a non-empty fields object"
        )
    raw: dict[str, str] = {}
    for line in text.splitlines():
        if delimiter not in line:
            continue
        key, value = line.split(delimiter, 1)
        raw[key.strip()] = value.strip()
    scalars: dict[str, int | float | bool] = {}
    for output_name, field_spec in fields.items():
        if isinstance(field_spec, str):
            source_name = str(output_name)
            type_name = field_spec
        elif isinstance(field_spec, dict):
            source_name = str(field_spec.get("source", output_name))
            type_name = str(field_spec.get("type", "float"))
        else:
            raise NumericalRegressionError(
                f"invalid key_value field specification for {output_name!r}"
            )
        if source_name not in raw:
            raise NumericalRegressionError(
                f"key_value output is missing field {source_name!r}"
            )
        scalars[str(output_name)] = _parse_scalar(raw[source_name], type_name)
    return Snapshot(scalars, {})


def _parse_scalar(value: str, type_name: str) -> int | float | bool:
    kind = type_name.lower()
    if kind == "int":
        return int(value)
    if kind == "float":
        return float(value.replace("D", "E").replace("d", "e"))
    if kind == "bool":
        lowered = value.strip().lower()
        if lowered in {"true", ".true.", "1", "yes"}:
            return True
        if lowered in {"false", ".false.", "0", "no"}:
            return False
        raise NumericalRegressionError(f"cannot parse boolean scalar: {value!r}")
    raise NumericalRegressionError(f"unsupported scalar type: {type_name}")


def _snapshot_from_payload(payload: Any, base_directory: Path) -> Snapshot:
    if not isinstance(payload, dict):
        raise NumericalRegressionError("snapshot JSON root must be an object")
    scalar_payload = payload.get("scalars", {})
    state_payload = payload.get("arrays", payload.get("states", {}))
    if not isinstance(scalar_payload, dict) or not isinstance(state_payload, dict):
        raise NumericalRegressionError("snapshot scalars and arrays must be objects")
    scalars: dict[str, int | float | bool] = {}
    for name, value in scalar_payload.items():
        if isinstance(value, bool):
            scalars[str(name)] = value
        elif isinstance(value, int):
            scalars[str(name)] = value
        elif isinstance(value, float):
            if not math.isfinite(value):
                scalars[str(name)] = value
            else:
                scalars[str(name)] = value
        else:
            raise NumericalRegressionError(
                f"snapshot scalar {name!r} must be int, float, or bool"
            )
    states = {
        str(name): _load_array(value, base_directory)
        for name, value in state_payload.items()
    }
    return Snapshot(scalars, states)


def _load_array(value: Any, base_directory: Path) -> np.ndarray:
    if isinstance(value, list):
        return np.asarray(value)
    if isinstance(value, str):
        return _load_array_file(base_directory / value, None)
    if isinstance(value, dict):
        if "values" in value:
            return np.asarray(value["values"], dtype=value.get("dtype"))
        path_value = value.get("path")
        if path_value is None:
            raise NumericalRegressionError("array object requires values or path")
        return _load_array_file(
            base_directory / str(path_value),
            str(value["key"]) if "key" in value else None,
        )
    raise NumericalRegressionError("snapshot array must be a list, path, or object")


def _load_array_file(path: Path, key: str | None) -> np.ndarray:
    target = path.expanduser().resolve()
    if not target.is_file():
        raise NumericalRegressionError(f"snapshot array file does not exist: {target}")
    if target.suffix.lower() == ".npy":
        return np.asarray(np.load(target, allow_pickle=False)).copy()
    if target.suffix.lower() == ".npz":
        with np.load(target, allow_pickle=False) as payload:
            selected = key or (payload.files[0] if len(payload.files) == 1 else None)
            if selected is None:
                raise NumericalRegressionError(
                    f"NPZ array file requires key because it contains {len(payload.files)} arrays"
                )
            if selected not in payload.files:
                raise NumericalRegressionError(
                    f"NPZ array key {selected!r} not found in {target}"
                )
            return np.asarray(payload[selected]).copy()
    raise NumericalRegressionError(
        f"unsupported snapshot array file extension: {target.suffix}"
    )


def _write_canonical_snapshot(snapshot: Snapshot, target: Path, run_dir: Path) -> None:
    arrays: dict[str, dict[str, str]] = {}
    arrays_dir = run_dir / "arrays"
    for name, value in snapshot.states.items():
        arrays_dir.mkdir(parents=True, exist_ok=True)
        path = arrays_dir / f"{_safe_name(name)}.npy"
        np.save(path, np.asarray(value), allow_pickle=False)
        arrays[name] = {"path": str(path.relative_to(run_dir))}
    payload = {
        "schema_version": "1.0",
        "scalars": snapshot.scalars,
        "arrays": arrays,
    }
    target.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )


def _numpy_scalar(value: np.ndarray) -> int | float | bool:
    item = value.item()
    if isinstance(item, (np.bool_, bool)):
        return bool(item)
    if isinstance(item, (np.integer, int)):
        return int(item)
    if isinstance(item, (np.floating, float)):
        return float(item)
    raise NumericalRegressionError(f"unsupported NPZ scalar type: {type(item).__name__}")


def _write_summary_csv(path: Path, rows: Iterable[Mapping[str, Any]]) -> None:
    fieldnames = [
        "case",
        "baseline",
        "candidate",
        "passed",
        "finite",
        "rtol",
        "atol",
        "max_scalar_absolute_difference",
        "max_state_absolute_difference",
    ]
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow({key: row.get(key) for key in fieldnames})


def _write_report(path: Path, payload: Mapping[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )


def _safe_name(value: str) -> str:
    rendered = "".join(char if char.isalnum() or char in {"-", "_"} else "_" for char in value)
    return rendered or "item"


def _nonnegative_float(value: Any, name: str) -> float:
    try:
        result = float(value)
    except (TypeError, ValueError) as exc:
        raise NumericalRegressionError(f"{name} must be a number") from exc
    if result < 0.0 or not math.isfinite(result):
        raise NumericalRegressionError(f"{name} must be finite and non-negative")
    return result


def _positive_float(value: Any, name: str) -> float:
    result = _nonnegative_float(value, name)
    if result <= 0.0:
        raise NumericalRegressionError(f"{name} must be greater than zero")
    return result



def _nonnegative_int(value: Any, name: str) -> int:
    try:
        result = int(value)
    except (TypeError, ValueError) as exc:
        raise NumericalRegressionError(f"{name} must be an integer") from exc
    if result < 0:
        raise NumericalRegressionError(f"{name} must be zero or greater")
    return result


def _timing_statistics(values: Sequence[float]) -> dict[str, float | int]:
    if not values:
        raise NumericalRegressionError("at least one measured timing is required")
    return {
        "count": len(values),
        "minimum_seconds": min(values),
        "median_seconds": statistics.median(values),
        "mean_seconds": statistics.fmean(values),
        "maximum_seconds": max(values),
        "stdev_seconds": statistics.stdev(values) if len(values) > 1 else 0.0,
    }


def _write_performance_csv(path: Path, rows: Iterable[Mapping[str, Any]]) -> None:
    fieldnames = [
        "case",
        "backend",
        "count",
        "minimum_seconds",
        "median_seconds",
        "mean_seconds",
        "maximum_seconds",
        "stdev_seconds",
        "speedup_vs_baseline",
        "minimum_speedup",
        "passed",
    ]
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow({key: row.get(key) for key in fieldnames})

def _positive_int(value: Any, name: str) -> int:
    try:
        result = int(value)
    except (TypeError, ValueError) as exc:
        raise NumericalRegressionError(f"{name} must be an integer") from exc
    if result <= 0:
        raise NumericalRegressionError(f"{name} must be greater than zero")
    return result
