from __future__ import annotations

import hashlib
import json
import shutil
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Iterable, Literal

from fortran_refactor.diagnostics import build_analysis_result
from fortran_refactor.extract import analyze_unit
from fortran_refactor.python_handoff import PythonHandoffError, write_python_handoff
from fortran_refactor.reporting import write_reports
from fortran_refactor.source import discover_fortran_files, split_program_units
from fpy_migrate.acceptance import diagnose_project, write_acceptance_report
from fpy_migrate.intake import validate_refactor_report
from fpy_migrate.ir import (
    UnsupportedFortranError,
    build_project_ir,
    validate_migration_ir,
    write_project_ir,
)
from fpy_migrate.refactor_bridge import RefactorBridgeError, verify_refactor_connection
from fpy_migrate.extraction.state_kernels import (
    StateKernelExtractionError,
    analyze_state_kernel,
    build_state_kernel_bundle_from_project,
)
from fpy_migrate.kernels import CythonBuildError, build_cython_extension
from fpy_migrate.translate import (
    generate_cython,
    generate_python,
    write_cython,
    write_python,
)

from .regression import NumericalRegressionError, run_numerical_regression
from .runtime import RuntimeBundleError, build_runtime_bundle
from .selection import (
    KernelSelectionError,
    has_kernel_selection,
    run_kernel_selection,
)

PipelineStatus = Literal["PASS", "REVIEW_REQUIRED", "BLOCKED"]
StageStatus = Literal["PASS", "REVIEW_REQUIRED", "BLOCKED", "SKIPPED"]


class ProcedureMigrationError(RuntimeError):
    """Raised when the staged procedure migration pipeline is blocked."""

    def __init__(self, message: str, *, manifest: Path | None = None):
        super().__init__(message)
        self.manifest = manifest


@dataclass
class PipelineStage:
    name: str
    status: StageStatus
    message: str
    artifacts: dict[str, str] = field(default_factory=dict)
    details: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "status": self.status,
            "message": self.message,
            "artifacts": dict(self.artifacts),
            "details": dict(self.details),
        }


@dataclass
class ProcedureMigrationResult:
    status: PipelineStatus
    manifest: Path
    output_directory: Path
    artifacts: dict[str, str]
    stages: tuple[PipelineStage, ...]


def run_procedure_migration(
    source: str | Path,
    *,
    procedure: str,
    output_directory: str | Path,
    include_dirs: Iterable[str | Path] = (),
    source_root: str | Path | None = None,
    storage_overlay_reports: Iterable[str | Path] = (),
    regression_reports: Iterable[str | Path] = (),
    legacy_source: str | Path | None = None,
    legacy_include_dirs: Iterable[str | Path] = (),
    cython_modes: Iterable[str] = (),
    allow_review_required: bool = False,
    overwrite: bool = False,
    regression_config: str | Path | None = None,
    state_kernels: Iterable[str] = (),
    auto_state_kernels: bool = False,
    package_runtime: bool = True,
    strict_runtime: bool = False,
) -> ProcedureMigrationResult:
    """Run the reviewed-Fortran to Python generation vertical slice.

    The function never edits either source tree. ``source`` must be the reviewed,
    migration-ready Fortran source. ``legacy_source`` is optional and is analyzed
    only to preserve evidence about the pre-refactoring state.
    """

    source_path = Path(source).expanduser().resolve()
    if not source_path.exists():
        raise ProcedureMigrationError(f"source path does not exist: {source_path}")
    legacy_path = Path(legacy_source).expanduser().resolve() if legacy_source else None
    if legacy_path is not None and not legacy_path.exists():
        raise ProcedureMigrationError(f"legacy source path does not exist: {legacy_path}")

    output = Path(output_directory).expanduser().resolve()
    if output.exists() and any(output.iterdir()):
        if not overwrite:
            raise ProcedureMigrationError(
                f"output directory is not empty: {output}; pass overwrite=True to replace it"
            )
        shutil.rmtree(output)
    output.mkdir(parents=True, exist_ok=True)

    include_paths = tuple(Path(item).expanduser().resolve() for item in include_dirs)
    legacy_include_paths = tuple(
        Path(item).expanduser().resolve() for item in legacy_include_dirs
    )
    cython_requested = tuple(dict.fromkeys(item.lower() for item in cython_modes))
    state_kernel_requested = tuple(dict.fromkeys(item.lower() for item in state_kernels))
    resolved_state_kernels = state_kernel_requested
    regression_config_path = (
        Path(regression_config).expanduser().resolve() if regression_config else None
    )
    if regression_config_path is not None and not regression_config_path.is_file():
        raise ProcedureMigrationError(
            f"regression config does not exist: {regression_config_path}"
        )
    configured_kernel_groups: set[str] = set()
    if regression_config_path is not None:
        try:
            regression_payload = json.loads(regression_config_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            raise ProcedureMigrationError(f"cannot read regression config: {exc}") from exc
        selection_payload = regression_payload.get("kernel_selection")
        if isinstance(selection_payload, dict):
            groups_payload = selection_payload.get("groups")
            if isinstance(groups_payload, dict):
                configured_kernel_groups = {str(name).lower() for name in groups_payload}
    invalid_modes = sorted(set(cython_requested) - {"safe", "optimized"})
    if invalid_modes:
        raise ProcedureMigrationError(
            f"unsupported Cython mode(s): {', '.join(invalid_modes)}"
        )

    stages: list[PipelineStage] = []
    artifacts: dict[str, str] = {}
    manifest = output / "migration_manifest.json"
    final_status: PipelineStatus = "PASS"

    def relative(path: Path) -> str:
        try:
            return path.resolve().relative_to(output).as_posix()
        except ValueError:
            return str(path.resolve())

    def add_stage(
        name: str,
        status: StageStatus,
        message: str,
        *,
        stage_artifacts: dict[str, Path] | None = None,
        details: dict[str, Any] | None = None,
    ) -> None:
        rendered = {
            key: relative(path) for key, path in (stage_artifacts or {}).items()
        }
        stages.append(
            PipelineStage(
                name=name,
                status=status,
                message=message,
                artifacts=rendered,
                details=details or {},
            )
        )
        artifacts.update(rendered)

    def write_manifest(status: PipelineStatus, error: str | None = None) -> Path:
        payload: dict[str, Any] = {
            "schema_version": "1.0",
            "toolchain_version": "0.11.0",
            "status": status,
            "procedure": procedure.lower(),
            "inputs": {
                "source": str(source_path),
                "legacy_source": str(legacy_path) if legacy_path else None,
                "include_dirs": [str(item) for item in include_paths],
                "legacy_include_dirs": [str(item) for item in legacy_include_paths],
                "source_root": str(Path(source_root).expanduser().resolve())
                if source_root
                else None,
                "cython_modes": list(cython_requested),
                "state_kernels": list(state_kernel_requested),
                "auto_state_kernels": auto_state_kernels,
                "resolved_state_kernels": list(resolved_state_kernels),
                "regression_config": str(regression_config_path)
                if regression_config_path
                else None,
                "package_runtime": package_runtime,
                "strict_runtime": strict_runtime,
            },
            "artifacts": dict(artifacts),
            "stages": [item.to_dict() for item in stages],
        }
        if error is not None:
            payload["error"] = error
        manifest.write_text(
            json.dumps(payload, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
        return manifest

    try:
        if legacy_path is not None:
            legacy_result = _analyze(legacy_path, legacy_include_paths)
            legacy_reports = output / "01_legacy_analysis"
            write_reports(legacy_result, legacy_reports)
            legacy_errors = sum(
                item.severity == "error" for item in legacy_result.diagnostics
            )
            add_stage(
                "legacy-analysis",
                "REVIEW_REQUIRED" if legacy_errors else "PASS",
                "Analyzed the original source without modifying it.",
                stage_artifacts={"legacy_analysis": legacy_reports},
                details={
                    "program_units": len(legacy_result.units),
                    "parse_success": sum(item.parse.success for item in legacy_result.units),
                    "diagnostic_errors": legacy_errors,
                },
            )

        reviewed_result = _analyze(source_path, include_paths)
        reviewed_reports = output / "02_reviewed_analysis"
        write_reports(reviewed_result, reviewed_reports)
        reviewed_errors = sum(
            item.severity == "error" for item in reviewed_result.diagnostics
        )
        add_stage(
            "reviewed-analysis",
            "BLOCKED" if reviewed_errors else "PASS",
            "Analyzed the reviewed Fortran source that will be consumed by the migrator.",
            stage_artifacts={"reviewed_analysis": reviewed_reports},
            details={
                "program_units": len(reviewed_result.units),
                "parse_success": sum(item.parse.success for item in reviewed_result.units),
                "diagnostic_errors": reviewed_errors,
            },
        )
        if reviewed_errors:
            raise ProcedureMigrationError(
                f"reviewed source contains {reviewed_errors} blocking analysis error(s)"
            )

        handoff_dir = output / "03_handoff"
        handoff = handoff_dir / "refactor_handoff.json"
        root = (
            Path(source_root).expanduser().resolve()
            if source_root
            else (source_path if source_path.is_dir() else source_path.parent)
        )
        write_python_handoff(
            reviewed_result,
            handoff,
            source_root=root,
            storage_overlay_reports=[Path(item) for item in storage_overlay_reports],
            regression_reports=[Path(item) for item in regression_reports],
        )
        validation_errors = validate_refactor_report(handoff)
        add_stage(
            "canonical-handoff",
            "BLOCKED" if validation_errors else "PASS",
            "Generated and schema-validated the canonical refactoring handoff.",
            stage_artifacts={"handoff": handoff},
            details={"validation_errors": validation_errors},
        )
        if validation_errors:
            raise ProcedureMigrationError(
                "canonical handoff validation failed: " + "; ".join(validation_errors)
            )

        connection_dir = output / "04_connection"
        connection = connection_dir / "refactor_connection.json"
        verify_refactor_connection(
            source_path,
            handoff,
            connection,
            procedure=procedure,
        )
        connection_payload = json.loads(connection.read_text(encoding="utf-8"))
        connection_status = str(connection_payload["status"])
        add_stage(
            "connection-gate",
            connection_status,
            "Cross-checked the handoff against the migrator's independently built source model.",
            stage_artifacts={"connection": connection},
            details={
                "coverage": connection_payload.get("coverage", {}),
                "issues": connection_payload.get("issues", []),
            },
        )
        if connection_status == "BLOCKED":
            raise ProcedureMigrationError("refactor-to-migrator connection is BLOCKED")
        if connection_status == "REVIEW_REQUIRED":
            final_status = "REVIEW_REQUIRED"
            if not allow_review_required:
                raise ProcedureMigrationError(
                    "refactor-to-migrator connection requires review; "
                    "pass --allow-review-required only after reviewing the connection report"
                )

        readiness_dir = output / "05_migration_readiness"
        readiness = diagnose_project(
            source_path,
            procedure=procedure,
            refactor_report=handoff,
        )
        readiness_report = write_acceptance_report(
            readiness, readiness_dir / "migration_readiness.json"
        )
        readiness_status = str(readiness.status)
        scoped_ir_status = str(readiness.project_ir_build.get("status", "BLOCKED"))
        root_record = next(
            (item for item in readiness.procedures if item.name == procedure.lower()),
            None,
        )
        if scoped_ir_status != "PASS":
            readiness_stage_status: StageStatus = "BLOCKED"
        elif root_record is not None and root_record.status == "REVIEW_REQUIRED":
            readiness_stage_status = "REVIEW_REQUIRED"
        else:
            readiness_stage_status = "PASS"
        add_stage(
            "migration-readiness",
            readiness_stage_status,
            "Inventoried constructs and dependencies for the selected procedure closure. "
            "Unrelated blocked procedures in the same file do not block this scoped migration.",
            stage_artifacts={"migration_readiness": readiness_report},
            details={
                "reported_project_status": readiness_status,
                "scoped_ir_status": scoped_ir_status,
                "root_procedure_status": root_record.status if root_record else None,
                "summary": dict(readiness.summary),
                "migration_order": list(readiness.migration_order),
            },
        )
        if scoped_ir_status != "PASS":
            raise ProcedureMigrationError(
                "the selected procedure closure contains constructs unsupported by the safe Migration IR"
            )

        ir_dir = output / "06_migration_ir"
        project = build_project_ir(
            source_path,
            procedure=procedure,
            refactor_report=handoff,
        )
        ir_path = write_project_ir(project, ir_dir / "migration_ir.json")
        ir_errors = validate_migration_ir(ir_path)
        add_stage(
            "migration-ir",
            "BLOCKED" if ir_errors else "PASS",
            "Built and schema-validated the safe Migration IR.",
            stage_artifacts={"migration_ir": ir_path},
            details={
                "procedures": [item.name for item in project.procedures],
                "state_groups": [item.name for item in project.state_groups],
                "validation_errors": ir_errors,
            },
        )
        if ir_errors:
            raise ProcedureMigrationError(
                "Migration IR validation failed: " + "; ".join(ir_errors)
            )

        candidate_dir = output / "06_kernel_candidates"
        candidate_dir.mkdir(parents=True, exist_ok=True)
        candidate_report_path = candidate_dir / "state_kernel_candidates.json"
        candidate_records: list[dict[str, Any]] = []
        automatic_candidates: list[str] = []
        for candidate_procedure in project.procedures:
            if not candidate_procedure.state_groups:
                continue
            try:
                extraction = analyze_state_kernel(project, candidate_procedure.name)
            except StateKernelExtractionError as exc:
                candidate_records.append({
                    "procedure": candidate_procedure.name,
                    "status": "BLOCKED",
                    "selected_automatically": False,
                    "reason": str(exc),
                })
            else:
                selected_automatically = bool(auto_state_kernels) and (
                    not configured_kernel_groups
                    or candidate_procedure.name in configured_kernel_groups
                )
                if selected_automatically:
                    automatic_candidates.append(candidate_procedure.name)
                candidate_records.append({
                    "procedure": candidate_procedure.name,
                    "kernel_procedure": extraction.kernel_procedure,
                    "status": "AUTO",
                    "selected_automatically": selected_automatically,
                    "loop_count": extraction.loop_count,
                    "binding_count": len(extraction.bindings),
                    "bindings": [item.to_dict() for item in extraction.bindings],
                    "diagnostics": list(extraction.diagnostics),
                })
        resolved_state_kernels = tuple(dict.fromkeys((*state_kernel_requested, *automatic_candidates)))
        candidate_report_path.write_text(
            json.dumps({
                "schema_version": "1.0",
                "toolchain_version": "0.11.0",
                "auto_selection_enabled": auto_state_kernels,
                "explicit_candidates": list(state_kernel_requested),
                "resolved_candidates": list(resolved_state_kernels),
                "candidates": candidate_records,
            }, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
        add_stage(
            "state-kernel-candidate-discovery",
            "PASS",
            "Discovered stateful loop procedures that can be converted to explicit-argument kernels.",
            stage_artifacts={"state_kernel_candidates": candidate_report_path},
            details={
                "automatic": auto_state_kernels,
                "resolved_candidates": list(resolved_state_kernels),
                "candidate_count": len(candidate_records),
                "configured_groups": sorted(configured_kernel_groups),
            },
        )

        python_dir = output / "07_python"
        generated_python = generate_python(project, procedure=procedure)
        python_path = write_python(
            generated_python,
            python_dir / f"{procedure.lower()}_generated.py",
        )
        compile(
            python_path.read_text(encoding="utf-8"),
            str(python_path),
            "exec",
        )
        add_stage(
            "python-generation",
            "PASS",
            "Generated readable Python and verified that it is valid Python syntax.",
            stage_artifacts={"python_source": python_path},
            details={"root_procedure": generated_python.procedure},
        )

        regression_artifacts: dict[str, str | Path] = {
            "generated_python": python_path,
        }

        for mode in cython_requested:
            cython_dir = output / "08_cython" / "full_procedure" / mode
            generated_cython = generate_cython(
                project,
                procedure=procedure,
                safety_mode=mode,
            )
            cython_path = write_cython(
                generated_cython,
                cython_dir / f"{procedure.lower()}_{mode}_cython.py",
            )
            compile(
                cython_path.read_text(encoding="utf-8"),
                str(cython_path),
                "exec",
            )
            module_name = _extension_module_name(procedure, mode)
            built = build_cython_extension(
                cython_path,
                module_name,
                cython_dir / "native_build",
                safety_mode=mode,
            )
            stage_artifacts = {
                f"cython_{mode}_source": cython_path,
                f"cython_{mode}_extension": built.extension,
            }
            if built.report is not None:
                stage_artifacts[f"cython_{mode}_build_report"] = built.report
            add_stage(
                f"cython-{mode}-native-build",
                "PASS",
                f"Generated and compiled the complete stateless procedure closure in {mode} mode.",
                stage_artifacts=stage_artifacts,
                details={
                    "root_procedure": generated_cython.procedure,
                    "module_name": built.module_name,
                    "extension_size_bytes": built.extension.stat().st_size,
                },
            )
            regression_artifacts[f"cython_{mode}_source"] = cython_path
            regression_artifacts[f"cython_{mode}_extension"] = built.extension
            regression_artifacts[f"cython_{mode}_module"] = built.module_name

        for kernel_procedure in resolved_state_kernels:
            kernel_dir = output / "09_state_kernels" / kernel_procedure
            bundle, bundle_manifest = build_state_kernel_bundle_from_project(
                project,
                procedure=kernel_procedure,
                build_directory=kernel_dir,
            )
            prefix = f"state_kernel_{_identifier(kernel_procedure)}"
            stage_artifacts: dict[str, Path] = {
                f"{prefix}_manifest": bundle_manifest,
            }
            for artifact_name, relative_path in bundle.artifacts.items():
                absolute = kernel_dir / relative_path
                stage_artifacts[f"{prefix}_{_identifier(artifact_name)}"] = absolute
                regression_artifacts[f"{prefix}_{_identifier(artifact_name)}"] = absolute
            for backend_name, module_name in bundle.module_names.items():
                regression_artifacts[
                    f"{prefix}_{_identifier(backend_name)}_module"
                ] = module_name
            add_stage(
                f"state-kernel-{kernel_procedure}",
                "PASS",
                "Extracted a state-free numerical kernel and compiled safe and optimized Cython extensions.",
                stage_artifacts=stage_artifacts,
                details={
                    "source_procedure": bundle.source_procedure,
                    "kernel_procedure": bundle.kernel_procedure,
                    "bindings": [item.to_dict() for item in bundle.bindings],
                    "module_names": bundle.module_names,
                },
            )

        selection_result = None
        if regression_config_path is not None:
            regression_dir = output / "10_numerical_regression"
            try:
                regression = run_numerical_regression(
                    regression_config_path,
                    source=source_path,
                    legacy_source=legacy_path,
                    generated_python=python_path,
                    output_directory=regression_dir,
                    artifacts=regression_artifacts,
                    overwrite=True,
                )
            except NumericalRegressionError as exc:
                report = exc.report or regression_dir / "regression_report.json"
                add_stage(
                    "numerical-regression",
                    "BLOCKED",
                    str(exc),
                    stage_artifacts={"numerical_regression": report}
                    if report.exists()
                    else None,
                )
                raise ProcedureMigrationError(str(exc)) from exc
            add_stage(
                "numerical-regression",
                "PASS",
                "Executed the reviewed Fortran and generated Python under the same cases and tolerances.",
                stage_artifacts={
                    "numerical_regression": regression.report,
                    "numerical_regression_summary": regression.summary_csv,
                    "numerical_regression_config": regression.config_copy,
                    **({"performance_summary": regression.performance_csv} if regression.performance_csv else {}),
                },
                details={
                    "cases": regression.cases,
                    "comparisons": regression.comparisons,
                    "performance": regression.performance_csv is not None,
                },
            )
            if has_kernel_selection(regression_config_path):
                selection_dir = output / "11_kernel_selection"
                selection = run_kernel_selection(
                    regression.report,
                    regression_config_path,
                    artifacts=regression_artifacts,
                    output_directory=selection_dir,
                    overwrite=True,
                )
                add_stage(
                    "kernel-selection",
                    "PASS",
                    "Selected Cython backends across representative cases using speed, correctness, build cost, and break-even gates.",
                    stage_artifacts={
                        "kernel_selection": selection.report,
                        "kernel_selection_summary": selection.summary_csv,
                        "selected_backends": selection.deployment_plan,
                    },
                    details={"selected": selection.selected},
                )
                selection_result = selection

        if selection_result is not None and package_runtime:
            # Runtime packaging consumes the machine-readable migration manifest.
            # Write the current PASS state first, then refresh it after adding the
            # runtime stage below.
            write_manifest(final_status)
            runtime_dir = output / "12_runtime"
            runtime = build_runtime_bundle(
                output,
                output_directory=runtime_dir,
                overwrite=True,
                strict_selected=strict_runtime,
                include_fortran=True,
                validate=True,
            )
            add_stage(
                "runtime-packaging",
                "PASS",
                "Packaged the reviewed backend choices with Python/Cython/Fortran fallback and runtime health evidence.",
                stage_artifacts={
                    "runtime_bundle": runtime.output_directory,
                    "runtime_manifest": runtime.manifest,
                    "runtime_config": runtime.config,
                    "runtime_health": runtime.health_report,
                    "runtime_launcher": runtime.launcher,
                },
                details={
                    "selected_backends": runtime.selected_backends,
                    "strict_selected": strict_runtime,
                },
            )

        guide = output / "README.md"
        guide.write_text(
            _render_output_readme(
                procedure=procedure.lower(),
                source=source_path,
                legacy_source=legacy_path,
                python_path=python_path,
                manifest=manifest,
                cython_modes=cython_requested,
                regression_config=regression_config_path,
                state_kernels=resolved_state_kernels,
                kernel_selection_enabled=(
                    regression_config_path is not None
                    and has_kernel_selection(regression_config_path)
                ),
                runtime_packaged=(selection_result is not None and package_runtime),
            ),
            encoding="utf-8",
        )
        artifacts["readme"] = relative(guide)
        write_manifest(final_status)
        if selection_result is not None and package_runtime:
            runtime_manifest_path = output / "12_runtime" / "runtime_manifest.json"
            if runtime_manifest_path.is_file():
                runtime_payload = json.loads(runtime_manifest_path.read_text(encoding="utf-8"))
                runtime_payload["source_manifest_sha256"] = hashlib.sha256(
                    manifest.read_bytes()
                ).hexdigest()
                runtime_manifest_path.write_text(
                    json.dumps(runtime_payload, ensure_ascii=False, indent=2) + "\n",
                    encoding="utf-8",
                )
        return ProcedureMigrationResult(
            status=final_status,
            manifest=manifest,
            output_directory=output,
            artifacts=dict(artifacts),
            stages=tuple(stages),
        )

    except (
        ProcedureMigrationError,
        PythonHandoffError,
        RefactorBridgeError,
        UnsupportedFortranError,
        ValueError,
        OSError,
        NumericalRegressionError,
        CythonBuildError,
        StateKernelExtractionError,
        KernelSelectionError,
        RuntimeBundleError,
    ) as exc:
        if isinstance(exc, CythonBuildError) and exc.report.exists():
            add_stage(
                "cython-native-build",
                "BLOCKED",
                str(exc),
                stage_artifacts={"cython_build_report": exc.report},
            )
        elif not stages or stages[-1].status != "BLOCKED":
            add_stage(
                "pipeline-stop",
                "BLOCKED",
                str(exc),
            )
        write_manifest("BLOCKED", str(exc))
        if isinstance(exc, ProcedureMigrationError):
            raise ProcedureMigrationError(str(exc), manifest=manifest) from exc
        raise ProcedureMigrationError(str(exc), manifest=manifest) from exc


def _analyze(source: Path, include_dirs: tuple[Path, ...]):
    files = discover_fortran_files([source])
    if not files:
        raise ProcedureMigrationError(f"no Fortran source files found under {source}")
    units = []
    for path in files:
        for unit in split_program_units(path, list(include_dirs)):
            units.append(analyze_unit(unit, list(include_dirs)))
    return build_analysis_result(units)


def _identifier(value: str) -> str:
    rendered = "".join(char if char.isalnum() or char == "_" else "_" for char in value.lower())
    if not rendered:
        return "item"
    if rendered[0].isdigit():
        return f"item_{rendered}"
    return rendered


def _extension_module_name(procedure: str, mode: str) -> str:
    return f"fpy_{_identifier(procedure)}_{_identifier(mode)}"


def _render_output_readme(
    *,
    procedure: str,
    source: Path,
    legacy_source: Path | None,
    python_path: Path,
    manifest: Path,
    cython_modes: tuple[str, ...],
    regression_config: Path | None,
    state_kernels: tuple[str, ...],
    kernel_selection_enabled: bool,
    runtime_packaged: bool,
) -> str:
    lines = [
        "# Procedure migration output",
        "",
        f"- Root procedure: `{procedure}`",
        f"- Reviewed Fortran source: `{source}`",
    ]
    if legacy_source is not None:
        lines.append(f"- Original legacy source: `{legacy_source}`")
    lines.extend(
        [
            f"- Generated Python: `{python_path.name}`",
            f"- Pipeline manifest: `{manifest.name}`",
            "",
            "The original and reviewed Fortran sources were not modified. The generated",
            "Python is a reference implementation and must pass project-specific numerical",
            "regression tests before replacing a production Fortran path.",
        ]
    )
    if regression_config is not None:
        lines.extend(
            [
                "",
                f"Numerical regression configuration: `{regression_config}`",
                "The regression report is stored under `10_numerical_regression`.",
            ]
        )
    if state_kernels:
        lines.extend(
            [
                "",
                "Compiled state kernels: " + ", ".join(f"`{item}`" for item in state_kernels),
            ]
        )
    if kernel_selection_enabled:
        lines.extend(
            [
                "",
                "Kernel selection evidence is stored under `11_kernel_selection`.",
                "Use `selected_backends.json` as the reviewed deployment choice; the generated wrapper still defaults to Python.",
            ]
        )
    if runtime_packaged:
        lines.extend(
            [
                "",
                "A relocatable execution bundle is stored under `12_runtime`.",
                "Run `12_runtime/run-runtime --backend auto` to use the reviewed backend with evidence-preserving fallback.",
            ]
        )
    if cython_modes:
        lines.extend(
            [
                "",
                "Generated Cython modes: " + ", ".join(f"`{item}`" for item in cython_modes),
            ]
        )
    return "\n".join(lines) + "\n"
