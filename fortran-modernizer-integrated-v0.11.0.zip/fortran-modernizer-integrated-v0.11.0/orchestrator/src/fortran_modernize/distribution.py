from __future__ import annotations

import hashlib
import json
import os
import shutil
import stat
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable, Literal

DistributionTarget = Literal["linux-wsl", "windows-native"]
DistributionStatus = Literal["PASS", "REVIEW_REQUIRED", "BLOCKED"]

_BINARY_SUFFIXES = {
    ".so", ".pyd", ".dll", ".dylib", ".o", ".obj", ".a", ".lib", ".exe", ".pyc",
}
_IGNORED_DIRS = {"__pycache__", ".pytest_cache", "temp", "build"}


class DistributionBundleError(RuntimeError):
    def __init__(self, message: str, *, manifest: Path | None = None):
        super().__init__(message)
        self.manifest = manifest


@dataclass(frozen=True)
class DistributionBundleResult:
    status: DistributionStatus
    output_directory: Path
    manifest: Path
    environment_probe: Path
    build_script: Path
    validation_report: Path


def build_distribution_bundle(
    migration_directory: str | Path,
    *,
    output_directory: str | Path,
    target: DistributionTarget,
    app_name: str = "fortran-modernized-app",
    overwrite: bool = False,
    wheelhouse: str | Path | None = None,
    include_fortran: bool = True,
) -> DistributionBundleResult:
    """Create a source-only target rebuild kit from a PASS migration.

    Native binaries are deliberately excluded. Cython extensions and the optional
    Fortran fallback are rebuilt on the destination host, then checked against
    canonical snapshots retained from the original numerical regression.
    """

    if target not in {"linux-wsl", "windows-native"}:
        raise DistributionBundleError(f"unsupported distribution target: {target}")
    if not app_name or any(item in app_name for item in "\\/:"):
        raise DistributionBundleError("app_name must be a non-empty file-system-safe name")

    migration = Path(migration_directory).expanduser().resolve()
    migration_manifest_path = migration / "migration_manifest.json"
    if not migration_manifest_path.is_file():
        raise DistributionBundleError(
            f"migration manifest does not exist: {migration_manifest_path}"
        )
    migration_manifest = _load_json(migration_manifest_path)
    if migration_manifest.get("status") != "PASS":
        raise DistributionBundleError("distribution packaging requires a PASS migration")
    artifacts = migration_manifest.get("artifacts")
    if not isinstance(artifacts, dict):
        raise DistributionBundleError("migration manifest has no artifact mapping")

    runtime_root = _artifact_path(migration, artifacts, "runtime_bundle")
    runtime_manifest = runtime_root / "runtime_manifest.json"
    runtime_config = runtime_root / "runtime_config.json"
    if not runtime_manifest.is_file() or not runtime_config.is_file():
        raise DistributionBundleError("migration has no complete v0.6+ runtime bundle")

    output = Path(output_directory).expanduser().resolve()
    if output.exists() and any(output.iterdir()):
        if not overwrite:
            raise DistributionBundleError(
                f"output directory is not empty: {output}; pass overwrite=True"
            )
        shutil.rmtree(output)
    output.mkdir(parents=True, exist_ok=True)

    payload = output / "payload"
    staged_runtime = payload / "runtime"
    staged_sources = payload / "native_sources"
    tools = output / "tools"
    wheelhouse_dir = output / "wheelhouse"
    references = output / "reference_snapshots"
    for path in (staged_runtime, staged_sources, tools, wheelhouse_dir, references):
        path.mkdir(parents=True, exist_ok=True)

    _copy_runtime_source_only(runtime_root, staged_runtime)

    selected_path = _artifact_path(migration, artifacts, "selected_backends")
    selected_payload = _load_json(selected_path)
    selected = selected_payload.get("selected_backends")
    if not isinstance(selected, dict) or not selected:
        raise DistributionBundleError("selected_backends.json contains no choices")

    native_extensions: list[dict[str, Any]] = []
    for group, selected_backend in selected.items():
        identifier = _identifier(str(group))
        source_manifest = _artifact_path(
            migration, artifacts, f"state_kernel_{identifier}_manifest"
        )
        kernel_manifest = _load_json(source_manifest)
        source_root = source_manifest.parent
        target_kernel = staged_runtime / "kernels" / identifier
        target_kernel.mkdir(parents=True, exist_ok=True)
        for mode, artifact_key, module_key in (
            ("safe", "cython_safe_source", "cython-safe"),
            ("optimized", "cython_optimized_source", "cython-optimized"),
        ):
            relative = kernel_manifest.get("artifacts", {}).get(artifact_key)
            module_name = kernel_manifest.get("module_names", {}).get(module_key)
            if not isinstance(relative, str) or not isinstance(module_name, str):
                continue
            source = (source_root / relative).resolve()
            if not source.is_file():
                continue
            destination = staged_sources / identifier / f"{module_name}.py"
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, destination)
            native_extensions.append({
                "group": str(group),
                "identifier": identifier,
                "backend": module_key,
                "mode": mode,
                "module_name": module_name,
                "source": destination.relative_to(output).as_posix(),
                "build_directory": (
                    staged_runtime / "kernels" / identifier /
                    ("cython_safe_build" if mode == "safe" else "cython_optimized_build")
                ).relative_to(output).as_posix(),
                "selected": str(selected_backend) == module_key,
            })

    fortran_spec: dict[str, Any] | None = None
    if include_fortran:
        inputs = migration_manifest.get("inputs", {})
        reviewed_source = inputs.get("source") if isinstance(inputs, dict) else None
        runtime_data = _load_json(runtime_config)
        backend_specs = runtime_data.get("backend_specs", {})
        raw_spec = backend_specs.get("fortran") if isinstance(backend_specs, dict) else None
        if isinstance(reviewed_source, str) and isinstance(raw_spec, dict):
            source_path = Path(reviewed_source).expanduser().resolve()
            copied_sources = _copy_fortran_source(source_path, payload / "fortran_source")
            if copied_sources:
                fortran_spec = {
                    "sources": [path.relative_to(output).as_posix() for path in copied_sources],
                    "build": raw_spec.get("build", []),
                    "executable_name": str(raw_spec.get("executable_name", app_name + "-fortran")),
                    "output": f"payload/runtime/fortran/{raw_spec.get('executable_name', app_name + '-fortran')}",
                }

    regression_report_path = _optional_artifact_path(
        migration, artifacts, "numerical_regression"
    )
    reference_cases: list[dict[str, Any]] = []
    if regression_report_path is not None:
        report = _load_json(regression_report_path)
        for case in report.get("cases", []):
            if not isinstance(case, dict):
                continue
            name = str(case.get("name", "default"))
            backend = case.get("backends", {}).get("fortran", {})
            runs = backend.get("runs", []) if isinstance(backend, dict) else []
            if not isinstance(runs, list) or not runs:
                continue
            artifacts_record = runs[0].get("artifacts", {}) if isinstance(runs[0], dict) else {}
            relative = artifacts_record.get("snapshot") if isinstance(artifacts_record, dict) else None
            if not isinstance(relative, str):
                continue
            source = regression_report_path.parent / relative
            if not source.is_file():
                continue
            destination = references / f"{_identifier(name)}.json"
            shutil.copy2(source, destination)
            reference_cases.append({
                "name": name,
                "snapshot": destination.relative_to(output).as_posix(),
                "rtol": float(case.get("rtol", 1e-12)),
                "atol": float(case.get("atol", 1e-13)),
            })

    if wheelhouse is not None:
        source_wheelhouse = Path(wheelhouse).expanduser().resolve()
        if not source_wheelhouse.is_dir():
            raise DistributionBundleError(f"wheelhouse is not a directory: {source_wheelhouse}")
        for wheel in source_wheelhouse.glob("*.whl"):
            shutil.copy2(wheel, wheelhouse_dir / wheel.name)

    manifest_payload: dict[str, Any] = {
        "schema_version": "1.0",
        "toolchain_version": "0.11.0",
        "status": "PASS",
        "app_name": app_name,
        "target": target,
        "source_migration_manifest_sha256": _sha256(migration_manifest_path),
        "runtime_root": "payload/runtime",
        "runtime_config": "payload/runtime/runtime_config.json",
        "runtime_launcher": "payload/runtime/run-runtime",
        "native_extensions": native_extensions,
        "fortran": fortran_spec,
        "reference_cases": reference_cases,
        "requirements": {
            "python": ">=3.11",
            "runtime": ["numpy"],
            "build": ["numpy", "Cython", "setuptools"],
        },
        "offline": {
            "wheelhouse": "wheelhouse",
            "required_packages": ["numpy", "Cython", "setuptools"],
            "bundled_wheels": sorted(path.name for path in wheelhouse_dir.glob("*.whl")),
        },
        "excluded_binary_suffixes": sorted(_BINARY_SUFFIXES),
    }
    manifest_path = output / "distribution_manifest.json"
    manifest_path.write_text(
        json.dumps(manifest_payload, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )

    (tools / "probe_environment.py").write_text(_environment_probe_source(), encoding="utf-8")
    (tools / "build_backends.py").write_text(_backend_builder_source(), encoding="utf-8")
    (tools / "self_check.py").write_text(_self_check_source(), encoding="utf-8")
    (output / "requirements-build.txt").write_text(
        "numpy\nCython\nsetuptools\n", encoding="utf-8"
    )
    (output / "requirements-runtime.txt").write_text("numpy\n", encoding="utf-8")
    (wheelhouse_dir / "README.md").write_text(
        "# Offline wheelhouse\n\nPlace target-compatible wheels for NumPy, Cython, and setuptools here.\n",
        encoding="utf-8",
    )
    (output / "build_wsl.sh").write_text(_wsl_script(), encoding="utf-8")
    (output / "build_windows.ps1").write_text(_windows_script(), encoding="utf-8")
    (output / "run_windows.bat").write_text(_windows_runner(), encoding="utf-8")
    (output / "README_DISTRIBUTION.md").write_text(
        _distribution_readme(app_name, target), encoding="utf-8"
    )
    for executable in (output / "build_wsl.sh", staged_runtime / "run-runtime"):
        if executable.exists():
            executable.chmod(executable.stat().st_mode | stat.S_IXUSR)

    validation_report = output / "distribution_validation.json"
    errors = validate_distribution_bundle(output)
    validation_payload = {
        "schema_version": "1.0",
        "toolchain_version": "0.11.0",
        "status": "PASS" if not errors else "BLOCKED",
        "errors": errors,
    }
    validation_report.write_text(
        json.dumps(validation_payload, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    if errors:
        raise DistributionBundleError(
            "invalid distribution bundle: " + "; ".join(errors), manifest=manifest_path
        )

    build_script = output / ("build_wsl.sh" if target == "linux-wsl" else "build_windows.ps1")
    return DistributionBundleResult(
        status="PASS",
        output_directory=output,
        manifest=manifest_path,
        environment_probe=tools / "probe_environment.py",
        build_script=build_script,
        validation_report=validation_report,
    )


def validate_distribution_bundle(root: str | Path) -> list[str]:
    base = Path(root).expanduser().resolve()
    manifest_path = base / "distribution_manifest.json"
    if not manifest_path.is_file():
        return ["distribution_manifest.json is missing"]
    try:
        payload = _load_json(manifest_path)
    except Exception as exc:
        return [f"cannot read distribution manifest: {exc}"]
    errors: list[str] = []
    for key in ("runtime_root", "runtime_config", "runtime_launcher"):
        value = payload.get(key)
        if not isinstance(value, str) or not (base / value).is_file() and key != "runtime_root":
            if key == "runtime_root" and isinstance(value, str) and (base / value).is_dir():
                continue
            errors.append(f"missing referenced artifact: {key}={value!r}")
    for item in payload.get("native_extensions", []):
        if not isinstance(item, dict):
            errors.append("invalid native extension record")
            continue
        source = base / str(item.get("source", ""))
        if not source.is_file():
            errors.append(f"missing Cython source: {source}")
    for path in base.rglob("*"):
        if any(part in _IGNORED_DIRS for part in path.parts):
            continue
        if path.is_file() and path.suffix.lower() in _BINARY_SUFFIXES:
            errors.append(f"platform-specific binary leaked into source kit: {path}")
    return errors


def _copy_runtime_source_only(source: Path, destination: Path) -> None:
    def ignore(directory: str, names: list[str]) -> set[str]:
        ignored: set[str] = set()
        for name in names:
            path = Path(directory) / name
            if name in _IGNORED_DIRS:
                ignored.add(name)
            elif path.is_file() and path.suffix.lower() in _BINARY_SUFFIXES:
                ignored.add(name)
            elif name in {
                "auto_runtime_report.json", "fallback_runtime_report.json",
                "fortran_runtime_report.json", "auto_snapshot.json",
                "fallback_snapshot.json", "fortran_snapshot.json",
                "runtime_api_validation.json",
            }:
                ignored.add(name)
        return ignored
    shutil.copytree(source, destination, dirs_exist_ok=True, ignore=ignore)
    fortran_dir = destination / "fortran"
    if fortran_dir.exists():
        for item in list(fortran_dir.iterdir()):
            if item.is_file():
                item.unlink()


def _copy_fortran_source(source: Path, destination: Path) -> list[Path]:
    extensions = {".f", ".for", ".ftn", ".f90", ".f95", ".f03", ".f08", ".inc"}
    output: list[Path] = []
    destination.mkdir(parents=True, exist_ok=True)
    if source.is_file():
        target = destination / source.name
        shutil.copy2(source, target)
        return [target]
    if source.is_dir():
        for item in source.rglob("*"):
            if item.is_file() and item.suffix.lower() in extensions:
                target = destination / item.relative_to(source)
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(item, target)
                output.append(target)
    return sorted(output)


def _artifact_path(root: Path, artifacts: dict[str, Any], key: str) -> Path:
    value = artifacts.get(key)
    if not isinstance(value, str) or not value:
        raise DistributionBundleError(f"migration artifact is missing: {key}")
    path = (root / value).resolve()
    if not path.exists():
        raise DistributionBundleError(f"migration artifact does not exist: {key}={path}")
    return path


def _optional_artifact_path(root: Path, artifacts: dict[str, Any], key: str) -> Path | None:
    value = artifacts.get(key)
    if not isinstance(value, str) or not value:
        return None
    path = (root / value).resolve()
    return path if path.exists() else None


def _load_json(path: Path) -> dict[str, Any]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise DistributionBundleError(f"JSON root must be an object: {path}")
    return payload


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _identifier(value: str) -> str:
    rendered = "".join(c if c.isalnum() or c == "_" else "_" for c in value.lower())
    return ("item_" + rendered) if rendered and rendered[0].isdigit() else (rendered or "item")


def _environment_probe_source() -> str:
    return r'''#!/usr/bin/env python3
from __future__ import annotations
import importlib.metadata as metadata
import json
from pathlib import Path
import platform
import shutil
import sys
import sysconfig

ROOT = Path(__file__).resolve().parents[1]
manifest = json.loads((ROOT / "distribution_manifest.json").read_text(encoding="utf-8"))
checks = []

def add(name, passed, **details):
    checks.append({"name": name, "status": "PASS" if passed else "BLOCKED", **details})

add("python-version", sys.version_info >= (3, 11), version=sys.version)
add("target-platform", (manifest["target"] == "linux-wsl" and sys.platform.startswith("linux")) or (manifest["target"] == "windows-native" and sys.platform == "win32"), platform=sys.platform)
include = Path(sysconfig.get_paths().get("include", ""))
add("python-headers", (include / "Python.h").is_file(), include=str(include))
compiler = shutil.which("cl") if sys.platform == "win32" else (shutil.which("cc") or shutil.which("gcc") or shutil.which("clang"))
add("c-compiler", bool(compiler), executable=compiler)
if manifest.get("fortran"):
    fc = shutil.which("gfortran")
    add("fortran-compiler", bool(fc), executable=fc)
for package in manifest["requirements"]["build"]:
    try:
        version = metadata.version(package)
    except metadata.PackageNotFoundError:
        add("package-" + package, False, package=package)
    else:
        add("package-" + package, True, package=package, version=version)
status = "PASS" if all(item["status"] == "PASS" for item in checks) else "BLOCKED"
payload = {
    "schema_version": "1.0", "toolchain_version": "0.11.0", "status": status,
    "target": manifest["target"], "system": platform.platform(), "machine": platform.machine(),
    "checks": checks,
}
path = ROOT / "environment_report.json"
path.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
print(json.dumps(payload, indent=2))
raise SystemExit(0 if status == "PASS" else 2)
'''


def _backend_builder_source() -> str:
    return r'''#!/usr/bin/env python3
from __future__ import annotations
from Cython.Build import cythonize
from setuptools import Extension, setup
import hashlib
import importlib.machinery
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
manifest_path = ROOT / "distribution_manifest.json"
manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
runtime_root = ROOT / manifest["runtime_root"]
results = []

for item in manifest["native_extensions"]:
    source = ROOT / item["source"]
    build_root = ROOT / item["build_directory"]
    if build_root.exists():
        shutil.rmtree(build_root)
    build_root.mkdir(parents=True)
    copied = build_root / f"{item['module_name']}.py"
    shutil.copy2(source, copied)
    checks = item["mode"] == "safe"
    args = ["/O2"] if os.name == "nt" and item["mode"] == "optimized" else (["-O3"] if item["mode"] == "optimized" else [])
    setup_path = build_root / "setup_generated_kernel.py"
    setup_path.write_text(
        "from Cython.Build import cythonize\nfrom setuptools import Extension, setup\n"
        f"extensions=[Extension({item['module_name']!r}, [{str(copied)!r}], extra_compile_args={args!r})]\n"
        "setup(name='generated-cython-kernel', ext_modules=cythonize(extensions, force=True, compiler_directives={"
        f"'language_level':3,'boundscheck':{checks!r},'wraparound':{checks!r},'initializedcheck':{checks!r},'cdivision':True"
        "}))\n",
        encoding="utf-8",
    )
    lib = build_root / "lib"
    temp = build_root / "temp"
    command = [sys.executable, str(setup_path), "build_ext", "--build-lib", str(lib), "--build-temp", str(temp)]
    started = time.perf_counter()
    completed = subprocess.run(command, cwd=build_root, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    elapsed = time.perf_counter() - started
    (build_root / "build_stdout.txt").write_text(completed.stdout, encoding="utf-8")
    (build_root / "build_stderr.txt").write_text(completed.stderr, encoding="utf-8")
    matches = []
    for suffix in importlib.machinery.EXTENSION_SUFFIXES:
        matches.extend(lib.glob(item["module_name"] + suffix))
    extension = sorted(matches)[0] if matches else None
    status = "PASS" if completed.returncode == 0 and extension else "BLOCKED"
    result = {
        "group": item["group"], "backend": item["backend"], "status": status,
        "command": command, "returncode": completed.returncode, "elapsed_seconds": elapsed,
        "source_sha256": hashlib.sha256(source.read_bytes()).hexdigest(),
        "extension": str(extension.relative_to(ROOT)) if extension else None,
        "extension_sha256": hashlib.sha256(extension.read_bytes()).hexdigest() if extension else None,
    }
    (build_root / "cython_build_report.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    results.append(result)

fortran_result = None
spec = manifest.get("fortran")
if spec:
    executable = ROOT / spec["output"]
    executable.parent.mkdir(parents=True, exist_ok=True)
    source_files = [str(ROOT / value) for value in spec["sources"]]
    commands = spec.get("build", [])
    command_results = []
    for template in commands:
        command = []
        for token in template:
            if token == "{source_files}":
                command.extend(source_files)
            else:
                rendered = str(token).replace("{source}", source_files[0]).replace("{executable}", str(executable))
                command.append(rendered)
        completed = subprocess.run(command, cwd=ROOT, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        command_results.append({"command": command, "returncode": completed.returncode, "stdout": completed.stdout, "stderr": completed.stderr})
        if completed.returncode:
            break
    status = "PASS" if executable.is_file() and all(item["returncode"] == 0 for item in command_results) else "BLOCKED"
    fortran_result = {"status": status, "executable": str(executable.relative_to(ROOT)) if executable.exists() else None, "commands": command_results}

config_path = runtime_root / "runtime_config.json"
config = json.loads(config_path.read_text(encoding="utf-8"))
for item, result in zip(manifest["native_extensions"], results):
    if result["status"] != "PASS":
        continue
    record = config["kernels"][item["group"]]["available_backends"][item["backend"]]
    record["path"] = str(Path(result["extension"]).relative_to(Path(manifest["runtime_root"])))
    record["sha256"] = result["extension_sha256"]
if fortran_result and fortran_result["status"] == "PASS":
    config["fortran"] = {"path": str(Path(fortran_result["executable"]).relative_to(Path(manifest["runtime_root"]))) }
config["toolchain_version"] = "0.11.0"
config_path.write_text(json.dumps(config, indent=2) + "\n", encoding="utf-8")

status = "PASS" if all(item["status"] == "PASS" for item in results) and (not spec or fortran_result["status"] == "PASS") else "BLOCKED"
payload = {"schema_version":"1.0","toolchain_version":"0.11.0","status":status,"native_extensions":results,"fortran":fortran_result}
(ROOT / "native_rebuild_report.json").write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
print(json.dumps(payload, indent=2))
raise SystemExit(0 if status == "PASS" else 2)
'''


def _self_check_source() -> str:
    return r'''#!/usr/bin/env python3
from __future__ import annotations
import json
import math
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
manifest = json.loads((ROOT / "distribution_manifest.json").read_text(encoding="utf-8"))
runtime = ROOT / manifest["runtime_root"]
checks = []

def compare(expected, actual, rtol, atol):
    failures = []
    for key, value in expected.get("scalars", {}).items():
        if key not in actual.get("scalars", {}):
            failures.append(f"missing scalar {key}")
            continue
        got = actual["scalars"][key]
        if isinstance(value, bool) or isinstance(value, str):
            if got != value: failures.append(f"{key}: expected {value!r}, got {got!r}")
        elif isinstance(value, int) and not isinstance(value, bool):
            if int(got) != value: failures.append(f"{key}: expected {value}, got {got}")
        else:
            if not math.isfinite(float(got)) or abs(float(got)-float(value)) > atol + rtol*abs(float(value)):
                failures.append(f"{key}: expected {value}, got {got}")
    return failures

backends = ["python"]
selected = []
config = json.loads((runtime / "runtime_config.json").read_text(encoding="utf-8"))
for item in config.get("application_fallback_order", []):
    if item not in selected: selected.append(item)
for case in manifest.get("reference_cases", []):
    expected = json.loads((ROOT / case["snapshot"]).read_text(encoding="utf-8"))
    for backend in selected:
        report = ROOT / f"self_check_{case['name']}_{backend}.json"
        snapshot = ROOT / f"self_check_{case['name']}_{backend}_snapshot.json"
        command = [sys.executable, str(runtime / "runtime_dispatch.py"), "--backend", backend, "--strict", "--case", case["name"], "--report", str(report), "--snapshot", str(snapshot)]
        completed = subprocess.run(command, cwd=runtime, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        if completed.returncode:
            checks.append({"case":case["name"],"backend":backend,"status":"BLOCKED","error":completed.stderr or completed.stdout})
            continue
        actual = json.loads(snapshot.read_text(encoding="utf-8"))
        failures = compare(expected, actual, float(case["rtol"]), float(case["atol"]))
        checks.append({"case":case["name"],"backend":backend,"status":"PASS" if not failures else "BLOCKED","failures":failures})
status = "PASS" if checks and all(item["status"] == "PASS" for item in checks) else "BLOCKED"
payload = {"schema_version":"1.0","toolchain_version":"0.11.0","status":status,"checks":checks}
(ROOT / "distribution_self_check.json").write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
print(json.dumps(payload, indent=2))
raise SystemExit(0 if status == "PASS" else 2)
'''


def _wsl_script() -> str:
    return r'''#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PYTHON_BIN="${PYTHON_BIN:-python3}"
if [[ ! -d "$ROOT/.venv" ]]; then "$PYTHON_BIN" -m venv "$ROOT/.venv"; fi
PY="$ROOT/.venv/bin/python"
PIP="$ROOT/.venv/bin/pip"
if compgen -G "$ROOT/wheelhouse/*.whl" >/dev/null; then
  "$PIP" install --no-index --find-links "$ROOT/wheelhouse" -r "$ROOT/requirements-build.txt"
else
  "$PIP" install -r "$ROOT/requirements-build.txt"
fi
"$PY" "$ROOT/tools/probe_environment.py"
"$PY" "$ROOT/tools/build_backends.py"
"$PY" "$ROOT/tools/self_check.py"
printf '\nTarget rebuild and self-check passed.\n'
'''


def _windows_script() -> str:
    return r'''$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
if (-not (Test-Path "$Root\.venv")) {
    if ($env:PYTHON_BIN) { & $env:PYTHON_BIN -m venv "$Root\.venv" }
    else { & py -3 -m venv "$Root\.venv" }
}
$Py = "$Root\.venv\Scripts\python.exe"
$Pip = "$Root\.venv\Scripts\pip.exe"
$Wheels = Get-ChildItem "$Root\wheelhouse" -Filter *.whl -ErrorAction SilentlyContinue
if ($Wheels) { & $Pip install --no-index --find-links "$Root\wheelhouse" -r "$Root\requirements-build.txt" }
else { & $Pip install -r "$Root\requirements-build.txt" }
& $Py "$Root\tools\probe_environment.py"
& $Py "$Root\tools\build_backends.py"
& $Py "$Root\tools\self_check.py"
Write-Host "Target rebuild and self-check passed."
'''


def _windows_runner() -> str:
    return r'''@echo off
setlocal
set "ROOT=%~dp0"
if not exist "%ROOT%.venv\Scripts\python.exe" (
  echo Virtual environment not found. Run build_windows.ps1 first.
  exit /b 2
)
"%ROOT%.venv\Scripts\python.exe" "%ROOT%payload\runtime\runtime_dispatch.py" %*
exit /b %ERRORLEVEL%
'''


def _distribution_readme(app_name: str, target: str) -> str:
    return f'''# {app_name} target rebuild kit

Target: `{target}`

This is a source-only package. Linux `.so`, Windows `.pyd`/`.dll`, executables,
and object files from the development machine are intentionally excluded.
Cython and optional Fortran backends are rebuilt on the destination host.

## WSL/Linux

```bash
./build_wsl.sh
```

## Windows native

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\\build_windows.ps1
```

For a fully offline build, place compatible target wheels for NumPy, Cython,
setuptools, and wheel under `wheelhouse/`. Windows Cython compilation requires
Microsoft C/C++ Build Tools or another compiler accepted by the active Python.
The optional Fortran fallback requires `gfortran` on PATH.

The build performs environment probing, native recompilation, and numerical
self-checks against canonical snapshots retained from the original validated
migration. A PASS on one OS/Python ABI does not certify another environment;
each target must create its own reports.
'''
