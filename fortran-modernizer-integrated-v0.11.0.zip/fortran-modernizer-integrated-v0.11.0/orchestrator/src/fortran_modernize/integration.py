from __future__ import annotations

import importlib
import importlib.metadata
import json
import os
import platform
import shutil
import subprocess
import sys
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable


TOOLCHAIN_VERSION = "0.11.0"
FORTRAN_SUFFIXES = {".f", ".for", ".ftn", ".f77", ".f90", ".f95", ".f03", ".f08", ".inc"}


class IntegratedProjectError(RuntimeError):
    pass


@dataclass(frozen=True)
class SetupResult:
    status: str
    project_root: Path
    project_config: Path
    policy_config: Path
    installation_manifest: Path
    copied_sources: tuple[str, ...]
    warnings: tuple[str, ...]


@dataclass(frozen=True)
class DoctorResult:
    status: str
    report: Path
    checks: tuple[dict[str, Any], ...]
    summary: dict[str, int]


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _write_json(path: Path, payload: Any, *, overwrite: bool = True) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists() and not overwrite:
        raise IntegratedProjectError(f"refusing to overwrite existing file: {path}")
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def _write_text(path: Path, text: str, *, overwrite: bool = True) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists() and not overwrite:
        raise IntegratedProjectError(f"refusing to overwrite existing file: {path}")
    path.write_text(text, encoding="utf-8")




def _install_copilot_files(target: Path, *, overwrite: bool) -> dict[str, Any]:
    bundle_root = Path(__file__).resolve().parents[3]
    template = bundle_root / "copilot-template"
    if not template.is_dir():
        raise IntegratedProjectError(f"Copilot workflow template is missing: {template}")
    copied: list[str] = []
    skipped: list[str] = []
    for source in sorted(path for path in template.rglob("*") if path.is_file() and "__pycache__" not in path.parts):
        relative = source.relative_to(template)
        destination = target / relative
        if destination.exists() and not overwrite:
            skipped.append(relative.as_posix())
            continue
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, destination)
        copied.append(relative.as_posix())
    status_file = target / "reports" / "COPILOT_STAGE_STATUS.md"
    if not status_file.exists():
        _write_text(
            status_file,
            "# Copilot stage status\n\n"
            "- Status: NOT_STARTED\n"
            "- Current successful source tree: not set\n"
            "- Current stage: integrated project setup\n"
            "- Pending approval IDs: none\n"
            "- First blocker: none recorded\n"
            "- Next action: run `./fortran-modernize doctor --project-root .`\n",
        )
        copied.append("reports/COPILOT_STAGE_STATUS.md")
    manifest = target / "reports" / "copilot_workflow_installation.json"
    _write_json(manifest, {
        "schema_version": "1.0",
        "toolchain_version": TOOLCHAIN_VERSION,
        "installed_at": _utc_now(),
        "target_repository": str(target),
        "copied": copied,
        "skipped_existing": skipped,
        "hook_preview_warning": "VS Code agent hooks may be unavailable under the installed version or organization policy.",
    })
    return {"status": "PASS", "manifest": manifest, "copied": copied, "skipped": skipped}


def _command_available(command: str) -> tuple[bool, str | None]:
    found = shutil.which(command)
    return (found is not None, found)


def _source_files(root: Path) -> list[Path]:
    return sorted(
        path for path in root.rglob("*")
        if path.is_file() and path.suffix.lower() in FORTRAN_SUFFIXES
    )


def _copy_sources(source: Path, target: Path) -> list[str]:
    copied: list[str] = []
    if source.is_file():
        if source.suffix.lower() not in FORTRAN_SUFFIXES:
            raise IntegratedProjectError(f"source is not a recognized Fortran file: {source}")
        destination = target / source.name
        if destination.exists():
            raise IntegratedProjectError(f"legacy source destination already exists: {destination}")
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, destination)
        return [destination.relative_to(target.parent).as_posix()]
    if not source.is_dir():
        raise IntegratedProjectError(f"source path does not exist: {source}")
    files = _source_files(source)
    if not files:
        raise IntegratedProjectError(f"source directory contains no recognized Fortran files: {source}")
    for item in files:
        relative = item.relative_to(source)
        destination = target / relative
        if destination.exists():
            raise IntegratedProjectError(f"legacy source destination already exists: {destination}")
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(item, destination)
        copied.append(destination.relative_to(target.parent).as_posix())
    return copied


def _default_project_config(
    root: Path,
    *,
    legacy_compiler: str | None,
    include_dirs: Iterable[str],
    build_command: str | None,
    run_command: str | None,
    integration_mode: str,
) -> dict[str, Any]:
    return {
        "schema_version": "1.0",
        "toolchain_version": TOOLCHAIN_VERSION,
        "project_status": "REVIEW_REQUIRED",
        "project_root": ".",
        "paths": {
            "legacy_source_root": "legacy-original",
            "include_directories": list(dict.fromkeys(str(item) for item in include_dirs)),
            "work_root": "work",
            "build_root": "build",
            "reports_root": "reports",
            "approvals_root": "approvals",
        },
        "source": {
            "form": "auto",
            "fixed_form_line_length": None,
            "preprocessor_definitions": [],
            "exclude_globs": ["work/**", "build/**", ".venv/**"],
        },
        "compilers": {
            "legacy": {
                "name": legacy_compiler or "UNKNOWN",
                "available": None,
                "build_command": build_command,
                "run_command": run_command,
                "baseline_status": "NOT_RECORDED",
            },
            "gfortran": {
                "command": "gfortran",
                "portability_status": "NOT_TESTED",
            },
        },
        "regression": {
            "status": "NOT_CONFIGURED",
            "configuration": None,
            "human_review_required": True,
        },
        "copilot": {
            "requested_mode": integration_mode,
            "configuration_installed": True,
            "runtime_activation": "UNKNOWN",
            "hooks": {
                "configured": True,
                "runtime_activation": "UNKNOWN",
                "preview_feature": True,
            },
            "cli_only_fallback": True,
        },
        "created_at": _utc_now(),
        "notes": [
            "Review compiler commands, INCLUDE paths, source form, baseline cases, and tolerances before source-changing work.",
            "Copilot and Hook runtime activation cannot be proven from static files; use doctor and a live VS Code session.",
        ],
    }


def _default_policy() -> dict[str, Any]:
    return {
        "schema_version": "1.0",
        "toolchain_version": TOOLCHAIN_VERSION,
        "policy": {
            "original_source_immutable": True,
            "direct_fortran_edits_prohibited": True,
            "dependency_schedule_required": True,
            "human_approval_required_for_ready_approval": True,
            "source_hash_required": True,
            "plan_hash_required": True,
            "stop_on_validation_failure": True,
            "cli_only_fallback": True,
        },
        "phase_order": [
            "intake",
            "baseline-establishment",
            "compiler-portability",
            "existing-defect-resolution",
            "declaration-stabilization",
            "structural-refactoring",
            "advanced-modernization",
            "python-migration",
        ],
        "human_only_operations": [
            "approve-ready",
            "record-workflow-gate --actor-kind human",
            "regression baseline and tolerance approval",
            "Python migration target approval",
        ],
    }


def _first_readme() -> str:
    return """# Fortran Modernizer integrated project v0.11.0

This directory is both the toolchain and the VS Code workspace.

## First use

1. Put an untouched copy of the legacy Fortran project under `legacy-original/`, or run:

   ```bash
   ./fortran-modernize setup-project . --source /path/to/legacy/project
   ```

2. Run the static environment and integration diagnosis:

   ```bash
   ./fortran-modernize doctor --project-root .
   ```

3. Review `config/project.json`. Do not invent legacy build commands, regression cases, or tolerances.

4. In VS Code, select the `Fortran Modernizer` custom agent and ask it to start read-only intake. If Copilot agents or Hooks are unavailable under the company policy, follow `docs/CLI_ONLY_WORKFLOW.md` with the same deterministic core.

## Safety boundary

- `legacy-original/` is immutable.
- Automatic candidates run only when the current dependency schedule marks them `READY_AUTOMATIC`.
- Human approval may precede automatic work.
- Copilot never creates approval evidence or records a human gate.
- Python migration starts only after the reviewed Fortran gates pass.

Production-code applicability is not yet validated. Begin with read-only analysis and a small pilot procedure.
"""


def _cli_only_readme() -> str:
    return """# CLI-only workflow

The deterministic workflow does not require GitHub Copilot.

1. Generate/read the refactoring plan for the current source tree.
2. Initialize or reuse workflow state.
3. Record only supported gate evidence.
4. Run `schedule-workflow` and follow `NEXT_ACTION.md`.
5. A human runs `approve-ready` for `READY_APPROVAL` candidates.
6. Run `apply-ready`; validate; advance state; reanalyze; reschedule.
7. Start `migrate-procedure` only after the current Fortran and human migration-readiness gates pass.

The same plan hashes, source hashes, approval records, prerequisite gates, compiler checks, and regression evidence apply in Copilot-integrated and CLI-only modes.
"""


def _extensions_json() -> dict[str, Any]:
    return {
        "recommendations": [
            "GitHub.copilot",
            "GitHub.copilot-chat",
            "fortran-lang.linter-gfortran",
        ],
        "unwantedRecommendations": [],
    }


def setup_integrated_project(
    target_repository: str | Path,
    *,
    source: str | Path | None = None,
    include_dirs: Iterable[str] = (),
    legacy_compiler: str | None = None,
    build_command: str | None = None,
    run_command: str | None = None,
    integration_mode: str = "auto",
    overwrite: bool = False,
) -> SetupResult:
    if integration_mode not in {"auto", "copilot", "cli-only"}:
        raise IntegratedProjectError(f"unsupported integration mode: {integration_mode}")
    target = Path(target_repository).expanduser().resolve()
    target.mkdir(parents=True, exist_ok=True)

    installation = _install_copilot_files(target, overwrite=overwrite)

    for relative in ("legacy-original", "work", "build", "reports", "approvals", "config", ".vscode"):
        directory = target / relative
        directory.mkdir(parents=True, exist_ok=True)
        marker = directory / ".gitkeep"
        if relative not in {"reports", "config", ".vscode"} and not marker.exists():
            marker.write_text("", encoding="utf-8")

    copied_sources: list[str] = []
    if source is not None:
        copied_sources = _copy_sources(Path(source).expanduser().resolve(), target / "legacy-original")

    project_config = target / "config" / "project.json"
    policy_config = target / "config" / "workflow-policy.json"
    if not project_config.exists() or overwrite:
        _write_json(
            project_config,
            _default_project_config(
                target,
                legacy_compiler=legacy_compiler,
                include_dirs=include_dirs,
                build_command=build_command,
                run_command=run_command,
                integration_mode=integration_mode,
            ),
            overwrite=True,
        )
    if not policy_config.exists() or overwrite:
        _write_json(policy_config, _default_policy(), overwrite=True)
    readme_first = target / "README_FIRST.md"
    if not readme_first.exists() or overwrite:
        _write_text(readme_first, _first_readme(), overwrite=True)
    cli_doc = target / "docs" / "CLI_ONLY_WORKFLOW.md"
    if not cli_doc.exists() or overwrite:
        _write_text(cli_doc, _cli_only_readme(), overwrite=True)
    extensions = target / ".vscode" / "extensions.json"
    if not extensions.exists() or overwrite:
        _write_json(extensions, _extensions_json(), overwrite=True)

    setup_manifest = target / "reports" / "integrated_project_setup.json"
    warnings: list[str] = []
    if not _source_files(target / "legacy-original"):
        warnings.append("legacy-original contains no Fortran source; add an immutable copy before intake")
    warnings.append("Copilot agent and Hook runtime activation must be checked in a live VS Code session")
    payload = {
        "schema_version": "1.0",
        "toolchain_version": TOOLCHAIN_VERSION,
        "status": "REVIEW_REQUIRED" if warnings else "PASS",
        "created_at": _utc_now(),
        "project_root": str(target),
        "project_config": str(project_config),
        "workflow_policy": str(policy_config),
        "copilot_installation_manifest": str(installation["manifest"]),
        "copied_sources": copied_sources,
        "warnings": warnings,
        "cli_only_fallback": True,
    }
    _write_json(setup_manifest, payload, overwrite=True)
    return SetupResult(
        status=str(payload["status"]),
        project_root=target,
        project_config=project_config,
        policy_config=policy_config,
        installation_manifest=setup_manifest,
        copied_sources=tuple(copied_sources),
        warnings=tuple(warnings),
    )


def _check(identifier: str, status: str, message: str, **details: Any) -> dict[str, Any]:
    return {"id": identifier, "status": status, "message": message, "details": details}


def _module_version(module: str) -> str | None:
    distribution = {"Cython": "Cython"}.get(module, module)
    try:
        return importlib.metadata.version(distribution)
    except importlib.metadata.PackageNotFoundError:
        return None


def _import_check(module: str) -> dict[str, Any]:
    try:
        loaded = importlib.import_module(module)
    except Exception as exc:  # diagnostic boundary
        return _check(f"python-module:{module}", "BLOCKED", f"cannot import {module}: {exc}")
    return _check(
        f"python-module:{module}",
        "PASS",
        f"imported {module}",
        version=_module_version(module),
    )


def _hook_static_check(root: Path) -> dict[str, Any]:
    config = root / ".github" / "hooks" / "fortran-human-approval.json"
    script = root / ".github" / "hooks" / "scripts" / "fortran_policy_hook.py"
    if not config.is_file() or not script.is_file():
        return _check("copilot-hook-static", "REVIEW_REQUIRED", "Copilot Hook files are missing")
    try:
        json.loads(config.read_text(encoding="utf-8"))
        completed = subprocess.run(
            [sys.executable, "-m", "py_compile", str(script)],
            text=True,
            capture_output=True,
            timeout=20,
        )
    except (OSError, json.JSONDecodeError, subprocess.SubprocessError) as exc:
        return _check("copilot-hook-static", "BLOCKED", f"Hook static validation failed: {exc}")
    if completed.returncode != 0:
        return _check("copilot-hook-static", "BLOCKED", "Hook Python script did not compile", stderr=completed.stderr)
    return _check(
        "copilot-hook-static",
        "PASS",
        "Hook files are structurally valid; live VS Code activation remains unverified",
        runtime_activation="UNKNOWN",
    )


def diagnose_integrated_project(
    project_root: str | Path,
    *,
    output: str | Path | None = None,
) -> DoctorResult:
    root = Path(project_root).expanduser().resolve()
    if not root.is_dir():
        raise IntegratedProjectError(f"project root does not exist: {root}")
    checks: list[dict[str, Any]] = []
    version = sys.version_info
    checks.append(_check(
        "python-version",
        "PASS" if version >= (3, 11) else "BLOCKED",
        f"Python {platform.python_version()}",
        executable=sys.executable,
    ))
    for module in ("fparser", "jsonschema", "numpy", "Cython"):
        checks.append(_import_check(module))
    for command, required in (("gfortran", False), ("findent", False), ("git", False), ("code", False)):
        available, path = _command_available(command)
        checks.append(_check(
            f"command:{command}",
            "PASS" if available else ("REVIEW_REQUIRED" if not required else "BLOCKED"),
            f"{command} {'found' if available else 'not found'}",
            path=path,
        ))

    required_files = (
        ".github/copilot-instructions.md",
        ".github/agents/fortran-modernizer.agent.md",
        ".github/hooks/fortran-human-approval.json",
        "config/project.json",
        "config/workflow-policy.json",
        "README_FIRST.md",
    )
    missing = [item for item in required_files if not (root / item).is_file()]
    checks.append(_check(
        "integrated-layout",
        "PASS" if not missing else "BLOCKED",
        "integrated project layout is complete" if not missing else "integrated project files are missing",
        missing=missing,
    ))
    skill_files = sorted((root / ".github" / "skills").glob("*/SKILL.md")) if (root / ".github" / "skills").is_dir() else []
    checks.append(_check(
        "copilot-skills",
        "PASS" if len(skill_files) >= 6 else "REVIEW_REQUIRED",
        f"found {len(skill_files)} Copilot skill definitions",
        files=[path.relative_to(root).as_posix() for path in skill_files],
    ))
    checks.append(_hook_static_check(root))

    legacy = root / "legacy-original"
    source_files = _source_files(legacy) if legacy.is_dir() else []
    checks.append(_check(
        "legacy-source",
        "PASS" if source_files else "REVIEW_REQUIRED",
        f"found {len(source_files)} legacy Fortran/INCLUDE files" if source_files else "no legacy source has been added",
        sample=[path.relative_to(root).as_posix() for path in source_files[:20]],
    ))

    project_config = root / "config" / "project.json"
    if project_config.is_file():
        try:
            config = json.loads(project_config.read_text(encoding="utf-8"))
            unresolved: list[str] = []
            legacy_compiler = config.get("compilers", {}).get("legacy", {})
            if legacy_compiler.get("name") in {None, "", "UNKNOWN"}:
                unresolved.append("legacy compiler name")
            if not legacy_compiler.get("build_command"):
                unresolved.append("legacy build command")
            if config.get("regression", {}).get("status") != "CONFIGURED":
                unresolved.append("regression baseline/cases/tolerances")
            checks.append(_check(
                "project-configuration",
                "PASS" if not unresolved else "REVIEW_REQUIRED",
                "project configuration reviewed" if not unresolved else "project configuration requires human review",
                unresolved=unresolved,
            ))
        except (OSError, json.JSONDecodeError) as exc:
            checks.append(_check("project-configuration", "BLOCKED", f"cannot read project configuration: {exc}"))

    counts = {"PASS": 0, "REVIEW_REQUIRED": 0, "BLOCKED": 0}
    for item in checks:
        status = str(item["status"])
        counts[status] = counts.get(status, 0) + 1
    overall = "BLOCKED" if counts.get("BLOCKED", 0) else ("REVIEW_REQUIRED" if counts.get("REVIEW_REQUIRED", 0) else "PASS")
    destination = Path(output).expanduser().resolve() if output else root / "reports" / "doctor.json"
    payload = {
        "schema_version": "1.0",
        "toolchain_version": TOOLCHAIN_VERSION,
        "status": overall,
        "generated_at": _utc_now(),
        "project_root": str(root),
        "checks": checks,
        "summary": counts,
        "notes": [
            "Static validation cannot prove that VS Code loaded the custom agent or enabled Preview Hooks.",
            "CLI-only mode remains available even when Copilot integration is unavailable.",
        ],
    }
    _write_json(destination, payload, overwrite=True)
    return DoctorResult(status=overall, report=destination, checks=tuple(checks), summary=counts)


def validate_integrated_project(project_root: str | Path) -> list[str]:
    root = Path(project_root).expanduser().resolve()
    errors: list[str] = []
    if not root.is_dir():
        return [f"project root does not exist: {root}"]
    required = [
        "fortran-modernize",
        "orchestrator/src/fortran_modernize/cli.py",
        "packages/fortran-refactor-tool/src",
        "packages/fortran-python-migrator/src",
        ".github/agents/fortran-modernizer.agent.md",
        ".github/copilot-instructions.md",
        ".github/hooks/fortran-human-approval.json",
        "config/project.json",
        "config/workflow-policy.json",
        "docs/CLI_ONLY_WORKFLOW.md",
        "README_FIRST.md",
    ]
    for item in required:
        if not (root / item).exists():
            errors.append(f"missing integrated artifact: {item}")
    skills = list((root / ".github" / "skills").glob("*/SKILL.md")) if (root / ".github" / "skills").is_dir() else []
    if len(skills) < 6:
        errors.append(f"expected at least 6 Copilot skills, found {len(skills)}")
    original = root / "legacy-original"
    if original.exists() and original.is_symlink():
        errors.append("legacy-original must not be a symlink")
    return errors
