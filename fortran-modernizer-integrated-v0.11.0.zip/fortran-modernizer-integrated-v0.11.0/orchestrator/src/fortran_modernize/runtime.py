from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
import stat
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable, Literal

RuntimeStatus = Literal["PASS", "REVIEW_REQUIRED", "BLOCKED"]


class RuntimeBundleError(RuntimeError):
    """Raised when a reviewed migration cannot be packaged or executed safely."""

    def __init__(self, message: str, *, report: Path | None = None):
        super().__init__(message)
        self.report = report


@dataclass(frozen=True)
class RuntimeBundleResult:
    status: RuntimeStatus
    output_directory: Path
    manifest: Path
    config: Path
    launcher: Path
    health_report: Path
    selected_backends: dict[str, str]


@dataclass(frozen=True)
class RuntimeExecutionResult:
    status: RuntimeStatus
    backend: str | None
    snapshot: Path | None
    report: Path
    attempts: tuple[dict[str, Any], ...]


def build_runtime_bundle(
    migration_directory: str | Path,
    *,
    output_directory: str | Path,
    overwrite: bool = False,
    strict_selected: bool = False,
    include_fortran: bool = True,
    validate: bool = True,
) -> RuntimeBundleResult:
    """Package a reviewed migration into a relocatable runtime bundle.

    The bundle retains the generated Python implementation for the mandatory
    fallback path, packages every available state-kernel backend, records the
    reviewed deployment choice, and optionally includes the regression-tested
    Fortran executable.  No source file in the migration directory is modified.
    """

    migration = Path(migration_directory).expanduser().resolve()
    manifest_path = migration / "migration_manifest.json"
    if not manifest_path.is_file():
        raise RuntimeBundleError(f"migration manifest does not exist: {manifest_path}")
    migration_manifest = _load_json(manifest_path)
    if migration_manifest.get("status") != "PASS":
        raise RuntimeBundleError(
            f"runtime packaging requires a PASS migration manifest: {manifest_path}"
        )

    artifacts = migration_manifest.get("artifacts")
    if not isinstance(artifacts, dict):
        raise RuntimeBundleError("migration manifest has no artifact mapping")
    selected_path = _artifact_path(migration, artifacts, "selected_backends")
    selected_payload = _load_json(selected_path)
    selected = selected_payload.get("selected_backends")
    if not isinstance(selected, dict) or not selected:
        raise RuntimeBundleError("selected_backends.json contains no deployment choices")
    selected_backends = {str(key): str(value) for key, value in selected.items()}

    output = Path(output_directory).expanduser().resolve()
    if output.exists() and any(output.iterdir()):
        if not overwrite:
            raise RuntimeBundleError(
                f"output directory is not empty: {output}; pass overwrite=True to replace it"
            )
        shutil.rmtree(output)
    output.mkdir(parents=True, exist_ok=True)

    copied: dict[str, dict[str, Any]] = {}

    def copy_file(source: Path, relative: str, *, executable: bool = False) -> Path:
        if not source.is_file():
            raise RuntimeBundleError(f"runtime artifact does not exist: {source}")
        destination = output / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, destination)
        if executable:
            destination.chmod(destination.stat().st_mode | stat.S_IXUSR)
        copied[relative] = {
            "source": str(source),
            "sha256": _sha256(destination),
            "size_bytes": destination.stat().st_size,
        }
        return destination

    generated_python = _artifact_path(migration, artifacts, "python_source")
    application_path = copy_file(
        generated_python, "application/generated_application.py"
    )

    kernel_records: dict[str, dict[str, Any]] = {}
    for group, chosen_backend in selected_backends.items():
        identifier = _identifier(group)
        kernel_manifest_source = _artifact_path(
            migration, artifacts, f"state_kernel_{identifier}_manifest"
        )
        kernel_manifest = _load_json(kernel_manifest_source)
        kernel_root = kernel_manifest_source.parent
        wrapper_rel = _required_string(
            kernel_manifest.get("artifacts", {}).get("wrapper"),
            f"state-kernel wrapper for {group}",
        )
        wrapper_source = (kernel_root / wrapper_rel).resolve()
        wrapper_target = copy_file(
            wrapper_source, f"kernels/{identifier}/{Path(wrapper_rel).name}"
        )
        copied_manifest = copy_file(
            kernel_manifest_source, f"kernels/{identifier}/state_kernel_manifest.json"
        )

        available: dict[str, dict[str, Any]] = {}
        artifact_names = {
            "python": "python",
            "cython-safe": "cython_safe_extension",
            "cython-optimized": "cython_optimized_extension",
        }
        for backend, artifact_key in artifact_names.items():
            relative_value = kernel_manifest.get("artifacts", {}).get(artifact_key)
            if not isinstance(relative_value, str) or not relative_value:
                continue
            source_path = (kernel_root / relative_value).resolve()
            if not source_path.is_file():
                continue
            if backend == "python":
                target_relative = f"kernels/{identifier}/{Path(relative_value).name}"
            else:
                parent = "cython_safe_build" if backend == "cython-safe" else "cython_optimized_build"
                target_relative = f"kernels/{identifier}/{parent}/lib/{source_path.name}"
            target = copy_file(source_path, target_relative)
            available[backend] = {
                "path": target.relative_to(output).as_posix(),
                "module_name": kernel_manifest.get("module_names", {}).get(backend),
                "sha256": _sha256(target),
            }

        if "python" not in available:
            raise RuntimeBundleError(
                f"state kernel {group!r} has no Python fallback artifact"
            )
        if chosen_backend not in available:
            if strict_selected:
                raise RuntimeBundleError(
                    f"selected backend {chosen_backend!r} for {group!r} is unavailable"
                )
            chosen_backend = "python"
            selected_backends[group] = chosen_backend

        fallback_order = _fallback_order(chosen_backend, available)
        kernel_records[group] = {
            "procedure": _required_string(
                kernel_manifest.get("wrapper_procedure"),
                f"wrapper procedure for {group}",
            ),
            "kernel_procedure": kernel_manifest.get("kernel_procedure"),
            "wrapper": wrapper_target.relative_to(output).as_posix(),
            "manifest": copied_manifest.relative_to(output).as_posix(),
            "selected_backend": chosen_backend,
            "fallback_order": fallback_order,
            "available_backends": available,
        }

    regression_config_source = _optional_artifact_path(
        migration, artifacts, "numerical_regression_config"
    )
    regression_report_source = _optional_artifact_path(
        migration, artifacts, "numerical_regression"
    )
    runtime_backend_specs: dict[str, Any] = {}
    cases: list[dict[str, Any]] = []
    support_records: list[dict[str, Any]] = []
    fortran_record: dict[str, Any] | None = None

    if regression_config_source is not None:
        regression_config = _load_json(regression_config_source)
        backends = regression_config.get("backends")
        if isinstance(backends, dict):
            runtime_backend_specs = json.loads(json.dumps(backends))
        raw_cases = regression_config.get("cases")
        if isinstance(raw_cases, list):
            cases = [item for item in raw_cases if isinstance(item, dict)]
        support_files = regression_config.get("support_files")
        if isinstance(support_files, list):
            config_root = regression_config_source.parent
            for item in support_files:
                if not isinstance(item, str):
                    continue
                candidates = [
                    config_root / item,
                    config_root / "support" / Path(item).name,
                    migration / "10_numerical_regression" / item,
                ]
                source = next((path.resolve() for path in candidates if path.is_file()), None)
                if source is None and regression_report_source is not None:
                    report_payload = _load_json(regression_report_source)
                    for record in report_payload.get("support_files", []):
                        if isinstance(record, dict) and Path(str(record.get("copy", ""))).name == Path(item).name:
                            candidate = migration / "10_numerical_regression" / str(record.get("copy"))
                            if candidate.is_file():
                                source = candidate.resolve()
                                break
                if source is None:
                    raise RuntimeBundleError(f"support file cannot be resolved: {item}")
                target = copy_file(source, f"support/{source.name}")
                support_records.append({
                    "path": target.relative_to(output).as_posix(),
                    "sha256": _sha256(target),
                })

        if include_fortran and isinstance(backends, dict) and "fortran" in backends:
            backend = backends["fortran"]
            executable_name = backend.get("executable_name") if isinstance(backend, dict) else None
            if isinstance(executable_name, str) and executable_name:
                candidates = [
                    migration / "10_numerical_regression" / "backends" / "fortran" / executable_name,
                    migration / "10_numerical_regression" / "backends" / "fortran" / f"{executable_name}.exe",
                ]
                executable_source = next((path for path in candidates if path.is_file()), None)
                if executable_source is not None:
                    executable_target = copy_file(
                        executable_source,
                        f"fortran/{executable_source.name}",
                        executable=True,
                    )
                    fortran_record = {
                        "path": executable_target.relative_to(output).as_posix(),
                        "sha256": _sha256(executable_target),
                    }

    runtime_api = output / "runtime_api.py"
    runtime_api.write_text(_runtime_api_source(), encoding="utf-8")
    copied[runtime_api.relative_to(output).as_posix()] = {
        "source": "generated",
        "sha256": _sha256(runtime_api),
        "size_bytes": runtime_api.stat().st_size,
    }

    dispatcher = output / "runtime_dispatch.py"
    dispatcher.write_text(_runtime_dispatch_source(), encoding="utf-8")
    dispatcher.chmod(dispatcher.stat().st_mode | stat.S_IXUSR)
    copied[dispatcher.relative_to(output).as_posix()] = {
        "source": "generated",
        "sha256": _sha256(dispatcher),
        "size_bytes": dispatcher.stat().st_size,
    }

    launcher = output / "run-runtime"
    launcher.write_text(
        "#!/usr/bin/env bash\n"
        "set -euo pipefail\n"
        "ROOT=\"$(cd \"$(dirname \"${BASH_SOURCE[0]}\")\" && pwd)\"\n"
        "PYTHON_BIN=\"${PYTHON_BIN:-python3}\"\n"
        "exec \"$PYTHON_BIN\" \"$ROOT/runtime_dispatch.py\" \"$@\"\n",
        encoding="utf-8",
    )
    launcher.chmod(launcher.stat().st_mode | stat.S_IXUSR)
    copied[launcher.relative_to(output).as_posix()] = {
        "source": "generated",
        "sha256": _sha256(launcher),
        "size_bytes": launcher.stat().st_size,
    }

    preferred_application_backend = _preferred_application_backend(selected_backends)
    config_path = output / "runtime_config.json"
    config_payload = {
        "schema_version": "1.0",
        "toolchain_version": "0.11.0",
        "root_procedure": migration_manifest.get("procedure"),
        "application": application_path.relative_to(output).as_posix(),
        "runtime_api": runtime_api.relative_to(output).as_posix(),
        "strict_selected": strict_selected,
        "preferred_application_backend": preferred_application_backend,
        "application_fallback_order": _application_fallback_order(
            preferred_application_backend,
            runtime_backend_specs,
            fortran_record is not None,
        ),
        "selected_backends": selected_backends,
        "kernels": kernel_records,
        "backend_specs": runtime_backend_specs,
        "cases": cases,
        "support_files": support_records,
        "fortran": fortran_record,
        "environment": {
            "global_override": "FORTRAN_MODERNIZE_BACKEND",
            "kernel_override_prefix": "FORTRAN_MODERNIZE_KERNEL_",
            "strict": "FORTRAN_MODERNIZE_STRICT",
        },
    }
    config_path.write_text(
        json.dumps(config_payload, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    copied[config_path.relative_to(output).as_posix()] = {
        "source": "generated",
        "sha256": _sha256(config_path),
        "size_bytes": config_path.stat().st_size,
    }

    readme = output / "README.md"
    readme.write_text(
        _runtime_readme(selected_backends, fortran_record is not None),
        encoding="utf-8",
    )
    copied[readme.relative_to(output).as_posix()] = {
        "source": "generated",
        "sha256": _sha256(readme),
        "size_bytes": readme.stat().st_size,
    }

    health_report = output / "runtime_health.json"
    health_payload = _validate_runtime_bundle(output, config_payload) if validate else {
        "status": "SKIPPED",
        "checks": [],
    }
    health_report.write_text(
        json.dumps(health_payload, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    copied[health_report.relative_to(output).as_posix()] = {
        "source": "generated",
        "sha256": _sha256(health_report),
        "size_bytes": health_report.stat().st_size,
    }
    if health_payload.get("status") != "PASS" and strict_selected:
        raise RuntimeBundleError(
            "selected runtime backend failed validation in strict mode",
            report=health_report,
        )

    bundle_manifest = output / "runtime_manifest.json"
    bundle_manifest.write_text(
        json.dumps(
            {
                "schema_version": "1.0",
                "toolchain_version": "0.11.0",
                "status": "PASS" if health_payload.get("status") == "PASS" else "REVIEW_REQUIRED",
                "source_migration": str(migration),
                "source_manifest_sha256": _sha256(manifest_path),
                "selected_backends": selected_backends,
                "runtime_config": config_path.relative_to(output).as_posix(),
                "health_report": health_report.relative_to(output).as_posix(),
                "files": copied,
            },
            ensure_ascii=False,
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )

    return RuntimeBundleResult(
        status="PASS" if health_payload.get("status") == "PASS" else "REVIEW_REQUIRED",
        output_directory=output,
        manifest=bundle_manifest,
        config=config_path,
        launcher=launcher,
        health_report=health_report,
        selected_backends=selected_backends,
    )


def run_runtime_bundle(
    bundle_directory: str | Path,
    *,
    backend: str = "auto",
    case: str | None = None,
    snapshot: str | Path | None = None,
    report: str | Path | None = None,
    strict: bool = False,
    extra_variables: dict[str, str] | None = None,
) -> RuntimeExecutionResult:
    """Execute a packaged backend with evidence-preserving fallback."""

    bundle = Path(bundle_directory).expanduser().resolve()
    config_path = bundle / "runtime_config.json"
    if not config_path.is_file():
        raise RuntimeBundleError(f"runtime config does not exist: {config_path}")
    config = _load_json(config_path)
    target_snapshot = (
        Path(snapshot).expanduser().resolve()
        if snapshot is not None
        else bundle / "last_snapshot.json"
    )
    target_report = (
        Path(report).expanduser().resolve()
        if report is not None
        else bundle / "last_runtime_report.json"
    )
    target_snapshot.parent.mkdir(parents=True, exist_ok=True)
    target_report.parent.mkdir(parents=True, exist_ok=True)

    requested = backend.lower()
    if requested == "auto":
        order = [str(item) for item in config.get("application_fallback_order", [])]
    else:
        order = [requested]
        if not strict:
            for item in config.get("application_fallback_order", []):
                item = str(item)
                if item not in order:
                    order.append(item)

    attempts: list[dict[str, Any]] = []
    selected_backend: str | None = None
    last_error: str | None = None
    for candidate in order:
        try:
            attempt = _execute_runtime_backend(
                bundle,
                config,
                candidate,
                case=case,
                snapshot=target_snapshot,
                extra_variables=extra_variables or {},
            )
        except Exception as exc:  # evidence is more useful than losing the fallback chain
            attempt = {
                "backend": candidate,
                "status": "FAILED",
                "error": str(exc),
            }
        attempts.append(attempt)
        if attempt.get("status") == "PASS":
            selected_backend = candidate
            break
        last_error = str(attempt.get("error") or attempt.get("stderr") or "runtime attempt failed")
        if strict:
            break

    status: RuntimeStatus = "PASS" if selected_backend is not None else "BLOCKED"
    payload = {
        "schema_version": "1.0",
        "toolchain_version": "0.11.0",
        "status": status,
        "requested_backend": requested,
        "selected_backend": selected_backend,
        "case": case,
        "snapshot": str(target_snapshot) if target_snapshot.is_file() else None,
        "strict": strict,
        "attempts": attempts,
        "error": last_error if status == "BLOCKED" else None,
    }
    target_report.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    result = RuntimeExecutionResult(
        status=status,
        backend=selected_backend,
        snapshot=target_snapshot if target_snapshot.is_file() else None,
        report=target_report,
        attempts=tuple(attempts),
    )
    if status == "BLOCKED":
        raise RuntimeBundleError(last_error or "all runtime backends failed", report=target_report)
    return result


def _execute_runtime_backend(
    bundle: Path,
    config: dict[str, Any],
    backend: str,
    *,
    case: str | None,
    snapshot: Path,
    extra_variables: dict[str, str],
) -> dict[str, Any]:
    specs = config.get("backend_specs")
    if not isinstance(specs, dict) or backend not in specs:
        raise RuntimeBundleError(f"runtime backend is not configured: {backend}")
    spec = specs[backend]
    if not isinstance(spec, dict):
        raise RuntimeBundleError(f"invalid runtime backend specification: {backend}")
    run_template = spec.get("run")
    if not isinstance(run_template, list) or not run_template:
        raise RuntimeBundleError(f"runtime backend has no run command: {backend}")

    variables: dict[str, str] = {
        "python": sys.executable,
        "generated_python": str(bundle / str(config["application"])),
        "support_dir": str(bundle / "support"),
        "snapshot": str(snapshot),
    }
    for group, record in config.get("kernels", {}).items():
        identifier = _identifier(str(group))
        variables[f"state_kernel_{identifier}_wrapper"] = str(bundle / str(record["wrapper"]))
    fortran = config.get("fortran")
    if isinstance(fortran, dict) and fortran.get("path"):
        variables["executable"] = str(bundle / str(fortran["path"]))

    case_payload = _resolve_case(config.get("cases"), case)
    for key, value in case_payload.get("variables", {}).items():
        variables[str(key)] = str(value)
    variables.update({str(key): str(value) for key, value in extra_variables.items()})

    command = [_format_token(str(token), variables) for token in run_template]
    started = __import__("time").perf_counter()
    completed = subprocess.run(
        command,
        cwd=bundle,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        check=False,
        timeout=float(case_payload.get("timeout_seconds", 120.0)),
    )
    elapsed = __import__("time").perf_counter() - started
    if completed.returncode != 0:
        return {
            "backend": backend,
            "status": "FAILED",
            "command": command,
            "returncode": completed.returncode,
            "elapsed_seconds": elapsed,
            "stdout": completed.stdout,
            "stderr": completed.stderr,
            "error": f"backend exited with code {completed.returncode}",
        }

    snapshot_spec = spec.get("snapshot", {})
    canonical = _collect_runtime_snapshot(
        snapshot_spec,
        snapshot=snapshot,
        stdout=completed.stdout,
    )
    snapshot.write_text(
        json.dumps(canonical, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    return {
        "backend": backend,
        "status": "PASS",
        "command": command,
        "returncode": completed.returncode,
        "elapsed_seconds": elapsed,
        "stdout": completed.stdout,
        "stderr": completed.stderr,
        "snapshot": str(snapshot),
    }


def _collect_runtime_snapshot(
    spec: Any,
    *,
    snapshot: Path,
    stdout: str,
) -> dict[str, Any]:
    if not isinstance(spec, dict):
        raise RuntimeBundleError("runtime snapshot specification is missing")
    source = str(spec.get("source", "file"))
    format_name = str(spec.get("format", "json"))
    if source == "file":
        if not snapshot.is_file():
            raise RuntimeBundleError(f"backend did not create snapshot: {snapshot}")
        if format_name != "json":
            raise RuntimeBundleError(f"unsupported runtime file snapshot format: {format_name}")
        payload = _load_json(snapshot)
        return _canonical_snapshot(payload)
    if source == "stdout" and format_name == "key_value":
        fields = spec.get("fields")
        if not isinstance(fields, dict):
            raise RuntimeBundleError("key_value snapshot requires a fields mapping")
        values: dict[str, Any] = {}
        for line in stdout.splitlines():
            if "=" not in line:
                continue
            key, raw = line.split("=", 1)
            key = key.strip()
            if key not in fields:
                continue
            kind = str(fields[key])
            rendered = raw.strip().replace("D", "E").replace("d", "e")
            if kind == "int":
                values[key] = int(rendered)
            elif kind == "float":
                values[key] = float(rendered)
            elif kind == "bool":
                values[key] = rendered.lower() in {"true", "t", "1", ".true."}
            else:
                values[key] = rendered
        missing = sorted(set(fields) - set(values))
        if missing:
            raise RuntimeBundleError(
                "runtime stdout snapshot is missing fields: " + ", ".join(missing)
            )
        return {"schema_version": "1.0", "scalars": values, "arrays": {}}
    raise RuntimeBundleError(
        f"unsupported runtime snapshot source/format: {source}/{format_name}"
    )


def _canonical_snapshot(payload: dict[str, Any]) -> dict[str, Any]:
    if "scalars" in payload or "arrays" in payload:
        return {
            "schema_version": str(payload.get("schema_version", "1.0")),
            "scalars": dict(payload.get("scalars", {})),
            "arrays": dict(payload.get("arrays", {})),
        }
    return {"schema_version": "1.0", "scalars": payload, "arrays": {}}


def _validate_runtime_bundle(root: Path, config: dict[str, Any]) -> dict[str, Any]:
    checks: list[dict[str, Any]] = []
    all_passed = True
    application = root / str(config["application"])
    try:
        compile(application.read_text(encoding="utf-8"), str(application), "exec")
    except Exception as exc:
        checks.append({"name": "generated-application", "status": "FAILED", "error": str(exc)})
        all_passed = False
    else:
        checks.append({"name": "generated-application", "status": "PASS", "path": str(application)})

    for group, record in config.get("kernels", {}).items():
        selected = str(record.get("selected_backend"))
        available = record.get("available_backends", {})
        selected_record = available.get(selected) if isinstance(available, dict) else None
        if not isinstance(selected_record, dict):
            checks.append({
                "name": f"kernel-{group}-{selected}",
                "status": "FAILED",
                "error": "selected backend is not packaged",
            })
            all_passed = False
            continue
        path = root / str(selected_record.get("path"))
        if not path.is_file():
            checks.append({
                "name": f"kernel-{group}-{selected}",
                "status": "FAILED",
                "error": f"backend file does not exist: {path}",
            })
            all_passed = False
        else:
            checks.append({
                "name": f"kernel-{group}-{selected}",
                "status": "PASS",
                "path": str(path),
                "sha256": _sha256(path),
            })

    runtime_api = root / str(config.get("runtime_api", "runtime_api.py"))
    try:
        import importlib.util
        module_name = f"fortran_modernize_runtime_api_{abs(hash(runtime_api))}"
        spec = importlib.util.spec_from_file_location(module_name, runtime_api)
        if spec is None or spec.loader is None:
            raise ImportError(f"cannot load runtime API: {runtime_api}")
        module = importlib.util.module_from_spec(spec)
        sys.modules[module_name] = module
        spec.loader.exec_module(module)
        handle = module.load_application(strict=True)
        checks.append({
            "name": "runtime-api-selected-backends",
            "status": "PASS",
            "selected_backends": dict(handle.backends),
        })
    except Exception as exc:
        checks.append({
            "name": "runtime-api-selected-backends",
            "status": "FAILED",
            "error": str(exc),
        })
        all_passed = False

    fortran = config.get("fortran")
    if isinstance(fortran, dict) and fortran.get("path"):
        path = root / str(fortran["path"])
        passed = path.is_file() and os.access(path, os.X_OK)
        checks.append({
            "name": "fortran-executable",
            "status": "PASS" if passed else "FAILED",
            "path": str(path),
        })
        all_passed = all_passed and passed
    return {
        "schema_version": "1.0",
        "toolchain_version": "0.11.0",
        "status": "PASS" if all_passed else "REVIEW_REQUIRED",
        "checks": checks,
    }


def _resolve_case(cases: Any, requested: str | None) -> dict[str, Any]:
    records = [item for item in cases if isinstance(item, dict)] if isinstance(cases, list) else []
    if not records:
        return {"name": requested or "default", "variables": {}, "timeout_seconds": 120.0}
    if requested is None:
        record = records[0]
    else:
        record = next((item for item in records if str(item.get("name")) == requested), None)
        if record is None:
            raise RuntimeBundleError(f"unknown runtime case: {requested}")
    return {
        **record,
        "variables": dict(record.get("variables", {})),
        "timeout_seconds": float(record.get("timeout_seconds", 120.0)),
    }


def _format_token(token: str, variables: dict[str, str]) -> str:
    names = re.findall(r"\{([A-Za-z_][A-Za-z0-9_]*)\}", token)
    missing = sorted({name for name in names if name not in variables})
    if missing:
        raise RuntimeBundleError(
            f"runtime command has unresolved placeholders: {', '.join(missing)}"
        )
    return token.format_map(variables)


def _preferred_application_backend(selected: dict[str, str]) -> str:
    values = list(dict.fromkeys(selected.values()))
    return values[0] if len(values) == 1 else "python"


def _application_fallback_order(
    preferred: str,
    specs: dict[str, Any],
    has_fortran: bool,
) -> list[str]:
    if preferred == "cython-optimized":
        candidates = ("cython-optimized", "cython-safe", "python", "fortran")
    elif preferred == "cython-safe":
        candidates = ("cython-safe", "python", "fortran")
    else:
        candidates = ("python", "fortran")
    order: list[str] = []
    for item in candidates:
        if item == "fortran" and not has_fortran:
            continue
        if item in specs and item not in order:
            order.append(item)
    return order


def _fallback_order(selected: str, available: dict[str, Any]) -> list[str]:
    order: list[str] = []
    candidates = [selected]
    if selected == "cython-optimized":
        candidates.append("cython-safe")
    candidates.append("python")
    for item in candidates:
        if item in available and item not in order:
            order.append(item)
    return order


def _artifact_path(root: Path, artifacts: dict[str, Any], key: str) -> Path:
    value = artifacts.get(key)
    if not isinstance(value, str) or not value:
        raise RuntimeBundleError(f"migration artifact is missing: {key}")
    path = (root / value).resolve()
    if not path.is_file():
        raise RuntimeBundleError(f"migration artifact does not exist: {path}")
    return path


def _optional_artifact_path(
    root: Path, artifacts: dict[str, Any], key: str
) -> Path | None:
    value = artifacts.get(key)
    if not isinstance(value, str) or not value:
        return None
    path = (root / value).resolve()
    return path if path.is_file() else None


def _required_string(value: Any, description: str) -> str:
    if not isinstance(value, str) or not value:
        raise RuntimeBundleError(f"missing {description}")
    return value


def _identifier(value: str) -> str:
    rendered = "".join(
        character if character.isalnum() or character == "_" else "_"
        for character in value.lower()
    )
    if not rendered:
        return "item"
    return f"item_{rendered}" if rendered[0].isdigit() else rendered


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _load_json(path: Path) -> dict[str, Any]:
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise RuntimeBundleError(f"cannot read JSON {path}: {exc}") from exc
    if not isinstance(payload, dict):
        raise RuntimeBundleError(f"JSON root must be an object: {path}")
    return payload


def _runtime_readme(selected: dict[str, str], has_fortran: bool) -> str:
    selected_lines = "\n".join(f"- `{group}` → `{backend}`" for group, backend in selected.items())
    fortran_line = "included" if has_fortran else "not included"
    return f"""# Generated runtime bundle

This directory was generated from a migration result that passed the numerical,
determinism, performance, and kernel-selection gates.

## Reviewed kernel choices

{selected_lines}

The regression-tested Fortran executable is **{fortran_line}**.

## Execute

```bash
./run-runtime --backend auto --snapshot result.json
```

`auto` tries the reviewed Cython choice first, then the safe Cython backend,
Python, and finally the packaged Fortran executable when available. Every
attempt is written to a runtime report. Use `--strict` to disable fallback.

Environment overrides are also supported:

```bash
FORTRAN_MODERNIZE_BACKEND=python ./run-runtime --backend auto
```

The compiled Cython extensions and Fortran executable are platform- and
Python-ABI-specific. On another platform, rebuild them from the source
migration bundle rather than copying the binaries blindly.
"""


def _runtime_api_source() -> str:
    return r'''"""Runtime API for a reviewed generated application.

Use ``load_application`` to import the generated Python module and patch each
selected numerical procedure with the reviewed Cython backend. If a compiled
backend cannot be imported, the API records the failure and falls back to the
next validated implementation unless strict mode is enabled.
"""

from __future__ import annotations

import importlib.util
import json
import os
import sys
from dataclasses import dataclass
from pathlib import Path
from types import ModuleType
from typing import Any

ROOT = Path(__file__).resolve().parent


@dataclass(frozen=True)
class RuntimeHandle:
    application: ModuleType
    backends: dict[str, str]
    attempts: tuple[dict[str, Any], ...]

    def invoke(self, procedure: str, *args: Any, **kwargs: Any) -> Any:
        return getattr(self.application, procedure)(*args, **kwargs)


def _load_module(path: Path, prefix: str) -> ModuleType:
    name = f"{prefix}_{abs(hash(path.resolve()))}"
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise ImportError(f"cannot import generated runtime module: {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def _environment_override(group: str) -> str | None:
    name = "FORTRAN_MODERNIZE_KERNEL_" + "".join(
        character if character.isalnum() else "_" for character in group.upper()
    )
    value = os.environ.get(name)
    return value.lower() if value else None


def _proxy(wrapper: ModuleType, procedure: str, backend: str):
    target = getattr(wrapper, procedure)

    def invoke(*args: Any, **kwargs: Any) -> Any:
        if "backend" in kwargs:
            raise TypeError("backend is controlled by the runtime dispatcher")
        return target(*args, backend=backend, **kwargs)

    invoke.__name__ = procedure
    invoke.__doc__ = f"Runtime-dispatched wrapper using {backend}."
    return invoke


def load_application(
    *,
    overrides: dict[str, str] | None = None,
    strict: bool | None = None,
) -> RuntimeHandle:
    config = json.loads((ROOT / "runtime_config.json").read_text(encoding="utf-8"))
    application = _load_module(ROOT / str(config["application"]), "generated_application")
    strict_mode = bool(config.get("strict_selected", False)) if strict is None else strict
    env_strict = os.environ.get("FORTRAN_MODERNIZE_STRICT", "").lower() in {
        "1", "true", "yes", "on"
    }
    strict_mode = strict_mode or env_strict
    requested_overrides = {str(k): str(v).lower() for k, v in (overrides or {}).items()}
    selected: dict[str, str] = {}
    attempts: list[dict[str, Any]] = []

    for group, record in config.get("kernels", {}).items():
        wrapper = _load_module(ROOT / str(record["wrapper"]), f"wrapper_{group}")
        requested = (
            requested_overrides.get(group)
            or _environment_override(group)
            or str(record.get("selected_backend", "python"))
        )
        if strict_mode:
            order = [requested]
        else:
            order = [requested]
            for candidate in record.get("fallback_order", []):
                candidate = str(candidate)
                if candidate not in order:
                    order.append(candidate)
        chosen = None
        for backend in order:
            try:
                loader = getattr(wrapper, "_load_backend")
                loader(backend)
            except Exception as exc:
                attempts.append({
                    "group": group,
                    "backend": backend,
                    "status": "FAILED",
                    "error": str(exc),
                })
                if strict_mode:
                    break
            else:
                procedure = str(record["procedure"])
                setattr(application, procedure, _proxy(wrapper, procedure, backend))
                selected[group] = backend
                chosen = backend
                attempts.append({
                    "group": group,
                    "backend": backend,
                    "status": "PASS",
                })
                break
        if chosen is None:
            raise RuntimeError(
                f"no usable backend remains for kernel group {group!r}; "
                f"attempts={attempts!r}"
            )
    return RuntimeHandle(application=application, backends=selected, attempts=tuple(attempts))
'''


def _runtime_dispatch_source() -> str:
    # Kept standalone so a runtime bundle does not need the orchestrator package.
    return r'''#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import os
import re
import subprocess
import sys
import time
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parent


def load_json(path: Path) -> dict[str, Any]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise RuntimeError(f"JSON root must be an object: {path}")
    return payload


def identifier(value: str) -> str:
    rendered = "".join(c if c.isalnum() or c == "_" else "_" for c in value.lower())
    return ("item_" + rendered) if rendered and rendered[0].isdigit() else (rendered or "item")


def resolve_case(config: dict[str, Any], requested: str | None) -> dict[str, Any]:
    cases = [item for item in config.get("cases", []) if isinstance(item, dict)]
    if not cases:
        return {"name": requested or "default", "variables": {}, "timeout_seconds": 120.0}
    if requested is None:
        return cases[0]
    for item in cases:
        if str(item.get("name")) == requested:
            return item
    raise RuntimeError(f"unknown runtime case: {requested}")


def format_token(token: str, variables: dict[str, str]) -> str:
    names = re.findall(r"\{([A-Za-z_][A-Za-z0-9_]*)\}", token)
    missing = sorted({name for name in names if name not in variables})
    if missing:
        raise RuntimeError("unresolved placeholders: " + ", ".join(missing))
    return token.format_map(variables)


def canonical_snapshot(spec: dict[str, Any], snapshot: Path, stdout: str) -> dict[str, Any]:
    source = str(spec.get("source", "file"))
    format_name = str(spec.get("format", "json"))
    if source == "file" and format_name == "json":
        if not snapshot.is_file():
            raise RuntimeError(f"backend did not create snapshot: {snapshot}")
        payload = load_json(snapshot)
        if "scalars" in payload or "arrays" in payload:
            return {
                "schema_version": str(payload.get("schema_version", "1.0")),
                "scalars": dict(payload.get("scalars", {})),
                "arrays": dict(payload.get("arrays", {})),
            }
        return {"schema_version": "1.0", "scalars": payload, "arrays": {}}
    if source == "stdout" and format_name == "key_value":
        fields = spec.get("fields", {})
        values: dict[str, Any] = {}
        for line in stdout.splitlines():
            if "=" not in line:
                continue
            key, raw = line.split("=", 1)
            key = key.strip()
            if key not in fields:
                continue
            rendered = raw.strip().replace("D", "E").replace("d", "e")
            kind = str(fields[key])
            values[key] = int(rendered) if kind == "int" else float(rendered) if kind == "float" else rendered
        missing = sorted(set(fields) - set(values))
        if missing:
            raise RuntimeError("stdout snapshot missing fields: " + ", ".join(missing))
        return {"schema_version": "1.0", "scalars": values, "arrays": {}}
    raise RuntimeError(f"unsupported snapshot source/format: {source}/{format_name}")


def execute(config: dict[str, Any], backend: str, case_name: str | None, snapshot: Path) -> dict[str, Any]:
    specs = config.get("backend_specs", {})
    if backend not in specs:
        raise RuntimeError(f"backend is not configured: {backend}")
    spec = specs[backend]
    run = spec.get("run")
    if not isinstance(run, list) or not run:
        raise RuntimeError(f"backend has no run command: {backend}")
    variables = {
        "python": sys.executable,
        "generated_python": str(ROOT / str(config["application"])),
        "support_dir": str(ROOT / "support"),
        "snapshot": str(snapshot),
    }
    for group, record in config.get("kernels", {}).items():
        variables[f"state_kernel_{identifier(str(group))}_wrapper"] = str(ROOT / str(record["wrapper"]))
    fortran = config.get("fortran")
    if isinstance(fortran, dict) and fortran.get("path"):
        variables["executable"] = str(ROOT / str(fortran["path"]))
    case = resolve_case(config, case_name)
    for key, value in case.get("variables", {}).items():
        variables[str(key)] = str(value)
    command = [format_token(str(token), variables) for token in run]
    started = time.perf_counter()
    completed = subprocess.run(
        command,
        cwd=ROOT,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        check=False,
        timeout=float(case.get("timeout_seconds", 120.0)),
    )
    elapsed = time.perf_counter() - started
    if completed.returncode != 0:
        return {
            "backend": backend,
            "status": "FAILED",
            "command": command,
            "returncode": completed.returncode,
            "elapsed_seconds": elapsed,
            "stdout": completed.stdout,
            "stderr": completed.stderr,
            "error": f"backend exited with code {completed.returncode}",
        }
    canonical = canonical_snapshot(spec.get("snapshot", {}), snapshot, completed.stdout)
    snapshot.write_text(json.dumps(canonical, indent=2) + "\n", encoding="utf-8")
    return {
        "backend": backend,
        "status": "PASS",
        "command": command,
        "returncode": 0,
        "elapsed_seconds": elapsed,
        "stdout": completed.stdout,
        "stderr": completed.stderr,
        "snapshot": str(snapshot),
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="Run a reviewed Fortran modernization runtime bundle")
    parser.add_argument("--backend", default="auto")
    parser.add_argument("--case")
    parser.add_argument("--snapshot", default=str(ROOT / "last_snapshot.json"))
    parser.add_argument("--report", default=str(ROOT / "last_runtime_report.json"))
    parser.add_argument("--strict", action="store_true")
    args = parser.parse_args()

    config = load_json(ROOT / "runtime_config.json")
    requested = os.environ.get("FORTRAN_MODERNIZE_BACKEND", args.backend).lower()
    env_strict = os.environ.get("FORTRAN_MODERNIZE_STRICT", "").lower() in {"1", "true", "yes", "on"}
    strict = args.strict or env_strict or bool(config.get("strict_selected", False))
    if requested == "auto":
        order = [str(item) for item in config.get("application_fallback_order", [])]
    else:
        order = [requested]
        if not strict:
            for item in config.get("application_fallback_order", []):
                if str(item) not in order:
                    order.append(str(item))

    snapshot = Path(args.snapshot).expanduser().resolve()
    report = Path(args.report).expanduser().resolve()
    snapshot.parent.mkdir(parents=True, exist_ok=True)
    report.parent.mkdir(parents=True, exist_ok=True)
    attempts = []
    selected = None
    for backend in order:
        try:
            attempt = execute(config, backend, args.case, snapshot)
        except Exception as exc:
            attempt = {"backend": backend, "status": "FAILED", "error": str(exc)}
        attempts.append(attempt)
        if attempt.get("status") == "PASS":
            selected = backend
            break
        if strict:
            break
    status = "PASS" if selected is not None else "BLOCKED"
    payload = {
        "schema_version": "1.0",
        "toolchain_version": "0.11.0",
        "status": status,
        "requested_backend": requested,
        "selected_backend": selected,
        "case": args.case,
        "snapshot": str(snapshot) if snapshot.is_file() else None,
        "strict": strict,
        "attempts": attempts,
    }
    report.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(payload, indent=2))
    return 0 if status == "PASS" else 2


if __name__ == "__main__":
    raise SystemExit(main())
'''
