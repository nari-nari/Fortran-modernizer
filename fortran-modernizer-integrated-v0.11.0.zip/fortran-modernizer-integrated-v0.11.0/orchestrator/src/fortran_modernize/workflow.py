from __future__ import annotations

import csv
import hashlib
import json
import shutil
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable

from fortran_refactor.apply import ApplyError, apply_plan
from fortran_refactor.compiler import VerificationError

from .approval import (
    APPROVAL_CONFIRMATION,
    ApprovalWorkflowError,
    _candidate_category,
    _candidate_digest,
    _file_digest,
    _load_plan,
    _machine_applicable,
    _plan_digest,
    _source_tree_digest,
    validate_approval,
)


WORKFLOW_CONFIRMATION = "I CONFIRM THIS WORKFLOW GATE"

GATE_DEFINITIONS: dict[str, dict[str, Any]] = {
    "GATE-READ_ONLY_ANALYSIS": {
        "label": "Read-only whole-project analysis completed",
        "human_required": False,
    },
    "GATE-LEGACY_BASELINE": {
        "label": "Legacy compiler/executable baseline captured",
        "human_required": True,
    },
    "GATE-REGRESSION_BASELINE": {
        "label": "Regression cases, outputs, and tolerances reviewed",
        "human_required": True,
    },
    "GATE-GFORTRAN_PORTABILITY": {
        "label": "gfortran portability baseline established",
        "human_required": False,
    },
    "GATE-TYPO_CANDIDATES_RESOLVED": {
        "label": "Implicit-variable typo candidates resolved",
        "human_required": True,
    },
    "GATE-COMMON_LAYOUTS_RESOLVED": {
        "label": "COMMON layouts and canonical declarations resolved",
        "human_required": True,
    },
    "GATE-CALL_SIGNATURES_RESOLVED": {
        "label": "Call signatures and external function types resolved",
        "human_required": True,
    },
    "GATE-IMPLICIT_TYPES_RESOLVED": {
        "label": "Remaining implicit types reviewed and resolved",
        "human_required": True,
    },
    "GATE-IMPLICIT_NONE_COMPLETE": {
        "label": "IMPLICIT NONE stage validated",
        "human_required": False,
    },
    "GATE-COMMON_DECLARATIONS_CENTRALIZED": {
        "label": "COMMON declarations centralized and validated",
        "human_required": False,
    },
    "GATE-COMMON_MODULE_COMPLETE": {
        "label": "COMMON-to-module stage validated",
        "human_required": False,
    },
    "GATE-EQUIVALENCE_PROBED": {
        "label": "EQUIVALENCE storage mapping compiler-probed",
        "human_required": False,
    },
    "GATE-EQUIVALENCE_RESOLVED": {
        "label": "EQUIVALENCE semantics resolved and validated",
        "human_required": True,
    },
    "GATE-FORTRAN_REGRESSION_PASS": {
        "label": "Current reviewed Fortran tree passes regression and determinism gates",
        "human_required": False,
    },
    "GATE-PYTHON_MIGRATION_READY": {
        "label": "Selected Fortran procedure closure is ready for Python migration",
        "human_required": True,
    },
}

PHASES: dict[int, str] = {
    0: "intake",
    10: "baseline-establishment",
    20: "compiler-portability",
    30: "existing-defect-resolution",
    40: "declaration-stabilization",
    50: "structural-refactoring",
    60: "advanced-modernization",
    70: "python-migration",
}


@dataclass(frozen=True)
class CandidateRule:
    phase: int
    prerequisites: tuple[str, ...] = ()
    provides: tuple[str, ...] = ()
    force_approval: bool = False
    blocks_later_phases: bool = True


_DEFAULT_RULE = CandidateRule(
    phase=30,
    prerequisites=("GATE-READ_ONLY_ANALYSIS", "GATE-LEGACY_BASELINE", "GATE-REGRESSION_BASELINE"),
)

_RULES: dict[str, CandidateRule] = {
    "manual_diagnostic_resolution": CandidateRule(
        20, ("GATE-READ_ONLY_ANALYSIS", "GATE-LEGACY_BASELINE"), force_approval=True
    ),
    "rewrite_fixed_form_statements": CandidateRule(
        20, ("GATE-READ_ONLY_ANALYSIS", "GATE-LEGACY_BASELINE"), force_approval=True
    ),
    "rename_implicit_typo": CandidateRule(
        30,
        ("GATE-READ_ONLY_ANALYSIS", "GATE-LEGACY_BASELINE", "GATE-REGRESSION_BASELINE"),
        ("GATE-TYPO_CANDIDATES_RESOLVED",),
        force_approval=True,
    ),
    "repair_common_layout": CandidateRule(
        30,
        ("GATE-LEGACY_BASELINE", "GATE-REGRESSION_BASELINE", "GATE-GFORTRAN_PORTABILITY"),
        ("GATE-COMMON_LAYOUTS_RESOLVED",),
        force_approval=True,
    ),
    "external_interface_migration": CandidateRule(
        30,
        ("GATE-LEGACY_BASELINE", "GATE-REGRESSION_BASELINE", "GATE-GFORTRAN_PORTABILITY"),
        ("GATE-CALL_SIGNATURES_RESOLVED",),
        force_approval=True,
    ),
    "introduce_implicit_none": CandidateRule(
        40,
        (
            "GATE-GFORTRAN_PORTABILITY",
            "GATE-REGRESSION_BASELINE",
            "GATE-TYPO_CANDIDATES_RESOLVED",
            "GATE-COMMON_LAYOUTS_RESOLVED",
            "GATE-CALL_SIGNATURES_RESOLVED",
            "GATE-IMPLICIT_TYPES_RESOLVED",
        ),
        ("GATE-IMPLICIT_NONE_COMPLETE",),
        force_approval=True,
    ),
    "add_dummy_intents": CandidateRule(
        40,
        ("GATE-IMPLICIT_NONE_COMPLETE", "GATE-CALL_SIGNATURES_RESOLVED", "GATE-FORTRAN_REGRESSION_PASS"),
        force_approval=True,
    ),
    "centralize_common_include": CandidateRule(
        50,
        ("GATE-COMMON_LAYOUTS_RESOLVED", "GATE-GFORTRAN_PORTABILITY", "GATE-FORTRAN_REGRESSION_PASS"),
        ("GATE-COMMON_DECLARATIONS_CENTRALIZED",),
        force_approval=True,
    ),
    "migrate_common_module": CandidateRule(
        50,
        (
            "GATE-COMMON_DECLARATIONS_CENTRALIZED",
            "GATE-IMPLICIT_NONE_COMPLETE",
            "GATE-FORTRAN_REGRESSION_PASS",
        ),
        ("GATE-COMMON_MODULE_COMPLETE",),
        force_approval=True,
    ),
    "migrate_block_data_initialization": CandidateRule(
        50,
        ("GATE-GFORTRAN_PORTABILITY", "GATE-REGRESSION_BASELINE", "GATE-FORTRAN_REGRESSION_PASS"),
        force_approval=True,
    ),
    "migrate_procedure_module": CandidateRule(
        50,
        ("GATE-CALL_SIGNATURES_RESOLVED", "GATE-IMPLICIT_NONE_COMPLETE", "GATE-FORTRAN_REGRESSION_PASS"),
        force_approval=True,
    ),
    "partition_procedure_modules": CandidateRule(
        50,
        ("GATE-CALL_SIGNATURES_RESOLVED", "GATE-IMPLICIT_NONE_COMPLETE", "GATE-FORTRAN_REGRESSION_PASS"),
        force_approval=True,
    ),
    "classify_procedure_modules": CandidateRule(
        50,
        ("GATE-CALL_SIGNATURES_RESOLVED", "GATE-IMPLICIT_NONE_COMPLETE"),
        force_approval=True,
    ),
    "convert_fixed_to_free": CandidateRule(
        50,
        ("GATE-GFORTRAN_PORTABILITY", "GATE-REGRESSION_BASELINE", "GATE-FORTRAN_REGRESSION_PASS"),
        force_approval=True,
    ),
    "standardize_kind_declarations": CandidateRule(
        60,
        ("GATE-IMPLICIT_NONE_COMPLETE", "GATE-FORTRAN_REGRESSION_PASS"),
        force_approval=True,
    ),
    "remove_equivalence_complete_alias": CandidateRule(
        60,
        (
            "GATE-LEGACY_BASELINE",
            "GATE-REGRESSION_BASELINE",
            "GATE-EQUIVALENCE_PROBED",
            "GATE-FORTRAN_REGRESSION_PASS",
        ),
        ("GATE-EQUIVALENCE_RESOLVED",),
        force_approval=True,
    ),
    "migrate_shared_state_objects": CandidateRule(
        60,
        ("GATE-COMMON_MODULE_COMPLETE", "GATE-EQUIVALENCE_RESOLVED", "GATE-FORTRAN_REGRESSION_PASS"),
        force_approval=True,
    ),
    "integrate_shared_state_objects": CandidateRule(
        60,
        ("GATE-COMMON_MODULE_COMPLETE", "GATE-EQUIVALENCE_RESOLVED", "GATE-FORTRAN_REGRESSION_PASS"),
        force_approval=True,
    ),
    "modernize_control_flow": CandidateRule(60, ("GATE-FORTRAN_REGRESSION_PASS",), force_approval=True),
    "modernize_allocatable_storage": CandidateRule(60, ("GATE-FORTRAN_REGRESSION_PASS",), force_approval=True),
    "modernize_array_interface": CandidateRule(
        60, ("GATE-CALL_SIGNATURES_RESOLVED", "GATE-FORTRAN_REGRESSION_PASS"), force_approval=True
    ),
    "organize_public_module_api": CandidateRule(
        60, ("GATE-CALL_SIGNATURES_RESOLVED", "GATE-FORTRAN_REGRESSION_PASS"), force_approval=True
    ),
}


class WorkflowError(RuntimeError):
    pass


@dataclass(frozen=True)
class WorkflowScheduleResult:
    status: str
    output_directory: Path
    workflow: Path
    summary_csv: Path
    next_action: Path
    ready_automatic_ids: tuple[str, ...]
    ready_approval_ids: tuple[str, ...]


@dataclass(frozen=True)
class WorkflowApplyResult:
    status: str
    output_directory: Path
    receipt: Path
    transformed_root: Path
    applied_ids: tuple[str, ...]


def initialize_workflow_state(
    plan_directory: str | Path,
    *,
    output: str | Path,
    overwrite: bool = False,
) -> Path:
    _plan, manifest, suggestions = _load_plan(plan_directory)
    destination = Path(output).expanduser().resolve()
    if destination.exists() and not overwrite:
        raise WorkflowError(f"workflow state already exists: {destination}")
    destination.parent.mkdir(parents=True, exist_ok=True)
    source_root = Path(str(manifest["source_root"])).expanduser().resolve()
    gates = {
        gate_id: {
            "status": "NOT_RUN",
            "label": definition["label"],
            "human_required": bool(definition["human_required"]),
            "recorded_at": None,
            "recorded_by": None,
            "actor_kind": None,
            "evidence": [],
        }
        for gate_id, definition in GATE_DEFINITIONS.items()
    }
    payload = {
        "schema_version": "1.0",
        "toolchain_version": "0.11.0",
        "initial_plan_directory": str(Path(plan_directory).expanduser().resolve()),
        "initial_plan_sha256": _plan_digest(manifest, suggestions),
        "source_root": str(source_root),
        "source_tree_sha256": _source_tree_digest(source_root),
        "gates": gates,
        "applied_candidates": [],
        "rejected_candidates": [],
        "stage_history": [],
        "updated_at": datetime.now(timezone.utc).isoformat(),
    }
    destination.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return destination


def record_workflow_gate(
    state_file: str | Path,
    *,
    gate_id: str,
    status: str,
    actor_kind: str,
    recorded_by: str,
    evidence: Iterable[str | Path] = (),
    output: str | Path | None = None,
    confirmation: str | None = None,
    note: str | None = None,
) -> Path:
    state_path, state = _load_state(state_file)
    if gate_id not in GATE_DEFINITIONS:
        raise WorkflowError(f"unknown workflow gate: {gate_id}")
    normalized_status = status.upper()
    if normalized_status not in {"PASS", "FAILED", "REVIEW_REQUIRED", "NOT_RUN"}:
        raise WorkflowError(f"unsupported gate status: {status}")
    normalized_actor = actor_kind.lower()
    if normalized_actor not in {"human", "tool"}:
        raise WorkflowError("actor_kind must be human or tool")
    if not recorded_by.strip():
        raise WorkflowError("recorded_by is required")
    gate = GATE_DEFINITIONS[gate_id]
    if gate["human_required"] and normalized_status == "PASS":
        if normalized_actor != "human" or confirmation != WORKFLOW_CONFIRMATION:
            raise WorkflowError(
                f"{gate_id} requires a human reviewer and exact confirmation: {WORKFLOW_CONFIRMATION}"
            )
    evidence_rows: list[dict[str, Any]] = []
    for raw in evidence:
        path = Path(raw).expanduser().resolve()
        if not path.is_file():
            raise WorkflowError(f"gate evidence does not exist: {path}")
        evidence_rows.append({"path": str(path), "sha256": _file_digest(path)})
    if normalized_status == "PASS" and not evidence_rows:
        raise WorkflowError("PASS gate records require at least one evidence file")

    state["gates"][gate_id] = {
        "status": normalized_status,
        "label": gate["label"],
        "human_required": bool(gate["human_required"]),
        "recorded_at": datetime.now(timezone.utc).isoformat(),
        "recorded_by": recorded_by.strip(),
        "actor_kind": normalized_actor,
        "evidence": evidence_rows,
        "note": note,
    }
    state["updated_at"] = datetime.now(timezone.utc).isoformat()
    destination = Path(output).expanduser().resolve() if output else state_path
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(json.dumps(state, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return destination


def schedule_workflow(
    plan_directory: str | Path,
    *,
    state_file: str | Path,
    output_directory: str | Path,
    overwrite: bool = False,
) -> WorkflowScheduleResult:
    plan, manifest, suggestions = _load_plan(plan_directory)
    _state_path, state = _load_state(state_file)
    _validate_state_binding(state, manifest, suggestions)
    output = _prepare_output(output_directory, overwrite=overwrite)

    gate_statuses = {
        gate_id: str(record.get("status", "NOT_RUN"))
        for gate_id, record in state.get("gates", {}).items()
        if isinstance(record, dict)
    }
    applied = set(str(item) for item in state.get("applied_candidates", []))
    rejected = set(str(item) for item in state.get("rejected_candidates", []))

    rows: list[dict[str, Any]] = []
    by_id = {str(item.get("id")): item for item in suggestions}
    for suggestion in suggestions:
        candidate_id = str(suggestion.get("id", ""))
        kind = str(suggestion.get("kind", ""))
        rule = _rule_for(suggestion)
        base_category = _candidate_category(suggestion)
        effective_category = _effective_category(suggestion, base_category, rule)
        explicit_gates, explicit_candidates = _explicit_dependencies(suggestion)
        prerequisites = tuple(dict.fromkeys((*rule.prerequisites, *explicit_gates)))
        candidate_dependencies = tuple(dict.fromkeys(explicit_candidates))
        missing_gates = [gate for gate in prerequisites if gate_statuses.get(gate, "NOT_RUN") != "PASS"]
        failed_gates = [gate for gate in prerequisites if gate_statuses.get(gate) == "FAILED"]
        missing_candidates = [item for item in candidate_dependencies if item not in applied]

        if candidate_id in applied:
            readiness = "APPLIED"
        elif candidate_id in rejected:
            readiness = "REJECTED"
        elif effective_category == "INFORMATIONAL":
            readiness = "INFORMATIONAL"
        elif effective_category == "BLOCKED":
            readiness = "BLOCKED"
        elif effective_category == "MANUAL_REVIEW":
            readiness = "MANUAL_REVIEW"
        elif failed_gates:
            readiness = "BLOCKED_BY_FAILED_GATE"
        elif missing_gates or missing_candidates:
            readiness = "WAITING_AUTOMATIC" if effective_category == "AUTOMATIC" else "WAITING_APPROVAL"
        else:
            readiness = "READY_AUTOMATIC" if effective_category == "AUTOMATIC" else "READY_APPROVAL"

        rows.append(
            {
                "id": candidate_id,
                "kind": kind,
                "original_category": base_category,
                "effective_category": effective_category,
                "phase": rule.phase,
                "phase_name": PHASES.get(rule.phase, f"phase-{rule.phase}"),
                "readiness": readiness,
                "prerequisite_gates": list(prerequisites),
                "candidate_dependencies": list(candidate_dependencies),
                "missing_gates": missing_gates,
                "failed_gates": failed_gates,
                "missing_candidates": missing_candidates,
                "provides_gates": list(rule.provides),
                "blocks_later_phases": rule.blocks_later_phases,
                "machine_applicable": _machine_applicable(suggestion),
                "candidate_sha256": _candidate_digest(suggestion),
                "path": suggestion.get("path"),
                "program_unit": suggestion.get("program_unit"),
                "line": suggestion.get("line"),
                "message": suggestion.get("message"),
            }
        )

    _apply_phase_barriers(rows)
    active = [row for row in rows if row["readiness"] not in {"APPLIED", "INFORMATIONAL"}]
    earliest_phase = min((int(row["phase"]) for row in active), default=None)
    current_rows = [row for row in rows if earliest_phase is not None and int(row["phase"]) == earliest_phase]
    ready_approval = tuple(row["id"] for row in current_rows if row["readiness"] == "READY_APPROVAL")
    # Conservative rule: an approval-ready candidate in the current phase stops automatic edits in that phase.
    ready_automatic = () if ready_approval else tuple(
        row["id"] for row in current_rows if row["readiness"] == "READY_AUTOMATIC"
    )

    if ready_approval:
        status = "REVIEW_REQUIRED"
        next_kind = "REQUEST_HUMAN_APPROVAL"
    elif ready_automatic:
        status = "READY"
        next_kind = "APPLY_READY_AUTOMATIC"
    elif not active:
        status = "PASS"
        next_kind = "WORKFLOW_COMPLETE"
    elif any(row["readiness"] in {"BLOCKED", "BLOCKED_BY_FAILED_GATE", "MANUAL_REVIEW", "REJECTED"} for row in current_rows):
        status = "BLOCKED"
        next_kind = "RESOLVE_BLOCKER"
    else:
        status = "WAITING"
        next_kind = "SATISFY_PREREQUISITES"

    payload = {
        "schema_version": "1.0",
        "toolchain_version": "0.11.0",
        "status": status,
        "plan_directory": str(plan),
        "plan_sha256": _plan_digest(manifest, suggestions),
        "source_root": str(Path(str(manifest["source_root"])).expanduser().resolve()),
        "source_tree_sha256": _source_tree_digest(Path(str(manifest["source_root"])).expanduser().resolve()),
        "state_file": str(Path(state_file).expanduser().resolve()),
        "state_sha256": _file_digest(Path(state_file).expanduser().resolve()),
        "earliest_active_phase": earliest_phase,
        "earliest_active_phase_name": PHASES.get(earliest_phase) if earliest_phase is not None else None,
        "next_action": next_kind,
        "ready_automatic_ids": list(ready_automatic),
        "ready_approval_ids": list(ready_approval),
        "gate_statuses": gate_statuses,
        "candidates": rows,
        "generated_at": datetime.now(timezone.utc).isoformat(),
    }
    workflow = output / "workflow_plan.json"
    workflow.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    summary_csv = output / "workflow_summary.csv"
    _write_summary_csv(summary_csv, rows)
    next_action = output / "NEXT_ACTION.md"
    next_action.write_text(_next_action_markdown(payload), encoding="utf-8")
    return WorkflowScheduleResult(
        status=status,
        output_directory=output,
        workflow=workflow,
        summary_csv=summary_csv,
        next_action=next_action,
        ready_automatic_ids=ready_automatic,
        ready_approval_ids=ready_approval,
    )


def create_ready_approval(
    plan_directory: str | Path,
    *,
    workflow_file: str | Path,
    approved_ids: Iterable[str],
    rejected_ids: Iterable[str] = (),
    approved_by: str,
    output: str | Path,
    confirmation: str,
    note: str | None = None,
) -> Path:
    if confirmation != APPROVAL_CONFIRMATION:
        raise WorkflowError("human confirmation phrase does not match")
    workflow = _load_workflow(workflow_file)
    plan, manifest, suggestions = _load_plan(plan_directory)
    _validate_workflow_binding(workflow, manifest, suggestions)
    ready = set(str(item) for item in workflow.get("ready_approval_ids", []))
    approved = tuple(dict.fromkeys(str(item) for item in approved_ids))
    rejected = tuple(dict.fromkeys(str(item) for item in rejected_ids))
    if not approved and not rejected:
        raise WorkflowError("at least one approved or rejected candidate ID is required")
    unauthorized = sorted((set(approved) | set(rejected)) - ready)
    if unauthorized:
        raise WorkflowError("candidate IDs are not currently READY_APPROVAL: " + ", ".join(unauthorized))
    if not approved_by.strip():
        raise WorkflowError("approved_by is required")
    by_id = {str(item.get("id")): item for item in suggestions}
    snapshot = {
        candidate_id: {
            "candidate_sha256": _candidate_digest(by_id[candidate_id]),
            "kind": by_id[candidate_id].get("kind"),
            "safety": by_id[candidate_id].get("safety"),
        }
        for candidate_id in sorted(set(approved) | set(rejected))
    }
    payload = {
        "schema_version": "1.1",
        "toolchain_version": "0.11.0",
        "approval_status": "APPROVED",
        "plan_directory": str(plan),
        "plan_sha256": _plan_digest(manifest, suggestions),
        "source_root": workflow["source_root"],
        "source_tree_sha256": workflow["source_tree_sha256"],
        "workflow_file": str(Path(workflow_file).expanduser().resolve()),
        "workflow_sha256": _file_digest(Path(workflow_file).expanduser().resolve()),
        "approved_candidates": list(approved),
        "rejected_candidates": list(rejected),
        "candidate_snapshot": snapshot,
        "approved_by": approved_by.strip(),
        "approved_at": datetime.now(timezone.utc).isoformat(),
        "human_confirmation": True,
    }
    if note:
        payload["note"] = note
    destination = Path(output).expanduser().resolve()
    if destination.exists():
        raise WorkflowError(f"approval output already exists: {destination}")
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    try:
        destination.chmod(0o444)
    except OSError:
        pass
    return destination


def validate_ready_approval(
    plan_directory: str | Path,
    workflow_file: str | Path,
    approval_file: str | Path,
) -> list[str]:
    errors: list[str] = []
    try:
        workflow = _load_workflow(workflow_file)
        _plan, manifest, suggestions = _load_plan(plan_directory)
        _validate_workflow_binding(workflow, manifest, suggestions)
    except (WorkflowError, ApprovalWorkflowError) as exc:
        return [str(exc)]
    approval_path = Path(approval_file).expanduser().resolve()
    try:
        approval = json.loads(approval_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        return [f"cannot read approval: {exc}"]
    if approval.get("workflow_sha256") != _file_digest(Path(workflow_file).expanduser().resolve()):
        errors.append("approval workflow hash is stale")
    if approval.get("plan_sha256") != workflow.get("plan_sha256"):
        errors.append("approval plan hash does not match workflow")
    if approval.get("source_tree_sha256") != workflow.get("source_tree_sha256"):
        errors.append("approval source tree hash does not match workflow")
    if approval.get("approval_status") != "APPROVED" or approval.get("human_confirmation") is not True:
        errors.append("approval lacks completed human confirmation")
    ready = set(str(item) for item in workflow.get("ready_approval_ids", []))
    approved = approval.get("approved_candidates")
    if not isinstance(approved, list) or not all(isinstance(item, str) for item in approved):
        errors.append("approved_candidates must be a list of strings")
        approved = []
    unauthorized = sorted(set(approved) - ready)
    if unauthorized:
        errors.append("approval includes candidates that are no longer READY_APPROVAL: " + ", ".join(unauthorized))
    by_id = {str(item.get("id")): item for item in suggestions}
    snapshot = approval.get("candidate_snapshot") if isinstance(approval.get("candidate_snapshot"), dict) else {}
    for candidate_id in approved:
        item = by_id.get(candidate_id)
        frozen = snapshot.get(candidate_id)
        if item is None:
            errors.append(f"approved candidate no longer exists: {candidate_id}")
        elif not isinstance(frozen, dict) or frozen.get("candidate_sha256") != _candidate_digest(item):
            errors.append(f"approved candidate snapshot is stale: {candidate_id}")
    return errors


def apply_ready_workflow(
    plan_directory: str | Path,
    *,
    workflow_file: str | Path,
    output_directory: str | Path,
    approval_file: str | Path | None = None,
    include_dirs: Iterable[str | Path] = (),
    compile_check: bool = False,
) -> WorkflowApplyResult:
    workflow = _load_workflow(workflow_file)
    _plan, manifest, suggestions = _load_plan(plan_directory)
    _validate_workflow_binding(workflow, manifest, suggestions)
    ready_auto = set(str(item) for item in workflow.get("ready_automatic_ids", []))
    ready_approval = set(str(item) for item in workflow.get("ready_approval_ids", []))
    selected = set(ready_auto)
    approval_payload: dict[str, Any] | None = None
    if approval_file:
        errors = validate_ready_approval(plan_directory, workflow_file, approval_file)
        if errors:
            raise WorkflowError("ready approval validation failed: " + "; ".join(errors))
        approval_payload = json.loads(Path(approval_file).expanduser().resolve().read_text(encoding="utf-8"))
        selected.update(str(item) for item in approval_payload.get("approved_candidates", []))
    if ready_approval and approval_file is None:
        raise WorkflowError(
            "current phase contains READY_APPROVAL candidates; obtain human approval before applying any candidate"
        )
    if not selected:
        raise WorkflowError("workflow contains no currently authorized ready candidates")
    if not selected.issubset(ready_auto | ready_approval):
        raise WorkflowError("selected candidates are outside the workflow ready set")

    output = Path(output_directory).expanduser().resolve()
    try:
        engine = apply_plan(
            Path(plan_directory),
            output,
            selected,
            False,
            bool(selected & ready_approval),
            [Path(item).expanduser().resolve() for item in include_dirs],
            compile_check,
        )
    except (ApplyError, VerificationError) as exc:
        raise WorkflowError(str(exc)) from exc
    transformed_root = Path(str(engine["transformed_root"])).resolve()
    payload = {
        "schema_version": "1.0",
        "toolchain_version": "0.11.0",
        "status": "PASS",
        "plan_directory": str(Path(plan_directory).expanduser().resolve()),
        "workflow_file": str(Path(workflow_file).expanduser().resolve()),
        "workflow_sha256": _file_digest(Path(workflow_file).expanduser().resolve()),
        "approval_file": str(Path(approval_file).expanduser().resolve()) if approval_file else None,
        "approval_sha256": _file_digest(Path(approval_file).expanduser().resolve()) if approval_file else None,
        "approved_by": approval_payload.get("approved_by") if approval_payload else None,
        "applied_ids": list(engine["applied_ids"]),
        "transformed_root": str(transformed_root),
        "transformed_source_tree_sha256": _source_tree_digest(transformed_root),
        "engine_receipt": engine,
        "completed_at": datetime.now(timezone.utc).isoformat(),
    }
    receipt = output / "workflow_apply_receipt.json"
    receipt.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return WorkflowApplyResult("PASS", output, receipt, transformed_root, tuple(engine["applied_ids"]))


def advance_workflow_state(
    state_file: str | Path,
    *,
    workflow_file: str | Path,
    receipt_file: str | Path,
    approval_file: str | Path | None = None,
    output: str | Path | None = None,
) -> Path:
    state_path, state = _load_state(state_file)
    workflow = _load_workflow(workflow_file)
    if workflow.get("state_sha256") != _file_digest(state_path):
        raise WorkflowError("workflow was generated from a different or stale state file")
    receipt_path = Path(receipt_file).expanduser().resolve()
    try:
        receipt = json.loads(receipt_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise WorkflowError(f"cannot read workflow receipt: {exc}") from exc
    if receipt.get("status") != "PASS":
        raise WorkflowError("only PASS receipts can advance workflow state")
    if receipt.get("workflow_sha256") != _file_digest(Path(workflow_file).expanduser().resolve()):
        raise WorkflowError("receipt workflow hash is stale")
    allowed = set(str(item) for item in workflow.get("ready_automatic_ids", [])) | set(
        str(item) for item in workflow.get("ready_approval_ids", [])
    )
    applied = set(str(item) for item in receipt.get("applied_ids", []))
    if not applied or not applied.issubset(allowed):
        raise WorkflowError("receipt contains candidates outside the workflow ready set")
    rejected: list[str] = []
    if approval_file:
        approval = json.loads(Path(approval_file).expanduser().resolve().read_text(encoding="utf-8"))
        rejected = [str(item) for item in approval.get("rejected_candidates", [])]
    history = list(state.get("stage_history", []))
    history.append({
        "workflow_file": str(Path(workflow_file).expanduser().resolve()),
        "workflow_sha256": _file_digest(Path(workflow_file).expanduser().resolve()),
        "receipt": str(receipt_path),
        "receipt_sha256": _file_digest(receipt_path),
        "applied_candidates": sorted(applied),
        "rejected_candidates": sorted(rejected),
        "input_source_root": state.get("source_root"),
        "input_source_tree_sha256": state.get("source_tree_sha256"),
        "output_source_root": receipt.get("transformed_root"),
        "output_source_tree_sha256": receipt.get("transformed_source_tree_sha256"),
        "completed_at": receipt.get("completed_at"),
    })
    state["stage_history"] = history
    state["source_root"] = str(Path(str(receipt["transformed_root"])).resolve())
    state["source_tree_sha256"] = str(receipt["transformed_source_tree_sha256"])
    state["applied_candidates"] = []
    state["rejected_candidates"] = []
    # Any source change invalidates evidence about the current compiled/regression state.
    for volatile_gate in (
        "GATE-READ_ONLY_ANALYSIS",
        "GATE-GFORTRAN_PORTABILITY",
        "GATE-FORTRAN_REGRESSION_PASS",
        "GATE-PYTHON_MIGRATION_READY",
    ):
        gate = state.get("gates", {}).get(volatile_gate)
        if isinstance(gate, dict) and gate.get("status") == "PASS":
            gate["status"] = "REVIEW_REQUIRED"
            gate["note"] = "Invalidated by a source-changing workflow stage; rerun validation on the transformed tree."
            gate["recorded_at"] = datetime.now(timezone.utc).isoformat()
    state["updated_at"] = datetime.now(timezone.utc).isoformat()
    destination = Path(output).expanduser().resolve() if output else state_path
    destination.write_text(json.dumps(state, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return destination


def _rule_for(suggestion: dict[str, Any]) -> CandidateRule:
    kind = str(suggestion.get("kind", ""))
    return _RULES.get(kind, _DEFAULT_RULE)


def _effective_category(suggestion: dict[str, Any], base: str, rule: CandidateRule) -> str:
    if rule.force_approval and _machine_applicable(suggestion) and base in {"AUTOMATIC", "APPROVAL_REQUIRED"}:
        return "APPROVAL_REQUIRED"
    return base


def _explicit_dependencies(suggestion: dict[str, Any]) -> tuple[tuple[str, ...], tuple[str, ...]]:
    details = suggestion.get("details") if isinstance(suggestion.get("details"), dict) else {}
    raw = []
    for key in ("workflow_prerequisites", "prerequisites", "depends_on"):
        value = details.get(key)
        if isinstance(value, list):
            raw.extend(str(item) for item in value)
    gates = tuple(item for item in raw if item.startswith("GATE-"))
    candidates = tuple(item for item in raw if not item.startswith("GATE-"))
    return gates, candidates


def _apply_phase_barriers(rows: list[dict[str, Any]]) -> None:
    phases = sorted(set(int(row["phase"]) for row in rows))
    for phase in phases:
        earlier = [row for row in rows if int(row["phase"]) < phase and row.get("blocks_later_phases")]
        blockers = [
            row["id"]
            for row in earlier
            if row["readiness"] not in {"APPLIED", "INFORMATIONAL"}
        ]
        if not blockers:
            continue
        for row in rows:
            if int(row["phase"]) != phase:
                continue
            if row["readiness"] in {"READY_AUTOMATIC", "READY_APPROVAL", "WAITING_AUTOMATIC", "WAITING_APPROVAL"}:
                row["readiness"] = "WAITING_PHASE"
                row["missing_candidates"] = sorted(set(row["missing_candidates"]) | set(blockers))


def _validate_state_binding(state: dict[str, Any], manifest: dict[str, Any], suggestions: list[dict[str, Any]]) -> None:
    source_root = Path(str(manifest["source_root"])).expanduser().resolve()
    if str(state.get("source_root")) != str(source_root):
        raise WorkflowError(
            "workflow state points to a different source tree; regenerate the plan from the state's current source root"
        )
    if state.get("source_tree_sha256") != _source_tree_digest(source_root):
        raise WorkflowError("workflow state source-tree hash is stale")


def _validate_workflow_binding(workflow: dict[str, Any], manifest: dict[str, Any], suggestions: list[dict[str, Any]]) -> None:
    if workflow.get("plan_sha256") != _plan_digest(manifest, suggestions):
        raise WorkflowError("workflow plan hash is stale")
    source_root = Path(str(manifest["source_root"])).expanduser().resolve()
    if workflow.get("source_tree_sha256") != _source_tree_digest(source_root):
        raise WorkflowError("workflow source-tree hash is stale")


def _load_state(path: str | Path) -> tuple[Path, dict[str, Any]]:
    state_path = Path(path).expanduser().resolve()
    try:
        state = json.loads(state_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise WorkflowError(f"cannot read workflow state: {exc}") from exc
    if not isinstance(state, dict) or not isinstance(state.get("gates"), dict):
        raise WorkflowError("workflow state is malformed")
    return state_path, state


def _load_workflow(path: str | Path) -> dict[str, Any]:
    workflow_path = Path(path).expanduser().resolve()
    try:
        workflow = json.loads(workflow_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise WorkflowError(f"cannot read workflow plan: {exc}") from exc
    if not isinstance(workflow, dict) or not isinstance(workflow.get("candidates"), list):
        raise WorkflowError("workflow plan is malformed")
    return workflow


def _prepare_output(path: str | Path, *, overwrite: bool) -> Path:
    output = Path(path).expanduser().resolve()
    if output.exists() and any(output.iterdir()):
        if not overwrite:
            raise WorkflowError(f"output directory is not empty: {output}")
        shutil.rmtree(output)
    output.mkdir(parents=True, exist_ok=True)
    return output


def _write_summary_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    fields = [
        "id", "kind", "original_category", "effective_category", "phase", "phase_name", "readiness",
        "prerequisite_gates", "candidate_dependencies", "missing_gates", "failed_gates", "missing_candidates",
        "provides_gates", "path", "program_unit", "line", "message",
    ]
    with path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            rendered = {key: row.get(key) for key in fields}
            for key in (
                "prerequisite_gates", "candidate_dependencies", "missing_gates", "failed_gates", "missing_candidates", "provides_gates"
            ):
                rendered[key] = ";".join(str(item) for item in rendered.get(key, []))
            writer.writerow(rendered)


def _next_action_markdown(payload: dict[str, Any]) -> str:
    lines = [
        "# Next workflow action",
        "",
        f"- Status: **{payload['status']}**",
        f"- Current phase: `{payload.get('earliest_active_phase_name')}`",
        f"- Action: `{payload['next_action']}`",
        f"- Plan SHA-256: `{payload['plan_sha256']}`",
        f"- Source SHA-256: `{payload['source_tree_sha256']}`",
        "",
    ]
    if payload["ready_approval_ids"]:
        lines.extend([
            "## Human approval required before automatic edits",
            "",
            *[f"- `{item}`" for item in payload["ready_approval_ids"]],
            "",
            "The agent must stop. A human may use `fortran-modernize approve-ready` for selected IDs.",
        ])
    elif payload["ready_automatic_ids"]:
        lines.extend([
            "## Ready automatic candidates",
            "",
            *[f"- `{item}`" for item in payload["ready_automatic_ids"]],
            "",
            "Apply only through `fortran-modernize apply-ready` using this workflow plan.",
        ])
    else:
        waiting = [row for row in payload["candidates"] if row["readiness"].startswith("WAITING")]
        blocked = [row for row in payload["candidates"] if row["readiness"] in {"BLOCKED", "BLOCKED_BY_FAILED_GATE", "MANUAL_REVIEW", "REJECTED"}]
        if waiting:
            lines.extend(["## Waiting prerequisites", ""])
            for row in waiting:
                dependencies = row["missing_gates"] + row["missing_candidates"]
                lines.append(f"- `{row['id']}`: {', '.join(dependencies) or row['readiness']}")
        if blocked:
            lines.extend(["", "## Blockers", ""])
            for row in blocked:
                lines.append(f"- `{row['id']}`: {row['readiness']}")
    lines.append("")
    return "\n".join(lines)
