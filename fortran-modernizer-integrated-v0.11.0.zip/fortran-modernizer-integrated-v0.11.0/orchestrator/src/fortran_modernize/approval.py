from __future__ import annotations

import csv
import hashlib
import json
import shutil
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable

from fortran_refactor.apply import ApplyError, apply_plan
from fortran_refactor.compiler import VerificationError


APPROVAL_CONFIRMATION = "I APPROVE THESE FORTRAN CHANGES"
_MUTATION_KEYS = (
    "edits",
    "file_edits",
    "file_replacements",
    "generated_files",
    "deleted_files",
)
_SOURCE_SUFFIXES = {
    ".f",
    ".for",
    ".ftn",
    ".f77",
    ".f90",
    ".f95",
    ".f03",
    ".f08",
    ".inc",
}


class ApprovalWorkflowError(RuntimeError):
    def __init__(self, message: str, *, report: Path | None = None) -> None:
        super().__init__(message)
        self.report = report


@dataclass(frozen=True)
class PlanClassificationResult:
    status: str
    output_directory: Path
    catalog: Path
    review_queue: Path
    summary_csv: Path
    approval_template: Path
    counts: dict[str, int]


@dataclass(frozen=True)
class ApprovalResult:
    status: str
    approval: Path
    approved_ids: tuple[str, ...]
    rejected_ids: tuple[str, ...]


@dataclass(frozen=True)
class ApprovedApplyResult:
    status: str
    output_directory: Path
    receipt: Path
    applied_ids: tuple[str, ...]
    transformed_root: Path


def classify_plan(
    plan_directory: str | Path,
    *,
    output_directory: str | Path,
    overwrite: bool = False,
) -> PlanClassificationResult:
    plan, manifest, suggestions = _load_plan(plan_directory)
    output = _prepare_output(output_directory, overwrite=overwrite)

    catalog_rows: list[dict[str, Any]] = []
    counts = {
        "AUTOMATIC": 0,
        "APPROVAL_REQUIRED": 0,
        "MANUAL_REVIEW": 0,
        "BLOCKED": 0,
        "INFORMATIONAL": 0,
    }
    for suggestion in suggestions:
        category = _candidate_category(suggestion)
        counts[category] += 1
        details = suggestion.get("details") if isinstance(suggestion.get("details"), dict) else {}
        catalog_rows.append(
            {
                "id": str(suggestion.get("id", "")),
                "category": category,
                "safety": str(suggestion.get("safety", "")),
                "kind": str(suggestion.get("kind", "")),
                "machine_applicable": _machine_applicable(suggestion),
                "path": suggestion.get("path"),
                "program_unit": suggestion.get("program_unit"),
                "line": suggestion.get("line"),
                "message": suggestion.get("message"),
                "rationale": suggestion.get("rationale"),
                "diagnostic_codes": list(suggestion.get("diagnostic_codes") or []),
                "candidate_sha256": _candidate_digest(suggestion),
                "preview_available": bool(
                    suggestion.get("applied_to_preview")
                    or details.get("edits")
                    or details.get("file_edits")
                    or details.get("file_replacements")
                    or details.get("generated_files")
                    or details.get("deleted_files")
                ),
            }
        )

    source_root = Path(str(manifest["source_root"])).expanduser().resolve()
    payload = {
        "schema_version": "1.0",
        "toolchain_version": "0.11.0",
        "status": "REVIEW_REQUIRED" if counts["APPROVAL_REQUIRED"] else "PASS",
        "plan_directory": str(plan),
        "plan_sha256": _plan_digest(manifest, suggestions),
        "source_root": str(source_root),
        "source_tree_sha256": _source_tree_digest(source_root),
        "counts": counts,
        "candidates": catalog_rows,
    }
    catalog = output / "candidate_catalog.json"
    catalog.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    summary_csv = output / "candidate_summary.csv"
    with summary_csv.open("w", encoding="utf-8", newline="") as stream:
        fieldnames = [
            "id", "category", "safety", "kind", "machine_applicable", "path",
            "program_unit", "line", "message", "rationale", "diagnostic_codes",
            "candidate_sha256", "preview_available",
        ]
        writer = csv.DictWriter(stream, fieldnames=fieldnames)
        writer.writeheader()
        for row in catalog_rows:
            rendered = dict(row)
            rendered["diagnostic_codes"] = ";".join(row["diagnostic_codes"])
            writer.writerow(rendered)

    review_queue = output / "COPILOT_REVIEW_QUEUE.md"
    review_queue.write_text(_review_markdown(payload), encoding="utf-8")

    template = {
        "schema_version": "1.0",
        "plan_directory": str(plan),
        "approved_candidates": [],
        "rejected_candidates": [],
        "note": (
            "This is an unapproved template. A human must run `fortran-modernize approve-plan`; "
            "Copilot must not mark candidates approved by editing this file."
        ),
    }
    approval_template = output / "approval_template.json"
    approval_template.write_text(json.dumps(template, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    return PlanClassificationResult(
        status=payload["status"],
        output_directory=output,
        catalog=catalog,
        review_queue=review_queue,
        summary_csv=summary_csv,
        approval_template=approval_template,
        counts=counts,
    )


def create_approval(
    plan_directory: str | Path,
    *,
    approved_ids: Iterable[str],
    rejected_ids: Iterable[str] = (),
    approved_by: str,
    output: str | Path,
    confirmation: str,
    note: str | None = None,
) -> ApprovalResult:
    if confirmation != APPROVAL_CONFIRMATION:
        raise ApprovalWorkflowError(
            "human confirmation phrase does not match; approval was not created"
        )
    actor = approved_by.strip()
    if not actor:
        raise ApprovalWorkflowError("approved_by must identify the human reviewer")

    plan, manifest, suggestions = _load_plan(plan_directory)
    by_id = {str(item.get("id")): item for item in suggestions}
    approved = tuple(dict.fromkeys(str(item) for item in approved_ids))
    rejected = tuple(dict.fromkeys(str(item) for item in rejected_ids))
    overlap = sorted(set(approved) & set(rejected))
    if overlap:
        raise ApprovalWorkflowError(
            "candidate IDs cannot be both approved and rejected: " + ", ".join(overlap)
        )
    unknown = sorted((set(approved) | set(rejected)) - set(by_id))
    if unknown:
        raise ApprovalWorkflowError("unknown candidate IDs: " + ", ".join(unknown))
    if not approved and not rejected:
        raise ApprovalWorkflowError("at least one approved or rejected candidate ID is required")

    for candidate_id in approved:
        item = by_id[candidate_id]
        if _candidate_category(item) != "APPROVAL_REQUIRED":
            raise ApprovalWorkflowError(
                f"{candidate_id} is not an applicable approval-required candidate"
            )

    source_root = Path(str(manifest["source_root"])).expanduser().resolve()
    candidate_snapshot = {
        candidate_id: {
            "candidate_sha256": _candidate_digest(by_id[candidate_id]),
            "safety": by_id[candidate_id].get("safety"),
            "kind": by_id[candidate_id].get("kind"),
            "path": by_id[candidate_id].get("path"),
            "program_unit": by_id[candidate_id].get("program_unit"),
            "line": by_id[candidate_id].get("line"),
            "message": by_id[candidate_id].get("message"),
        }
        for candidate_id in sorted(set(approved) | set(rejected))
    }
    payload: dict[str, Any] = {
        "schema_version": "1.0",
        "toolchain_version": "0.11.0",
        "approval_status": "APPROVED",
        "plan_directory": str(plan),
        "plan_sha256": _plan_digest(manifest, suggestions),
        "source_root": str(source_root),
        "source_tree_sha256": _source_tree_digest(source_root),
        "approved_candidates": list(approved),
        "rejected_candidates": list(rejected),
        "candidate_snapshot": candidate_snapshot,
        "approved_by": actor,
        "approved_at": datetime.now(timezone.utc).isoformat(),
        "human_confirmation": True,
    }
    if note:
        payload["note"] = note

    destination = Path(output).expanduser().resolve()
    destination.parent.mkdir(parents=True, exist_ok=True)
    if destination.exists():
        raise ApprovalWorkflowError(f"approval output already exists: {destination}")
    destination.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    try:
        destination.chmod(0o444)
    except OSError:
        pass
    return ApprovalResult(
        status="APPROVED",
        approval=destination,
        approved_ids=approved,
        rejected_ids=rejected,
    )


def validate_approval(
    plan_directory: str | Path,
    approval_file: str | Path,
) -> list[str]:
    errors: list[str] = []
    try:
        _plan, manifest, suggestions = _load_plan(plan_directory)
    except ApprovalWorkflowError as exc:
        return [str(exc)]
    approval_path = Path(approval_file).expanduser().resolve()
    try:
        approval = json.loads(approval_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        return [f"cannot read approval file: {exc}"]
    if not isinstance(approval, dict):
        return ["approval file must contain a JSON object"]

    expected_plan = _plan_digest(manifest, suggestions)
    if approval.get("plan_sha256") != expected_plan:
        errors.append("approval plan hash does not match the current plan")

    source_root = Path(str(manifest["source_root"])).expanduser().resolve()
    current_source_hash = _source_tree_digest(source_root)
    if approval.get("source_tree_sha256") != current_source_hash:
        errors.append("approval source tree hash is stale")
    if str(approval.get("source_root")) != str(source_root):
        errors.append("approval source root does not match the plan")
    if approval.get("approval_status") != "APPROVED" or approval.get("human_confirmation") is not True:
        errors.append("approval does not contain a completed human confirmation")
    if not str(approval.get("approved_by") or "").strip():
        errors.append("approval does not identify the human reviewer")

    by_id = {str(item.get("id")): item for item in suggestions}
    approved = approval.get("approved_candidates")
    rejected = approval.get("rejected_candidates")
    if not isinstance(approved, list) or not all(isinstance(item, str) for item in approved):
        errors.append("approved_candidates must be a list of candidate IDs")
        approved = []
    if not isinstance(rejected, list) or not all(isinstance(item, str) for item in rejected):
        errors.append("rejected_candidates must be a list of candidate IDs")
        rejected = []
    overlap = sorted(set(approved) & set(rejected))
    if overlap:
        errors.append("approved and rejected candidate IDs overlap: " + ", ".join(overlap))

    snapshot = approval.get("candidate_snapshot")
    if not isinstance(snapshot, dict):
        errors.append("candidate_snapshot must be a JSON object")
        snapshot = {}
    for candidate_id in approved:
        item = by_id.get(candidate_id)
        if item is None:
            errors.append(f"approved candidate no longer exists: {candidate_id}")
            continue
        if _candidate_category(item) != "APPROVAL_REQUIRED":
            errors.append(f"approved candidate is no longer approval-required and applicable: {candidate_id}")
        frozen = snapshot.get(candidate_id)
        if not isinstance(frozen, dict) or frozen.get("candidate_sha256") != _candidate_digest(item):
            errors.append(f"approved candidate snapshot is stale: {candidate_id}")
    for candidate_id in rejected:
        item = by_id.get(candidate_id)
        if item is None:
            errors.append(f"rejected candidate no longer exists: {candidate_id}")
            continue
        frozen = snapshot.get(candidate_id)
        if not isinstance(frozen, dict) or frozen.get("candidate_sha256") != _candidate_digest(item):
            errors.append(f"rejected candidate snapshot is stale: {candidate_id}")
    return errors


def apply_approved_plan(
    plan_directory: str | Path,
    *,
    output_directory: str | Path,
    approval_file: str | Path | None = None,
    all_automatic: bool = False,
    include_dirs: Iterable[str | Path] = (),
    compile_check: bool = False,
) -> ApprovedApplyResult:
    approved_ids: set[str] = set()
    approval_payload: dict[str, Any] | None = None
    approval_path: Path | None = None
    if approval_file is not None:
        approval_path = Path(approval_file).expanduser().resolve()
        errors = validate_approval(plan_directory, approval_path)
        if errors:
            raise ApprovalWorkflowError("approval validation failed: " + "; ".join(errors))
        approval_payload = json.loads(approval_path.read_text(encoding="utf-8"))
        approved_ids = set(str(item) for item in approval_payload["approved_candidates"])
    if not all_automatic and not approved_ids:
        raise ApprovalWorkflowError(
            "nothing is authorized: provide --all-automatic and/or a valid approval file"
        )

    output = Path(output_directory).expanduser().resolve()
    try:
        receipt_payload = apply_plan(
            Path(plan_directory),
            output,
            approved_ids,
            all_automatic,
            bool(approved_ids),
            [Path(item).expanduser().resolve() for item in include_dirs],
            compile_check,
        )
    except (ApplyError, VerificationError) as exc:
        raise ApprovalWorkflowError(str(exc)) from exc

    transformed_root = Path(str(receipt_payload["transformed_root"])).resolve()
    receipt = output / "human_approval_receipt.json"
    payload = {
        "schema_version": "1.0",
        "toolchain_version": "0.11.0",
        "status": "PASS",
        "plan_directory": str(Path(plan_directory).expanduser().resolve()),
        "approval_file": str(approval_path) if approval_path else None,
        "approval_sha256": _file_digest(approval_path) if approval_path else None,
        "approved_by": approval_payload.get("approved_by") if approval_payload else None,
        "approved_at": approval_payload.get("approved_at") if approval_payload else None,
        "all_automatic": all_automatic,
        "applied_ids": list(receipt_payload["applied_ids"]),
        "transformed_root": str(transformed_root),
        "transformed_source_tree_sha256": _source_tree_digest(transformed_root),
        "engine_receipt": receipt_payload,
        "completed_at": datetime.now(timezone.utc).isoformat(),
    }
    receipt.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    _append_audit(
        output / "approval_audit.jsonl",
        {
            "event": "apply-approved",
            "timestamp": payload["completed_at"],
            "status": "PASS",
            "approval_file": payload["approval_file"],
            "applied_ids": payload["applied_ids"],
            "transformed_root": payload["transformed_root"],
        },
    )
    return ApprovedApplyResult(
        status="PASS",
        output_directory=output,
        receipt=receipt,
        applied_ids=tuple(receipt_payload["applied_ids"]),
        transformed_root=transformed_root,
    )


def install_copilot_workflow(
    target_repository: str | Path,
    *,
    overwrite: bool = False,
) -> dict[str, Any]:
    target = Path(target_repository).expanduser().resolve()
    if not target.is_dir():
        raise ApprovalWorkflowError(f"target repository does not exist: {target}")
    bundle_root = Path(__file__).resolve().parents[3]
    template = bundle_root / "copilot-template"
    if not template.is_dir():
        raise ApprovalWorkflowError(f"Copilot workflow template is missing: {template}")

    copied: list[str] = []
    skipped: list[str] = []
    for source in sorted(
        path for path in template.rglob("*")
        if path.is_file()
        and "__pycache__" not in path.parts
        and path.suffix not in {".pyc", ".pyo"}
    ):
        relative = source.relative_to(template)
        destination = target / relative
        if destination.exists() and not overwrite:
            skipped.append(relative.as_posix())
            continue
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, destination)
        copied.append(relative.as_posix())

    status_file = target / "reports" / "COPILOT_STAGE_STATUS.md"
    if not status_file.exists():
        status_file.parent.mkdir(parents=True, exist_ok=True)
        status_file.write_text(
            "# Copilot stage status\n\n"
            "- Status: NOT_STARTED\n"
            "- Current successful source tree: not set\n"
            "- Current stage: project intake\n"
            "- Pending approval IDs: none\n"
            "- First blocker: none recorded\n"
            "- Next action: run read-only intake with the Fortran Modernizer agent\n",
            encoding="utf-8",
        )
        copied.append("reports/COPILOT_STAGE_STATUS.md")

    manifest = target / "reports" / "copilot_workflow_installation.json"
    manifest.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "schema_version": "1.0",
        "toolchain_version": "0.11.0",
        "installed_at": datetime.now(timezone.utc).isoformat(),
        "target_repository": str(target),
        "copied": copied,
        "skipped_existing": skipped,
        "hook_preview_warning": (
            "VS Code agent hooks are a Preview feature. Review the scripts before enabling them."
        ),
    }
    manifest.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return {"status": "PASS", "manifest": manifest, "copied": copied, "skipped": skipped}


def _load_plan(plan_directory: str | Path) -> tuple[Path, dict[str, Any], list[dict[str, Any]]]:
    plan = Path(plan_directory).expanduser().resolve()
    manifest_path = plan / "manifest.json"
    suggestions_path = plan / "suggestions.json"
    if not manifest_path.is_file() or not suggestions_path.is_file():
        raise ApprovalWorkflowError(
            "plan directory must contain manifest.json and suggestions.json"
        )
    try:
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        suggestions = json.loads(suggestions_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise ApprovalWorkflowError(f"cannot read plan: {exc}") from exc
    if not isinstance(manifest, dict) or not isinstance(suggestions, list):
        raise ApprovalWorkflowError("plan manifest or suggestions have an invalid JSON shape")
    if not manifest.get("source_root"):
        raise ApprovalWorkflowError("plan manifest does not define source_root")
    for item in suggestions:
        if not isinstance(item, dict) or not item.get("id"):
            raise ApprovalWorkflowError("every suggestion must be a JSON object with an id")
    return plan, manifest, suggestions


def _candidate_category(item: dict[str, Any]) -> str:
    safety = str(item.get("safety", "")).lower()
    applicable = _machine_applicable(item)
    if safety == "automatic-preview" and applicable:
        return "AUTOMATIC"
    if safety == "approval-required" and applicable:
        return "APPROVAL_REQUIRED"
    if safety in {"manual-review", "review-candidate"}:
        return "MANUAL_REVIEW"
    if safety in {"blocked", "unsupported", "analysis-only"}:
        return "BLOCKED"
    if safety in {"not-needed", "informational", "pass"}:
        return "INFORMATIONAL"
    return "BLOCKED" if not applicable else "MANUAL_REVIEW"


def _machine_applicable(item: dict[str, Any]) -> bool:
    details = item.get("details")
    return isinstance(details, dict) and any(bool(details.get(key)) for key in _MUTATION_KEYS)


def _canonical_digest(value: Any) -> str:
    rendered = json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    return hashlib.sha256(rendered).hexdigest()


def _candidate_digest(candidate: dict[str, Any]) -> str:
    return _canonical_digest(candidate)


def _plan_digest(manifest: dict[str, Any], suggestions: list[dict[str, Any]]) -> str:
    return _canonical_digest({"manifest": manifest, "suggestions": suggestions})


def _file_digest(path: Path | None) -> str | None:
    if path is None:
        return None
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _source_tree_digest(root: Path) -> str:
    if not root.is_dir():
        raise ApprovalWorkflowError(f"source root does not exist: {root}")
    digest = hashlib.sha256()
    files = sorted(
        path for path in root.rglob("*")
        if path.is_file() and path.suffix.lower() in _SOURCE_SUFFIXES
    )
    for path in files:
        relative = path.relative_to(root).as_posix().encode("utf-8")
        content = path.read_bytes()
        digest.update(len(relative).to_bytes(8, "big"))
        digest.update(relative)
        digest.update(len(content).to_bytes(8, "big"))
        digest.update(content)
    return digest.hexdigest()


def _prepare_output(path: str | Path, *, overwrite: bool) -> Path:
    output = Path(path).expanduser().resolve()
    if output.exists() and any(output.iterdir()):
        if not overwrite:
            raise ApprovalWorkflowError(
                f"output directory is not empty: {output}; pass --overwrite to replace it"
            )
        shutil.rmtree(output)
    output.mkdir(parents=True, exist_ok=True)
    return output


def _append_audit(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as stream:
        stream.write(json.dumps(payload, ensure_ascii=False, sort_keys=True) + "\n")


def _review_markdown(payload: dict[str, Any]) -> str:
    counts = payload["counts"]
    lines = [
        "# Copilot review queue",
        "",
        "This report is generated from the tool plan. It does not approve any change.",
        "",
        f"- Status: **{payload['status']}**",
        f"- Automatic: {counts['AUTOMATIC']}",
        f"- Approval required: {counts['APPROVAL_REQUIRED']}",
        f"- Manual review only: {counts['MANUAL_REVIEW']}",
        f"- Blocked: {counts['BLOCKED']}",
        f"- Informational: {counts['INFORMATIONAL']}",
        f"- Plan SHA-256: `{payload['plan_sha256']}`",
        f"- Source tree SHA-256: `{payload['source_tree_sha256']}`",
        "",
        "## Candidates",
        "",
        "| ID | Category | Kind | Location | Recommendation / evidence |",
        "|---|---|---|---|---|",
    ]
    for item in payload["candidates"]:
        location = str(item.get("path") or "")
        if item.get("program_unit"):
            location += f" :: {item['program_unit']}"
        if item.get("line"):
            location += f":{item['line']}"
        evidence = str(item.get("message") or item.get("rationale") or "").replace("|", "\\|")
        lines.append(
            f"| `{item['id']}` | {item['category']} | `{item['kind']}` | "
            f"{location.replace('|', '\\|')} | {evidence} |"
        )
    lines.extend(
        [
            "",
            "## Human approval procedure",
            "",
            "A human reviewer must run `fortran-modernize approve-plan` in a terminal.",
            "The Fortran Modernizer agent and hooks are instructed to refuse that command.",
            "Approval is bound to both the plan hash and the current Fortran source-tree hash.",
            "",
        ]
    )
    return "\n".join(lines)
