from __future__ import annotations

import csv
import hashlib
import json
import shutil
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable, Literal

from .distribution import validate_distribution_bundle

CompatibilityStatus = Literal["PASS", "REVIEW_REQUIRED", "BLOCKED"]
_DEFAULT_PYTHON_VERSIONS = ("3.11", "3.12", "3.13", "3.14")
_BINARY_SUFFIXES = {".so", ".pyd", ".dll", ".dylib", ".o", ".obj", ".a", ".lib", ".exe", ".pyc"}


class CompatibilitySuiteError(RuntimeError):
    def __init__(self, message: str, *, manifest: Path | None = None):
        super().__init__(message)
        self.manifest = manifest


@dataclass(frozen=True)
class CompatibilitySuiteResult:
    status: CompatibilityStatus
    output_directory: Path
    manifest: Path
    workflow: Path
    validation_report: Path
    summary: Path


@dataclass(frozen=True)
class CompatibilitySummaryResult:
    status: CompatibilityStatus
    output_directory: Path
    report: Path
    csv: Path
    markdown: Path


def build_compatibility_suite(
    *,
    linux_kit: str | Path,
    windows_kit: str | Path,
    output_directory: str | Path,
    python_versions: Iterable[str] = _DEFAULT_PYTHON_VERSIONS,
    overwrite: bool = False,
) -> CompatibilitySuiteResult:
    """Package source-only target kits with a GitHub Actions compatibility matrix.

    The generated workflow rebuilds native Cython and optional Fortran backends on
    each requested OS/Python cell, executes the retained numerical self-checks,
    uploads cell evidence, and merges the results into JSON/CSV/Markdown reports.
    """

    versions = _normalize_python_versions(python_versions)
    linux = Path(linux_kit).expanduser().resolve()
    windows = Path(windows_kit).expanduser().resolve()
    for label, kit, expected in (
        ("linux", linux, "linux-wsl"),
        ("windows", windows, "windows-native"),
    ):
        errors = validate_distribution_bundle(kit)
        if errors:
            raise CompatibilitySuiteError(
                f"invalid {label} distribution kit: " + "; ".join(errors)
            )
        manifest = _load_json(kit / "distribution_manifest.json")
        if manifest.get("target") != expected:
            raise CompatibilitySuiteError(
                f"{label} kit target must be {expected!r}, got {manifest.get('target')!r}"
            )

    output = Path(output_directory).expanduser().resolve()
    if output.exists() and any(output.iterdir()):
        if not overwrite:
            raise CompatibilitySuiteError(
                f"output directory is not empty: {output}; pass overwrite=True"
            )
        shutil.rmtree(output)
    output.mkdir(parents=True, exist_ok=True)

    kits = output / "kits"
    tools = output / "tools"
    workflows = output / ".github" / "workflows"
    results = output / "compatibility-results"
    for path in (kits, tools, workflows, results):
        path.mkdir(parents=True, exist_ok=True)

    shutil.copytree(linux, kits / "linux-wsl")
    shutil.copytree(windows, kits / "windows-native")

    matrix: list[dict[str, str]] = []
    for runner, target, kit_name in (
        ("ubuntu-latest", "linux-wsl", "linux-wsl"),
        ("windows-latest", "windows-native", "windows-native"),
    ):
        for version in versions:
            cell_id = f"{target}-py{version.replace('.', '')}"
            matrix.append(
                {
                    "id": cell_id,
                    "runner": runner,
                    "target": target,
                    "kit": f"kits/{kit_name}",
                    "python": version,
                }
            )

    manifest_payload: dict[str, Any] = {
        "schema_version": "1.0",
        "toolchain_version": "0.11.0",
        "status": "PASS",
        "python_versions": list(versions),
        "kits": {
            "linux-wsl": {
                "path": "kits/linux-wsl",
                "manifest_sha256": _sha256(kits / "linux-wsl" / "distribution_manifest.json"),
            },
            "windows-native": {
                "path": "kits/windows-native",
                "manifest_sha256": _sha256(kits / "windows-native" / "distribution_manifest.json"),
            },
        },
        "matrix": matrix,
        "ci": {
            "provider": "github-actions",
            "workflow": ".github/workflows/fortran-modernization-compatibility.yml",
            "actions": {
                "checkout": "actions/checkout@v6",
                "setup_python": "actions/setup-python@v6",
                "setup_fortran": "fortran-lang/setup-fortran@v1",
                "upload_artifact": "actions/upload-artifact@v4",
                "download_artifact": "actions/download-artifact@v4",
            },
            "fortran_compiler": {"compiler": "gcc", "version": "14"},
        },
    }
    manifest_path = output / "compatibility_suite_manifest.json"
    _write_json(manifest_path, manifest_payload)

    runner_path = tools / "run_compatibility_cell.py"
    runner_path.write_text(_cell_runner_source(), encoding="utf-8")
    merger_path = tools / "summarize_compatibility.py"
    merger_path.write_text(_summary_cli_source(), encoding="utf-8")
    workflow = workflows / "fortran-modernization-compatibility.yml"
    workflow.write_text(_github_workflow(matrix), encoding="utf-8")
    (output / "README_COMPATIBILITY.md").write_text(
        _compatibility_readme(versions), encoding="utf-8"
    )

    validation_report = output / "compatibility_suite_validation.json"
    errors = validate_compatibility_suite(output)
    _write_json(
        validation_report,
        {
            "schema_version": "1.0",
            "toolchain_version": "0.11.0",
            "status": "PASS" if not errors else "BLOCKED",
            "errors": errors,
        },
    )
    if errors:
        raise CompatibilitySuiteError(
            "invalid compatibility suite: " + "; ".join(errors),
            manifest=manifest_path,
        )

    initial_summary = summarize_compatibility_results(
        suite_manifest=manifest_path,
        results_directory=results,
        output_directory=output / "compatibility-summary",
        overwrite=True,
    )
    return CompatibilitySuiteResult(
        status="PASS",
        output_directory=output,
        manifest=manifest_path,
        workflow=workflow,
        validation_report=validation_report,
        summary=initial_summary.report,
    )


def validate_compatibility_suite(root: str | Path) -> list[str]:
    base = Path(root).expanduser().resolve()
    manifest_path = base / "compatibility_suite_manifest.json"
    if not manifest_path.is_file():
        return ["compatibility_suite_manifest.json is missing"]
    try:
        payload = _load_json(manifest_path)
    except Exception as exc:
        return [f"cannot read compatibility suite manifest: {exc}"]

    errors: list[str] = []
    matrix = payload.get("matrix")
    if not isinstance(matrix, list) or not matrix:
        errors.append("compatibility matrix is empty")
        matrix = []
    ids: set[str] = set()
    for item in matrix:
        if not isinstance(item, dict):
            errors.append("invalid compatibility matrix cell")
            continue
        cell_id = item.get("id")
        if not isinstance(cell_id, str) or not cell_id:
            errors.append("matrix cell has no id")
        elif cell_id in ids:
            errors.append(f"duplicate matrix cell id: {cell_id}")
        else:
            ids.add(cell_id)
        kit = item.get("kit")
        if not isinstance(kit, str) or not (base / kit / "distribution_manifest.json").is_file():
            errors.append(f"matrix cell references missing kit: {kit!r}")

    required = (
        ".github/workflows/fortran-modernization-compatibility.yml",
        "tools/run_compatibility_cell.py",
        "tools/summarize_compatibility.py",
    )
    for relative in required:
        if not (base / relative).is_file():
            errors.append(f"missing compatibility artifact: {relative}")

    for script in (base / "tools").glob("*.py"):
        try:
            compile(script.read_text(encoding="utf-8"), str(script), "exec")
        except SyntaxError as exc:
            errors.append(f"invalid Python script {script.name}: {exc}")

    for path in (base / "kits").rglob("*"):
        if path.is_file() and path.suffix.lower() in _BINARY_SUFFIXES:
            errors.append(f"platform-specific binary leaked into compatibility suite: {path}")
    return errors


def summarize_compatibility_results(
    *,
    suite_manifest: str | Path,
    results_directory: str | Path,
    output_directory: str | Path,
    overwrite: bool = False,
) -> CompatibilitySummaryResult:
    manifest_path = Path(suite_manifest).expanduser().resolve()
    manifest = _load_json(manifest_path)
    matrix = manifest.get("matrix")
    if not isinstance(matrix, list) or not matrix:
        raise CompatibilitySuiteError("suite manifest contains no compatibility matrix")

    output = Path(output_directory).expanduser().resolve()
    if output.exists() and any(output.iterdir()):
        if not overwrite:
            raise CompatibilitySuiteError(
                f"output directory is not empty: {output}; pass overwrite=True"
            )
        shutil.rmtree(output)
    output.mkdir(parents=True, exist_ok=True)

    result_root = Path(results_directory).expanduser().resolve()
    discovered: dict[str, dict[str, Any]] = {}
    invalid_reports: list[str] = []
    if result_root.exists():
        for path in sorted(result_root.rglob("*.json")):
            try:
                payload = _load_json(path)
            except Exception:
                continue
            if payload.get("schema_version") != "1.0" or "cell_id" not in payload:
                continue
            cell_id = payload.get("cell_id")
            if not isinstance(cell_id, str):
                invalid_reports.append(str(path))
                continue
            if cell_id in discovered:
                invalid_reports.append(f"duplicate result for {cell_id}: {path}")
                continue
            payload["_source"] = str(path)
            discovered[cell_id] = payload

    rows: list[dict[str, Any]] = []
    for cell in matrix:
        if not isinstance(cell, dict):
            continue
        cell_id = str(cell.get("id", ""))
        result = discovered.get(cell_id)
        if result is None:
            rows.append(
                {
                    "cell_id": cell_id,
                    "runner": str(cell.get("runner", "")),
                    "target": str(cell.get("target", "")),
                    "python": str(cell.get("python", "")),
                    "status": "NOT_RUN",
                    "environment": "NOT_RUN",
                    "native_rebuild": "NOT_RUN",
                    "self_check": "NOT_RUN",
                    "fortran": "NOT_RUN",
                    "system": "",
                    "machine": "",
                    "source": "",
                }
            )
            continue
        checks = result.get("checks") if isinstance(result.get("checks"), dict) else {}
        native = result.get("native_rebuild") if isinstance(result.get("native_rebuild"), dict) else {}
        fortran = native.get("fortran") if isinstance(native.get("fortran"), dict) else {}
        rows.append(
            {
                "cell_id": cell_id,
                "runner": str(cell.get("runner", "")),
                "target": str(cell.get("target", "")),
                "python": str(cell.get("python", "")),
                "status": str(result.get("status", "BLOCKED")),
                "environment": str(checks.get("environment", "BLOCKED")),
                "native_rebuild": str(checks.get("native_rebuild", "BLOCKED")),
                "self_check": str(checks.get("self_check", "BLOCKED")),
                "fortran": str(fortran.get("status", "NOT_CONFIGURED")),
                "system": str(result.get("system", "")),
                "machine": str(result.get("machine", "")),
                "source": str(result.get("_source", "")),
            }
        )

    statuses = [row["status"] for row in rows]
    if invalid_reports or any(status == "BLOCKED" for status in statuses):
        overall: CompatibilityStatus = "BLOCKED"
    elif statuses and all(status == "PASS" for status in statuses):
        overall = "PASS"
    else:
        overall = "REVIEW_REQUIRED"

    report_payload = {
        "schema_version": "1.0",
        "toolchain_version": "0.11.0",
        "status": overall,
        "suite_manifest": str(manifest_path),
        "suite_manifest_sha256": _sha256(manifest_path),
        "planned_cells": len(rows),
        "passed_cells": sum(row["status"] == "PASS" for row in rows),
        "blocked_cells": sum(row["status"] == "BLOCKED" for row in rows),
        "not_run_cells": sum(row["status"] == "NOT_RUN" for row in rows),
        "invalid_reports": invalid_reports,
        "cells": rows,
    }
    report = output / "compatibility_matrix.json"
    _write_json(report, report_payload)

    csv_path = output / "compatibility_matrix.csv"
    fields = [
        "cell_id", "runner", "target", "python", "status", "environment",
        "native_rebuild", "self_check", "fortran", "system", "machine", "source",
    ]
    with csv_path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)

    markdown = output / "compatibility_matrix.md"
    markdown.write_text(_summary_markdown(report_payload), encoding="utf-8")
    return CompatibilitySummaryResult(
        status=overall,
        output_directory=output,
        report=report,
        csv=csv_path,
        markdown=markdown,
    )


def _normalize_python_versions(values: Iterable[str]) -> tuple[str, ...]:
    versions: list[str] = []
    for raw in values:
        value = str(raw).strip()
        parts = value.split(".")
        if len(parts) != 2 or not all(part.isdigit() for part in parts):
            raise CompatibilitySuiteError(
                f"Python version must use MAJOR.MINOR syntax: {raw!r}"
            )
        if int(parts[0]) < 3 or (int(parts[0]) == 3 and int(parts[1]) < 11):
            raise CompatibilitySuiteError("compatibility suite requires Python 3.11 or newer")
        if value not in versions:
            versions.append(value)
    if not versions:
        raise CompatibilitySuiteError("at least one Python version is required")
    return tuple(versions)


def _load_json(path: Path) -> dict[str, Any]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise CompatibilitySuiteError(f"JSON root must be an object: {path}")
    return payload


def _write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _github_workflow(matrix: list[dict[str, str]]) -> str:
    include_lines: list[str] = []
    for cell in matrix:
        include_lines.extend(
            [
                f"          - id: {cell['id']}",
                f"            runner: {cell['runner']}",
                f"            target: {cell['target']}",
                f"            kit: {cell['kit']}",
                f"            python: '{cell['python']}'",
            ]
        )
    include = "\n".join(include_lines)
    return f'''name: Fortran modernization compatibility

on:
  workflow_dispatch:
  push:
  pull_request:

permissions:
  contents: read

jobs:
  validate:
    name: ${{{{ matrix.id }}}}
    runs-on: ${{{{ matrix.runner }}}}
    timeout-minutes: 45
    strategy:
      fail-fast: false
      matrix:
        include:
{include}
    steps:
      - uses: actions/checkout@v6
      - uses: actions/setup-python@v6
        with:
          python-version: ${{{{ matrix.python }}}}
          cache: pip
          cache-dependency-path: ${{{{ matrix.kit }}}}/requirements-build.txt
      - name: Set up GNU Fortran
        uses: fortran-lang/setup-fortran@v1
        with:
          compiler: gcc
          version: '14'
      - name: Install build requirements
        run: python -m pip install -r "${{{{ matrix.kit }}}}/requirements-build.txt"
      - name: Rebuild and validate target
        run: >-
          python tools/run_compatibility_cell.py
          --suite-root .
          --kit "${{{{ matrix.kit }}}}"
          --cell-id "${{{{ matrix.id }}}}"
          --expected-target "${{{{ matrix.target }}}}"
          --output "compatibility-results/${{{{ matrix.id }}}}/compatibility_result.json"
      - name: Upload cell evidence
        if: always()
        uses: actions/upload-artifact@v4
        with:
          name: compatibility-${{{{ matrix.id }}}}
          if-no-files-found: warn
          path: |
            compatibility-results/${{{{ matrix.id }}}}
          retention-days: 30

  summarize:
    name: Compatibility matrix
    if: always()
    needs: validate
    runs-on: ubuntu-latest
    permissions:
      contents: read
    steps:
      - uses: actions/checkout@v6
      - uses: actions/setup-python@v6
        with:
          python-version: '3.13'
      - uses: actions/download-artifact@v4
        with:
          pattern: compatibility-*
          path: compatibility-results
          merge-multiple: true
      - name: Build compatibility reports
        continue-on-error: true
        run: >-
          python tools/summarize_compatibility.py
          --manifest compatibility_suite_manifest.json
          --results compatibility-results
          --output compatibility-summary
      - uses: actions/upload-artifact@v4
        if: always()
        with:
          name: compatibility-matrix
          path: compatibility-summary
          retention-days: 90
'''


def _cell_runner_source() -> str:
    return r'''#!/usr/bin/env python3
from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess
import sys
import time


def load(path):
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {}
    return value if isinstance(value, dict) else {}


def sha256(path):
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def run_stage(name, command, cwd, log_root, timeout):
    started = time.perf_counter()
    try:
        completed = subprocess.run(
            command, cwd=cwd, text=True, stdout=subprocess.PIPE,
            stderr=subprocess.PIPE, timeout=timeout,
        )
        returncode = completed.returncode
        stdout = completed.stdout
        stderr = completed.stderr
        error = None
    except subprocess.TimeoutExpired as exc:
        returncode = 124
        stdout = exc.stdout or ""
        stderr = exc.stderr or ""
        error = f"timeout after {timeout} seconds"
    elapsed = time.perf_counter() - started
    stage_root = log_root / name
    stage_root.mkdir(parents=True, exist_ok=True)
    (stage_root / "stdout.txt").write_text(str(stdout), encoding="utf-8")
    (stage_root / "stderr.txt").write_text(str(stderr), encoding="utf-8")
    payload = {
        "name": name,
        "status": "PASS" if returncode == 0 else "BLOCKED",
        "command": [str(item) for item in command],
        "returncode": returncode,
        "elapsed_seconds": elapsed,
        "error": error,
        "stdout": str((stage_root / "stdout.txt").resolve()),
        "stderr": str((stage_root / "stderr.txt").resolve()),
    }
    (stage_root / "stage.json").write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    return payload


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--suite-root", default=".")
    parser.add_argument("--kit", required=True)
    parser.add_argument("--cell-id", required=True)
    parser.add_argument("--expected-target", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--timeout", type=int, default=1200)
    args = parser.parse_args()

    suite = Path(args.suite_root).expanduser().resolve()
    source_kit = (suite / args.kit).resolve()
    output = Path(args.output).expanduser()
    if not output.is_absolute():
        output = (suite / output).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    log_root = output.parent / "stages"
    kit = output.parent / "work-kit"
    if kit.exists():
        shutil.rmtree(kit)
    shutil.copytree(source_kit, kit)

    manifest_path = kit / "distribution_manifest.json"
    manifest = load(manifest_path)
    target_matches = manifest.get("target") == args.expected_target
    stages = []
    for name, script in (
        ("environment", "probe_environment.py"),
        ("native_rebuild", "build_backends.py"),
        ("self_check", "self_check.py"),
    ):
        stages.append(
            run_stage(
                name,
                [sys.executable, str(kit / "tools" / script)],
                kit,
                log_root,
                args.timeout,
            )
        )

    environment = load(kit / "environment_report.json")
    native = load(kit / "native_rebuild_report.json")
    self_check = load(kit / "distribution_self_check.json")
    manifest_digest = sha256(manifest_path) if manifest_path.is_file() else None
    evidence = output.parent / "evidence"
    evidence.mkdir(parents=True, exist_ok=True)
    for name, value in (("environment_report.json", environment), ("native_rebuild_report.json", native), ("distribution_self_check.json", self_check)):
        (evidence / name).write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")
    shutil.rmtree(kit)
    checks = {
        "target": "PASS" if target_matches else "BLOCKED",
        "environment": str(environment.get("status", stages[0]["status"])),
        "native_rebuild": str(native.get("status", stages[1]["status"])),
        "self_check": str(self_check.get("status", stages[2]["status"])),
    }
    status = "PASS" if all(value == "PASS" for value in checks.values()) else "BLOCKED"
    payload = {
        "schema_version": "1.0",
        "toolchain_version": "0.11.0",
        "cell_id": args.cell_id,
        "status": status,
        "target": args.expected_target,
        "source_kit": str(source_kit),
        "work_kit_removed": True,
        "distribution_manifest_sha256": manifest_digest,
        "evidence_directory": str(evidence),
        "python": platform.python_version(),
        "python_executable": sys.executable,
        "system": platform.platform(),
        "machine": platform.machine(),
        "runner": {
            "os": os.environ.get("RUNNER_OS"),
            "arch": os.environ.get("RUNNER_ARCH"),
            "name": os.environ.get("RUNNER_NAME"),
            "github_run_id": os.environ.get("GITHUB_RUN_ID"),
            "github_sha": os.environ.get("GITHUB_SHA"),
        },
        "checks": checks,
        "stages": stages,
        "environment_report": environment,
        "native_rebuild": native,
        "self_check": self_check,
    }
    output.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(payload, indent=2))
    raise SystemExit(0 if status == "PASS" else 2)


if __name__ == "__main__":
    main()
'''


def _summary_cli_source() -> str:
    return r'''#!/usr/bin/env python3
from __future__ import annotations
import argparse
import csv
import hashlib
import json
from pathlib import Path


def load(path):
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"JSON root must be an object: {path}")
    return value


def sha256(path):
    digest = hashlib.sha256()
    digest.update(path.read_bytes())
    return digest.hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--manifest", required=True)
    parser.add_argument("--results", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    manifest_path = Path(args.manifest).resolve()
    results_root = Path(args.results).resolve()
    output = Path(args.output).resolve()
    output.mkdir(parents=True, exist_ok=True)
    manifest = load(manifest_path)
    discovered = {}
    for path in results_root.rglob("*.json") if results_root.exists() else []:
        try:
            payload = load(path)
        except Exception:
            continue
        cell_id = payload.get("cell_id")
        if payload.get("schema_version") == "1.0" and isinstance(cell_id, str):
            payload["_source"] = str(path)
            discovered.setdefault(cell_id, payload)
    rows = []
    for cell in manifest.get("matrix", []):
        cell_id = str(cell.get("id", ""))
        result = discovered.get(cell_id)
        if result is None:
            rows.append({"cell_id":cell_id,"runner":cell.get("runner", ""),"target":cell.get("target", ""),"python":cell.get("python", ""),"status":"NOT_RUN","environment":"NOT_RUN","native_rebuild":"NOT_RUN","self_check":"NOT_RUN","fortran":"NOT_RUN","system":"","machine":"","source":""})
            continue
        checks = result.get("checks", {})
        native = result.get("native_rebuild", {})
        fortran = native.get("fortran", {}) if isinstance(native, dict) else {}
        rows.append({"cell_id":cell_id,"runner":cell.get("runner", ""),"target":cell.get("target", ""),"python":cell.get("python", ""),"status":result.get("status", "BLOCKED"),"environment":checks.get("environment", "BLOCKED"),"native_rebuild":checks.get("native_rebuild", "BLOCKED"),"self_check":checks.get("self_check", "BLOCKED"),"fortran":fortran.get("status", "NOT_CONFIGURED") if isinstance(fortran, dict) else "NOT_CONFIGURED","system":result.get("system", ""),"machine":result.get("machine", ""),"source":result.get("_source", "")})
    statuses = [row["status"] for row in rows]
    status = "BLOCKED" if any(item == "BLOCKED" for item in statuses) else ("PASS" if statuses and all(item == "PASS" for item in statuses) else "REVIEW_REQUIRED")
    report = {"schema_version":"1.0","toolchain_version":"0.11.0","status":status,"suite_manifest":str(manifest_path),"suite_manifest_sha256":sha256(manifest_path),"planned_cells":len(rows),"passed_cells":sum(r["status"]=="PASS" for r in rows),"blocked_cells":sum(r["status"]=="BLOCKED" for r in rows),"not_run_cells":sum(r["status"]=="NOT_RUN" for r in rows),"invalid_reports":[],"cells":rows}
    (output / "compatibility_matrix.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    fields = ["cell_id","runner","target","python","status","environment","native_rebuild","self_check","fortran","system","machine","source"]
    with (output / "compatibility_matrix.csv").open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields); writer.writeheader(); writer.writerows(rows)
    lines = ["# Compatibility matrix", "", f"Overall status: **{status}**", "", "| Target | Runner | Python | Environment | Rebuild | Self-check | Fortran | Status |", "|---|---|---:|---|---|---|---|---|"]
    for row in rows:
        lines.append(f"| {row['target']} | {row['runner']} | {row['python']} | {row['environment']} | {row['native_rebuild']} | {row['self_check']} | {row['fortran']} | **{row['status']}** |")
    lines.extend(["", f"Passed: {report['passed_cells']} / {report['planned_cells']}", f"Blocked: {report['blocked_cells']}", f"Not run: {report['not_run_cells']}", ""])
    (output / "compatibility_matrix.md").write_text("\n".join(lines), encoding="utf-8")
    print(json.dumps(report, indent=2))
    raise SystemExit(0 if status == "PASS" else 2)


if __name__ == "__main__":
    main()
'''


def _summary_markdown(payload: dict[str, Any]) -> str:
    lines = [
        "# Compatibility matrix",
        "",
        f"Overall status: **{payload['status']}**",
        "",
        "| Target | Runner | Python | Environment | Rebuild | Self-check | Fortran | Status |",
        "|---|---|---:|---|---|---|---|---|",
    ]
    for row in payload["cells"]:
        lines.append(
            f"| {row['target']} | {row['runner']} | {row['python']} | "
            f"{row['environment']} | {row['native_rebuild']} | {row['self_check']} | "
            f"{row['fortran']} | **{row['status']}** |"
        )
    lines.extend(
        [
            "",
            f"Passed: {payload['passed_cells']} / {payload['planned_cells']}",
            f"Blocked: {payload['blocked_cells']}",
            f"Not run: {payload['not_run_cells']}",
            "",
        ]
    )
    if payload["not_run_cells"]:
        lines.append(
            "`NOT_RUN` means that the matrix cell has not produced CI or local evidence; "
            "it is not treated as compatible."
        )
        lines.append("")
    return "\n".join(lines)


def _compatibility_readme(versions: tuple[str, ...]) -> str:
    rendered = ", ".join(versions)
    return f'''# Fortran modernization compatibility suite

This suite validates the source-only Windows and Linux/WSL rebuild kits across
Python {rendered}. Each matrix cell performs:

1. environment and compiler probing;
2. safe and optimized Cython native rebuilds;
3. optional GNU Fortran fallback rebuild;
4. numerical self-checks against retained canonical snapshots;
5. evidence upload and compatibility-matrix aggregation.

## GitHub Actions

Copy this directory to the root of a GitHub repository, or copy
`.github/workflows/fortran-modernization-compatibility.yml` into the matching
repository location. The workflow has read-only repository permissions and
uploads per-cell evidence plus JSON/CSV/Markdown summaries.

The workflow uses `actions/checkout@v6`, `actions/setup-python@v6`,
`actions/upload-artifact@v4`, `actions/download-artifact@v4`, and the community
`fortran-lang/setup-fortran@v1` action. Review and pin third-party actions to
commit SHAs if required by your organization's supply-chain policy.

## Local Linux/WSL cell

```bash
python tools/run_compatibility_cell.py \\
  --suite-root . \\
  --kit kits/linux-wsl \\
  --cell-id linux-wsl-local \\
  --expected-target linux-wsl \\
  --output compatibility-results/linux-wsl-local/compatibility_result.json
```

## Rebuild the summary

```bash
python tools/summarize_compatibility.py \\
  --manifest compatibility_suite_manifest.json \\
  --results compatibility-results \\
  --output compatibility-summary
```

A `NOT_RUN` cell is deliberately distinct from `PASS`; Windows compatibility is
not claimed until a Windows runner has rebuilt and numerically checked the kit.
'''
