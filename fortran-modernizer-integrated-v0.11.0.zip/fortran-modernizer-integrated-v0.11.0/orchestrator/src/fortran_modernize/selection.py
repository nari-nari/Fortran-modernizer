from __future__ import annotations

import csv
import json
import math
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping


class KernelSelectionError(RuntimeError):
    """Raised when a kernel-selection report cannot be produced."""


@dataclass(frozen=True)
class KernelSelectionResult:
    status: str
    report: Path
    summary_csv: Path
    deployment_plan: Path
    selected: dict[str, str]


def has_kernel_selection(config: str | Path) -> bool:
    payload = _load_json(Path(config))
    spec = payload.get("kernel_selection")
    return isinstance(spec, dict) and bool(spec.get("enabled", True))


def run_kernel_selection(
    regression_report: str | Path,
    config: str | Path,
    *,
    artifacts: Mapping[str, str | Path] | None,
    output_directory: str | Path,
    overwrite: bool = False,
) -> KernelSelectionResult:
    report_path = Path(regression_report).expanduser().resolve()
    config_path = Path(config).expanduser().resolve()
    if not report_path.is_file():
        raise KernelSelectionError(f"regression report does not exist: {report_path}")
    if not config_path.is_file():
        raise KernelSelectionError(f"selection config does not exist: {config_path}")

    regression = _load_json(report_path)
    config_payload = _load_json(config_path)
    spec = config_payload.get("kernel_selection")
    if not isinstance(spec, dict) or not spec.get("enabled", True):
        raise KernelSelectionError("kernel_selection is not enabled in the configuration")

    output = Path(output_directory).expanduser().resolve()
    if output.exists() and any(output.iterdir()):
        if not overwrite:
            raise KernelSelectionError(
                f"selection output directory is not empty: {output}; pass overwrite=True"
            )
        import shutil

        shutil.rmtree(output)
    output.mkdir(parents=True, exist_ok=True)

    artifact_paths = {
        str(name): Path(value).expanduser().resolve()
        for name, value in (artifacts or {}).items()
    }
    groups = spec.get("groups")
    if not isinstance(groups, dict) or not groups:
        raise KernelSelectionError("kernel_selection.groups must be a non-empty object")

    defaults = {
        "minimum_weighted_speedup": _number(spec.get("minimum_weighted_speedup", 1.0), "minimum_weighted_speedup", lower=0.0),
        "minimum_case_speedup": _number(spec.get("minimum_case_speedup", 0.0), "minimum_case_speedup", lower=0.0),
        "minimum_case_coverage": _number(spec.get("minimum_case_coverage", 1.0), "minimum_case_coverage", lower=0.0, upper=1.0),
        "maximum_build_seconds": _optional_number(spec.get("maximum_build_seconds"), "maximum_build_seconds", lower=0.0),
        "maximum_artifact_mb": _optional_number(spec.get("maximum_artifact_mb"), "maximum_artifact_mb", lower=0.0),
        "maximum_break_even_runs": _optional_number(spec.get("maximum_break_even_runs"), "maximum_break_even_runs", lower=0.0),
    }
    case_weights_raw = spec.get("case_weights", {})
    if not isinstance(case_weights_raw, dict):
        raise KernelSelectionError("kernel_selection.case_weights must be an object")
    case_weights = {
        str(name): _number(value, f"case_weights.{name}", lower=0.0)
        for name, value in case_weights_raw.items()
    }

    numerical_cases = {
        str(item.get("name")): item for item in regression.get("cases", [])
        if isinstance(item, dict) and item.get("name") is not None
    }
    performance = regression.get("performance")
    if not isinstance(performance, dict):
        raise KernelSelectionError("regression report has no performance section")
    performance_cases = {
        str(item.get("name")): item for item in performance.get("cases", [])
        if isinstance(item, dict) and item.get("name") is not None
    }
    if not performance_cases:
        raise KernelSelectionError("regression report has no performance cases")

    baseline = str(performance.get("baseline", "python"))
    rows: list[dict[str, Any]] = []
    group_records: list[dict[str, Any]] = []
    selected: dict[str, str] = {}

    for group_name, raw_group in groups.items():
        if not isinstance(raw_group, dict):
            raise KernelSelectionError(f"kernel_selection.groups.{group_name} must be an object")
        fallback = str(raw_group.get("fallback", baseline))
        raw_candidates = raw_group.get("candidates")
        if not isinstance(raw_candidates, dict) or not raw_candidates:
            raise KernelSelectionError(
                f"kernel_selection.groups.{group_name}.candidates must be a non-empty object"
            )
        thresholds = dict(defaults)
        for key in tuple(defaults):
            if key in raw_group:
                if key in {"maximum_build_seconds", "maximum_artifact_mb", "maximum_break_even_runs"}:
                    thresholds[key] = _optional_number(raw_group[key], f"{group_name}.{key}", lower=0.0)
                elif key == "minimum_case_coverage":
                    thresholds[key] = _number(raw_group[key], f"{group_name}.{key}", lower=0.0, upper=1.0)
                else:
                    thresholds[key] = _number(raw_group[key], f"{group_name}.{key}", lower=0.0)

        candidate_records: list[dict[str, Any]] = []
        for backend_name, raw_candidate in raw_candidates.items():
            if not isinstance(raw_candidate, dict):
                raise KernelSelectionError(
                    f"kernel_selection.groups.{group_name}.candidates.{backend_name} must be an object"
                )
            build_artifact = raw_candidate.get("build_report_artifact")
            build_report = None
            if build_artifact is not None:
                artifact_name = str(build_artifact)
                build_path = artifact_paths.get(artifact_name)
                if build_path is None:
                    raise KernelSelectionError(
                        f"missing artifact {artifact_name!r} for candidate {backend_name!r}"
                    )
                if not build_path.is_file():
                    raise KernelSelectionError(f"build report does not exist: {build_path}")
                build_report = _load_json(build_path)

            case_records: list[dict[str, Any]] = []
            weighted_baseline = 0.0
            weighted_candidate = 0.0
            weight_total = 0.0
            observed = 0
            numerical_passed = True
            deterministic = True
            min_speedup = math.inf
            for case_name, perf_case in performance_cases.items():
                comparison = perf_case.get("comparisons", {}).get(backend_name)
                backend_perf = perf_case.get("backends", {}).get(backend_name)
                baseline_perf = perf_case.get("backends", {}).get(baseline)
                if not isinstance(comparison, dict) or not isinstance(backend_perf, dict) or not isinstance(baseline_perf, dict):
                    continue
                observed += 1
                weight = case_weights.get(case_name, 1.0)
                baseline_seconds = float(comparison["baseline_median_seconds"])
                candidate_seconds = float(comparison["candidate_median_seconds"])
                speedup = float(comparison["speedup"])
                min_speedup = min(min_speedup, speedup)
                weighted_baseline += weight * baseline_seconds
                weighted_candidate += weight * candidate_seconds
                weight_total += weight

                numerical_case = numerical_cases.get(case_name, {})
                numerical_comparison = numerical_case.get("comparisons", {}).get(backend_name, {})
                candidate_numerical_passed = bool(numerical_comparison.get("passed", False))
                backend_deterministic = bool(
                    numerical_case.get("backends", {}).get(backend_name, {}).get("deterministic", False)
                )
                numerical_passed = numerical_passed and candidate_numerical_passed
                deterministic = deterministic and backend_deterministic
                case_records.append({
                    "name": case_name,
                    "weight": weight,
                    "baseline_median_seconds": baseline_seconds,
                    "candidate_median_seconds": candidate_seconds,
                    "speedup": speedup,
                    "numerical_passed": candidate_numerical_passed,
                    "deterministic": backend_deterministic,
                })

            total_cases = len(performance_cases)
            coverage = observed / total_cases if total_cases else 0.0
            weighted_speedup = (
                weighted_baseline / weighted_candidate
                if weighted_candidate > 0.0
                else math.inf
            )
            saved_seconds = (
                (weighted_baseline - weighted_candidate) / weight_total
                if weight_total > 0.0
                else 0.0
            )
            build_seconds = float(build_report.get("elapsed_seconds", 0.0)) if build_report else 0.0
            artifact_bytes = int(build_report.get("extension_size_bytes", 0)) if build_report else 0
            artifact_mb = artifact_bytes / (1024.0 * 1024.0)
            break_even_runs = build_seconds / saved_seconds if saved_seconds > 0.0 else None

            checks: dict[str, bool] = {
                "numerical_passed": numerical_passed,
                "deterministic": deterministic,
                "case_coverage": coverage >= float(thresholds["minimum_case_coverage"]),
                "weighted_speedup": weighted_speedup >= float(thresholds["minimum_weighted_speedup"]),
                "minimum_case_speedup": min_speedup >= float(thresholds["minimum_case_speedup"]),
            }
            if thresholds["maximum_build_seconds"] is not None:
                checks["build_seconds"] = build_seconds <= float(thresholds["maximum_build_seconds"])
            if thresholds["maximum_artifact_mb"] is not None:
                checks["artifact_mb"] = artifact_mb <= float(thresholds["maximum_artifact_mb"])
            if thresholds["maximum_break_even_runs"] is not None:
                checks["break_even_runs"] = (
                    break_even_runs is not None
                    and break_even_runs <= float(thresholds["maximum_break_even_runs"])
                )
            eligible = all(checks.values())
            reasons = [name for name, passed in checks.items() if not passed]
            record = {
                "backend": str(backend_name),
                "eligible": eligible,
                "decision": "ELIGIBLE" if eligible else "REJECTED",
                "reasons": reasons,
                "checks": checks,
                "case_count": total_cases,
                "observed_case_count": observed,
                "case_coverage": coverage,
                "weighted_speedup": weighted_speedup,
                "minimum_case_speedup": min_speedup if observed else None,
                "saved_seconds_per_weighted_run": saved_seconds,
                "build_seconds": build_seconds,
                "artifact_size_bytes": artifact_bytes,
                "artifact_size_mb": artifact_mb,
                "break_even_runs": break_even_runs,
                "build_report": str(build_artifact) if build_artifact is not None else None,
                "cases": case_records,
            }
            candidate_records.append(record)

        eligible = [item for item in candidate_records if item["eligible"]]
        if eligible:
            winner = max(
                eligible,
                key=lambda item: (
                    float(item["weighted_speedup"]),
                    -float(item["build_seconds"]),
                    -int(item["artifact_size_bytes"]),
                ),
            )
            winner["decision"] = "SELECTED"
            selected[str(group_name)] = str(winner["backend"])
            for item in eligible:
                if item is not winner:
                    item["decision"] = "NOT_SELECTED"
            group_status = "SELECTED"
            group_backend = str(winner["backend"])
        else:
            selected[str(group_name)] = fallback
            group_status = "FALLBACK"
            group_backend = fallback

        group_record = {
            "group": str(group_name),
            "status": group_status,
            "selected_backend": group_backend,
            "fallback": fallback,
            "thresholds": thresholds,
            "candidates": candidate_records,
        }
        group_records.append(group_record)
        for item in candidate_records:
            rows.append({
                "group": group_name,
                "backend": item["backend"],
                "decision": item["decision"],
                "eligible": item["eligible"],
                "case_coverage": item["case_coverage"],
                "weighted_speedup": item["weighted_speedup"],
                "minimum_case_speedup": item["minimum_case_speedup"],
                "saved_seconds_per_weighted_run": item["saved_seconds_per_weighted_run"],
                "build_seconds": item["build_seconds"],
                "artifact_size_mb": item["artifact_size_mb"],
                "break_even_runs": item["break_even_runs"],
                "reasons": ";".join(item["reasons"]),
            })

    report_output = output / "kernel_selection_report.json"
    summary_output = output / "kernel_selection_summary.csv"
    plan_output = output / "selected_backends.json"
    payload = {
        "schema_version": "1.0",
        "toolchain_version": "0.11.0",
        "status": "PASS",
        "regression_report": str(report_path),
        "config": str(config_path),
        "performance_baseline": baseline,
        "case_weights": case_weights,
        "groups": group_records,
        "selected": selected,
    }
    report_output.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    _write_csv(summary_output, rows)
    plan_output.write_text(
        json.dumps(
            {
                "schema_version": "1.0",
                "toolchain_version": "0.11.0",
                "selected_backends": selected,
            },
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )
    return KernelSelectionResult(
        status="PASS",
        report=report_output,
        summary_csv=summary_output,
        deployment_plan=plan_output,
        selected=selected,
    )


def _write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    fields = [
        "group",
        "backend",
        "decision",
        "eligible",
        "case_coverage",
        "weighted_speedup",
        "minimum_case_speedup",
        "saved_seconds_per_weighted_run",
        "build_seconds",
        "artifact_size_mb",
        "break_even_runs",
        "reasons",
    ]
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({key: row.get(key) for key in fields})


def _load_json(path: Path) -> dict[str, Any]:
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise KernelSelectionError(f"cannot read JSON {path}: {exc}") from exc
    if not isinstance(payload, dict):
        raise KernelSelectionError(f"JSON root must be an object: {path}")
    return payload


def _number(value: Any, name: str, *, lower: float | None = None, upper: float | None = None) -> float:
    try:
        rendered = float(value)
    except (TypeError, ValueError) as exc:
        raise KernelSelectionError(f"{name} must be a number") from exc
    if not math.isfinite(rendered):
        raise KernelSelectionError(f"{name} must be finite")
    if lower is not None and rendered < lower:
        raise KernelSelectionError(f"{name} must be >= {lower}")
    if upper is not None and rendered > upper:
        raise KernelSelectionError(f"{name} must be <= {upper}")
    return rendered


def _optional_number(value: Any, name: str, *, lower: float | None = None) -> float | None:
    if value is None:
        return None
    return _number(value, name, lower=lower)
