from __future__ import annotations

import json
from pathlib import Path

import pytest

from fortran_modernize.runtime import (
    RuntimeBundleError,
    build_runtime_bundle,
    run_runtime_bundle,
)


def _write_fake_migration(tmp_path: Path, *, selected: str = "python") -> Path:
    migration = tmp_path / "migration"
    app_dir = migration / "07_python"
    kernel_dir = migration / "09_state_kernels" / "step"
    regression_dir = migration / "10_numerical_regression"
    selection_dir = migration / "11_kernel_selection"
    app_dir.mkdir(parents=True)
    (kernel_dir / "cython_safe_build" / "lib").mkdir(parents=True)
    (kernel_dir / "cython_optimized_build" / "lib").mkdir(parents=True)
    (regression_dir / "support").mkdir(parents=True)
    selection_dir.mkdir(parents=True)

    (app_dir / "run_generated.py").write_text(
        "def run():\n    return 42\n",
        encoding="utf-8",
    )
    (kernel_dir / "step_kernel_python.py").write_text(
        "def step_kernel(value):\n    return value\n",
        encoding="utf-8",
    )
    (kernel_dir / "step_state_wrapper.py").write_text(
        """from __future__ import annotations
import importlib.util
from pathlib import Path
_ROOT = Path(__file__).resolve().parent

def _load_backend(backend):
    if backend == 'python':
        path = _ROOT / 'step_kernel_python.py'
        spec = importlib.util.spec_from_file_location('step_kernel_python', path)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        return module
    path = _ROOT / ('cython_safe_build/lib/dummy.so' if backend == 'cython-safe' else 'cython_optimized_build/lib/dummy.so')
    spec = importlib.util.spec_from_file_location('dummy', path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

def step(value, *, backend='python'):
    return _load_backend(backend).step_kernel(value)
""",
        encoding="utf-8",
    )
    (kernel_dir / "cython_safe_build" / "lib" / "dummy.so").write_bytes(b"not-an-extension")
    (kernel_dir / "cython_optimized_build" / "lib" / "dummy.so").write_bytes(b"not-an-extension")
    (kernel_dir / "state_kernel_manifest.json").write_text(
        json.dumps(
            {
                "schema_version": "1.0",
                "source_procedure": "step",
                "kernel_procedure": "step_kernel",
                "wrapper_procedure": "step",
                "artifacts": {
                    "wrapper": "step_state_wrapper.py",
                    "python": "step_kernel_python.py",
                    "cython_safe_extension": "cython_safe_build/lib/dummy.so",
                    "cython_optimized_extension": "cython_optimized_build/lib/dummy.so",
                },
                "module_names": {
                    "python": "step_kernel_python",
                    "cython-safe": "dummy_safe",
                    "cython-optimized": "dummy_optimized",
                },
            }
        ),
        encoding="utf-8",
    )

    support = regression_dir / "support" / "driver.py"
    support.write_text(
        """from __future__ import annotations
import argparse, json, sys
from pathlib import Path
p=argparse.ArgumentParser(); p.add_argument('--snapshot'); p.add_argument('--fail', action='store_true'); a=p.parse_args()
if a.fail: raise SystemExit(7)
Path(a.snapshot).write_text(json.dumps({'schema_version':'1.0','scalars':{'value':42},'arrays':{}}))
""",
        encoding="utf-8",
    )
    backend_specs = {
        "python": {
            "run": ["{python}", "{support_dir}/driver.py", "--snapshot", "{snapshot}"],
            "snapshot": {"source": "file", "format": "json", "path": "{snapshot}"},
        },
        "cython-safe": {
            "run": ["{python}", "{support_dir}/driver.py", "--snapshot", "{snapshot}"],
            "snapshot": {"source": "file", "format": "json", "path": "{snapshot}"},
        },
        "cython-optimized": {
            "run": ["{python}", "{support_dir}/driver.py", "--snapshot", "{snapshot}", "--fail"],
            "snapshot": {"source": "file", "format": "json", "path": "{snapshot}"},
        },
    }
    (regression_dir / "regression_config.json").write_text(
        json.dumps(
            {
                "schema_version": "1.2",
                "backends": backend_specs,
                "cases": [{"name": "default", "variables": {}}],
                "support_files": ["support/driver.py"],
            }
        ),
        encoding="utf-8",
    )
    (regression_dir / "regression_report.json").write_text(
        json.dumps(
            {
                "status": "PASS",
                "support_files": [
                    {
                        "source": str(support),
                        "copy": "support/driver.py",
                        "sha256": "unused",
                    }
                ],
            }
        ),
        encoding="utf-8",
    )
    (selection_dir / "selected_backends.json").write_text(
        json.dumps(
            {
                "schema_version": "1.0",
                "selected_backends": {"step": selected},
            }
        ),
        encoding="utf-8",
    )
    (migration / "migration_manifest.json").write_text(
        json.dumps(
            {
                "schema_version": "1.0",
                "status": "PASS",
                "procedure": "run",
                "artifacts": {
                    "python_source": "07_python/run_generated.py",
                    "state_kernel_step_manifest": "09_state_kernels/step/state_kernel_manifest.json",
                    "numerical_regression_config": "10_numerical_regression/regression_config.json",
                    "numerical_regression": "10_numerical_regression/regression_report.json",
                    "selected_backends": "11_kernel_selection/selected_backends.json",
                },
            }
        ),
        encoding="utf-8",
    )
    return migration


def test_runtime_bundle_packages_python_backend_and_executes(tmp_path: Path) -> None:
    migration = _write_fake_migration(tmp_path, selected="python")
    result = build_runtime_bundle(
        migration,
        output_directory=tmp_path / "runtime",
    )
    assert result.status == "PASS"
    health = json.loads(result.health_report.read_text(encoding="utf-8"))
    assert health["status"] == "PASS"

    execution = run_runtime_bundle(
        result.output_directory,
        backend="auto",
        case="default",
        snapshot=tmp_path / "snapshot.json",
        report=tmp_path / "runtime_report.json",
    )
    assert execution.backend == "python"
    snapshot = json.loads(execution.snapshot.read_text(encoding="utf-8"))
    assert snapshot["scalars"]["value"] == 42


def test_runtime_auto_falls_back_after_selected_backend_failure(tmp_path: Path) -> None:
    migration = _write_fake_migration(tmp_path, selected="cython-optimized")
    result = build_runtime_bundle(
        migration,
        output_directory=tmp_path / "runtime",
        strict_selected=False,
    )
    execution = run_runtime_bundle(
        result.output_directory,
        backend="auto",
        snapshot=tmp_path / "snapshot.json",
        report=tmp_path / "runtime_report.json",
    )
    assert execution.backend == "cython-safe"
    assert [item["status"] for item in execution.attempts] == ["FAILED", "PASS"]


def test_runtime_strict_selected_rejects_unloadable_extension(tmp_path: Path) -> None:
    migration = _write_fake_migration(tmp_path, selected="cython-optimized")
    with pytest.raises(RuntimeBundleError) as caught:
        build_runtime_bundle(
            migration,
            output_directory=tmp_path / "runtime",
            strict_selected=True,
        )
    assert caught.value.report is not None
