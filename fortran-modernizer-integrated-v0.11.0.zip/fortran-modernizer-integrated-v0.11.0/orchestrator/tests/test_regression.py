from __future__ import annotations

import json
from pathlib import Path

import pytest

from fortran_modernize.regression import NumericalRegressionError, run_numerical_regression


def _write_config(path: Path, candidate_value: float, *, repeat: int = 2) -> Path:
    payload = {
        "schema_version": "1.0",
        "baseline": "fortran",
        "candidates": ["python"],
        "defaults": {"rtol": 1.0e-12, "atol": 1.0e-13, "repeat": repeat},
        "backends": {
            "fortran": {
                "run": ["{python}", "-c", "print('value=1.0')"],
                "snapshot": {
                    "source": "stdout",
                    "format": "key_value",
                    "fields": {"value": "float"},
                },
            },
            "python": {
                "run": [
                    "{python}",
                    "-c",
                    f"print('value={candidate_value}')",
                ],
                "snapshot": {
                    "source": "stdout",
                    "format": "key_value",
                    "fields": {"value": "float"},
                },
            },
        },
        "cases": [{"name": "standard"}],
    }
    path.write_text(json.dumps(payload), encoding="utf-8")
    return path


def _inputs(tmp_path: Path) -> tuple[Path, Path]:
    source = tmp_path / "reviewed.f90"
    source.write_text("subroutine reviewed\nend subroutine reviewed\n", encoding="utf-8")
    generated = tmp_path / "generated.py"
    generated.write_text("# generated\n", encoding="utf-8")
    return source, generated


def test_declarative_regression_passes_and_checks_repeatability(tmp_path: Path) -> None:
    source, generated = _inputs(tmp_path)
    result = run_numerical_regression(
        _write_config(tmp_path / "regression.json", 1.0),
        source=source,
        generated_python=generated,
        output_directory=tmp_path / "out",
    )

    assert result.status == "PASS"
    report = json.loads(result.report.read_text(encoding="utf-8"))
    assert report["summary"] == {
        "case_count": 1,
        "passed_cases": 1,
        "failed_cases": 0,
        "comparison_count": 1,
        "failed_comparisons": 0,
        "failed_determinism_checks": 0,
        "performance_comparison_count": 0,
        "failed_performance_gates": 0,
    }
    assert report["cases"][0]["backends"]["fortran"]["deterministic"] is True
    assert report["cases"][0]["backends"]["python"]["deterministic"] is True


def test_regression_mismatch_is_blocked_and_report_is_retained(tmp_path: Path) -> None:
    source, generated = _inputs(tmp_path)
    output = tmp_path / "out"

    with pytest.raises(NumericalRegressionError) as caught:
        run_numerical_regression(
            _write_config(tmp_path / "regression.json", 2.0, repeat=1),
            source=source,
            generated_python=generated,
            output_directory=output,
        )

    assert caught.value.report == output / "regression_report.json"
    report = json.loads(caught.value.report.read_text(encoding="utf-8"))
    assert report["status"] == "BLOCKED"
    assert report["summary"]["failed_comparisons"] == 1
    assert report["cases"][0]["comparisons"]["python"]["passed"] is False


def test_regression_compares_external_array_snapshots(tmp_path: Path) -> None:
    source, generated = _inputs(tmp_path)
    driver = tmp_path / "snapshot_driver.py"
    driver.write_text(
        """from __future__ import annotations
import json
import sys
from pathlib import Path
import numpy as np
snapshot = Path(sys.argv[1])
scale = float(sys.argv[2])
array_path = snapshot.parent / 'field.npy'
np.save(array_path, np.array([[1.0, 2.0], [3.0, 4.0]]) * scale)
snapshot.write_text(json.dumps({'scalars': {'value': scale}, 'arrays': {'field': {'path': 'field.npy'}}}))
""",
        encoding="utf-8",
    )
    config = {
        "schema_version": "1.0",
        "baseline": "fortran",
        "candidates": ["python"],
        "backends": {
            "fortran": {
                "run": ["{python}", str(driver), "{snapshot}", "1.0"],
                "snapshot": {"source": "file", "format": "json", "path": "{snapshot}"},
            },
            "python": {
                "run": ["{python}", str(driver), "{snapshot}", "1.0"],
                "snapshot": {"source": "file", "format": "json", "path": "{snapshot}"},
            },
        },
        "cases": [{"name": "arrays"}],
    }
    config_path = tmp_path / "arrays.json"
    config_path.write_text(json.dumps(config), encoding="utf-8")

    result = run_numerical_regression(
        config_path,
        source=source,
        generated_python=generated,
        output_directory=tmp_path / "array_out",
    )
    report = json.loads(result.report.read_text(encoding="utf-8"))
    comparison = report["cases"][0]["comparisons"]["python"]
    assert comparison["passed"] is True
    assert comparison["state_differences"]["field"]["shape"] == [2, 2]


def test_performance_section_records_speedup_and_csv(tmp_path: Path) -> None:
    source, generated = _inputs(tmp_path)
    payload = {
        "schema_version": "1.1",
        "baseline": "fortran",
        "candidates": ["python", "cython"],
        "defaults": {"repeat": 1},
        "backends": {
            "fortran": {
                "run": ["{python}", "-c", "print('value=1.0')"],
                "snapshot": {"source": "stdout", "format": "key_value", "fields": {"value": "float"}},
            },
            "python": {
                "run": ["{python}", "-c", "import time; time.sleep(1.0); print('value=1.0')"],
                "snapshot": {"source": "stdout", "format": "key_value", "fields": {"value": "float"}},
            },
            "cython": {
                "run": ["{python}", "-c", "import time; time.sleep(0.0); print('value=1.0')"],
                "snapshot": {"source": "stdout", "format": "key_value", "fields": {"value": "float"}},
            },
        },
        "performance": {
            "baseline": "python",
            "candidates": ["cython"],
            "warmup": 0,
            "repeat": 2,
            "minimum_speedup": {"cython": 1.2},
        },
        "cases": [{"name": "performance"}],
    }
    config = tmp_path / "performance.json"
    config.write_text(json.dumps(payload), encoding="utf-8")

    result = run_numerical_regression(
        config,
        source=source,
        generated_python=generated,
        output_directory=tmp_path / "performance_out",
    )

    assert result.performance_csv is not None and result.performance_csv.is_file()
    report = json.loads(result.report.read_text(encoding="utf-8"))
    comparison = report["performance"]["cases"][0]["comparisons"]["cython"]
    assert comparison["passed"] is True
    assert comparison["speedup"] >= 1.2
    assert report["summary"]["failed_performance_gates"] == 0


def test_artifact_placeholder_is_available_to_commands(tmp_path: Path) -> None:
    source, generated = _inputs(tmp_path)
    payload = {
        "schema_version": "1.1",
        "baseline": "fortran",
        "candidates": ["python"],
        "backends": {
            "fortran": {
                "run": ["{python}", "-c", "print('value=1.0')"],
                "snapshot": {"source": "stdout", "format": "key_value", "fields": {"value": "float"}},
            },
            "python": {
                "run": ["{python}", "-c", "print('value={expected_value}')"],
                "snapshot": {"source": "stdout", "format": "key_value", "fields": {"value": "float"}},
            },
        },
        "cases": [{"name": "artifact"}],
    }
    config = tmp_path / "artifact.json"
    config.write_text(json.dumps(payload), encoding="utf-8")
    result = run_numerical_regression(
        config,
        source=source,
        generated_python=generated,
        artifacts={"expected_value": "1.0"},
        output_directory=tmp_path / "artifact_out",
    )
    assert result.status == "PASS"
