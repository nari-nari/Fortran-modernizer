from __future__ import annotations

import json
from pathlib import Path

from fortran_modernize.integration import (
    diagnose_integrated_project,
    setup_integrated_project,
    validate_integrated_project,
)


def test_setup_project_installs_copilot_and_cli_fallback(tmp_path: Path) -> None:
    source = tmp_path / "input"
    source.mkdir()
    (source / "solver.f").write_text("      program demo\n      end\n", encoding="utf-8")
    (source / "defs.inc").write_text("      integer n\n", encoding="utf-8")
    project = tmp_path / "project"

    result = setup_integrated_project(
        project,
        source=source,
        include_dirs=["legacy-original"],
        legacy_compiler="Absoft",
        integration_mode="auto",
    )

    assert result.status == "REVIEW_REQUIRED"
    assert (project / "legacy-original" / "solver.f").is_file()
    assert (project / "legacy-original" / "defs.inc").is_file()
    assert (project / ".github" / "agents" / "fortran-modernizer.agent.md").is_file()
    assert (project / ".github" / "skills" / "fortran-integrated-setup" / "SKILL.md").is_file()
    assert (project / ".github" / "hooks" / "fortran-human-approval.json").is_file()
    assert (project / "docs" / "CLI_ONLY_WORKFLOW.md").is_file()
    config = json.loads((project / "config" / "project.json").read_text(encoding="utf-8"))
    assert config["compilers"]["legacy"]["name"] == "Absoft"
    assert config["copilot"]["cli_only_fallback"] is True
    assert config["regression"]["status"] == "NOT_CONFIGURED"


def test_doctor_reports_static_copilot_limit_and_missing_human_config(tmp_path: Path) -> None:
    project = tmp_path / "project"
    setup_integrated_project(project)
    result = diagnose_integrated_project(project)
    assert result.status in {"REVIEW_REQUIRED", "BLOCKED"}
    report = json.loads(result.report.read_text(encoding="utf-8"))
    hook = next(item for item in report["checks"] if item["id"] == "copilot-hook-static")
    assert hook["details"].get("runtime_activation") == "UNKNOWN"
    config = next(item for item in report["checks"] if item["id"] == "project-configuration")
    assert "regression baseline/cases/tolerances" in config["details"]["unresolved"]


def test_validate_integrated_project_accepts_bundle_root() -> None:
    root = Path(__file__).resolve().parents[2]
    assert validate_integrated_project(root) == []
