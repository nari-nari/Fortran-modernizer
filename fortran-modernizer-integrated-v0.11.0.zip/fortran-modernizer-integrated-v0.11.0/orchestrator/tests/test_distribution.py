from __future__ import annotations

import json
from pathlib import Path

from fortran_modernize.distribution import (
    build_distribution_bundle,
    validate_distribution_bundle,
)


def _write_json(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")


def _fake_migration(tmp_path: Path) -> Path:
    migration = tmp_path / "migration"
    runtime = migration / "12_runtime"
    kernel = migration / "09_state_kernels" / "advance"
    regression = migration / "10_numerical_regression"
    selection = migration / "11_kernel_selection"
    source = tmp_path / "reviewed.f90"
    source.write_text("program demo\nprint *, 1\nend program\n", encoding="utf-8")

    (runtime / "application").mkdir(parents=True)
    (runtime / "application" / "generated_application.py").write_text(
        "def run(): return 1\n", encoding="utf-8"
    )
    (runtime / "kernels" / "advance").mkdir(parents=True)
    (runtime / "kernels" / "advance" / "advance_state_wrapper.py").write_text(
        "def advance(*args, **kwargs): return None\n", encoding="utf-8"
    )
    (runtime / "kernels" / "advance" / "advance_kernel_python.py").write_text(
        "def advance_kernel(x): return x\n", encoding="utf-8"
    )
    (runtime / "runtime_dispatch.py").write_text("raise SystemExit(0)\n", encoding="utf-8")
    (runtime / "runtime_api.py").write_text("pass\n", encoding="utf-8")
    (runtime / "run-runtime").write_text("#!/usr/bin/env python3\n", encoding="utf-8")
    (runtime / "stale.so").write_bytes(b"linux")
    (runtime / "fortran").mkdir()
    (runtime / "fortran" / "stale.exe").write_bytes(b"windows")
    _write_json(runtime / "runtime_manifest.json", {"status": "PASS"})
    _write_json(
        runtime / "runtime_config.json",
        {
            "schema_version": "1.0",
            "application": "application/generated_application.py",
            "application_fallback_order": ["cython-optimized", "cython-safe", "python", "fortran"],
            "kernels": {
                "advance": {
                    "wrapper": "kernels/advance/advance_state_wrapper.py",
                    "available_backends": {
                        "python": {"path": "kernels/advance/advance_kernel_python.py"},
                        "cython-safe": {"path": "kernels/advance/old.so"},
                        "cython-optimized": {"path": "kernels/advance/old.so"},
                    },
                }
            },
            "backend_specs": {
                "fortran": {
                    "executable_name": "demo_fortran",
                    "build": [["gfortran", "{source}", "-o", "{executable}"]],
                    "run": ["{executable}"],
                    "snapshot": {"source": "stdout", "format": "key_value", "fields": {"value": "int"}},
                },
                "python": {"run": ["{python}"], "snapshot": {"source": "file", "format": "json"}},
            },
            "cases": [{"name": "smoke", "variables": {}}],
        },
    )

    kernel.mkdir(parents=True)
    (kernel / "advance_kernel_cython_safe.py").write_text(
        "import cython\ndef advance_kernel(x: cython.double) -> cython.double: return x\n",
        encoding="utf-8",
    )
    (kernel / "advance_kernel_cython_optimized.py").write_text(
        "import cython\ndef advance_kernel(x: cython.double) -> cython.double: return x\n",
        encoding="utf-8",
    )
    (kernel / "advance_kernel_python.py").write_text("def advance_kernel(x): return x\n", encoding="utf-8")
    (kernel / "advance_state_wrapper.py").write_text("pass\n", encoding="utf-8")
    _write_json(
        kernel / "state_kernel_manifest.json",
        {
            "artifacts": {
                "cython_safe_source": "advance_kernel_cython_safe.py",
                "cython_optimized_source": "advance_kernel_cython_optimized.py",
                "wrapper": "advance_state_wrapper.py",
                "python": "advance_kernel_python.py",
            },
            "module_names": {
                "cython-safe": "fpy_advance_safe",
                "cython-optimized": "fpy_advance_optimized",
                "python": "advance_kernel_python",
            },
        },
    )
    _write_json(selection / "selected_backends.json", {"selected_backends": {"advance": "cython-optimized"}})
    snapshot = regression / "cases" / "smoke" / "fortran" / "run_01" / "canonical_snapshot.json"
    _write_json(snapshot, {"schema_version": "1.0", "scalars": {"value": 1}, "arrays": {}})
    _write_json(
        regression / "regression_report.json",
        {
            "status": "PASS",
            "cases": [
                {
                    "name": "smoke",
                    "rtol": 1e-12,
                    "atol": 1e-13,
                    "backends": {
                        "fortran": {
                            "runs": [
                                {
                                    "artifacts": {
                                        "snapshot": "cases/smoke/fortran/run_01/canonical_snapshot.json"
                                    }
                                }
                            ]
                        }
                    },
                }
            ],
        },
    )

    _write_json(
        migration / "migration_manifest.json",
        {
            "status": "PASS",
            "inputs": {"source": str(source)},
            "artifacts": {
                "runtime_bundle": "12_runtime",
                "selected_backends": "11_kernel_selection/selected_backends.json",
                "state_kernel_advance_manifest": "09_state_kernels/advance/state_kernel_manifest.json",
                "numerical_regression": "10_numerical_regression/regression_report.json",
            },
        },
    )
    return migration


def test_distribution_bundle_is_source_only_and_rebuildable(tmp_path: Path) -> None:
    migration = _fake_migration(tmp_path)
    result = build_distribution_bundle(
        migration,
        output_directory=tmp_path / "kit",
        target="linux-wsl",
        app_name="demo",
    )
    assert result.status == "PASS"
    assert validate_distribution_bundle(result.output_directory) == []
    assert not list(result.output_directory.rglob("*.so"))
    assert not list(result.output_directory.rglob("*.exe"))
    assert (result.output_directory / "payload/native_sources/advance/fpy_advance_safe.py").is_file()
    assert (result.output_directory / "payload/fortran_source/reviewed.f90").is_file()
    compile((result.output_directory / "tools/build_backends.py").read_text(), "build_backends.py", "exec")
    compile((result.output_directory / "tools/self_check.py").read_text(), "self_check.py", "exec")


def test_distribution_validation_rejects_binary_leak(tmp_path: Path) -> None:
    migration = _fake_migration(tmp_path)
    result = build_distribution_bundle(
        migration,
        output_directory=tmp_path / "kit",
        target="windows-native",
    )
    leaked = result.output_directory / "payload/runtime/leaked.dll"
    leaked.write_bytes(b"bad")
    errors = validate_distribution_bundle(result.output_directory)
    assert any("binary leaked" in item for item in errors)
