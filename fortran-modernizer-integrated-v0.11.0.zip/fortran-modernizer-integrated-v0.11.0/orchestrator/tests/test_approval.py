from __future__ import annotations

import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path

import pytest

from fortran_modernize.approval import (
    APPROVAL_CONFIRMATION,
    ApprovalWorkflowError,
    apply_approved_plan,
    classify_plan,
    create_approval,
    install_copilot_workflow,
    validate_approval,
)


def _plan(tmp_path: Path) -> tuple[Path, Path]:
    source = tmp_path / "source"
    source.mkdir()
    code = (
        "program demo\n"
        "  implicit none\n"
        "  integer :: x, y\n"
        "  x = 1\n"
        "  y = x\n"
        "  print *, y\n"
        "end program demo\n"
    )
    src = source / "demo.f90"
    src.write_text(code, encoding="utf-8")
    source_hash = hashlib.sha256(code.encode("utf-8")).hexdigest()
    plan = tmp_path / "plan"
    plan.mkdir()
    manifest = {
        "schema_version": 1,
        "kind": "test-plan",
        "source_root": str(source.resolve()),
        "suggestion_file": "suggestions.json",
    }
    suggestions = [
        {
            "id": "AUTO-0001",
            "kind": "safe_constant_preview",
            "safety": "automatic-preview",
            "message": "Update an isolated test constant.",
            "path": str(src.resolve()),
            "program_unit": "demo",
            "line": 4,
            "source_sha256": source_hash,
            "details": {
                "edits": [{
                    "operation": "replace_line",
                    "line": 4,
                    "expected": "  x = 1\n",
                    "replacement": "  x = 2\n",
                }]
            },
        },
        {
            "id": "REV-0001",
            "kind": "semantic_expression_change",
            "safety": "approval-required",
            "message": "Change a dependent expression after human review.",
            "rationale": "Synthetic approval fixture.",
            "path": str(src.resolve()),
            "program_unit": "demo",
            "line": 5,
            "source_sha256": source_hash,
            "details": {
                "edits": [{
                    "operation": "replace_line",
                    "line": 5,
                    "expected": "  y = x\n",
                    "replacement": "  y = x + 1\n",
                }]
            },
        },
        {
            "id": "BLOCK-0001",
            "kind": "ambiguous_change",
            "safety": "blocked",
            "message": "No safe transformation is available.",
            "path": str(src.resolve()),
            "program_unit": "demo",
            "line": 6,
            "details": {},
        },
    ]
    (plan / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    (plan / "suggestions.json").write_text(json.dumps(suggestions, indent=2) + "\n", encoding="utf-8")
    return plan, source


def test_classify_approve_validate_and_apply(tmp_path: Path) -> None:
    plan, _source = _plan(tmp_path)
    triage = classify_plan(plan, output_directory=tmp_path / "triage")
    assert triage.status == "REVIEW_REQUIRED"
    assert triage.counts["AUTOMATIC"] == 1
    assert triage.counts["APPROVAL_REQUIRED"] == 1
    assert triage.counts["BLOCKED"] == 1
    assert "REV-0001" in triage.review_queue.read_text(encoding="utf-8")

    approval = create_approval(
        plan,
        approved_ids=["REV-0001"],
        rejected_ids=["BLOCK-0001"],
        approved_by="Human Reviewer",
        output=tmp_path / "approvals" / "stage.json",
        confirmation=APPROVAL_CONFIRMATION,
    )
    assert validate_approval(plan, approval.approval) == []

    result = apply_approved_plan(
        plan,
        output_directory=tmp_path / "applied",
        approval_file=approval.approval,
        all_automatic=True,
    )
    assert set(result.applied_ids) == {"AUTO-0001", "REV-0001"}
    transformed = (result.transformed_root / "demo.f90").read_text(encoding="utf-8")
    assert "x = 2" in transformed
    assert "y = x + 1" in transformed
    receipt = json.loads(result.receipt.read_text(encoding="utf-8"))
    assert receipt["approved_by"] == "Human Reviewer"
    assert receipt["status"] == "PASS"


def test_approval_is_invalidated_by_source_change(tmp_path: Path) -> None:
    plan, source = _plan(tmp_path)
    approval = create_approval(
        plan,
        approved_ids=["REV-0001"],
        approved_by="Human Reviewer",
        output=tmp_path / "approval.json",
        confirmation=APPROVAL_CONFIRMATION,
    )
    path = source / "demo.f90"
    path.write_text(path.read_text(encoding="utf-8") + "! changed\n", encoding="utf-8")
    errors = validate_approval(plan, approval.approval)
    assert any("source tree hash" in item for item in errors)
    with pytest.raises(ApprovalWorkflowError):
        apply_approved_plan(
            plan,
            output_directory=tmp_path / "blocked",
            approval_file=approval.approval,
        )


def test_approval_requires_exact_human_confirmation(tmp_path: Path) -> None:
    plan, _source = _plan(tmp_path)
    with pytest.raises(ApprovalWorkflowError):
        create_approval(
            plan,
            approved_ids=["REV-0001"],
            approved_by="Human Reviewer",
            output=tmp_path / "approval.json",
            confirmation="yes",
        )


def test_install_copilot_workflow(tmp_path: Path) -> None:
    repository = tmp_path / "repo"
    repository.mkdir()
    result = install_copilot_workflow(repository)
    assert result["status"] == "PASS"
    assert (repository / ".github" / "agents" / "fortran-modernizer.agent.md").is_file()
    assert (repository / ".github" / "skills" / "fortran-human-approval" / "SKILL.md").is_file()
    assert (repository / ".github" / "hooks" / "fortran-human-approval.json").is_file()
    assert (repository / "reports" / "COPILOT_STAGE_STATUS.md").is_file()


def _run_hook(script: Path, cwd: Path, tool_name: str, tool_input: dict[str, object]) -> dict[str, object]:
    completed = subprocess.run(
        [sys.executable, str(script)],
        cwd=cwd,
        input=json.dumps({"hook_event_name": "PreToolUse", "cwd": str(cwd), "tool_name": tool_name, "tool_input": tool_input}),
        text=True,
        capture_output=True,
        check=True,
    )
    return json.loads(completed.stdout)


def test_hook_blocks_bypass_and_allows_valid_approval(tmp_path: Path) -> None:
    repository = tmp_path / "repo"
    repository.mkdir()
    install_copilot_workflow(repository)
    hook = repository / ".github" / "hooks" / "scripts" / "fortran_policy_hook.py"

    denied = _run_hook(hook, repository, "editFiles", {"files": ["legacy-original/a.f"]})
    assert denied["hookSpecificOutput"]["permissionDecision"] == "deny"

    denied = _run_hook(hook, repository, "runInTerminal", {"command": "./frt apply plan --approve-review -o work/x"})
    assert denied["hookSpecificOutput"]["permissionDecision"] == "deny"

    denied = _run_hook(
        hook,
        repository,
        "runInTerminal",
        {"command": "./fortran-modernize approve-plan plan --id REV-0001 --approved-by AI --confirm x --output approval.json"},
    )
    assert denied["hookSpecificOutput"]["permissionDecision"] == "deny"

    plan, _source = _plan(tmp_path)
    approval = create_approval(
        plan,
        approved_ids=["REV-0001"],
        approved_by="Human Reviewer",
        output=tmp_path / "approval.json",
        confirmation=APPROVAL_CONFIRMATION,
    )
    command = (
        f"./fortran-modernize apply-approved {shlex_quote(plan)} "
        f"--approval {shlex_quote(approval.approval)} --output-directory work/stage"
    )
    denied = _run_hook(hook, repository, "runInTerminal", {"command": command})
    assert denied["hookSpecificOutput"]["permissionDecision"] == "deny"


def shlex_quote(path: Path) -> str:
    import shlex
    return shlex.quote(str(path))
