from __future__ import annotations

import json
from pathlib import Path

from fortran_modernize.selection import has_kernel_selection, run_kernel_selection


def _write_inputs(tmp_path: Path, *, max_break_even: float = 1000.0) -> tuple[Path, Path, dict[str, Path]]:
    cases = []
    perf_cases = []
    timings = {
        "light": {"python": 1.0, "cython-safe": 0.75, "cython-optimized": 0.62},
        "standard": {"python": 2.0, "cython-safe": 1.4, "cython-optimized": 2.5},
        "heavy": {"python": 4.0, "cython-safe": 3.0, "cython-optimized": 2.4},
    }
    for name, values in timings.items():
        cases.append({
            "name": name,
            "backends": {
                "cython-safe": {"deterministic": True},
                "cython-optimized": {"deterministic": True},
            },
            "comparisons": {
                "cython-safe": {"passed": True},
                "cython-optimized": {"passed": True},
            },
        })
        comparisons = {}
        backends = {}
        for backend, seconds in values.items():
            backends[backend] = {"statistics": {"median_seconds": seconds}}
            if backend != "python":
                comparisons[backend] = {
                    "baseline_median_seconds": values["python"],
                    "candidate_median_seconds": seconds,
                    "speedup": values["python"] / seconds,
                }
        perf_cases.append({"name": name, "backends": backends, "comparisons": comparisons})
    regression = tmp_path / "regression_report.json"
    regression.write_text(json.dumps({
        "status": "PASS",
        "cases": cases,
        "performance": {"baseline": "python", "cases": perf_cases},
    }), encoding="utf-8")

    artifacts: dict[str, Path] = {}
    for backend, elapsed, size in (
        ("safe", 2.0, 500_000),
        ("optimized", 4.0, 800_000),
    ):
        path = tmp_path / f"{backend}_build.json"
        path.write_text(json.dumps({
            "status": "PASS",
            "elapsed_seconds": elapsed,
            "extension_size_bytes": size,
        }), encoding="utf-8")
        artifacts[f"{backend}_build"] = path

    config = tmp_path / "config.json"
    config.write_text(json.dumps({
        "schema_version": "1.2",
        "kernel_selection": {
            "enabled": True,
            "case_weights": {"light": 1.0, "standard": 2.0, "heavy": 3.0},
            "minimum_weighted_speedup": 1.2,
            "minimum_case_speedup": 0.9,
            "minimum_case_coverage": 1.0,
            "maximum_break_even_runs": max_break_even,
            "groups": {
                "solve_reynolds": {
                    "fallback": "python",
                    "candidates": {
                        "cython-safe": {"build_report_artifact": "safe_build"},
                        "cython-optimized": {"build_report_artifact": "optimized_build"},
                    },
                }
            },
        },
    }), encoding="utf-8")
    return regression, config, artifacts


def test_selection_rejects_worst_case_slowdown_and_selects_safe(tmp_path: Path) -> None:
    regression, config, artifacts = _write_inputs(tmp_path)
    assert has_kernel_selection(config) is True
    result = run_kernel_selection(
        regression,
        config,
        artifacts=artifacts,
        output_directory=tmp_path / "selection",
    )
    assert result.status == "PASS"
    assert result.selected == {"solve_reynolds": "cython-safe"}
    payload = json.loads(result.report.read_text(encoding="utf-8"))
    candidates = {item["backend"]: item for item in payload["groups"][0]["candidates"]}
    assert candidates["cython-safe"]["decision"] == "SELECTED"
    assert candidates["cython-optimized"]["decision"] == "REJECTED"
    assert "minimum_case_speedup" in candidates["cython-optimized"]["reasons"]


def test_selection_uses_fallback_when_break_even_is_too_large(tmp_path: Path) -> None:
    regression, config, artifacts = _write_inputs(tmp_path, max_break_even=0.01)
    result = run_kernel_selection(
        regression,
        config,
        artifacts=artifacts,
        output_directory=tmp_path / "selection",
    )
    assert result.selected == {"solve_reynolds": "python"}
    payload = json.loads(result.deployment_plan.read_text(encoding="utf-8"))
    assert payload["selected_backends"]["solve_reynolds"] == "python"
