from __future__ import annotations

import hashlib
import json
from pathlib import Path

import pytest

from fortran_modernize.approval import APPROVAL_CONFIRMATION
from fortran_modernize.workflow import (
    WORKFLOW_CONFIRMATION,
    WorkflowError,
    advance_workflow_state,
    apply_ready_workflow,
    create_ready_approval,
    initialize_workflow_state,
    record_workflow_gate,
    schedule_workflow,
)


def _write_plan(tmp_path: Path, suggestions: list[dict[str, object]]) -> tuple[Path, Path]:
    source = tmp_path / "source"
    source.mkdir()
    code = (
        "program demo\n"
        "  integer x, y\n"
        "  x = 1\n"
        "  y = x\n"
        "  print *, y\n"
        "end program demo\n"
    )
    src = source / "demo.f90"
    src.write_text(code, encoding="utf-8")
    digest = hashlib.sha256(code.encode("utf-8")).hexdigest()
    for item in suggestions:
        item.setdefault("path", str(src.resolve()))
        item.setdefault("program_unit", "demo")
        item.setdefault("source_sha256", digest)
    plan = tmp_path / "plan"
    plan.mkdir()
    (plan / "manifest.json").write_text(
        json.dumps({"schema_version": 1, "kind": "mixed-plan", "source_root": str(source.resolve())}, indent=2) + "\n",
        encoding="utf-8",
    )
    (plan / "suggestions.json").write_text(json.dumps(suggestions, indent=2) + "\n", encoding="utf-8")
    return plan, source


def _evidence(tmp_path: Path, name: str) -> Path:
    path = tmp_path / f"{name}.json"
    path.write_text(json.dumps({"status": "PASS", "name": name}) + "\n", encoding="utf-8")
    return path


def _set_gate(state: Path, tmp_path: Path, gate: str, *, human: bool = False) -> None:
    record_workflow_gate(
        state,
        gate_id=gate,
        status="PASS",
        actor_kind="human" if human else "tool",
        recorded_by="Human Reviewer" if human else "test-tool",
        evidence=[_evidence(tmp_path, gate)],
        confirmation=WORKFLOW_CONFIRMATION if human else None,
    )


def test_typo_approval_precedes_automatic_cleanup(tmp_path: Path) -> None:
    plan, _source = _write_plan(
        tmp_path,
        [
            {
                "id": "TYPO-0001",
                "kind": "rename_implicit_typo",
                "safety": "automatic-preview",
                "line": 3,
                "message": "Possible typo requires semantic review.",
                "details": {"edits": [{"operation": "replace_line", "line": 3, "expected": "  x = 1\n", "replacement": "  x = 2\n"}]},
            },
            {
                "id": "AUTO-0001",
                "kind": "safe_cleanup",
                "safety": "automatic-preview",
                "line": 4,
                "message": "Mechanical cleanup.",
                "details": {"edits": [{"operation": "replace_line", "line": 4, "expected": "  y = x\n", "replacement": "  y = x + 0\n"}]},
            },
        ],
    )
    state = initialize_workflow_state(plan, output=tmp_path / "state.json")
    for gate, human in (
        ("GATE-READ_ONLY_ANALYSIS", False),
        ("GATE-LEGACY_BASELINE", True),
        ("GATE-REGRESSION_BASELINE", True),
    ):
        _set_gate(state, tmp_path, gate, human=human)

    first = schedule_workflow(plan, state_file=state, output_directory=tmp_path / "schedule-1")
    assert first.status == "REVIEW_REQUIRED"
    assert first.ready_approval_ids == ("TYPO-0001",)
    assert first.ready_automatic_ids == ()
    payload = json.loads(first.workflow.read_text(encoding="utf-8"))
    typo = next(item for item in payload["candidates"] if item["id"] == "TYPO-0001")
    assert typo["original_category"] == "AUTOMATIC"
    assert typo["effective_category"] == "APPROVAL_REQUIRED"

    approval = create_ready_approval(
        plan,
        workflow_file=first.workflow,
        approved_ids=["TYPO-0001"],
        approved_by="Human Reviewer",
        output=tmp_path / "approval.json",
        confirmation=APPROVAL_CONFIRMATION,
    )
    applied = apply_ready_workflow(
        plan,
        workflow_file=first.workflow,
        approval_file=approval,
        output_directory=tmp_path / "applied-typo",
    )
    assert applied.applied_ids == ("TYPO-0001",)
    advance_workflow_state(state, workflow_file=first.workflow, receipt_file=applied.receipt)
    _set_gate(state, tmp_path, "GATE-TYPO_CANDIDATES_RESOLVED", human=True)
    _set_gate(state, tmp_path, "GATE-READ_ONLY_ANALYSIS")

    transformed = applied.transformed_root / "demo.f90"
    code2 = transformed.read_text(encoding="utf-8")
    digest2 = hashlib.sha256(code2.encode("utf-8")).hexdigest()
    plan2 = tmp_path / "plan-2"
    plan2.mkdir()
    (plan2 / "manifest.json").write_text(
        json.dumps({"schema_version": 1, "kind": "cleanup-plan", "source_root": str(applied.transformed_root)}, indent=2) + "\n",
        encoding="utf-8",
    )
    (plan2 / "suggestions.json").write_text(
        json.dumps([{
            "id": "AUTO-0001",
            "kind": "safe_cleanup",
            "safety": "automatic-preview",
            "path": str(transformed),
            "program_unit": "demo",
            "line": 4,
            "source_sha256": digest2,
            "details": {"edits": [{"operation": "replace_line", "line": 4, "expected": "  y = x\n", "replacement": "  y = x + 0\n"}]},
        }], indent=2) + "\n",
        encoding="utf-8",
    )
    second = schedule_workflow(plan2, state_file=state, output_directory=tmp_path / "schedule-2")
    assert second.status == "READY"
    assert second.ready_automatic_ids == ("AUTO-0001",)
    assert second.ready_approval_ids == ()


def test_absoft_portability_approval_blocks_later_automatic(tmp_path: Path) -> None:
    plan, _source = _write_plan(
        tmp_path,
        [
            {
                "id": "PORT-0001",
                "kind": "manual_diagnostic_resolution",
                "safety": "approval-required",
                "line": 3,
                "details": {"edits": [{"operation": "replace_line", "line": 3, "expected": "  x = 1\n", "replacement": "  x = 2\n"}]},
            },
            {
                "id": "AUTO-0001",
                "kind": "safe_cleanup",
                "safety": "automatic-preview",
                "line": 4,
                "details": {"edits": [{"operation": "replace_line", "line": 4, "expected": "  y = x\n", "replacement": "  y = x + 0\n"}]},
            },
        ],
    )
    state = initialize_workflow_state(plan, output=tmp_path / "state.json")
    _set_gate(state, tmp_path, "GATE-READ_ONLY_ANALYSIS")
    _set_gate(state, tmp_path, "GATE-LEGACY_BASELINE", human=True)
    _set_gate(state, tmp_path, "GATE-REGRESSION_BASELINE", human=True)
    schedule = schedule_workflow(plan, state_file=state, output_directory=tmp_path / "schedule")
    assert schedule.ready_approval_ids == ("PORT-0001",)
    assert schedule.ready_automatic_ids == ()
    payload = json.loads(schedule.workflow.read_text(encoding="utf-8"))
    auto = next(item for item in payload["candidates"] if item["id"] == "AUTO-0001")
    assert auto["readiness"] == "WAITING_PHASE"


def test_implicit_none_waits_for_semantic_gates(tmp_path: Path) -> None:
    plan, _source = _write_plan(
        tmp_path,
        [
            {
                "id": "IMP-0001",
                "kind": "introduce_implicit_none",
                "safety": "approval-required",
                "line": 2,
                "details": {"edits": [{"operation": "replace_line", "line": 2, "expected": "  integer x, y\n", "replacement": "  implicit none\n  integer x, y\n"}]},
            }
        ],
    )
    state = initialize_workflow_state(plan, output=tmp_path / "state.json")
    schedule = schedule_workflow(plan, state_file=state, output_directory=tmp_path / "schedule")
    assert schedule.status == "WAITING"
    payload = json.loads(schedule.workflow.read_text(encoding="utf-8"))
    item = payload["candidates"][0]
    assert item["readiness"] == "WAITING_APPROVAL"
    assert "GATE-TYPO_CANDIDATES_RESOLVED" in item["missing_gates"]
    assert "GATE-GFORTRAN_PORTABILITY" in item["missing_gates"]


def test_human_gate_requires_confirmation_and_evidence(tmp_path: Path) -> None:
    plan, _source = _write_plan(tmp_path, [])
    state = initialize_workflow_state(plan, output=tmp_path / "state.json")
    with pytest.raises(WorkflowError):
        record_workflow_gate(
            state,
            gate_id="GATE-LEGACY_BASELINE",
            status="PASS",
            actor_kind="tool",
            recorded_by="agent",
            evidence=[_evidence(tmp_path, "legacy")],
        )
    with pytest.raises(WorkflowError):
        record_workflow_gate(
            state,
            gate_id="GATE-LEGACY_BASELINE",
            status="PASS",
            actor_kind="human",
            recorded_by="reviewer",
            evidence=[],
            confirmation=WORKFLOW_CONFIRMATION,
        )


def test_apply_ready_rejects_stale_workflow(tmp_path: Path) -> None:
    plan, source = _write_plan(
        tmp_path,
        [{
            "id": "AUTO-0001",
            "kind": "safe_cleanup",
            "safety": "automatic-preview",
            "line": 4,
            "details": {"edits": [{"operation": "replace_line", "line": 4, "expected": "  y = x\n", "replacement": "  y = x + 0\n"}]},
        }],
    )
    state = initialize_workflow_state(plan, output=tmp_path / "state.json")
    _set_gate(state, tmp_path, "GATE-READ_ONLY_ANALYSIS")
    _set_gate(state, tmp_path, "GATE-LEGACY_BASELINE", human=True)
    _set_gate(state, tmp_path, "GATE-REGRESSION_BASELINE", human=True)
    schedule = schedule_workflow(plan, state_file=state, output_directory=tmp_path / "schedule")
    path = source / "demo.f90"
    path.write_text(path.read_text(encoding="utf-8") + "! changed\n", encoding="utf-8")
    with pytest.raises(WorkflowError):
        apply_ready_workflow(
            plan,
            workflow_file=schedule.workflow,
            output_directory=tmp_path / "blocked",
        )


def test_hook_allows_only_dependency_aware_apply_ready(tmp_path: Path) -> None:
    import shlex
    import subprocess
    import sys

    from fortran_modernize.approval import install_copilot_workflow

    plan, _source = _write_plan(
        tmp_path,
        [{
            "id": "AUTO-0001",
            "kind": "safe_cleanup",
            "safety": "automatic-preview",
            "line": 4,
            "details": {"edits": [{"operation": "replace_line", "line": 4, "expected": "  y = x\n", "replacement": "  y = x + 0\n"}]},
        }],
    )
    state = initialize_workflow_state(plan, output=tmp_path / "state.json")
    _set_gate(state, tmp_path, "GATE-READ_ONLY_ANALYSIS")
    _set_gate(state, tmp_path, "GATE-LEGACY_BASELINE", human=True)
    _set_gate(state, tmp_path, "GATE-REGRESSION_BASELINE", human=True)
    schedule = schedule_workflow(plan, state_file=state, output_directory=tmp_path / "schedule")

    repo = tmp_path / "repo"
    repo.mkdir()
    install_copilot_workflow(repo)
    hook = repo / ".github" / "hooks" / "scripts" / "fortran_policy_hook.py"
    command = (
        f"./fortran-modernize apply-ready {shlex.quote(str(plan))} "
        f"--workflow {shlex.quote(str(schedule.workflow))} --output-directory work/stage"
    )
    completed = subprocess.run(
        [sys.executable, str(hook)],
        cwd=repo,
        input=json.dumps({
            "hook_event_name": "PreToolUse",
            "cwd": str(repo),
            "tool_name": "runInTerminal",
            "tool_input": {"command": command},
        }),
        text=True,
        capture_output=True,
        check=True,
    )
    decision = json.loads(completed.stdout)
    assert decision["hookSpecificOutput"]["permissionDecision"] == "allow"
