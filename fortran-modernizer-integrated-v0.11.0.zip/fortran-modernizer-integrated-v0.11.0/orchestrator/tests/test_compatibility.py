from __future__ import annotations

import json
from pathlib import Path

from fortran_modernize.compatibility import (
    build_compatibility_suite,
    summarize_compatibility_results,
    validate_compatibility_suite,
)


def _write_json(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")


def _fake_distribution(root: Path, target: str) -> Path:
    kit = root / target
    runtime = kit / "payload" / "runtime"
    source = kit / "payload" / "native_sources" / "advance" / "fpy_advance_safe.py"
    source.parent.mkdir(parents=True, exist_ok=True)
    source.write_text("def advance(x): return x\n", encoding="utf-8")
    runtime.mkdir(parents=True)
    _write_json(runtime / "runtime_config.json", {"schema_version": "1.0"})
    (runtime / "run-runtime").write_text("#!/usr/bin/env python3\n", encoding="utf-8")
    (kit / "tools").mkdir()
    for name in ("probe_environment.py", "build_backends.py", "self_check.py"):
        (kit / "tools" / name).write_text("raise SystemExit(0)\n", encoding="utf-8")
    (kit / "requirements-build.txt").write_text("numpy\nCython\nsetuptools\n", encoding="utf-8")
    _write_json(
        kit / "distribution_manifest.json",
        {
            "schema_version": "1.0",
            "toolchain_version": "0.8.0",
            "status": "PASS",
            "target": target,
            "runtime_root": "payload/runtime",
            "runtime_config": "payload/runtime/runtime_config.json",
            "runtime_launcher": "payload/runtime/run-runtime",
            "native_extensions": [
                {"source": "payload/native_sources/advance/fpy_advance_safe.py"}
            ],
        },
    )
    return kit


def _cell_payload(cell_id: str, status: str) -> dict:
    return {
        "schema_version": "1.0",
        "toolchain_version": "0.8.0",
        "cell_id": cell_id,
        "status": status,
        "system": "test-system",
        "machine": "x86_64",
        "checks": {
            "target": status,
            "environment": status,
            "native_rebuild": status,
            "self_check": status,
        },
        "native_rebuild": {"fortran": {"status": status}},
    }


def test_build_compatibility_suite_generates_matrix_and_workflow(tmp_path: Path) -> None:
    linux = _fake_distribution(tmp_path / "inputs", "linux-wsl")
    windows = _fake_distribution(tmp_path / "inputs", "windows-native")
    result = build_compatibility_suite(
        linux_kit=linux,
        windows_kit=windows,
        output_directory=tmp_path / "suite",
        python_versions=("3.11", "3.13"),
    )
    assert result.status == "PASS"
    assert validate_compatibility_suite(result.output_directory) == []
    manifest = json.loads(result.manifest.read_text(encoding="utf-8"))
    assert len(manifest["matrix"]) == 4
    assert {item["target"] for item in manifest["matrix"]} == {
        "linux-wsl",
        "windows-native",
    }
    workflow = result.workflow.read_text(encoding="utf-8")
    assert "actions/checkout@v6" in workflow
    assert "actions/setup-python@v6" in workflow
    assert "fortran-lang/setup-fortran@v1" in workflow
    initial = json.loads(result.summary.read_text(encoding="utf-8"))
    assert initial["status"] == "REVIEW_REQUIRED"
    assert initial["not_run_cells"] == 4


def test_compatibility_summary_keeps_blocked_and_not_run_distinct(tmp_path: Path) -> None:
    linux = _fake_distribution(tmp_path / "inputs", "linux-wsl")
    windows = _fake_distribution(tmp_path / "inputs", "windows-native")
    suite = build_compatibility_suite(
        linux_kit=linux,
        windows_kit=windows,
        output_directory=tmp_path / "suite",
        python_versions=("3.12",),
    )
    results = tmp_path / "results"
    _write_json(results / "linux" / "compatibility_result.json", _cell_payload("linux-wsl-py312", "PASS"))
    _write_json(results / "windows" / "compatibility_result.json", _cell_payload("windows-native-py312", "BLOCKED"))
    summary = summarize_compatibility_results(
        suite_manifest=suite.manifest,
        results_directory=results,
        output_directory=tmp_path / "summary",
    )
    assert summary.status == "BLOCKED"
    report = json.loads(summary.report.read_text(encoding="utf-8"))
    assert report["passed_cells"] == 1
    assert report["blocked_cells"] == 1
    assert report["not_run_cells"] == 0


def test_compatibility_validation_rejects_binary_leak(tmp_path: Path) -> None:
    linux = _fake_distribution(tmp_path / "inputs", "linux-wsl")
    windows = _fake_distribution(tmp_path / "inputs", "windows-native")
    suite = build_compatibility_suite(
        linux_kit=linux,
        windows_kit=windows,
        output_directory=tmp_path / "suite",
        python_versions=("3.13",),
    )
    leaked = suite.output_directory / "kits" / "windows-native" / "bad.pyd"
    leaked.write_bytes(b"bad")
    errors = validate_compatibility_suite(suite.output_directory)
    assert any("binary leaked" in item for item in errors)
