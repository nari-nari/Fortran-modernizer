from __future__ import annotations

import importlib.util
import json
import sys
from pathlib import Path

import numpy as np
import pytest

from fortran_modernize.pipeline import ProcedureMigrationError, run_procedure_migration
from fortran_modernize.runtime import run_runtime_bundle


ROOT = Path(__file__).resolve().parents[2]
MIGRATOR = ROOT / "packages" / "fortran-python-migrator"


def _load_module(path: Path):
    name = f"generated_{path.stem}_{abs(hash(path))}"
    spec = importlib.util.spec_from_file_location(name, path)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def test_legacy_vertical_slice_generates_executable_python(tmp_path: Path) -> None:
    sample = MIGRATOR / "samples" / "e2e" / "journal_bearing"
    output = tmp_path / "migration"

    result = run_procedure_migration(
        sample / "normalized" / "journal_bearing_normalized.f90",
        procedure="run_numeric",
        legacy_source=sample / "legacy" / "journal_bearing_legacy.for",
        legacy_include_dirs=[sample / "legacy" / "include"],
        output_directory=output,
    )

    assert result.status == "PASS"
    manifest = json.loads(result.manifest.read_text(encoding="utf-8"))
    assert manifest["status"] == "PASS"
    assert manifest["artifacts"]["python_source"] == "07_python/run_numeric_generated.py"
    connection = json.loads(
        (output / manifest["artifacts"]["connection"]).read_text(encoding="utf-8")
    )
    assert connection["status"] == "PASS"
    assert set(connection["coverage"].values()) == {1.0}

    generated = _load_module(output / manifest["artifacts"]["python_source"])
    state = generated.CommonFieldState(
        p=np.zeros((36, 17), dtype=np.float64, order="F"),
        h=np.zeros(36, dtype=np.float64),
        theta=np.zeros(36, dtype=np.float64),
    )
    actual = generated.run_numeric(state)
    expected = (
        173,
        9.3243524013075785e-11,
        2.6071517885680344,
        3.1797719040494399,
        0.4,
        7.8539816339744828,
    )
    assert actual[0] == expected[0]
    assert np.allclose(actual[1:], expected[1:], rtol=1.0e-12, atol=1.0e-13)


def test_optional_cython_sources_are_generated_for_stateless_kernel(tmp_path: Path) -> None:
    source = MIGRATOR / "samples" / "migration_units" / "compute_film.f90"
    result = run_procedure_migration(
        source,
        procedure="compute_film",
        output_directory=tmp_path / "cython",
        cython_modes=["safe", "optimized"],
    )

    assert result.status == "PASS"
    manifest = json.loads(result.manifest.read_text(encoding="utf-8"))
    assert Path(result.output_directory / manifest["artifacts"]["cython_safe_source"]).is_file()
    assert Path(result.output_directory / manifest["artifacts"]["cython_optimized_source"]).is_file()
    assert Path(result.output_directory / manifest["artifacts"]["cython_safe_extension"]).is_file()
    assert Path(result.output_directory / manifest["artifacts"]["cython_optimized_extension"]).is_file()
    assert Path(result.output_directory / manifest["artifacts"]["cython_safe_build_report"]).is_file()
    assert Path(result.output_directory / manifest["artifacts"]["cython_optimized_build_report"]).is_file()


def test_blocked_pipeline_keeps_machine_readable_manifest(tmp_path: Path) -> None:
    source = MIGRATOR / "samples" / "migration_units" / "unsupported_select.f90"
    output = tmp_path / "blocked"

    with pytest.raises(ProcedureMigrationError) as caught:
        run_procedure_migration(
            source,
            procedure="unsupported_select",
            output_directory=output,
        )

    assert caught.value.manifest == output / "migration_manifest.json"
    payload = json.loads(caught.value.manifest.read_text(encoding="utf-8"))
    assert payload["status"] == "BLOCKED"
    assert payload["stages"][-1]["status"] == "BLOCKED"
    assert "unsupported" in payload["error"].lower()


def test_vertical_slice_runs_project_regression_gate(tmp_path: Path) -> None:
    import shutil

    if shutil.which("gfortran") is None:
        pytest.skip("gfortran is required for the regression integration test")
    sample = MIGRATOR / "samples" / "e2e" / "journal_bearing"
    config = ROOT / "examples" / "regression" / "journal_bearing_regression.json"
    result = run_procedure_migration(
        sample / "normalized" / "journal_bearing_normalized.f90",
        procedure="run_numeric",
        legacy_source=sample / "legacy" / "journal_bearing_legacy.for",
        legacy_include_dirs=[sample / "legacy" / "include"],
        regression_config=config,
        output_directory=tmp_path / "regression_pipeline",
    )

    assert result.status == "PASS"
    manifest = json.loads(result.manifest.read_text(encoding="utf-8"))
    report_path = result.output_directory / manifest["artifacts"]["numerical_regression"]
    report = json.loads(report_path.read_text(encoding="utf-8"))
    assert report["status"] == "PASS"
    assert report["summary"]["failed_comparisons"] == 0
    assert report["summary"]["failed_determinism_checks"] == 0
    assert report["cases"][0]["comparisons"]["python"]["passed"] is True


def test_state_kernel_cython_backends_match_fortran_and_report_performance(tmp_path: Path) -> None:
    import shutil

    if shutil.which("gfortran") is None or shutil.which("gcc") is None:
        pytest.skip("gfortran and a C compiler are required")
    sample = MIGRATOR / "samples" / "e2e" / "journal_bearing"
    config = ROOT / "examples" / "regression" / "journal_bearing_cython_regression.json"
    result = run_procedure_migration(
        sample / "normalized" / "journal_bearing_normalized.f90",
        procedure="run_numeric",
        legacy_source=sample / "legacy" / "journal_bearing_legacy.for",
        legacy_include_dirs=[sample / "legacy" / "include"],
        state_kernels=["solve_reynolds"],
        regression_config=config,
        output_directory=tmp_path / "cython_regression_pipeline",
    )

    assert result.status == "PASS"
    manifest = json.loads(result.manifest.read_text(encoding="utf-8"))
    assert "state_kernel_solve_reynolds_cython_safe_extension" in manifest["artifacts"]
    assert "state_kernel_solve_reynolds_cython_optimized_extension" in manifest["artifacts"]
    report = json.loads(
        (result.output_directory / manifest["artifacts"]["numerical_regression"]).read_text(encoding="utf-8")
    )
    assert report["status"] == "PASS"
    assert report["cases"][0]["comparisons"]["cython-safe"]["passed"] is True
    assert report["cases"][0]["comparisons"]["cython-optimized"]["passed"] is True
    assert report["performance"]["status"] == "PASS"
    assert report["performance"]["cases"][0]["comparisons"]["cython-optimized"]["speedup"] >= 1.0


def test_auto_state_kernel_selection_across_cases(tmp_path: Path) -> None:
    import shutil

    if shutil.which("gfortran") is None or shutil.which("gcc") is None:
        pytest.skip("gfortran and a C compiler are required")
    sample = MIGRATOR / "samples" / "e2e" / "journal_bearing"
    config = ROOT / "examples" / "regression" / "journal_bearing_kernel_selection.json"
    result = run_procedure_migration(
        sample / "normalized" / "journal_bearing_normalized.f90",
        procedure="run_numeric",
        legacy_source=sample / "legacy" / "journal_bearing_legacy.for",
        legacy_include_dirs=[sample / "legacy" / "include"],
        auto_state_kernels=True,
        regression_config=config,
        output_directory=tmp_path / "auto_selection_pipeline",
    )

    assert result.status == "PASS"
    manifest = json.loads(result.manifest.read_text(encoding="utf-8"))
    candidate_report = json.loads(
        (result.output_directory / manifest["artifacts"]["state_kernel_candidates"]).read_text(encoding="utf-8")
    )
    assert candidate_report["resolved_candidates"] == ["solve_reynolds"]
    selection = json.loads(
        (result.output_directory / manifest["artifacts"]["kernel_selection"]).read_text(encoding="utf-8")
    )
    assert selection["selected"]["solve_reynolds"] in {"cython-safe", "cython-optimized"}
    assert all(group["status"] == "SELECTED" for group in selection["groups"])
    runtime_dir = result.output_directory / manifest["artifacts"]["runtime_bundle"]
    runtime_health = json.loads((runtime_dir / "runtime_health.json").read_text(encoding="utf-8"))
    assert runtime_health["status"] == "PASS"
    execution = run_runtime_bundle(
        runtime_dir,
        backend="auto",
        case="light",
        snapshot=tmp_path / "runtime_snapshot.json",
        report=tmp_path / "runtime_report.json",
    )
    assert execution.backend in {"cython-safe", "cython-optimized"}
