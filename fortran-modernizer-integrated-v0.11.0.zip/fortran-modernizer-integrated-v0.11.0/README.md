# Fortran Modernizer integrated project v0.11.0

This is the user-facing all-in-one workspace for:

- **fortran-refactor-tool v0.50.0**;
- **fortran-python-migrator v0.23.0 / Milestone 23**;
- **fortran-modernize orchestrator v0.11.0**;
- the **Fortran Modernizer GitHub Copilot custom agent**;
- seven stage-specific Copilot skills;
- the dependency-aware human-approval Hook;
- a deterministic CLI-only fallback.

The distribution is integrated for the user, while the deterministic core and
Copilot navigation remain internally separated. Copilot does not decide whether
a candidate is safe, create human approval evidence, or bypass source/plan hash
checks.

## First use

Read `README_FIRST.md`, then initialize or refresh the workspace:

```bash
./fortran-modernize setup-project .
./fortran-modernize doctor --project-root .
```

Copy an untouched project during setup if preferred:

```bash
./fortran-modernize setup-project . \
  --source /path/to/legacy-project \
  --legacy-compiler Absoft
```

Open this directory in VS Code and select **Fortran Modernizer**. Start with:

```text
legacy-originalを読み取り専用で解析してください。
依存グラフ上でREADYな自動処理だけを検証付きで進め、
要承認候補が先行する場合は推奨案と候補IDを提示して停止してください。
```

Static files cannot prove that VS Code loaded the agent or enabled Preview
Hooks. `doctor` reports that runtime state as unknown rather than claiming PASS.
If Copilot or Hooks are unavailable under company policy, use
`docs/CLI_ONLY_WORKFLOW.md`; all hashes, gates, approvals, and validation rules
remain the same.

## Integrated layout

```text
.github/                  Copilot instructions, agent, skills, Hook
config/                   project and workflow policy
legacy-original/          immutable input source
work/                     staged reviewed Fortran outputs
build/                    migration/runtime/distribution outputs
approvals/                human-created approval evidence
reports/                  status, schedules, diagnostics, audit logs
orchestrator/             deterministic integration CLI
packages/                 refactor and Python-migration engines
```

Production-code applicability is still unvalidated. Begin with read-only
analysis and a small pilot procedure; do not start whole-project automatic
conversion.

## Dependency-aware Human-in-the-loop refactoring

Initialize state for the current source tree and plan:

```bash
./fortran-modernize init-workflow-state reports/current-plan \
  --output reports/workflow_state.json
```

Record evidence for prerequisites. Tool gates may be recorded by automation;
human-required gates such as the legacy/Absoft baseline and reviewed regression
definition require a human confirmation and evidence file.

```bash
./fortran-modernize record-workflow-gate reports/workflow_state.json \
  --gate GATE-READ_ONLY_ANALYSIS --status PASS --actor-kind tool \
  --recorded-by frt --evidence reports/analysis.json
```

Schedule the next safe action:

```bash
./fortran-modernize schedule-workflow reports/current-plan \
  --state reports/workflow_state.json \
  --output-directory reports/current-schedule
```

The scheduler emits `workflow_plan.json`, `workflow_summary.csv`, and
`NEXT_ACTION.md`. It distinguishes `READY_AUTOMATIC`, `WAITING_AUTOMATIC`,
`READY_APPROVAL`, `WAITING_APPROVAL`, `WAITING_PHASE`, and blocked/manual
states. A `READY_APPROVAL` candidate in the active phase stops automatic edits.

A human approves only currently ready IDs:

```bash
./fortran-modernize approve-ready reports/current-plan \
  --workflow reports/current-schedule/workflow_plan.json \
  --id TYPO-0003 --approved-by "Human Reviewer" \
  --confirm "I APPROVE THESE FORTRAN CHANGES" \
  --output approvals/current-stage.json
```

Apply only the workflow-exposed candidates:

```bash
./fortran-modernize apply-ready reports/current-plan \
  --workflow reports/current-schedule/workflow_plan.json \
  --approval approvals/current-stage.json \
  --compile-check --output-directory work/current-stage
```

After parser/compiler/regression validation, advance state to the transformed
source root and regenerate analysis and a new plan before continuing:

```bash
./fortran-modernize advance-workflow-state reports/workflow_state.json \
  --workflow reports/current-schedule/workflow_plan.json \
  --receipt work/current-stage/workflow_apply_receipt.json
```

Important enforced orderings include:

- legacy/Absoft baseline before gfortran portability corrections;
- typo review before remaining implicit-type declarations and IMPLICIT NONE;
- COMMON layout resolution before centralization and module migration;
- call-signature resolution before interfaces, INTENT, and procedure modules;
- EQUIVALENCE proof before state-object or Python migration;
- current Fortran regression PASS before Python/Cython migration.

The older `classify-plan`, `approve-plan`, and `apply-approved` commands remain
for compatibility, but the installed Copilot Hook rejects their use as an agent
bypass. The Copilot workflow uses `schedule-workflow`, `approve-ready`, and
`apply-ready`.

## GitHub Copilot workflow installation

```bash
./fortran-modernize install-copilot-workflow /path/to/your/project
```

The installed custom agent and skills follow `NEXT_ACTION.md`. The PreToolUse
Hook denies direct Fortran edits, direct `frt apply`, legacy approval/application
commands, agent-created human gates, and stale workflow/approval evidence.

## Offline setup

```bash
./setup-offline.sh
```

Python 3.11 or newer is required. The supplied wheels provide `fparser 0.2.4`
and the Linux x86_64 `findent 4.3.6` executable. A completely fresh offline
machine also needs compatible wheels for NumPy, Cython, jsonschema, pytest,
setuptools, and wheel. Native Cython builds require a C compiler and compatible
Python development headers. Fortran compilation and the optional Fortran
runtime fallback require gfortran or an equivalent configured compiler.

## End-to-end migration

```bash
./fortran-modernize migrate-procedure path/to/reviewed-fortran \
  --procedure root_subroutine \
  --legacy-source path/to/original-legacy-fortran \
  --legacy-include-dir path/to/legacy/includes \
  --auto-state-kernels \
  --regression-config path/to/kernel_selection.json \
  --output-directory build/root-subroutine-migration \
  --overwrite
```

The reviewed source must be the human-reviewed result of the staged v0.50.0
refactoring process. The command does not silently apply all refactoring
suggestions.

When `kernel_selection` is enabled and all gates pass, the retained runtime
stage creates:

```text
12_runtime/
├── application/generated_application.py
├── kernels/<kernel>/
├── support/
├── fortran/                       # when a validated executable is available
├── runtime_api.py
├── runtime_config.json
├── runtime_health.json
├── runtime_manifest.json
├── runtime_dispatch.py
└── run-runtime
```

Use `--no-runtime-package` to omit this stage. Use `--strict-runtime` to reject
a package when the reviewed selected backend cannot be imported exactly.


## Target rebuild distributions

Create a source-only kit from any PASS v0.6-or-later migration result:

```bash
./fortran-modernize package-distribution build/migration \
  --target linux-wsl \
  --app-name lubrication-runtime \
  --output-directory build/distribution-linux \
  --overwrite
```

For Windows-native preparation, change `--target` to `windows-native`. The kit
contains generated Python, Cython sources, optional reviewed Fortran sources,
reference snapshots, environment probes, and target-side build scripts. It
intentionally excludes `.so`, `.pyd`, `.dll`, `.exe`, object, and static-library
artifacts from the development host.

On WSL/Linux:

```bash
cd build/distribution-linux
./build_wsl.sh
```

On Windows PowerShell:

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\build_windows.ps1
```

A completely offline target must place compatible wheels for NumPy, Cython,
and setuptools under `wheelhouse/`. Each build produces:

- `environment_report.json`;
- `native_rebuild_report.json`;
- `distribution_self_check.json`.

The self-check executes every configured backend for every retained regression
case and compares its canonical snapshot with the original Fortran reference.
Windows source-kit generation is validated on Linux, but the actual Windows C/C++
and Fortran compilation must be performed on a Windows host.

Validate a kit without building it:

```bash
./fortran-modernize validate-distribution build/distribution-linux
```

## Windows/Linux compatibility CI

Combine the two source-only kits into a GitHub Actions compatibility suite:

```bash
./fortran-modernize package-compatibility-ci \
  --linux-kit build/distribution-linux \
  --windows-kit build/distribution-windows \
  --output-directory build/compatibility-ci \
  --overwrite
```

The default matrix contains Linux/WSL and Windows-native cells for Python 3.11,
3.12, 3.13, and 3.14. Every cell performs environment probing, native Cython
rebuilds, optional GNU Fortran rebuilding, and retained numerical self-checks.
The generated suite contains:

```text
compatibility-ci/
├── .github/workflows/fortran-modernization-compatibility.yml
├── kits/linux-wsl/
├── kits/windows-native/
├── tools/run_compatibility_cell.py
├── tools/summarize_compatibility.py
├── compatibility_suite_manifest.json
└── compatibility-summary/
```

A cell is recorded as `PASS`, `BLOCKED`, or `NOT_RUN`. Missing evidence is never
silently treated as compatibility. Rebuild summaries can also be generated from
locally collected or downloaded CI artifacts:

```bash
./fortran-modernize summarize-compatibility \
  --suite-manifest build/compatibility-ci/compatibility_suite_manifest.json \
  --results-directory build/compatibility-ci/compatibility-results \
  --output-directory build/compatibility-ci/compatibility-summary-local \
  --overwrite
```

The summary produces `compatibility_matrix.json`, `.csv`, and `.md`. Validate the
source-only CI suite with:

```bash
./fortran-modernize validate-compatibility-ci build/compatibility-ci
```

## Runtime execution

The runtime launcher selects the reviewed backend and preserves evidence for
every attempted fallback:

```bash
build/root-subroutine-migration/12_runtime/run-runtime \
  --backend auto \
  --case standard \
  --snapshot result.json \
  --report runtime_report.json
```

The default order is:

```text
selected optimized Cython
→ safe Cython
→ generated Python
→ packaged Fortran executable
```

Only backends present in the reviewed runtime configuration are attempted.
When different kernel groups select different Cython modes, the generic command
launcher defaults to the Python application profile; use `runtime_api.py` for
per-kernel mixed dispatch. `--strict` disables fallback. A backend can be forced explicitly:

```bash
12_runtime/run-runtime --backend python --strict
12_runtime/run-runtime --backend fortran --strict
```

The global environment override is:

```bash
FORTRAN_MODERNIZE_BACKEND=python 12_runtime/run-runtime --backend auto
```

## In-process Python API

For applications that already run in Python, `runtime_api.py` loads the
generated application and patches each selected numerical procedure in process:

```python
import runtime_api

handle = runtime_api.load_application()
application = handle.application
print(handle.backends)
```

A kernel-specific override is available through either the API or an
environment variable:

```python
handle = runtime_api.load_application(
    overrides={"solve_reynolds": "python"}
)
```

```bash
FORTRAN_MODERNIZE_KERNEL_SOLVE_REYNOLDS=python python app.py
```

If a compiled extension cannot be imported, the API tries the reviewed fallback
order and records every attempt. `strict=True` disables this behavior.

## Standalone runtime commands

Package an existing v0.5.0-or-later migration result:

```bash
./fortran-modernize package-runtime build/automatic-selection \
  --output-directory build/runtime \
  --overwrite
```

Execute it through the orchestrator:

```bash
./fortran-modernize run-runtime build/runtime \
  --backend auto \
  --case light \
  --snapshot build/runtime-result.json
```

## Selection criteria retained from v0.5.0

Kernel selection considers:

- numerical equivalence against the Fortran baseline;
- repeated-run determinism;
- weighted speedup across representative cases;
- the slowest individual case;
- case coverage;
- native build time;
- extension size;
- estimated break-even run count.

The selected backend is not trusted solely because it is fastest. Runtime
packaging is allowed only after the retained numerical, determinism, and
selection reports exist.

## Complete sample

```bash
./examples/run_journal_bearing_kernel_selection.sh
./examples/run_journal_bearing_runtime.sh
./examples/run_journal_bearing_compatibility_ci.sh
```

## Safety boundary

The production Fortran code has not been supplied or tested. The included
results use synthetic and repository sample fixtures. Performance, binary
compatibility, and backend selection are host-, workload-, compiler-, Python-
ABI-, and measurement-method dependent. Generated Python/Cython and packaged
executables remain provisional until the real project passes its own compiler,
numerical, repeated-call, determinism, performance, packaging, security, and
operational tests.
