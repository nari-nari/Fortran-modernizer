# Project-wide Copilot instructions

- Never overwrite files under `samples/**/fortran_reference` or
  `samples/**/fortran_legacy`.
- Change one program unit or one numerical kernel per task.
- Preserve floating-point precision, loop order and in-place update order unless
  an approved migration plan explicitly says otherwise.
- Do not vectorise Gauss-Seidel/SOR loops without proving numerical equivalence.
- Every generated Python implementation must be compared with its Fortran
  reference before a Cython version is edited.
- Unsupported syntax must produce `BLOCKED`; never guess or omit it.
- Run `./scripts/test_all.sh` after implementation changes.

- Before translating a procedure, run `fpy-migrate build-ir` and `validate-ir`; do not edit serialised IR to bypass a `BLOCKED` result.
