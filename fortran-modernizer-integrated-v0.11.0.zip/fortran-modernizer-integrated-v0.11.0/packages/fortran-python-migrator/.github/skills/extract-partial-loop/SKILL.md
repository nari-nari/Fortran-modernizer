# Extract one internal loop safely

Use this skill when a Fortran procedure mixes scalar setup or post-processing
with one performance-critical top-level DO loop.

## Required sequence

1. Build Migration IR and inspect every top-level loop in source order.
2. Select the loop explicitly with a 1-based `loop_index`; never guess from line count alone.
3. Run `analyze-partial-loop` and review:
   - source span;
   - Python-side pre/post statement counts;
   - explicit kernel arguments and intents;
   - COMMON/module aliases mapped to canonical fields.
4. Stop if the selected loop contains a procedure call, local array lifetime,
   or a local scalar read before an unconditional Python-side definition.
5. Build all three loop backends with `build-partial-loop`.
6. Confirm that setup and teardown remain in `partial_wrapper_reference.py`.
7. Compare Python, safe Cython, optimized Cython, and compiled Fortran using the
   complete state and all scalar outputs—not only the extracted loop output.
8. Keep the safe Cython backend available for diagnosis after optimized Cython passes.

## Prohibited changes

- Do not reorder setup, the extracted loop, or teardown.
- Do not move file I/O, allocation policy, or unrelated reduction loops into Cython.
- Do not silently extract nested loops or calls.
- Do not disable Cython safety checks before equivalence passes.
