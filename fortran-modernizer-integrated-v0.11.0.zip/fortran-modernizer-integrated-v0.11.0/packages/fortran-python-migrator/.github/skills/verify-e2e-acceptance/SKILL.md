# Verify a complete Fortran-to-Python acceptance path

Use this skill after a legacy source snapshot, its reviewed normalized Fortran,
a canonical refactoring handoff, and an adapter configuration are available.

1. Keep the legacy source, all INCLUDE files, normalized source, and handoff from
   the same reviewed revision. Never update a recorded fingerprint merely to make
   a gate pass.
2. Run `fpy-migrate verify-e2e` with an explicit program name and handoff root
   procedure.
3. Require the legacy and normalized fingerprints in the report to match the
   handoff exactly.
4. Require the refactoring connection report to be `PASS` with complete coverage
   for program units, symbols, calls, and COMMON members.
5. Keep the type, rank, COMMON-position, and fingerprint negative controls. The
   acceptance is invalid if any intentional mismatch is not observed as
   `BLOCKED`.
6. Compare original and normalized compiled Fortran before assessing generated
   Python or native backends.
7. Compare complete arrays, not only formatted output or scalar reductions.
8. Require integer iteration counts to match exactly; use reviewed explicit
   tolerances for floating scalars and arrays.
9. Reject NaN and infinity even when another comparison appears to pass.
10. Preserve the final JSON report, NPZ snapshots, connection reports, compile
    commands, source fingerprints, and generated manifest together.
11. Do not claim production applicability from the controlled fixture. Repeat the
    gate with the actual refactoring-tool artifact and sanitized production code.
