# Use a project-level Fortran kernel backend

Use this skill when a migrated project must retain one or more verified Fortran
numerical kernels behind the same Python state and backend-selection API as the
Python and Cython implementations.

## Required sequence

1. Confirm the selected full-procedure or partial-loop kernel is already
   extractable as a call-free explicit-argument Migration IR procedure.
2. Build with `--include-fortran`. Use `--default-backend fortran` only when the
   whole generated runtime should default to Fortran.
3. Review the generated `bind(C)` source and ctypes wrapper. The Python layer
   must pass only numerical scalars and C-contiguous NumPy arrays; COMMON/module
   storage must not cross the ABI boundary.
4. Run Python, safe Cython, optimized Cython, and Fortran backends against the
   original compiled Fortran program. Compare complete state arrays and scalar
   outputs.
5. Run at least one mixed configuration, for example Python orchestration with
   only the hot update procedure overridden to `fortran`.
6. Keep the generated Fortran source, shared library, wrapper, IR, and manifest
   together. Do not hard-code an absolute build path.

## Safety rules

- The Fortran backend is optional and must not be built unless requested.
- Never expose a legacy COMMON block directly through ctypes. Generate the
  backend from the canonical explicit-argument kernel IR.
- Arrays use a C-contiguous NumPy contract. The generator reverses Fortran
  pointer dimensions and logical indices to preserve the Python/Cython result.
- Block kernels containing unresolved calls or local automatic arrays.
- Do not silently copy an incompatible array layout inside the hot kernel.
- Linux shared-library generation is verified in this repository. Windows DLL
  generation and final packaging require target-side validation.
