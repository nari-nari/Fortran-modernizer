# Select native kernels by measured economics

Use this skill after a single-case or multi-case Python-reference profile exists.
Do not choose Cython kernels from static eligibility or speedup alone.

## Required order

1. Run `benchmark-hybrid-economics` with the approved profile report.
2. Review every candidate's:
   - weighted speedup and saved time;
   - build time;
   - optimized extension and complete bundle size;
   - break-even suite runs and calls;
   - case-specific regressions.
3. Choose explicit thresholds for the intended deployment volume and update rate.
4. Run `analyze-hybrid-project --economics-report ...` and inspect every selection reason.
5. Build only the selected candidates with the same thresholds.
6. Compare Python, safe Cython, optimized Cython, and compiled Fortran complete state.
7. Keep rejected candidates in readable Python; do not force a native build.

## Safety rules

- Treat timing as machine- and workload-specific.
- Reject candidates with negative weighted savings or no finite break-even unless a documented non-performance reason exists.
- Do not hide build cost by reusing an old binary when measuring a new source revision.
- Do not use bundle size as a proxy for runtime memory without measuring memory separately.
- Preserve the economics report, plan, manifest, compiler information, and representative workloads together.
