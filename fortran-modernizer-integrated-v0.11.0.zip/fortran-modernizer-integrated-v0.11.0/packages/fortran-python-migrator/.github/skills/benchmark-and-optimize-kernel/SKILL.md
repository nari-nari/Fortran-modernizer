# Benchmark and optimise one verified kernel

Only optimise a Cython kernel after Fortran, generated Python, and safe Cython match numerically.

1. Run `fpy-migrate benchmark-kernel SOURCE --procedure NAME --build-directory build/NAME_benchmark --output reports/NAME_benchmark.json`.
2. Compare multiple grid sizes; do not infer performance from one tiny case.
3. Apply one optimisation class at a time: safety directives, memory-layout contract, leaf-call inlining, then compiler optimisation.
4. Preserve loop order, in-place update order, clipping, precision, and array-index mapping.
5. Re-run the full equivalence suite after every optimisation.
6. Report both seconds per call and speedup; never claim portable speed from one machine.
7. Keep the safe Cython source as a diagnostic backend even after the optimised backend passes.
