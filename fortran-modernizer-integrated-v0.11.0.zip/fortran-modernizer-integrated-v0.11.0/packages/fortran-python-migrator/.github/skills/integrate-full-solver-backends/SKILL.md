# Integrate full solver backends

Use this skill when moving from a verified numerical kernel to a complete
iterative solver with selectable Python, Cython, and Fortran implementations.

## Required order

1. Build Migration IR for the root solver and all local dependencies.
2. Confirm `EXIT`/convergence control is preserved in generated Python.
3. Generate safe Cython and compare every output against generated Python.
4. Generate optimised Cython only after the safe comparison passes.
5. Build the Fortran executable as an independent reference backend.
6. Run all backends from the same TOML case and backend configuration.
7. Compare full pressure arrays, film arrays, iteration counts, residuals, and
   convergence status.
8. Benchmark complete solves separately from single-sweep kernel benchmarks.

Never optimise by changing the convergence condition, loop order, clipping,
precision, or SOR update order. Never hide a failed or non-converged run.
