# Select native kernels from a measured workload

Use this skill after static hybrid analysis has identified full-procedure and
partial-loop candidates.

## Required sequence

1. Create or review a workload module with exactly one callable:
   `run(reference_module)`.
2. Make the workload representative of production call counts and problem sizes.
3. Run `profile-hybrid-project` with warmup runs before measured runs.
4. Review call counts, self time, candidate share, and wall share. Do not rank by
   loop depth alone after measured data exists.
5. Apply explicit thresholds with `analyze-hybrid-project --profile-report`.
6. Confirm that statically eligible but cold procedures are marked
   `selected=false` and remain Python.
7. Build with the same profile report and thresholds.
8. Compare the complete generated state and all scalar outputs against compiled
   Fortran for Python, safe Cython, and optimized Cython.
9. Keep the profile report and profiled plan in the build manifest.

## Prohibited shortcuts

- Do not treat one machine's timing as a portable guarantee.
- Do not profile optimized Cython and use that to justify the initial selection;
  selection must begin from the readable Python reference implementation.
- Do not exclude warmup for workloads with import or cache initialization.
- Do not compile a cold candidate solely because it is statically eligible.
- Do not accept speed measurements without the numerical equivalence gate.
