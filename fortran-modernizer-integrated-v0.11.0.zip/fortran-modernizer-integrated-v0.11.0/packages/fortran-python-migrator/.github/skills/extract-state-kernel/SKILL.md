# Extract a state-dependent numerical kernel

Use this skill only after the generated Python state-object implementation matches the Fortran reference.

## Required sequence

1. Select one state-dependent procedure that contains the hot loop and has no unresolved or nested procedure calls.
2. Run:
   `fpy-migrate analyze-state-kernel SOURCE --procedure NAME --output build/NAME_state_kernel.json --ir-output build/NAME_kernel.ir.json`.
3. Review every state-field binding, especially COMMON aliases, inferred `in`/`out`/`inout`, rank, kind, and shape.
4. Build all backends with:
   `fpy-migrate build-state-kernel SOURCE --procedure NAME --build-directory build/NAME_state_kernel`.
5. Keep the generated dataclass and adapter in normal Python. Pass only numerical arrays and scalars to the generated kernel.
6. Compare the complete state transition for Python, safe Cython, optimized Cython, and Fortran.
7. Retain the safe Cython backend as a diagnostic implementation after optimized Cython passes.

## Safety rules

- Do not pass Python dataclass objects into Cython.
- Do not extract a stateful call graph until interprocedural side effects are supported.
- Do not infer a COMMON alias by name; use the canonical storage-position mapping from Migration IR.
- Treat an array written in place as `inout`, not `out`.
- Keep bundle paths relative so the generated state-kernel directory remains movable.
- Do not change loop order, array indexing, precision, or update timing during extraction.
