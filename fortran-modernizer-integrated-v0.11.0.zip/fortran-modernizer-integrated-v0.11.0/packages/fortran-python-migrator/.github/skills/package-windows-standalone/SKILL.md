# Package a verified hybrid solver for Windows

Use this skill only after the selected Python/Cython hybrid project has passed
Fortran equivalence tests.

## Required order

1. Build the approved hybrid project and preserve its manifest.
2. Create a small app adapter with `run(runtime, argv)` and a deterministic
   `self_check(runtime)` known case.
3. Run `prepare-distribution` to create a source-only kit.
4. Run `validate-distribution`; confirm that no Linux `.so` or other
   platform-specific binary leaked into the kit.
5. In WSL/Linux, run `tools/build_native.py` and `launcher.py --self-check` to
   prove that the kit is independent of the original repository.
6. Review `required_wheels.json` and collect compatible Windows x86-64 wheels
   for offline use when required.
7. On Windows, use Microsoft C/C++ Build Tools to rebuild Cython `.pyd` files.
8. Run the source-tree self-check before Nuitka packaging.
9. Build Nuitka standalone-directory mode and copy the generated payload,
   notices, license inventory, and native extensions beside the executable.
10. Run the packaged executable `--self-check` on a clean Windows x64 machine
    without Python installed.

## Safety and compliance rules

- Never reuse Linux `.so` files on Windows.
- Do not claim the Windows package is verified until MSVC, Nuitka, and the
  clean-machine self-check have actually run.
- Keep standalone-directory mode until dependency/DLL issues are understood;
  do not switch to one-file merely for appearance.
- Treat generated Python orchestration files beside the executable as visible
  source; only selected Cython kernels are native-code boundaries.
- Generate and review third-party notices on the target build machine.
- Current standard Nuitka releases use AGPLv3 with a runtime exception for
  created binaries. Review the exact release and internal commercial-compliance
  requirements before distribution.
