# Integrate verified post-processing

Use this skill after the pressure/state solver already matches Fortran.

1. Keep post-processing in a separate Fortran procedure with explicit scalar and
   array inputs and explicit `intent(out)` results.
2. Define every reported quantity and its units or dimensionless status before
   translation.
3. Distinguish equality residuals from constrained/complementarity residuals.
4. Build Migration IR for the complete analysis root and include all local
   dependencies.
5. Compare complete arrays before comparing reductions such as loads or sums.
6. Require Python, safe Cython, optimised Cython, and Fortran to write the same
   JSON/CSV output contract.
7. Never rename a dimensionless verification metric as a dimensional physical
   prediction.
8. Preserve quadrature order, loop order, precision, pressure clipping, and
   boundary treatment.
