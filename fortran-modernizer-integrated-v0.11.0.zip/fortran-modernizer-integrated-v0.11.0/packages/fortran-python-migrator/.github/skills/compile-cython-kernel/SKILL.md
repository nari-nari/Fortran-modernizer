# Generate and compile one safe Cython kernel

Start only from a procedure whose generated Python reference already matches the Fortran result.

1. Rank the procedure with:
   `fpy-migrate analyze-kernels SOURCE --procedure NAME --output build/NAME.candidates.json`.
2. Generate Cython Pure Python Mode code with:
   `fpy-migrate translate-cython SOURCE --procedure NAME --output generated/NAME_cython.py`.
3. Compile the generated source with:
   `fpy-migrate compile-cython generated/NAME_cython.py --module-name NAME_cython --build-directory build/NAME_cython`.
4. Keep bounds, wraparound, and initialized-value checks enabled.
5. Compare Fortran, generated Python, and generated Cython fields and scalars.
6. Do not disable safety checks or restructure loops in the same change.

A `BLOCKED` candidate must not be bypassed. A `REVIEW_REQUIRED` candidate needs an explicit reason before compilation.
