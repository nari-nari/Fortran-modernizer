# Investigate a numerical difference

Find the first iteration and array index that diverge. Check dtype/kind, index origin, loop order, in-place updates, boundaries, clipping and aliasing before changing formulas.
