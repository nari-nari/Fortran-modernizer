# Build a project-level hybrid backend

Use this skill when several reachable Fortran procedures share COMMON/module
state and the user wants Python orchestration with selectable Python/Cython and optional Fortran
numerical kernels.

## Required sequence

1. Build one Migration IR for the selected root procedure. For a directory,
   confirm every relevant source file appears in `source_files`.
2. Run `analyze-hybrid-project` and review every candidate:
   - `AUTO` means the complete supported stateful numerical body is extracted;
   - `PARTIAL_AUTO` means the procedure remains Python and one safe top-level
     loop is replaced by a generated backend-dispatched kernel;
   - `PYTHON_ONLY` means neither full nor partial extraction is currently safe.
3. Verify COMMON aliases are canonicalized by storage position before building.
4. For each `PARTIAL_AUTO` item, review `loop_index`, source span, bridge
   variables, and inferred intents. Do not silently choose a different loop.
5. Build all full and partial kernels together with `build-hybrid-project`. Add `--include-fortran` when a Fortran fallback or reference backend is required.
6. Keep the original IR, transformed IR, generated Python reference, safe Cython
   modules, and optimized Cython modules. Do not remove diagnostic artifacts.
7. Run the root procedure using every generated project backend and compare complete
   state arrays and scalar outputs with compiled Fortran.
8. When Fortran is included, test at least one Fortran override and one mixed per-procedure override that includes a partial-loop
   procedure. Never apply an override to a procedure not listed in
   `EXTRACTED_PROCEDURES`.
9. Preserve relative paths in all manifests so the complete build directory can
   be moved without regeneration.

## Safety rules

- Prefer full-procedure state-kernel extraction when it is safe.
- Partial extraction may select only the first safe top-level loop in the current
  automatic policy; calls inside the selected loop remain blocked.
- Preserve all pre-loop and post-loop statements in generated Python and keep
  their source order unchanged.
- Do not flatten a stateful call graph into one native function.
- Keep orchestration and backend selection in Python.
- Do not pass dataclass objects into Cython; generated kernels receive only
  explicit numerical scalars and NumPy-compatible arrays.
- A mixed-backend run must pass the same complete-state equivalence checks as a
  uniform-backend run.
