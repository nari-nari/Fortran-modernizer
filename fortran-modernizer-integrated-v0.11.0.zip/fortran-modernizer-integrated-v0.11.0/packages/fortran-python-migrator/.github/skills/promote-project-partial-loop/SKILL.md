# Promote a project procedure's internal loop

Use this skill when `analyze-hybrid-project` classifies a procedure as
`PARTIAL_AUTO`.

1. Confirm whole-procedure extraction was attempted first and record why it was
   blocked.
2. Review the selected 1-based top-level `loop_index` and its source span.
3. Verify the selected loop contains no unresolved calls and that every bridge
   local is definitely initialized before the loop.
4. Confirm state aliases map to canonical COMMON/module fields and inferred
   intents match the Fortran reads and writes.
5. Build the project hybrid bundle, not an isolated replacement project.
6. Inspect `hybrid_transformed.ir.json`: only the selected loop may be replaced
   by the synthetic kernel call; surrounding calls and scalar statements must
   remain in source order.
7. Compare Python, safe Cython, optimized Cython, and at least one mixed override
   against the complete compiled-Fortran state and outputs.
