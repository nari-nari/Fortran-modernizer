# Connect the Fortran refactoring tool

Use this skill before translating a project that has already been analysed or
normalised by the separate Fortran refactoring tool.

1. Keep the reviewed Fortran source snapshot and the refactoring reports from the
   same run together. Do not combine reports from a different source revision.
2. Run `fpy-migrate import-refactor-bundle REPORT_DIR --output handoff.json`.
3. Validate the generated hand-off with `fpy-migrate validate-refactor-report`.
4. Run `fpy-migrate verify-refactor-connection SOURCE --procedure ROOT
   --report handoff.json --output connection.json`.
5. Stop if the status is `BLOCKED`. Do not edit the hand-off merely to make the
   comparison pass. Resolve the disagreement in the source or producer report.
6. Review every `REVIEW_REQUIRED` issue. Missing evidence must not be treated as
   confirmed agreement.
7. Only pass the canonical hand-off to `build-ir`, `translate`, or hybrid build
   commands after the connection report is accepted.
8. Preserve the connection report with generated Migration IR for auditability.
