# Diagnose a real Fortran project before migration

Use this workflow before translating production Fortran.

1. Never start by translating the entire project.
2. Run `fpy-migrate diagnose-project` against the supplied source root.
3. Provide `--procedure` when the application entry/root procedure is known.
4. Provide the canonical refactoring hand-off with `--refactor-report` when available.
5. Review all four rates separately:
   - file parse rate;
   - procedure IR build rate;
   - procedure migratable rate;
   - procedure READY rate.
6. Treat `BLOCKED` as a hard stop for that procedure and every caller that depends on it.
7. Do not infer missing external procedures. Supply their source or retain the calling path in Fortran.
8. Sort migration work by the report's dependency-first `migration_order`.
9. Use the recommended vertical slice only after its blocked-procedure list is empty.
10. Prioritise high-frequency unsupported constructs. Do not implement rare syntax merely because it appears once.
11. Establish a Fortran regression case before converting the first READY procedure.
12. Preserve the generated JSON and CSV as acceptance evidence.

A successful fparser parse is not sufficient evidence of migration readiness. A procedure is ready only when its current safe Migration IR can represent it and its required dependency chain is available.
