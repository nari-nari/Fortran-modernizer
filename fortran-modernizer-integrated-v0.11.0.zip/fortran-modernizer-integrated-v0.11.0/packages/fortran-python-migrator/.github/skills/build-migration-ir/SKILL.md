# Build and review Migration IR

Run `fpy-migrate build-ir SOURCE --procedure NAME --refactor-report REPORT --output build/NAME.ir.json`.
Validate it with `fpy-migrate validate-ir`.

Confirm:

1. the selected root procedure and every automatically included local call dependency;
2. argument order, type/kind, `intent`, rank, and explicit/assumed shape;
3. source spans, loop bounds, one-based array references, IF branches, and call output mapping;
4. that every called subroutine is resolved and that output actual arguments are assignable.

A `BLOCKED` result must be resolved in Fortran or in the translator; never bypass it by editing the IR manually.
