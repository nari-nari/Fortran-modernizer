# Select a Cython candidate

Use `fpy-migrate analyze-kernels` on one approved root procedure. Prefer procedures with nested numeric loops, array arguments, no I/O, resolved calls, and limited side effects. Review dependencies separately: a helper with no loop may still be included because the selected root calls it, but it should not be presented as a standalone performance target.
