# Preserve Fortran named constants and intrinsic limits

Use this skill when a normalized numerical procedure still contains scalar
`PARAMETER` declarations, constant-dependent array extents, `ACOS`/`DACOS`, or
`HUGE`.

## Required sequence

1. Keep named constants separate from mutable symbols in Migration IR.
2. Verify that every constant initializer depends only on other named constants
   and supported intrinsic expressions.
3. Topologically order dependencies and stop on unresolved names or cycles.
4. Confirm that array extents, loop bounds, and executable expressions resolve
   against the same ordered constants.
5. Generate and inspect all three forms:
   - readable Python assignments;
   - typed Cython local constants;
   - `parameter` declarations in generated `bind(C)` Fortran.
6. Check type-directed `HUGE` lowering against the generated backend contract.
7. Compile safe Cython, optimized Cython, and generated Fortran before accepting
   the new intrinsic or constant form.
8. Compare complete arrays, scalar outputs, and iteration counts against the
   compiled normalized Fortran program.

## Stop conditions

- parameter arrays or character parameters;
- cyclic constant dependencies;
- constants that reference mutable variables;
- an unsupported intrinsic or unsupported type kind;
- unresolved names remaining in generated Python/Cython;
- a backend-specific value that disagrees with the normalized Fortran baseline.
