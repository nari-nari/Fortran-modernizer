# Select native kernels across representative cases

Use this skill when one workload is not sufficient to decide which Fortran-derived
procedures or loops should be compiled with Cython.

## Required sequence

1. Define independent workload modules for the operating cases that matter in
   production. Each module must expose `run(reference_module)`.
2. Give every case a stable name and an explicit positive weight. Document why
   the weights represent expected use or engineering importance.
3. Run `profile-hybrid-suite` against the generated readable Python reference.
4. Review every candidate's per-case call count and self time before looking at
   the aggregate metrics.
5. Use weighted share to represent expected use, mean share to avoid a single
   dominant case, maximum share to retain kernels critical in an extreme case,
   and minimum case count to reject case-specific measurement gaps.
6. Apply the same suite report and thresholds to both `analyze-hybrid-project`
   and `build-hybrid-project`.
7. Confirm that the plan records case count, coverage, mean share, maximum share,
   weighted share, and the reason for each selected or rejected candidate.
8. Compare Python, safe Cython, and optimized Cython complete outputs against the
   compiled Fortran reference.
9. Preserve the suite report, plan, manifest, and equivalence report together.

## Prohibited shortcuts

- Do not concatenate unrelated workloads into one opaque script; keep case-level
  measurements inspectable.
- Do not choose weights after seeing which kernel wins unless the weighting
  rationale is documented and reviewed.
- Do not use maximum share alone; a one-off extreme case must not silently define
  the complete production build.
- Do not allow the hottest fallback to bypass the minimum case-count requirement.
- Do not interpret timings from one CPU as a portable performance guarantee.
- Do not accept the aggregated selection without the complete Fortran numerical
  equivalence gate.
