# Build a procedure-scoped Migration IR

Use this skill when one Fortran source file contains both migratable numerical
procedures and unreachable unsupported procedures such as formatted reporting.

## Required sequence

1. Select one numerical root with `--procedure`; do not request whole-project
   strict translation merely to avoid choosing a root.
2. Review the dependency-first procedure list in the generated Migration IR.
3. Confirm every reachable `CALL` is resolved and that no unsupported reachable
   procedure was silently omitted.
4. Review the project-wide COMMON layout. Unreachable program units still
   participate in COMMON member-count, type, rank, shape, and storage-position
   validation.
5. Generate readable Python and compare the complete selected numerical path
   against the compiled Fortran baseline.
6. Run strict whole-project construction separately as a diagnostic when the
   remaining unsupported boundaries must be inventoried.

## Safety rules

- Never suppress an unsupported procedure that is reachable from the selected
  root.
- Never scope COMMON validation to the selected dependency closure.
- Do not treat a main program as a subroutine root; main-program orchestration
  remains a separate migration stage.
- Duplicate program-unit names and unresolved reachable calls are blocking.
- `procedure=None` remains strict and must continue to expose unsupported
  siblings rather than silently skipping them.
