# Migrate one procedure

Use the approved plan and select exactly one leaf or low-dependency subroutine.

1. Build and validate its Migration IR. Review every automatically included call dependency.
2. Generate a readable Python reference with `fpy-migrate translate`.
3. Preserve source mappings, precision, one-based indexing semantics, loop order, branch conditions, calls, and in-place update order.
4. Add a Fortran/Python equivalence test before considering Cython.
5. Do not optimise, vectorise, or Cythonise in the same change.

Unsupported syntax must remain `BLOCKED`; do not infer or omit operations.
