# Compare backends

Run `fpy-migrate sample compare` or the corresponding project comparison. Treat scalar and field comparisons separately and report the maximum absolute and relative field errors.
