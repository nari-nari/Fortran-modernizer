# Migrate Fortran shared state

Use this skill when a procedure depends on a `COMMON` block or module variables.

## Required sequence

1. Run `fpy-migrate analyze-state` for the selected root procedure.
2. Review each state group, field order, type, kind, rank, and alias mapping.
3. Do not merge COMMON declarations if their storage-compatible layout is not proven.
4. Generate readable Python with `fpy-migrate translate`.
5. Instantiate the generated dataclass with explicit NumPy arrays and scalars.
6. Compare the complete state after the same procedure sequence against Fortran.
7. Keep the dataclass wrapper in Python.
8. For performance work, extract a stateless function whose arguments are only the arrays and scalars needed by the hot loop, then run the normal Cython equivalence workflow.

## Safety rules

- Never represent shared state as Python module globals.
- Never silently choose one incompatible COMMON declaration as canonical.
- Preserve compatible COMMON aliases by storage position.
- Do not pass Python dataclass objects directly into generated Cython kernels.
- Do not optimise until the state-object Python result matches Fortran.
