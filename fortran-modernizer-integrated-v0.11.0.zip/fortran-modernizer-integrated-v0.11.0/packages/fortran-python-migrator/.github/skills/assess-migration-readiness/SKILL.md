# Assess migration readiness

Run `fpy-migrate assess <source> --output build/assessment.json`. Review every `BLOCKED` item before translation. Do not infer missing types.
