---
name: build-main-orchestration
description: Generate a Python application from a supported Fortran main-program CALL sequence while replacing trailing reporting routines with validated Python adapters.
---

# Build main-program orchestration

1. Run `analyze-orchestration` before compiling anything.
2. Require the main program to contain only top-level `CALL` statements in milestone 22.
3. Treat configured adapter calls as a trailing suffix. Stop if numerical calls resume after an adapter.
4. Validate adapter source with the adapter-config schema and require an exact positional Python signature.
5. Build Migration IR only for the numerical calls and their reachable dependencies. Do not translate the formatted-output routine.
6. Generate the synthetic numerical root and inspect it before native compilation.
7. Preserve whole-project COMMON layout validation, including the main program and unselected procedures.
8. Build Python, safe Cython, optimized Cython, and optional Fortran backends behind the same generated `main()` API.
9. Compare iterations, residual, arrays or scalar metrics, and adapter output against the compiled Fortran baseline.
10. Do not claim support for interleaved I/O, adapter writes to state, arbitrary main-program statements, or missing upstream refactoring reports.
