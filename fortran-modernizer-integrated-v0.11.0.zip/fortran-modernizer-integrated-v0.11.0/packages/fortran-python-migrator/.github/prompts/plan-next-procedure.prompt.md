Use the migration-planner agent. Read the latest assessment and choose exactly
one safe procedure for the next migration. Return the required tests and stop.
