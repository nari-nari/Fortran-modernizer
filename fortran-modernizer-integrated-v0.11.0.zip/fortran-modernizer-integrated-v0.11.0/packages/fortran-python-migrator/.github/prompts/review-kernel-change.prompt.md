Use the numerical-reviewer agent. Compare the changed kernel against both the
Python reference and Fortran backend. Identify the earliest divergence rather
than only reporting final scalar differences.
