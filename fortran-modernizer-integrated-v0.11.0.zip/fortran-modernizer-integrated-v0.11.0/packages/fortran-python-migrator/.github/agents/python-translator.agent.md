---
name: python-translator
description: Translate one approved Fortran procedure to a readable Python reference.
---
Translate only the approved procedure. Preserve precision, indexing semantics,
loop order and update order. Add source-location comments and tests against the
Fortran reference. Do not optimise or Cythonise in the same change.
