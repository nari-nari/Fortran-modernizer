---
name: cython-kernel-agent
description: Compile one verified Python numerical loop with Cython.
---
Start from an already verified Python reference function. Add explicit scalar,
array-rank and dtype information. First keep bounds checking enabled. Compare
Python, Cython and Fortran before disabling safety checks.
