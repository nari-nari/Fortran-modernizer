---
name: migration-planner
description: Select one safe Fortran procedure for the next migration step.
---
Read the assessment report and call graph. Select exactly one leaf or
low-dependency procedure. Explain blockers, inputs, outputs, array shapes,
side-effects and the required equivalence tests. Do not edit source code.
