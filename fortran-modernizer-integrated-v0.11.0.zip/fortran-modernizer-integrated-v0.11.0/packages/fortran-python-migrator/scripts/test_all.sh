#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PY="${PYTHON_BIN:-$ROOT/.venv/bin/python}"

cd "$ROOT"
"$PY" setup.py build_ext --inplace

# Run fast tests together, then start compiler-heavy files in fresh Python
# processes. This avoids retaining many dynamically loaded Cython extensions in
# one interpreter while preserving the complete standard suite; the slow E2E native-build gate runs independently below.
PYTHONPATH="$ROOT/src" "$PY" -m pytest -m 'not integration'

INTEGRATION_FILES=(
  tests/test_fortran_equivalence.py
  tests/test_generated_fortran_equivalence.py
  tests/test_generated_sor_equivalence.py
  tests/test_generated_cython_equivalence.py
  tests/test_analysis_backends.py
  tests/test_full_solver_backends.py
  tests/test_kernel_benchmark.py
  tests/test_state_migration.py
  tests/test_state_kernel_extraction.py
  tests/test_partial_loop_extraction.py
  tests/test_fortran_kernel_backend.py
  tests/test_parameter_constants.py
)
for test_file in "${INTEGRATION_FILES[@]}"; do
  PYTHONPATH="$ROOT/src" "$PY" -m pytest -m integration "$test_file"
done

# The two project-level builds each load several generated extensions. Run them
# as separate test nodes so no interpreter retains both complete build graphs.
HYBRID_TESTS=(
  tests/test_hybrid_project.py::test_hybrid_project_backends_and_per_procedure_override_match_fortran
  tests/test_hybrid_project.py::test_module_state_hybrid_project_matches_fortran
  tests/test_hybrid_project.py::test_project_hybrid_combines_full_and_partial_kernels_and_matches_fortran
  tests/test_profile_driven_selection.py::test_profiled_build_compiles_only_hot_partial_loop_and_matches_fortran
  tests/test_multi_case_profiling.py::test_multi_case_selected_build_matches_fortran
  tests/test_economics_selection.py::test_economics_selected_build_matches_fortran
  tests/test_economics_selection.py::test_economics_benchmark_records_build_size_and_speedup
  tests/test_distribution_packaging.py::test_prepared_distribution_rebuilds_native_and_passes_self_check
  tests/test_orchestration.py::test_generated_application_runs_all_four_backends
)
for test_node in "${HYBRID_TESTS[@]}"; do
  PYTHONPATH="$ROOT/src" "$PY" -m pytest -m integration "$test_node"
done

# The journal-bearing E2E gate starts several nested native builds. Running it
# directly avoids hosted pytest teardown stalls while preserving the exact same
# acceptance implementation and JSON Schema validation.
E2E_BUILD="$ROOT/build/e2e_acceptance"
E2E_REPORT="$ROOT/reports/e2e_acceptance.json"
rm -rf "$E2E_BUILD"
mkdir -p "$(dirname "$E2E_REPORT")"
PYTHONPATH="$ROOT/src" "$PY" "$ROOT/tests/helpers/run_e2e_acceptance.py" \
  "$E2E_BUILD" "$E2E_REPORT"

PYTHONPATH="$ROOT/src" "$PY" -m fpy_migrate sample compare
