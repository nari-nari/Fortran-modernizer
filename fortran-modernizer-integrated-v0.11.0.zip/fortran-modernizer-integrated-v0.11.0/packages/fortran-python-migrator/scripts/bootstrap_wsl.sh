#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PYTHON_BIN="${PYTHON_BIN:-python3}"

if [[ ! -d "$ROOT/.venv" ]]; then
  "$PYTHON_BIN" -m venv "$ROOT/.venv"
fi

PY="$ROOT/.venv/bin/python"
PIP="$ROOT/.venv/bin/pip"

# Core packages may be installed from an online index. In a fully offline
# environment, place their compatible wheels under vendor/wheels first.
if ! "$PY" -c "import numpy, Cython, pytest, jsonschema, setuptools" >/dev/null 2>&1; then
  "$PIP" install --find-links "$ROOT/vendor/wheels" \
    numpy Cython pytest jsonschema setuptools wheel || {
      echo "Missing offline wheels for NumPy/Cython/pytest/jsonschema/setuptools/wheel." >&2
      echo "Add compatible wheels to vendor/wheels and rerun this script." >&2
      exit 2
    }
fi

"$PIP" install --no-index \
  "$ROOT/vendor/wheels/fparser-0.2.4-py3-none-any.whl" \
  "$ROOT/vendor/wheels/findent-4.3.6-py3-none-manylinux_2_24_x86_64.manylinux_2_28_x86_64.whl"

cd "$ROOT"
"$PY" setup.py build_ext --inplace

echo "Bootstrap complete. Activate with: source $ROOT/.venv/bin/activate"
