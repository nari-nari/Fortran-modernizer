#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PY="${PYTHON_BIN:-$ROOT/.venv/bin/python}"
cd "$ROOT"
PYTHONPATH="$ROOT/src" "$PY" -m fpy_migrate sample build
