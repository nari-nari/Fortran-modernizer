# Third-Party Notices

Generated from installed package metadata.

- **numpy 2.3.5** (runtime,build): SEE_COPIED_LICENSE_FILES_OR_PACKAGE_METADATA; License :: OSI Approved :: BSD License; copied files: licenses/numpy/LICENSE.txt, licenses/numpy/0f4ffb29_LICENSE.txt, licenses/numpy/LICENSE, licenses/numpy/LICENSE.md
- **Cython 3.2.4** (build): Apache-2.0; License :: OSI Approved :: Apache Software License
- **setuptools 82.0.1** (build): MIT; copied files: licenses/setuptools/LICENSE, licenses/setuptools/b8b1f5f0_LICENSE, licenses/setuptools/c9e41e71_LICENSE, licenses/setuptools/4a7fd6a9_LICENSE, licenses/setuptools/9fe05a31_LICENSE, licenses/setuptools/4d09286a_LICENSE, licenses/setuptools/63a92caf_LICENSE, licenses/setuptools/6562dd76_LICENSE, licenses/setuptools/c2780f51_LICENSE, licenses/setuptools/LICENSE.APACHE, licenses/setuptools/LICENSE.BSD, licenses/setuptools/d6b8bc45_LICENSE, licenses/setuptools/1ab641e9_LICENSE, licenses/setuptools/LICENSE.txt, licenses/setuptools/0e45092c_LICENSE, licenses/setuptools/NOTICE, licenses/setuptools/e972ee51_NOTICE
- **wheel** (build): not installed at notice-generation time
- **Nuitka** (build): not installed at notice-generation time

This inventory is an aid, not a substitute for reviewing the license files
distributed by each dependency and the organization's legal/compliance process.
