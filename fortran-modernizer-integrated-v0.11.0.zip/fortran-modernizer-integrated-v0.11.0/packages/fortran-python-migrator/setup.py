from pathlib import Path

from Cython.Build import cythonize
import numpy as np
from setuptools import Extension, setup

ROOT = Path(__file__).parent

extensions = [
    Extension(
        "fpy_migrate.sample.journal_bearing._cython_kernel",
        [str(ROOT / "src/fpy_migrate/sample/journal_bearing/_cython_kernel.pyx")],
        include_dirs=[np.get_include()],
    )
]

setup(
    ext_modules=cythonize(
        extensions,
        compiler_directives={
            "language_level": "3",
            "boundscheck": True,
            "wraparound": True,
            "initializedcheck": True,
            "cdivision": True,
        },
    )
)
