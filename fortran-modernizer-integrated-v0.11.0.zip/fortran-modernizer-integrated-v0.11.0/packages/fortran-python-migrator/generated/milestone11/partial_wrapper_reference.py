"""Generated from Fortran by fpy-migrate. Do not edit by hand."""

from dataclasses import dataclass
import math

import numpy as np
import numpy.typing as npt

FloatArray = npt.NDArray[np.float64]
IntArray = npt.NDArray[np.int64]
BoolArray = npt.NDArray[np.bool_]

@dataclass
class CommonFieldState:
    # Fortran common: field
    pressure: FloatArray
    film: FloatArray
    relaxation_factor: float

def run_partial_loop_loop_1_kernel(n: int, bias: float, pressure: FloatArray, film: FloatArray) -> FloatArray:
    # Source: /mnt/data/fortran-python-migrator/samples/migration_units/partial_loop_analysis.f90:13-15
    for i in range(1, (n) + 1):
        pressure[(i) - 1] = (pressure[(i) - 1] + (bias * film[(i) - 1]))
    return pressure

def run_partial_loop(state_common_field: CommonFieldState, n: int, scale: float) -> tuple[float, float]:
    # Source: /mnt/data/fortran-python-migrator/samples/migration_units/partial_loop_analysis.f90:1-24
    bias = (scale * state_common_field.relaxation_factor)
    state_common_field.pressure = run_partial_loop_loop_1_kernel(n, bias, state_common_field.pressure, state_common_field.film)
    total_pressure = 0.0
    peak_pressure = state_common_field.pressure[(1) - 1]
    for i in range(1, (n) + 1):
        total_pressure = (total_pressure + state_common_field.pressure[(i) - 1])
        if (state_common_field.pressure[(i) - 1] > peak_pressure):
            peak_pressure = state_common_field.pressure[(i) - 1]
    total_pressure = (total_pressure + scale)
    return total_pressure, peak_pressure
