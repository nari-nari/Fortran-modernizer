# cython: language_level=3, boundscheck=False, wraparound=False, initializedcheck=False, cdivision=True
"""Generated Cython optimized kernel from Fortran by fpy-migrate."""

import math

import cython
import numpy as np

@cython.boundscheck(False)
@cython.wraparound(False)
@cython.initializedcheck(False)
@cython.cdivision(True)
def run_partial_loop_loop_1_kernel(n: cython.int, bias: cython.double, pressure: cython.double[::1], film: cython.double[::1]):
    # Source: /mnt/data/fortran-python-migrator/samples/migration_units/partial_loop_analysis.f90:13-15
    i: cython.int
    for i in range(1, (n) + 1):
        pressure[(i) - 1] = (pressure[(i) - 1] + (bias * film[(i) - 1]))
    return pressure
