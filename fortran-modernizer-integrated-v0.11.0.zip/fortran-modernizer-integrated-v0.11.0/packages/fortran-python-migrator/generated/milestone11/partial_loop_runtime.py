"""Generated Python wrapper with a selectable compiled internal loop."""

from contextvars import ContextVar
import importlib.util
from pathlib import Path
import sys
from types import ModuleType
from typing import Literal

import numpy as np

BackendName = Literal["python", "cython-safe", "cython-optimized"]
DEFAULT_BACKEND: BackendName = 'cython-optimized'
_ROOT = Path(__file__).resolve().parent
_MODULE_CACHE: dict[str, ModuleType] = {}
_BACKEND: ContextVar[BackendName] = ContextVar('fpy_partial_loop_backend', default=DEFAULT_BACKEND)

def _load_module(name: str, relative_path: str) -> ModuleType:
    if name in _MODULE_CACHE:
        return _MODULE_CACHE[name]
    path = (_ROOT / relative_path).resolve()
    if not path.exists():
        raise FileNotFoundError(path)
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise ImportError(f'cannot load generated module: {path}')
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    _MODULE_CACHE[name] = module
    return module

_WRAPPER = _load_module('fpy_partial_wrapper', 'partial_wrapper_reference.py')
_ARTIFACTS = {'python': 'run_partial_loop_loop_1_kernel_python.py', 'cython-safe': 'cython_safe_build/lib/fpy_run_partial_loop_loop_1_kernel_safe.cpython-313-x86_64-linux-gnu.so', 'cython-optimized': 'cython_optimized_build/lib/fpy_run_partial_loop_loop_1_kernel_optimized.cpython-313-x86_64-linux-gnu.so'}
_MODULE_NAMES = {'python': 'run_partial_loop_loop_1_kernel_python', 'cython-safe': 'fpy_run_partial_loop_loop_1_kernel_safe', 'cython-optimized': 'fpy_run_partial_loop_loop_1_kernel_optimized'}
_BACKENDS = {
    name: _load_module(_MODULE_NAMES[name], path)
    for name, path in _ARTIFACTS.items()
}

def _dispatch_run_partial_loop_loop_1_kernel(*args):
    selected = _BACKEND.get()
    function = getattr(_BACKENDS[selected], 'run_partial_loop_loop_1_kernel')
    result = function(*args)
    return np.asarray(result)

_WRAPPER.run_partial_loop_loop_1_kernel = _dispatch_run_partial_loop_loop_1_kernel

CommonFieldState = _WRAPPER.CommonFieldState

def create_common_field() -> CommonFieldState:
    return CommonFieldState(pressure=np.zeros((16,), dtype=np.float64), film=np.zeros((16,), dtype=np.float64), relaxation_factor=0.0)

def run_partial_loop(state_common_field, n, scale, *, backend: BackendName = DEFAULT_BACKEND):
    token = _BACKEND.set(backend)
    try:
        return _WRAPPER.run_partial_loop(state_common_field, n, scale)
    finally:
        _BACKEND.reset(token)
