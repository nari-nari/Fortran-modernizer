"""Generated from Fortran by fpy-migrate. Do not edit by hand."""

import math

import numpy as np
import numpy.typing as npt

FloatArray = npt.NDArray[np.float64]

def compute_film(ntheta: int, eccentricity: float) -> FloatArray:
    # Source: /mnt/data/fortran-python-migrator/samples/migration_units/compute_film.f90:7-20
    film = np.empty((ntheta,), dtype=np.float64)
    pi = (4.0 * math.atan(1.0))
    dtheta = ((2.0 * pi) / float(ntheta))
    for i in range(1, (ntheta) + 1):
        theta = (float((i - 1)) * dtheta)
        film[(i) - 1] = (1.0 + (eccentricity * math.cos(theta)))
    return film
