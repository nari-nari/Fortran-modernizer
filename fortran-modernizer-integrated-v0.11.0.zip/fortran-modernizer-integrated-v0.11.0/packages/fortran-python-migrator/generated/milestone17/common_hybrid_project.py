"""Generated project-level Python/Cython/Fortran hybrid runtime."""

from contextvars import ContextVar
import importlib.machinery
import importlib.util
from pathlib import Path
import sys
from types import ModuleType
from typing import Literal, Mapping

import numpy as np

BackendName = Literal['python', 'cython-safe', 'cython-optimized', 'fortran']
DEFAULT_BACKEND: BackendName = 'cython-optimized'
ELIGIBLE_PROCEDURES = ('initialize_common_state', 'advance_common_state', 'summarize_common_state')
EXTRACTED_PROCEDURES = ('initialize_common_state', 'advance_common_state', 'summarize_common_state')
FULL_EXTRACTED_PROCEDURES = ('initialize_common_state', 'advance_common_state', 'summarize_common_state')
PARTIAL_EXTRACTED_PROCEDURES = ()
PYTHON_ONLY_PROCEDURES = ('run_common_state',)
_ROOT = Path(__file__).resolve().parent
_MODULE_CACHE: dict[str, ModuleType] = {}
_BACKEND_CONTEXT: ContextVar[tuple[BackendName, dict[str, BackendName]]] = ContextVar(
    'fpy_hybrid_backend', default=(DEFAULT_BACKEND, {})
)

def _resolve_module_path(name: str, relative_path: str) -> Path:
    path = (_ROOT / relative_path).resolve()
    if path.exists():
        return path
    candidates: list[Path] = []
    for suffix in importlib.machinery.EXTENSION_SUFFIXES:
        candidates.extend(_ROOT.rglob(f'{name}{suffix}'))
    candidates.extend(_ROOT.rglob(f'{name}.py'))
    files = sorted({item.resolve() for item in candidates if item.is_file()}, key=lambda item: (len(item.parts), str(item)))
    if not files:
        raise FileNotFoundError(path)
    return files[0]

def _load_module(name: str, relative_path: str) -> ModuleType:
    if name in _MODULE_CACHE:
        return _MODULE_CACHE[name]
    path = _resolve_module_path(name, relative_path)
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise ImportError(f'cannot load generated module: {path}')
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    _MODULE_CACHE[name] = module
    return module

_REFERENCE = _load_module('fpy_hybrid_reference', 'project_reference.py')
_FULL_WRAPPER_PATHS = {'initialize_common_state': 'kernels/initialize_common_state/initialize_common_state_state_wrapper.py', 'advance_common_state': 'kernels/advance_common_state/advance_common_state_state_wrapper.py', 'summarize_common_state': 'kernels/summarize_common_state/summarize_common_state_state_wrapper.py'}
_FULL_WRAPPERS = {
    name: _load_module(f'fpy_hybrid_wrapper_{name}', path)
    for name, path in _FULL_WRAPPER_PATHS.items()
}
_PARTIAL_SPECS = {}
_PARTIAL_BACKENDS = {
    procedure: {
        backend: _load_module(spec['module_names'][backend], path)
        for backend, path in spec['artifacts'].items()
    }
    for procedure, spec in _PARTIAL_SPECS.items()
}

def _backend_for(procedure: str) -> BackendName:
    default, overrides = _BACKEND_CONTEXT.get()
    return overrides.get(procedure, default)

def available_kernels() -> tuple[str, ...]:
    return EXTRACTED_PROCEDURES

def eligible_kernels() -> tuple[str, ...]:
    return ELIGIBLE_PROCEDURES

def call_kernel(procedure: str, *args, backend: BackendName | None = None, **kwargs):
    if procedure not in FULL_EXTRACTED_PROCEDURES:
        raise ValueError('direct call_kernel is limited to full-procedure kernels')
    wrapper = _FULL_WRAPPERS[procedure]
    selected = backend or _backend_for(procedure)
    return getattr(wrapper, procedure)(*args, backend=selected, **kwargs)

CommonFieldState = _REFERENCE.CommonFieldState

def create_common_field() -> CommonFieldState:
    return CommonFieldState(pressure=np.zeros((16,), dtype=np.float64), film=np.zeros((16,), dtype=np.float64), relaxation_factor=0.0)

def _dispatch_initialize_common_state(state_common_field, n, eccentricity):
    return call_kernel('initialize_common_state', state_common_field, n, eccentricity)

_REFERENCE.initialize_common_state = _dispatch_initialize_common_state
def _dispatch_advance_common_state(state_common_field, n):
    return call_kernel('advance_common_state', state_common_field, n)

_REFERENCE.advance_common_state = _dispatch_advance_common_state
def _dispatch_summarize_common_state(state_common_field, n):
    return call_kernel('summarize_common_state', state_common_field, n)

_REFERENCE.summarize_common_state = _dispatch_summarize_common_state

def run_common_state(state_common_field, n, eccentricity, *, backend: BackendName = DEFAULT_BACKEND, backend_overrides: Mapping[str, BackendName] | None = None):
    overrides = dict(backend_overrides or {})
    unknown = sorted(set(overrides) - set(EXTRACTED_PROCEDURES))
    if unknown:
        raise ValueError(f'backend override refers to non-kernel procedures: {unknown}')
    token = _BACKEND_CONTEXT.set((backend, overrides))
    try:
        return _REFERENCE.run_common_state(state_common_field, n, eccentricity)
    finally:
        _BACKEND_CONTEXT.reset(token)
