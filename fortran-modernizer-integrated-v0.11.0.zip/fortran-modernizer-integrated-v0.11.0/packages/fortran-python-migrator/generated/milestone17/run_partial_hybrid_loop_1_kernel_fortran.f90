subroutine run_partial_hybrid_loop_1_kernel_c( &
  n, &
  bias, &
  pressure_ptr, &
  pressure_dim1, &
  film_ptr, &
  film_dim1) bind(C, name="fpy_run_partial_hybrid_loop_1_kernel")
  use iso_c_binding, only: c_ptr, c_f_pointer, c_int, c_double, c_bool
  implicit none
  integer(c_int), value, intent(in) :: n
  real(c_double), value, intent(in) :: bias
  type(c_ptr), value, intent(in) :: pressure_ptr
  integer(c_int), value, intent(in) :: pressure_dim1
  real(c_double), pointer :: pressure(:)
  type(c_ptr), value, intent(in) :: film_ptr
  integer(c_int), value, intent(in) :: film_dim1
  real(c_double), pointer :: film(:)
  integer(c_int) :: i
  call c_f_pointer(pressure_ptr, pressure, [pressure_dim1])
  call c_f_pointer(film_ptr, film, [film_dim1])
  do i = 1, n, 1
    pressure(i) = (pressure(i) + (bias * film(i)))
  end do
end subroutine run_partial_hybrid_loop_1_kernel_c
