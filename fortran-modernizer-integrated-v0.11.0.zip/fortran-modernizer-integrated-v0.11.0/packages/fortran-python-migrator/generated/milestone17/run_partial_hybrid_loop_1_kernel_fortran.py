"""Generated ctypes adapter for a C-interoperable Fortran kernel."""

import ctypes
from pathlib import Path

import numpy as np

_ROOT = Path(__file__).resolve().parent
_LIBRARY_NAME = 'librun_partial_hybrid_loop_1_kernel_fortran.so'
_LIBRARY_PATH = (_ROOT / _LIBRARY_NAME).resolve()
if not _LIBRARY_PATH.exists():
    candidates = sorted(_ROOT.rglob(_LIBRARY_NAME))
    if not candidates:
        raise FileNotFoundError(_LIBRARY_PATH)
    _LIBRARY_PATH = candidates[0]
_LIBRARY = ctypes.CDLL(str(_LIBRARY_PATH))
_FUNCTION = getattr(_LIBRARY, 'fpy_run_partial_hybrid_loop_1_kernel')
_FUNCTION.argtypes = [ctypes.c_int, ctypes.c_double, ctypes.c_void_p, ctypes.c_int, ctypes.c_void_p, ctypes.c_int]
_FUNCTION.restype = None

def run_partial_hybrid_loop_1_kernel(n, bias, pressure, film):
    _original_pressure = pressure
    _array_pressure = np.ascontiguousarray(pressure, dtype=np.float64)
    if _array_pressure.ndim != 1: raise ValueError('pressure must have rank 1')
    _original_film = film
    _array_film = np.ascontiguousarray(film, dtype=np.float64)
    if _array_film.ndim != 1: raise ValueError('film must have rank 1')
    _FUNCTION(ctypes.c_int(n), ctypes.c_double(bias), ctypes.c_void_p(_array_pressure.ctypes.data), ctypes.c_int(_array_pressure.shape[0]), ctypes.c_void_p(_array_film.ctypes.data), ctypes.c_int(_array_film.shape[0]))
    if isinstance(_original_pressure, np.ndarray) and _original_pressure.shape == _array_pressure.shape:
        _original_pressure[...] = _array_pressure
    return _array_pressure
