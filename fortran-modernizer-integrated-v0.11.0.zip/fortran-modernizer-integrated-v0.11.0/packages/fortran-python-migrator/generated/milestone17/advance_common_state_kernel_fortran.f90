subroutine advance_common_state_kernel_c( &
  n, &
  pressure_ptr, &
  pressure_dim1, &
  film_ptr, &
  film_dim1, &
  relaxation_factor) bind(C, name="fpy_advance_common_state_kernel")
  use iso_c_binding, only: c_ptr, c_f_pointer, c_int, c_double, c_bool
  implicit none
  integer(c_int), value, intent(in) :: n
  type(c_ptr), value, intent(in) :: pressure_ptr
  integer(c_int), value, intent(in) :: pressure_dim1
  real(c_double), pointer :: pressure(:)
  type(c_ptr), value, intent(in) :: film_ptr
  integer(c_int), value, intent(in) :: film_dim1
  real(c_double), pointer :: film(:)
  real(c_double), value, intent(in) :: relaxation_factor
  integer(c_int) :: i
  call c_f_pointer(pressure_ptr, pressure, [pressure_dim1])
  call c_f_pointer(film_ptr, film, [film_dim1])
  do i = 2, (n - 1), 1
    pressure(i) = (pressure(i) + ((relaxation_factor * ((0.5_c_double * (pressure((i - 1)) + pressure((i + 1)))) - pressure(i))) / film(i)))
  end do
end subroutine advance_common_state_kernel_c
