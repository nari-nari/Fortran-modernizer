"""Generated from Fortran by fpy-migrate. Do not edit by hand."""

from dataclasses import dataclass
import math

import numpy as np
import numpy.typing as npt

FloatArray = npt.NDArray[np.float64]
IntArray = npt.NDArray[np.int64]
BoolArray = npt.NDArray[np.bool_]

@dataclass
class CommonFieldState:
    # Fortran common: field
    p: FloatArray
    h: FloatArray
    theta: FloatArray

def solve_reynolds(state_common_field: CommonFieldState) -> tuple[int, float]:
    # Source: /mnt/data/fortran-python-migrator/samples/migration_units/legacy_scoped_analysis.f90:31-76
    ntheta = 36
    nz = 17
    maxit = 25000
    omega = 1.55
    toler = 1e-10
    aspect = 0.5
    pi = math.acos((-1.0))
    dtheta = ((2.0 * pi) / float(ntheta))
    dz = (1.0 / float((nz - 1)))
    for j in range(1, (nz) + 1):
        for i in range(1, (ntheta) + 1):
            state_common_field.p[(i) - 1, (j) - 1] = 0.0
    residual = np.finfo(np.float64).max
    for iterations in range(1, (maxit) + 1):
        residual = 0.0
        for j in range(2, ((nz - 1)) + 1):
            for i in range(1, (ntheta) + 1):
                ip = (i + 1)
                if (ip > ntheta):
                    ip = 1
                im = (i - 1)
                if (im < 1):
                    im = ntheta
                hplus = (0.5 * (state_common_field.h[(i) - 1] + state_common_field.h[(ip) - 1]))
                hminus = (0.5 * (state_common_field.h[(i) - 1] + state_common_field.h[(im) - 1]))
                ae = ((hplus ** 3) / (dtheta ** 2))
                aw = ((hminus ** 3) / (dtheta ** 2))
                az = (((aspect ** 2) * (state_common_field.h[(i) - 1] ** 3)) / (dz ** 2))
                ap = ((ae + aw) + (2.0 * az))
                rhs = (-((6.0 * 0.6) * math.sin(state_common_field.theta[(i) - 1])))
                pstar = (((((ae * state_common_field.p[(ip) - 1, (j) - 1]) + (aw * state_common_field.p[(im) - 1, (j) - 1])) + (az * (state_common_field.p[(i) - 1, ((j + 1)) - 1] + state_common_field.p[(i) - 1, ((j - 1)) - 1]))) - rhs) / ap)
                updated = max(0.0, (state_common_field.p[(i) - 1, (j) - 1] + (omega * (pstar - state_common_field.p[(i) - 1, (j) - 1]))))
                change = abs((updated - state_common_field.p[(i) - 1, (j) - 1]))
                residual = max(residual, change)
                state_common_field.p[(i) - 1, (j) - 1] = updated
        if (residual < toler):
            break
    return iterations, residual
