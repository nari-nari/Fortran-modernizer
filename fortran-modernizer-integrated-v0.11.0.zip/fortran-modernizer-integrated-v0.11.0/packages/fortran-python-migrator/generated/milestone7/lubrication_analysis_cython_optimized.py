# cython: language_level=3, boundscheck=False, wraparound=False, initializedcheck=False, cdivision=True
"""Generated Cython optimized kernel from Fortran by fpy-migrate."""

import math

import cython
import numpy as np

@cython.boundscheck(False)
@cython.wraparound(False)
@cython.initializedcheck(False)
@cython.cdivision(True)
def periodic_neighbors(i: cython.int, ntheta: cython.int):
    # Source: /mnt/data/fortran-python-migrator/samples/migration_units/lubrication_analysis.f90:23-37
    iw: cython.int
    ie: cython.int
    if (i > 1):
        iw = (i - 1)
    else:
        iw = ntheta
    if (i < ntheta):
        ie = (i + 1)
    else:
        ie = 1
    return iw, ie

@cython.boundscheck(False)
@cython.wraparound(False)
@cython.initializedcheck(False)
@cython.cdivision(True)
def compute_postprocess(ntheta: cython.int, nz: cython.int, film: cython.double[::1], pressure: cython.double[:, ::1], axial_scale: cython.double):
    # Source: /mnt/data/fortran-python-migrator/samples/migration_units/lubrication_analysis.f90:108-170
    equation_residual: cython.double
    load_x: cython.double
    load_y: cython.double
    load_magnitude: cython.double
    dimensionless_friction: cython.double
    maximum_pressure: cython.double
    minimum_film_thickness: cython.double
    i: cython.int
    j: cython.int
    iw: cython.int
    ie: cython.int
    pi: cython.double
    dtheta: cython.double
    dz: cython.double
    theta: cython.double
    ki: cython.double
    ae: cython.double
    aw: cython.double
    an: cython.double
    asouth: cython.double
    ap: cython.double
    rhs: cython.double
    equation_value: cython.double
    difference: cython.double
    pressure_gradient: cython.double
    local_shear: cython.double
    pi = (4.0 * math.atan(1.0))
    dtheta = ((2.0 * pi) / float(ntheta))
    dz = (1.0 / float((nz - 1)))
    equation_residual = 0.0
    load_x = 0.0
    load_y = 0.0
    dimensionless_friction = 0.0
    maximum_pressure = pressure[(1) - 1, (1) - 1]
    minimum_film_thickness = film[(1) - 1]
    for i in range(1, (ntheta) + 1):
        # Inlined leaf call: periodic_neighbors
        if (i > 1):
            iw = (i - 1)
        else:
            iw = ntheta
        if (i < ntheta):
            ie = (i + 1)
        else:
            ie = 1
        theta = (float((i - 1)) * dtheta)
        ki = (film[(i) - 1] ** 3)
        ae = ((0.5 * (ki + (film[(ie) - 1] ** 3))) / (dtheta * dtheta))
        aw = ((0.5 * (ki + (film[(iw) - 1] ** 3))) / (dtheta * dtheta))
        an = ((axial_scale * ki) / (dz * dz))
        asouth = an
        ap = (((ae + aw) + an) + asouth)
        rhs = ((3.0 * (film[(ie) - 1] - film[(iw) - 1])) / dtheta)
        if (film[(i) - 1] < minimum_film_thickness):
            minimum_film_thickness = film[(i) - 1]
        for j in range(1, (nz) + 1):
            if (pressure[(i) - 1, (j) - 1] > maximum_pressure):
                maximum_pressure = pressure[(i) - 1, (j) - 1]
        for j in range(2, ((nz - 1)) + 1):
            equation_value = ((((((ap * pressure[(i) - 1, (j) - 1]) - (ae * pressure[(ie) - 1, (j) - 1])) - (aw * pressure[(iw) - 1, (j) - 1])) - (an * pressure[(i) - 1, ((j + 1)) - 1])) - (asouth * pressure[(i) - 1, ((j - 1)) - 1])) + rhs)
            if (pressure[(i) - 1, (j) - 1] > 0.0):
                difference = abs(equation_value)
            else:
                if (equation_value < 0.0):
                    difference = abs(equation_value)
                else:
                    difference = 0.0
            if (difference > equation_residual):
                equation_residual = difference
            load_x = (load_x + (((pressure[(i) - 1, (j) - 1] * math.cos(theta)) * dtheta) * dz))
            load_y = (load_y + (((pressure[(i) - 1, (j) - 1] * math.sin(theta)) * dtheta) * dz))
            pressure_gradient = ((pressure[(ie) - 1, (j) - 1] - pressure[(iw) - 1, (j) - 1]) / (2.0 * dtheta))
            local_shear = ((1.0 / film[(i) - 1]) + ((0.5 * film[(i) - 1]) * pressure_gradient))
            dimensionless_friction = (dimensionless_friction + ((abs(local_shear) * dtheta) * dz))
    load_magnitude = math.sqrt(((load_x * load_x) + (load_y * load_y)))
    return equation_residual, load_x, load_y, load_magnitude, dimensionless_friction, maximum_pressure, minimum_film_thickness

@cython.boundscheck(False)
@cython.wraparound(False)
@cython.initializedcheck(False)
@cython.cdivision(True)
def compute_film(ntheta: cython.int, eccentricity: cython.double):
    # Source: /mnt/data/fortran-python-migrator/samples/migration_units/lubrication_analysis.f90:8-21
    film: cython.double[::1]
    i: cython.int
    pi: cython.double
    dtheta: cython.double
    theta: cython.double
    film = np.empty((ntheta,), dtype=np.float64)
    pi = (4.0 * math.atan(1.0))
    dtheta = ((2.0 * pi) / float(ntheta))
    for i in range(1, (ntheta) + 1):
        theta = (float((i - 1)) * dtheta)
        film[(i) - 1] = (1.0 + (eccentricity * math.cos(theta)))
    return film

@cython.boundscheck(False)
@cython.wraparound(False)
@cython.initializedcheck(False)
@cython.cdivision(True)
def sor_sweep(ntheta: cython.int, nz: cython.int, film: cython.double[::1], pressure: cython.double[:, ::1], dtheta: cython.double, dz: cython.double, axial_scale: cython.double, relaxation_factor: cython.double):
    # Source: /mnt/data/fortran-python-migrator/samples/migration_units/lubrication_analysis.f90:39-74
    update_residual: cython.double
    i: cython.int
    j: cython.int
    iw: cython.int
    ie: cython.int
    ki: cython.double
    ae: cython.double
    aw: cython.double
    an: cython.double
    asouth: cython.double
    ap: cython.double
    rhs: cython.double
    old_value: cython.double
    candidate: cython.double
    updated: cython.double
    difference: cython.double
    update_residual = 0.0
    for i in range(1, (ntheta) + 1):
        # Inlined leaf call: periodic_neighbors
        if (i > 1):
            iw = (i - 1)
        else:
            iw = ntheta
        if (i < ntheta):
            ie = (i + 1)
        else:
            ie = 1
        ki = (film[(i) - 1] ** 3)
        ae = ((0.5 * (ki + (film[(ie) - 1] ** 3))) / (dtheta * dtheta))
        aw = ((0.5 * (ki + (film[(iw) - 1] ** 3))) / (dtheta * dtheta))
        an = ((axial_scale * ki) / (dz * dz))
        asouth = an
        ap = (((ae + aw) + an) + asouth)
        rhs = ((3.0 * (film[(ie) - 1] - film[(iw) - 1])) / dtheta)
        for j in range(2, ((nz - 1)) + 1):
            old_value = pressure[(i) - 1, (j) - 1]
            candidate = ((((((ae * pressure[(ie) - 1, (j) - 1]) + (aw * pressure[(iw) - 1, (j) - 1])) + (an * pressure[(i) - 1, ((j + 1)) - 1])) + (asouth * pressure[(i) - 1, ((j - 1)) - 1])) - rhs) / ap)
            if ((candidate < 0.0) and (ap > 0.0)):
                candidate = 0.0
            updated = (old_value + (relaxation_factor * (candidate - old_value)))
            if (updated < 0.0):
                updated = 0.0
            pressure[(i) - 1, (j) - 1] = updated
            difference = abs((updated - old_value))
            if (difference > update_residual):
                update_residual = difference
    return pressure, update_residual

@cython.boundscheck(False)
@cython.wraparound(False)
@cython.initializedcheck(False)
@cython.cdivision(True)
def solve_pressure(ntheta: cython.int, nz: cython.int, eccentricity: cython.double, relaxation_factor: cython.double, tolerance: cython.double, max_iterations: cython.int, axial_scale: cython.double):
    # Source: /mnt/data/fortran-python-migrator/samples/migration_units/lubrication_analysis.f90:76-106
    pressure: cython.double[:, ::1]
    film: cython.double[::1]
    iterations: cython.int
    update_residual: cython.double
    converged: cython.bint
    iteration: cython.int
    pi: cython.double
    dtheta: cython.double
    dz: cython.double
    pressure = np.empty((ntheta, nz), dtype=np.float64)
    film = np.empty((ntheta,), dtype=np.float64)
    pi = (4.0 * math.atan(1.0))
    dtheta = ((2.0 * pi) / float(ntheta))
    dz = (1.0 / float((nz - 1)))
    pressure[...] = 0.0
    film = compute_film(ntheta, eccentricity)
    iterations = 0
    update_residual = 0.0
    converged = False
    for iteration in range(1, (max_iterations) + 1):
        pressure, update_residual = sor_sweep(ntheta, nz, film, pressure, dtheta, dz, axial_scale, relaxation_factor)
        iterations = iteration
        if (update_residual <= tolerance):
            converged = True
            break
    return pressure, film, iterations, update_residual, converged

@cython.boundscheck(False)
@cython.wraparound(False)
@cython.initializedcheck(False)
@cython.cdivision(True)
def solve_analysis(ntheta: cython.int, nz: cython.int, eccentricity: cython.double, relaxation_factor: cython.double, tolerance: cython.double, max_iterations: cython.int, axial_scale: cython.double):
    # Source: /mnt/data/fortran-python-migrator/samples/migration_units/lubrication_analysis.f90:172-194
    pressure: cython.double[:, ::1]
    film: cython.double[::1]
    iterations: cython.int
    update_residual: cython.double
    converged: cython.bint
    equation_residual: cython.double
    load_x: cython.double
    load_y: cython.double
    load_magnitude: cython.double
    dimensionless_friction: cython.double
    maximum_pressure: cython.double
    minimum_film_thickness: cython.double
    pressure = np.empty((ntheta, nz), dtype=np.float64)
    film = np.empty((ntheta,), dtype=np.float64)
    pressure, film, iterations, update_residual, converged = solve_pressure(ntheta, nz, eccentricity, relaxation_factor, tolerance, max_iterations, axial_scale)
    equation_residual, load_x, load_y, load_magnitude, dimensionless_friction, maximum_pressure, minimum_film_thickness = compute_postprocess(ntheta, nz, film, pressure, axial_scale)
    return pressure, film, iterations, update_residual, converged, equation_residual, load_x, load_y, load_magnitude, dimensionless_friction, maximum_pressure, minimum_film_thickness
