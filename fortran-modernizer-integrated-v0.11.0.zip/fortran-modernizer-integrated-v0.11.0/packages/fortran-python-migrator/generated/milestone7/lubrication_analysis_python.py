"""Generated from Fortran by fpy-migrate. Do not edit by hand."""

import math

import numpy as np
import numpy.typing as npt

FloatArray = npt.NDArray[np.float64]
IntArray = npt.NDArray[np.int64]
BoolArray = npt.NDArray[np.bool_]

def periodic_neighbors(i: int, ntheta: int) -> tuple[int, int]:
    # Source: /mnt/data/fortran-python-migrator/samples/migration_units/lubrication_analysis.f90:23-37
    if (i > 1):
        iw = (i - 1)
    else:
        iw = ntheta
    if (i < ntheta):
        ie = (i + 1)
    else:
        ie = 1
    return iw, ie

def compute_postprocess(ntheta: int, nz: int, film: FloatArray, pressure: FloatArray, axial_scale: float) -> tuple[float, float, float, float, float, float, float]:
    # Source: /mnt/data/fortran-python-migrator/samples/migration_units/lubrication_analysis.f90:108-170
    pi = (4.0 * math.atan(1.0))
    dtheta = ((2.0 * pi) / float(ntheta))
    dz = (1.0 / float((nz - 1)))
    equation_residual = 0.0
    load_x = 0.0
    load_y = 0.0
    dimensionless_friction = 0.0
    maximum_pressure = pressure[(1) - 1, (1) - 1]
    minimum_film_thickness = film[(1) - 1]
    for i in range(1, (ntheta) + 1):
        iw, ie = periodic_neighbors(i, ntheta)
        theta = (float((i - 1)) * dtheta)
        ki = (film[(i) - 1] ** 3)
        ae = ((0.5 * (ki + (film[(ie) - 1] ** 3))) / (dtheta * dtheta))
        aw = ((0.5 * (ki + (film[(iw) - 1] ** 3))) / (dtheta * dtheta))
        an = ((axial_scale * ki) / (dz * dz))
        asouth = an
        ap = (((ae + aw) + an) + asouth)
        rhs = ((3.0 * (film[(ie) - 1] - film[(iw) - 1])) / dtheta)
        if (film[(i) - 1] < minimum_film_thickness):
            minimum_film_thickness = film[(i) - 1]
        for j in range(1, (nz) + 1):
            if (pressure[(i) - 1, (j) - 1] > maximum_pressure):
                maximum_pressure = pressure[(i) - 1, (j) - 1]
        for j in range(2, ((nz - 1)) + 1):
            equation_value = ((((((ap * pressure[(i) - 1, (j) - 1]) - (ae * pressure[(ie) - 1, (j) - 1])) - (aw * pressure[(iw) - 1, (j) - 1])) - (an * pressure[(i) - 1, ((j + 1)) - 1])) - (asouth * pressure[(i) - 1, ((j - 1)) - 1])) + rhs)
            if (pressure[(i) - 1, (j) - 1] > 0.0):
                difference = abs(equation_value)
            else:
                if (equation_value < 0.0):
                    difference = abs(equation_value)
                else:
                    difference = 0.0
            if (difference > equation_residual):
                equation_residual = difference
            load_x = (load_x + (((pressure[(i) - 1, (j) - 1] * math.cos(theta)) * dtheta) * dz))
            load_y = (load_y + (((pressure[(i) - 1, (j) - 1] * math.sin(theta)) * dtheta) * dz))
            pressure_gradient = ((pressure[(ie) - 1, (j) - 1] - pressure[(iw) - 1, (j) - 1]) / (2.0 * dtheta))
            local_shear = ((1.0 / film[(i) - 1]) + ((0.5 * film[(i) - 1]) * pressure_gradient))
            dimensionless_friction = (dimensionless_friction + ((abs(local_shear) * dtheta) * dz))
    load_magnitude = math.sqrt(((load_x * load_x) + (load_y * load_y)))
    return equation_residual, load_x, load_y, load_magnitude, dimensionless_friction, maximum_pressure, minimum_film_thickness

def compute_film(ntheta: int, eccentricity: float) -> FloatArray:
    # Source: /mnt/data/fortran-python-migrator/samples/migration_units/lubrication_analysis.f90:8-21
    film = np.empty((ntheta,), dtype=np.float64)
    pi = (4.0 * math.atan(1.0))
    dtheta = ((2.0 * pi) / float(ntheta))
    for i in range(1, (ntheta) + 1):
        theta = (float((i - 1)) * dtheta)
        film[(i) - 1] = (1.0 + (eccentricity * math.cos(theta)))
    return film

def sor_sweep(ntheta: int, nz: int, film: FloatArray, pressure: FloatArray, dtheta: float, dz: float, axial_scale: float, relaxation_factor: float) -> tuple[FloatArray, float]:
    # Source: /mnt/data/fortran-python-migrator/samples/migration_units/lubrication_analysis.f90:39-74
    update_residual = 0.0
    for i in range(1, (ntheta) + 1):
        iw, ie = periodic_neighbors(i, ntheta)
        ki = (film[(i) - 1] ** 3)
        ae = ((0.5 * (ki + (film[(ie) - 1] ** 3))) / (dtheta * dtheta))
        aw = ((0.5 * (ki + (film[(iw) - 1] ** 3))) / (dtheta * dtheta))
        an = ((axial_scale * ki) / (dz * dz))
        asouth = an
        ap = (((ae + aw) + an) + asouth)
        rhs = ((3.0 * (film[(ie) - 1] - film[(iw) - 1])) / dtheta)
        for j in range(2, ((nz - 1)) + 1):
            old_value = pressure[(i) - 1, (j) - 1]
            candidate = ((((((ae * pressure[(ie) - 1, (j) - 1]) + (aw * pressure[(iw) - 1, (j) - 1])) + (an * pressure[(i) - 1, ((j + 1)) - 1])) + (asouth * pressure[(i) - 1, ((j - 1)) - 1])) - rhs) / ap)
            if ((candidate < 0.0) and (ap > 0.0)):
                candidate = 0.0
            updated = (old_value + (relaxation_factor * (candidate - old_value)))
            if (updated < 0.0):
                updated = 0.0
            pressure[(i) - 1, (j) - 1] = updated
            difference = abs((updated - old_value))
            if (difference > update_residual):
                update_residual = difference
    return pressure, update_residual

def solve_pressure(ntheta: int, nz: int, eccentricity: float, relaxation_factor: float, tolerance: float, max_iterations: int, axial_scale: float) -> tuple[FloatArray, FloatArray, int, float, bool]:
    # Source: /mnt/data/fortran-python-migrator/samples/migration_units/lubrication_analysis.f90:76-106
    pressure = np.empty((ntheta, nz), dtype=np.float64)
    film = np.empty((ntheta,), dtype=np.float64)
    pi = (4.0 * math.atan(1.0))
    dtheta = ((2.0 * pi) / float(ntheta))
    dz = (1.0 / float((nz - 1)))
    pressure[...] = 0.0
    film = compute_film(ntheta, eccentricity)
    iterations = 0
    update_residual = 0.0
    converged = False
    for iteration in range(1, (max_iterations) + 1):
        pressure, update_residual = sor_sweep(ntheta, nz, film, pressure, dtheta, dz, axial_scale, relaxation_factor)
        iterations = iteration
        if (update_residual <= tolerance):
            converged = True
            break
    return pressure, film, iterations, update_residual, converged

def solve_analysis(ntheta: int, nz: int, eccentricity: float, relaxation_factor: float, tolerance: float, max_iterations: int, axial_scale: float) -> tuple[FloatArray, FloatArray, int, float, bool, float, float, float, float, float, float, float]:
    # Source: /mnt/data/fortran-python-migrator/samples/migration_units/lubrication_analysis.f90:172-194
    pressure = np.empty((ntheta, nz), dtype=np.float64)
    film = np.empty((ntheta,), dtype=np.float64)
    pressure, film, iterations, update_residual, converged = solve_pressure(ntheta, nz, eccentricity, relaxation_factor, tolerance, max_iterations, axial_scale)
    equation_residual, load_x, load_y, load_magnitude, dimensionless_friction, maximum_pressure, minimum_film_thickness = compute_postprocess(ntheta, nz, film, pressure, axial_scale)
    return pressure, film, iterations, update_residual, converged, equation_residual, load_x, load_y, load_magnitude, dimensionless_friction, maximum_pressure, minimum_film_thickness
