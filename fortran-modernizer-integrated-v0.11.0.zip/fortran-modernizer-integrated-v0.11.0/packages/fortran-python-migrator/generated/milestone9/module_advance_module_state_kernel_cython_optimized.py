# cython: language_level=3, boundscheck=False, wraparound=False, initializedcheck=False, cdivision=True
"""Generated Cython optimized kernel from Fortran by fpy-migrate."""

import math

import cython
import numpy as np

@cython.boundscheck(False)
@cython.wraparound(False)
@cython.initializedcheck(False)
@cython.cdivision(True)
def advance_module_state_kernel(active_count: cython.int, pressure: cython.double[::1], film: cython.double[::1], relaxation_factor: cython.double):
    # Source: /mnt/data/fortran-python-migrator/samples/migration_units/module_state_analysis.f90:24-32
    i: cython.int
    for i in range(2, ((active_count - 1)) + 1):
        pressure[(i) - 1] = (pressure[(i) - 1] + ((relaxation_factor * ((0.5 * (pressure[((i - 1)) - 1] + pressure[((i + 1)) - 1])) - pressure[(i) - 1])) / film[(i) - 1]))
    return pressure
