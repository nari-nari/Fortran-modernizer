"""Generated Python state wrapper and selectable numerical backends."""

from dataclasses import dataclass
import importlib.util
from pathlib import Path
import sys
from types import ModuleType
from typing import Literal

import numpy as np
import numpy.typing as npt

FloatArray = npt.NDArray[np.float64]
IntArray = npt.NDArray[np.int64]
BoolArray = npt.NDArray[np.bool_]
BackendName = Literal["python", "cython-safe", "cython-optimized"]

@dataclass
class ModuleModuleStateAnalysisModState:
    # Fortran module: module_state_analysis_mod
    active_count: int
    pressure: FloatArray
    film: FloatArray
    relaxation_factor: float

_ROOT = Path(__file__).resolve().parent
_BACKEND_PATHS = {'python': 'advance_module_state_kernel_python.py', 'cython-safe': 'cython_safe_build/lib/fpy_advance_module_state_kernel_safe.cpython-313-x86_64-linux-gnu.so', 'cython-optimized': 'cython_optimized_build/lib/fpy_advance_module_state_kernel_optimized.cpython-313-x86_64-linux-gnu.so'}
_BACKEND_MODULES = {'python': 'advance_module_state_kernel_python', 'cython-safe': 'fpy_advance_module_state_kernel_safe', 'cython-optimized': 'fpy_advance_module_state_kernel_optimized'}
_CACHE: dict[str, ModuleType] = {}

def _load_backend(backend: BackendName) -> ModuleType:
    if backend in _CACHE:
        return _CACHE[backend]
    try:
        relative_path = _BACKEND_PATHS[backend]
        module_name = _BACKEND_MODULES[backend]
    except KeyError as exc:
        raise ValueError(f'unsupported state-kernel backend: {backend}') from exc
    path = (_ROOT / relative_path).resolve()
    if not path.exists():
        raise FileNotFoundError(path)
    spec = importlib.util.spec_from_file_location(module_name, path)
    if spec is None or spec.loader is None:
        raise ImportError(f'cannot load generated backend: {path}')
    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    spec.loader.exec_module(module)
    _CACHE[backend] = module
    return module

def advance_module_state(state_module_module_state_analysis_mod: ModuleModuleStateAnalysisModState, *, backend: BackendName = 'python') -> None:
    # Extracted kernel: advance_module_state_kernel; state remains in Python.
    module = _load_backend(backend)
    kernel = getattr(module, 'advance_module_state_kernel')
    _result_0 = kernel(state_module_module_state_analysis_mod.active_count, state_module_module_state_analysis_mod.pressure, state_module_module_state_analysis_mod.film, state_module_module_state_analysis_mod.relaxation_factor)
    state_module_module_state_analysis_mod.pressure = np.asarray(_result_0)
    return None
