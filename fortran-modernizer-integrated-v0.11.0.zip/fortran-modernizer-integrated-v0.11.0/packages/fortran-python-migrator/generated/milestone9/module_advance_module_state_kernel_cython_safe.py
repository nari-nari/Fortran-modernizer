# cython: language_level=3, boundscheck=True, wraparound=True, initializedcheck=True, cdivision=True
"""Generated Cython safe kernel from Fortran by fpy-migrate."""

import math

import cython
import numpy as np

@cython.boundscheck(True)
@cython.wraparound(True)
@cython.initializedcheck(True)
@cython.cdivision(True)
def advance_module_state_kernel(active_count: cython.int, pressure: cython.double[:], film: cython.double[:], relaxation_factor: cython.double):
    # Source: /mnt/data/fortran-python-migrator/samples/migration_units/module_state_analysis.f90:24-32
    i: cython.int
    for i in range(2, ((active_count - 1)) + 1):
        pressure[(i) - 1] = (pressure[(i) - 1] + ((relaxation_factor * ((0.5 * (pressure[((i - 1)) - 1] + pressure[((i + 1)) - 1])) - pressure[(i) - 1])) / film[(i) - 1]))
    return pressure
