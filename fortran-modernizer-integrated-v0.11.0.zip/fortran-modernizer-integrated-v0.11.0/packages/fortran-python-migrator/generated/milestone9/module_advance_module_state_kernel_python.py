"""Generated from Fortran by fpy-migrate. Do not edit by hand."""

from dataclasses import dataclass
import math

import numpy as np
import numpy.typing as npt

FloatArray = npt.NDArray[np.float64]
IntArray = npt.NDArray[np.int64]
BoolArray = npt.NDArray[np.bool_]

def advance_module_state_kernel(active_count: int, pressure: FloatArray, film: FloatArray, relaxation_factor: float) -> FloatArray:
    # Source: /mnt/data/fortran-python-migrator/samples/migration_units/module_state_analysis.f90:24-32
    for i in range(2, ((active_count - 1)) + 1):
        pressure[(i) - 1] = (pressure[(i) - 1] + ((relaxation_factor * ((0.5 * (pressure[((i - 1)) - 1] + pressure[((i + 1)) - 1])) - pressure[(i) - 1])) / film[(i) - 1]))
    return pressure
