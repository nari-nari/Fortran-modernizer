"""Generated from Fortran by fpy-migrate. Do not edit by hand."""

from dataclasses import dataclass
import math

import numpy as np
import numpy.typing as npt

FloatArray = npt.NDArray[np.float64]
IntArray = npt.NDArray[np.int64]
BoolArray = npt.NDArray[np.bool_]

def parameter_intrinsics() -> tuple[FloatArray, float, int]:
    # Source: /mnt/data/fortran-python-migrator/samples/migration_units/parameter_intrinsics.f90:1-16
    nbase = 4
    nvalues = (nbase + 1)
    pi = math.acos((-1.0))
    values = np.empty((nvalues,), dtype=np.float64)
    for i in range(1, (nvalues) + 1):
        values[(i) - 1] = math.cos(((float((i - 1)) * pi) / float(nvalues)))
    real_limit = np.finfo(np.float64).max
    int_limit = int(np.iinfo(np.int32).max)
    return values, real_limit, int_limit
