"""Generated ctypes adapter for a C-interoperable Fortran kernel."""

import ctypes
import math
from pathlib import Path

import numpy as np

_ROOT = Path(__file__).resolve().parent
_LIBRARY_NAME = 'libparameter_intrinsics_fortran.so'
_LIBRARY_PATH = (_ROOT / _LIBRARY_NAME).resolve()
if not _LIBRARY_PATH.exists():
    candidates = sorted(_ROOT.rglob(_LIBRARY_NAME))
    if not candidates:
        raise FileNotFoundError(_LIBRARY_PATH)
    _LIBRARY_PATH = candidates[0]
_LIBRARY = ctypes.CDLL(str(_LIBRARY_PATH))
_FUNCTION = getattr(_LIBRARY, 'fpy_parameter_intrinsics')
_FUNCTION.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.POINTER(ctypes.c_double), ctypes.POINTER(ctypes.c_int)]
_FUNCTION.restype = None

def parameter_intrinsics():
    nbase = 4
    nvalues = (nbase + 1)
    pi = math.acos((-1.0))
    _array_values = np.empty((nvalues,), dtype=np.float64, order='C')
    _original_values = None
    _scalar_real_limit = ctypes.c_double(0)
    _scalar_int_limit = ctypes.c_int(0)
    _FUNCTION(ctypes.c_void_p(_array_values.ctypes.data), ctypes.c_int(_array_values.shape[0]), ctypes.byref(_scalar_real_limit), ctypes.byref(_scalar_int_limit))
    return _array_values, _scalar_real_limit.value, _scalar_int_limit.value
