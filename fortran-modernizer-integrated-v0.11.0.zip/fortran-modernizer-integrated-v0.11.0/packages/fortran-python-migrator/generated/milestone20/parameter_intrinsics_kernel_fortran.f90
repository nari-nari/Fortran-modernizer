subroutine parameter_intrinsics_c( &
  values_ptr, &
  values_dim1, &
  real_limit, &
  int_limit) bind(C, name="fpy_parameter_intrinsics")
  use iso_c_binding, only: c_ptr, c_f_pointer, c_int, c_double, c_bool
  implicit none
  integer(c_int), parameter :: nbase = 4
  integer(c_int), parameter :: nvalues = (nbase + 1)
  real(c_double), parameter :: pi = acos((- 1.0_c_double))
  type(c_ptr), value, intent(in) :: values_ptr
  integer(c_int), value, intent(in) :: values_dim1
  real(c_double), pointer :: values(:)
  real(c_double), intent(out) :: real_limit
  integer(c_int), intent(out) :: int_limit
  integer(c_int) :: i
  call c_f_pointer(values_ptr, values, [values_dim1])
  do i = 1, nvalues, 1
    values(i) = cos(((real((i - 1), c_double) * pi) / real(nvalues, c_double)))
  end do
  real_limit = huge(1.0_c_double)
  int_limit = huge(1)
end subroutine parameter_intrinsics_c
