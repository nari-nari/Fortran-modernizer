"""Generated from Fortran by fpy-migrate. Do not edit by hand."""

from dataclasses import dataclass
import math

import numpy as np
import numpy.typing as npt

FloatArray = npt.NDArray[np.float64]
IntArray = npt.NDArray[np.int64]
BoolArray = npt.NDArray[np.bool_]

@dataclass
class CommonFieldState:
    # Fortran common: field
    press: FloatArray
    film: FloatArray
    angle: FloatArray

def compute_metrics(state_common_field: CommonFieldState) -> tuple[float, float, float, float]:
    # Source: /mnt/data/fortran-python-migrator/samples/migration_projects/legacy_parameter_project/compute_metrics.f90:1-34
    ntheta = 36
    nz = 17
    pi = math.acos((-1.0))
    dtheta = ((2.0 * pi) / float(ntheta))
    dz = (1.0 / float((nz - 1)))
    loadx = 0.0
    loady = 0.0
    for j in range(2, ((nz - 1)) + 1):
        for i in range(1, (ntheta) + 1):
            loadx = (loadx + (((state_common_field.press[(i) - 1, (j) - 1] * math.cos(state_common_field.angle[(i) - 1])) * dtheta) * dz))
            loady = (loady + (((state_common_field.press[(i) - 1, (j) - 1] * math.sin(state_common_field.angle[(i) - 1])) * dtheta) * dz))
    load = math.sqrt(((loadx ** 2) + (loady ** 2)))
    pmax = 0.0
    for j in range(1, (nz) + 1):
        for i in range(1, (ntheta) + 1):
            pmax = max(pmax, state_common_field.press[(i) - 1, (j) - 1])
    hmin = state_common_field.film[(1) - 1]
    friction = 0.0
    for i in range(1, (ntheta) + 1):
        hmin = min(hmin, state_common_field.film[(i) - 1])
        friction = (friction + (dtheta / state_common_field.film[(i) - 1]))
    return load, pmax, hmin, friction

def init_geometry(state_common_field: CommonFieldState) -> None:
    # Source: /mnt/data/fortran-python-migrator/samples/migration_projects/legacy_parameter_project/init_geometry.f90:1-15
    ntheta = 36
    nz = 17
    pi = math.acos((-1.0))
    ecc = 0.6
    for i in range(1, (ntheta) + 1):
        state_common_field.angle[(i) - 1] = (((2.0 * pi) * float((i - 1))) / float(ntheta))
        state_common_field.film[(i) - 1] = (1.0 + (ecc * math.cos(state_common_field.angle[(i) - 1])))
    return None

def solve_reynolds(state_common_field: CommonFieldState) -> tuple[int, float]:
    # Source: /mnt/data/fortran-python-migrator/samples/migration_projects/legacy_parameter_project/solve_reynolds.f90:1-46
    ntheta = 36
    nz = 17
    maxit = 25000
    omega = 1.55
    toler = 1e-10
    aspect = 0.5
    pi = math.acos((-1.0))
    dtheta = ((2.0 * pi) / float(ntheta))
    dz = (1.0 / float((nz - 1)))
    for j in range(1, (nz) + 1):
        for i in range(1, (ntheta) + 1):
            state_common_field.press[(i) - 1, (j) - 1] = 0.0
    residual = np.finfo(np.float64).max
    for iterations in range(1, (maxit) + 1):
        residual = 0.0
        for j in range(2, ((nz - 1)) + 1):
            for i in range(1, (ntheta) + 1):
                ip = (i + 1)
                if (ip > ntheta):
                    ip = 1
                im = (i - 1)
                if (im < 1):
                    im = ntheta
                hplus = (0.5 * (state_common_field.film[(i) - 1] + state_common_field.film[(ip) - 1]))
                hminus = (0.5 * (state_common_field.film[(i) - 1] + state_common_field.film[(im) - 1]))
                ae = ((hplus ** 3) / (dtheta ** 2))
                aw = ((hminus ** 3) / (dtheta ** 2))
                az = (((aspect ** 2) * (state_common_field.film[(i) - 1] ** 3)) / (dz ** 2))
                ap = ((ae + aw) + (2.0 * az))
                rhs = (-((6.0 * 0.6) * math.sin(state_common_field.angle[(i) - 1])))
                pstar = (((((ae * state_common_field.press[(ip) - 1, (j) - 1]) + (aw * state_common_field.press[(im) - 1, (j) - 1])) + (az * (state_common_field.press[(i) - 1, ((j + 1)) - 1] + state_common_field.press[(i) - 1, ((j - 1)) - 1]))) - rhs) / ap)
                updated = max(0.0, (state_common_field.press[(i) - 1, (j) - 1] + (omega * (pstar - state_common_field.press[(i) - 1, (j) - 1]))))
                change = abs((updated - state_common_field.press[(i) - 1, (j) - 1]))
                residual = max(residual, change)
                state_common_field.press[(i) - 1, (j) - 1] = updated
        if (residual < toler):
            break
    return iterations, residual
