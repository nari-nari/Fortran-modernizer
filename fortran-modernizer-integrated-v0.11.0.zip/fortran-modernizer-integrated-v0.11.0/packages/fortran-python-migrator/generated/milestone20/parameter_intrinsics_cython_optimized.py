# cython: language_level=3, boundscheck=False, wraparound=False, initializedcheck=False, cdivision=True
"""Generated Cython optimized kernel from Fortran by fpy-migrate."""

import math

import cython
import numpy as np

@cython.boundscheck(False)
@cython.wraparound(False)
@cython.initializedcheck(False)
@cython.cdivision(True)
def parameter_intrinsics():
    # Source: /mnt/data/fortran-python-migrator/samples/migration_units/parameter_intrinsics.f90:1-16
    nbase: cython.int = 4
    nvalues: cython.int = (nbase + 1)
    pi: cython.double = math.acos((-1.0))
    values: cython.double[::1]
    real_limit: cython.double
    int_limit: cython.int
    i: cython.int
    values = np.empty((nvalues,), dtype=np.float64)
    for i in range(1, (nvalues) + 1):
        values[(i) - 1] = math.cos(((float((i - 1)) * pi) / float(nvalues)))
    real_limit = np.finfo(np.float64).max
    int_limit = int(np.iinfo(np.int32).max)
    return values, real_limit, int_limit
