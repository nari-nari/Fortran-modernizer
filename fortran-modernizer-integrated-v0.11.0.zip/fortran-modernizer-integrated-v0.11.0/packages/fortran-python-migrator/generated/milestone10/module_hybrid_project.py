"""Generated project-level Python/Cython hybrid runtime."""

from contextvars import ContextVar
import importlib.util
from pathlib import Path
import sys
from types import ModuleType
from typing import Literal, Mapping

import numpy as np

BackendName = Literal["python", "cython-safe", "cython-optimized"]
DEFAULT_BACKEND: BackendName = 'cython-optimized'
EXTRACTED_PROCEDURES = ('initialize_module_state', 'advance_module_state', 'summarize_module_state')
PYTHON_ONLY_PROCEDURES = ('run_module_state',)
_ROOT = Path(__file__).resolve().parent
_MODULE_CACHE: dict[str, ModuleType] = {}
_BACKEND_CONTEXT: ContextVar[tuple[BackendName, dict[str, BackendName]]] = ContextVar(
    'fpy_hybrid_backend', default=(DEFAULT_BACKEND, {})
)

def _load_module(name: str, relative_path: str) -> ModuleType:
    if name in _MODULE_CACHE:
        return _MODULE_CACHE[name]
    path = (_ROOT / relative_path).resolve()
    if not path.exists():
        raise FileNotFoundError(path)
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise ImportError(f'cannot load generated module: {path}')
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    _MODULE_CACHE[name] = module
    return module

_REFERENCE = _load_module('fpy_hybrid_reference', 'project_reference.py')
_WRAPPER_PATHS = {'initialize_module_state': 'kernels/initialize_module_state/initialize_module_state_state_wrapper.py', 'advance_module_state': 'kernels/advance_module_state/advance_module_state_state_wrapper.py', 'summarize_module_state': 'kernels/summarize_module_state/summarize_module_state_state_wrapper.py'}
_WRAPPERS = {
    name: _load_module(f'fpy_hybrid_wrapper_{name}', path)
    for name, path in _WRAPPER_PATHS.items()
}

def _backend_for(procedure: str) -> BackendName:
    default, overrides = _BACKEND_CONTEXT.get()
    return overrides.get(procedure, default)

def available_kernels() -> tuple[str, ...]:
    return EXTRACTED_PROCEDURES

def call_kernel(procedure: str, *args, backend: BackendName | None = None, **kwargs):
    try:
        wrapper = _WRAPPERS[procedure]
    except KeyError as exc:
        raise ValueError(f'procedure is not an extracted kernel: {procedure}') from exc
    selected = backend or _backend_for(procedure)
    return getattr(wrapper, procedure)(*args, backend=selected, **kwargs)

ModuleModuleStateAnalysisModState = _REFERENCE.ModuleModuleStateAnalysisModState

def create_module_module_state_analysis_mod() -> ModuleModuleStateAnalysisModState:
    return ModuleModuleStateAnalysisModState(active_count=0, pressure=np.zeros((16,), dtype=np.float64), film=np.zeros((16,), dtype=np.float64), relaxation_factor=0.0)

def _dispatch_initialize_module_state(state_module_module_state_analysis_mod, n, eccentricity):
    return call_kernel('initialize_module_state', state_module_module_state_analysis_mod, n, eccentricity)

_REFERENCE.initialize_module_state = _dispatch_initialize_module_state
def _dispatch_advance_module_state(state_module_module_state_analysis_mod):
    return call_kernel('advance_module_state', state_module_module_state_analysis_mod)

_REFERENCE.advance_module_state = _dispatch_advance_module_state
def _dispatch_summarize_module_state(state_module_module_state_analysis_mod):
    return call_kernel('summarize_module_state', state_module_module_state_analysis_mod)

_REFERENCE.summarize_module_state = _dispatch_summarize_module_state

def run_module_state(state_module_module_state_analysis_mod, n, eccentricity, *, backend: BackendName = DEFAULT_BACKEND, backend_overrides: Mapping[str, BackendName] | None = None):
    overrides = dict(backend_overrides or {})
    unknown = sorted(set(overrides) - set(EXTRACTED_PROCEDURES))
    if unknown:
        raise ValueError(f'backend override refers to non-kernel procedures: {unknown}')
    token = _BACKEND_CONTEXT.set((backend, overrides))
    try:
        return _REFERENCE.run_module_state(state_module_module_state_analysis_mod, n, eccentricity)
    finally:
        _BACKEND_CONTEXT.reset(token)
