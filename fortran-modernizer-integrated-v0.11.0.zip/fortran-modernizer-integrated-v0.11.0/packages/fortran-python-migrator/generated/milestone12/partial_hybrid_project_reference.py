"""Generated from Fortran by fpy-migrate. Do not edit by hand."""

from dataclasses import dataclass
import math

import numpy as np
import numpy.typing as npt

FloatArray = npt.NDArray[np.float64]
IntArray = npt.NDArray[np.int64]
BoolArray = npt.NDArray[np.bool_]

@dataclass
class CommonFieldState:
    # Fortran common: field
    pressure: FloatArray
    film: FloatArray
    relaxation_factor: float

def initialize_partial_state(state_common_field: CommonFieldState, n: int, eccentricity: float) -> None:
    # Source: /mnt/data/fortran-python-migrator/samples/migration_projects/partial_hybrid_project/10_initialize.f90:1-18
    pi = (4.0 * math.atan(1.0))
    state_common_field.relaxation_factor = 1.25
    state_common_field.pressure[...] = 0.0
    for i in range(1, (n) + 1):
        theta = (((2.0 * pi) * float((i - 1))) / float(n))
        state_common_field.film[(i) - 1] = (1.0 + (eccentricity * math.cos(theta)))
        state_common_field.pressure[(i) - 1] = (float(i) * state_common_field.film[(i) - 1])
    return None

def summarize_partial_state(state_common_field: CommonFieldState, n: int) -> tuple[float, float]:
    # Source: /mnt/data/fortran-python-migrator/samples/migration_projects/partial_hybrid_project/20_summarize.f90:1-15
    total_pressure = 0.0
    peak_pressure = state_common_field.pressure[(1) - 1]
    for i in range(1, (n) + 1):
        total_pressure = (total_pressure + state_common_field.pressure[(i) - 1])
        if (state_common_field.pressure[(i) - 1] > peak_pressure):
            peak_pressure = state_common_field.pressure[(i) - 1]
    return total_pressure, peak_pressure

def run_partial_hybrid_loop_1_kernel(n: int, bias: float, pressure: FloatArray, film: FloatArray) -> FloatArray:
    # Source: /mnt/data/fortran-python-migrator/samples/migration_projects/partial_hybrid_project/30_run.f90:13-15
    for i in range(1, (n) + 1):
        pressure[(i) - 1] = (pressure[(i) - 1] + (bias * film[(i) - 1]))
    return pressure

def run_partial_hybrid(state_common_field: CommonFieldState, n: int, eccentricity: float) -> tuple[float, float]:
    # Source: /mnt/data/fortran-python-migrator/samples/migration_projects/partial_hybrid_project/30_run.f90:1-17
    initialize_partial_state(state_common_field, n, eccentricity)
    bias = (0.5 * state_common_field.relaxation_factor)
    state_common_field.pressure = run_partial_hybrid_loop_1_kernel(n, bias, state_common_field.pressure, state_common_field.film)
    total_pressure, peak_pressure = summarize_partial_state(state_common_field, n)
    return total_pressure, peak_pressure
