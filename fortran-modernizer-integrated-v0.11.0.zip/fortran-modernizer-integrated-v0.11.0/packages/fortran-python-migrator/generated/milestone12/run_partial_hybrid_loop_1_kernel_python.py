"""Generated from Fortran by fpy-migrate. Do not edit by hand."""

from dataclasses import dataclass
import math

import numpy as np
import numpy.typing as npt

FloatArray = npt.NDArray[np.float64]
IntArray = npt.NDArray[np.int64]
BoolArray = npt.NDArray[np.bool_]

def run_partial_hybrid_loop_1_kernel(n: int, bias: float, pressure: FloatArray, film: FloatArray) -> FloatArray:
    # Source: /mnt/data/fortran-python-migrator/samples/migration_projects/partial_hybrid_project/30_run.f90:13-15
    for i in range(1, (n) + 1):
        pressure[(i) - 1] = (pressure[(i) - 1] + (bias * film[(i) - 1]))
    return pressure
