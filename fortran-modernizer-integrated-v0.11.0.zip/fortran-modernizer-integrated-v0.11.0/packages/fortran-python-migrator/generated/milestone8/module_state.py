"""Generated from Fortran by fpy-migrate. Do not edit by hand."""

from dataclasses import dataclass
import math

import numpy as np
import numpy.typing as npt

FloatArray = npt.NDArray[np.float64]
IntArray = npt.NDArray[np.int64]
BoolArray = npt.NDArray[np.bool_]

@dataclass
class ModuleModuleStateAnalysisModState:
    # Fortran module: module_state_analysis_mod
    active_count: int
    pressure: FloatArray
    film: FloatArray
    relaxation_factor: float

def advance_module_state(state_module_module_state_analysis_mod: ModuleModuleStateAnalysisModState) -> None:
    # Source: /mnt/data/fortran-python-migrator/samples/migration_units/module_state_analysis.f90:24-32
    for i in range(2, ((state_module_module_state_analysis_mod.active_count - 1)) + 1):
        state_module_module_state_analysis_mod.pressure[(i) - 1] = (state_module_module_state_analysis_mod.pressure[(i) - 1] + ((state_module_module_state_analysis_mod.relaxation_factor * ((0.5 * (state_module_module_state_analysis_mod.pressure[((i - 1)) - 1] + state_module_module_state_analysis_mod.pressure[((i + 1)) - 1])) - state_module_module_state_analysis_mod.pressure[(i) - 1])) / state_module_module_state_analysis_mod.film[(i) - 1]))
    return None

def initialize_module_state(state_module_module_state_analysis_mod: ModuleModuleStateAnalysisModState, n: int, eccentricity: float) -> None:
    # Source: /mnt/data/fortran-python-migrator/samples/migration_units/module_state_analysis.f90:6-22
    state_module_module_state_analysis_mod.active_count = n
    pi = (4.0 * math.atan(1.0))
    state_module_module_state_analysis_mod.relaxation_factor = 1.25
    state_module_module_state_analysis_mod.pressure[...] = 0.0
    for i in range(1, (n) + 1):
        theta = (((2.0 * pi) * float((i - 1))) / float(n))
        state_module_module_state_analysis_mod.film[(i) - 1] = (1.0 + (eccentricity * math.cos(theta)))
        state_module_module_state_analysis_mod.pressure[(i) - 1] = (float(i) * state_module_module_state_analysis_mod.film[(i) - 1])
    return None

def summarize_module_state(state_module_module_state_analysis_mod: ModuleModuleStateAnalysisModState) -> tuple[float, float]:
    # Source: /mnt/data/fortran-python-migrator/samples/migration_units/module_state_analysis.f90:34-45
    total_pressure = 0.0
    minimum_film = state_module_module_state_analysis_mod.film[(1) - 1]
    for i in range(1, (state_module_module_state_analysis_mod.active_count) + 1):
        total_pressure = (total_pressure + state_module_module_state_analysis_mod.pressure[(i) - 1])
        if (state_module_module_state_analysis_mod.film[(i) - 1] < minimum_film):
            minimum_film = state_module_module_state_analysis_mod.film[(i) - 1]
    return total_pressure, minimum_film

def run_module_state(state_module_module_state_analysis_mod: ModuleModuleStateAnalysisModState, n: int, eccentricity: float) -> tuple[float, float]:
    # Source: /mnt/data/fortran-python-migrator/samples/migration_units/module_state_analysis.f90:47-56
    initialize_module_state(state_module_module_state_analysis_mod, n, eccentricity)
    advance_module_state(state_module_module_state_analysis_mod)
    total_pressure, minimum_film = summarize_module_state(state_module_module_state_analysis_mod)
    return total_pressure, minimum_film
