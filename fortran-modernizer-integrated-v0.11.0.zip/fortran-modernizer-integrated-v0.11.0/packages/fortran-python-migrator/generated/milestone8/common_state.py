"""Generated from Fortran by fpy-migrate. Do not edit by hand."""

from dataclasses import dataclass
import math

import numpy as np
import numpy.typing as npt

FloatArray = npt.NDArray[np.float64]
IntArray = npt.NDArray[np.int64]
BoolArray = npt.NDArray[np.bool_]

@dataclass
class CommonFieldState:
    # Fortran common: field
    pressure: FloatArray
    film: FloatArray
    relaxation_factor: float

def advance_common_state(state_common_field: CommonFieldState, n: int) -> None:
    # Source: /mnt/data/fortran-python-migrator/samples/migration_units/common_state_analysis.f90:20-30
    for i in range(2, ((n - 1)) + 1):
        state_common_field.pressure[(i) - 1] = (state_common_field.pressure[(i) - 1] + ((state_common_field.relaxation_factor * ((0.5 * (state_common_field.pressure[((i - 1)) - 1] + state_common_field.pressure[((i + 1)) - 1])) - state_common_field.pressure[(i) - 1])) / state_common_field.film[(i) - 1]))
    return None

def initialize_common_state(state_common_field: CommonFieldState, n: int, eccentricity: float) -> None:
    # Source: /mnt/data/fortran-python-migrator/samples/migration_units/common_state_analysis.f90:1-18
    pi = (4.0 * math.atan(1.0))
    state_common_field.relaxation_factor = 1.25
    state_common_field.pressure[...] = 0.0
    for i in range(1, (n) + 1):
        theta = (((2.0 * pi) * float((i - 1))) / float(n))
        state_common_field.film[(i) - 1] = (1.0 + (eccentricity * math.cos(theta)))
        state_common_field.pressure[(i) - 1] = (float(i) * state_common_field.film[(i) - 1])
    return None

def summarize_common_state(state_common_field: CommonFieldState, n: int) -> tuple[float, float]:
    # Source: /mnt/data/fortran-python-migrator/samples/migration_units/common_state_analysis.f90:32-46
    total_pressure = 0.0
    minimum_film = state_common_field.film[(1) - 1]
    for i in range(1, (n) + 1):
        total_pressure = (total_pressure + state_common_field.pressure[(i) - 1])
        if (state_common_field.film[(i) - 1] < minimum_film):
            minimum_film = state_common_field.film[(i) - 1]
    return total_pressure, minimum_film

def run_common_state(state_common_field: CommonFieldState, n: int, eccentricity: float) -> tuple[float, float]:
    # Source: /mnt/data/fortran-python-migrator/samples/migration_units/common_state_analysis.f90:48-59
    initialize_common_state(state_common_field, n, eccentricity)
    advance_common_state(state_common_field, n)
    total_pressure, minimum_film = summarize_common_state(state_common_field, n)
    return total_pressure, minimum_film
