# cython: language_level=3, boundscheck=True, wraparound=True, initializedcheck=True, cdivision=True
"""Generated Cython safe kernel from Fortran by fpy-migrate."""

import math

import cython
import numpy as np

@cython.boundscheck(True)
@cython.wraparound(True)
@cython.initializedcheck(True)
def periodic_neighbors(i: cython.int, ntheta: cython.int):
    # Source: /mnt/data/fortran-python-migrator/samples/migration_units/sor_sweep.f90:7-21
    iw: cython.int
    ie: cython.int
    if (i > 1):
        iw = (i - 1)
    else:
        iw = ntheta
    if (i < ntheta):
        ie = (i + 1)
    else:
        ie = 1
    return iw, ie

@cython.boundscheck(True)
@cython.wraparound(True)
@cython.initializedcheck(True)
def sor_sweep(ntheta: cython.int, nz: cython.int, film: cython.double[:], pressure: cython.double[:, :], dtheta: cython.double, dz: cython.double, axial_scale: cython.double, relaxation_factor: cython.double):
    # Source: /mnt/data/fortran-python-migrator/samples/migration_units/sor_sweep.f90:23-58
    update_residual: cython.double
    i: cython.int
    j: cython.int
    iw: cython.int
    ie: cython.int
    ki: cython.double
    ae: cython.double
    aw: cython.double
    an: cython.double
    asouth: cython.double
    ap: cython.double
    rhs: cython.double
    old_value: cython.double
    candidate: cython.double
    updated: cython.double
    difference: cython.double
    update_residual = 0.0
    for i in range(1, (ntheta) + 1):
        iw, ie = periodic_neighbors(i, ntheta)
        ki = (film[(i) - 1] ** 3)
        ae = ((0.5 * (ki + (film[(ie) - 1] ** 3))) / (dtheta * dtheta))
        aw = ((0.5 * (ki + (film[(iw) - 1] ** 3))) / (dtheta * dtheta))
        an = ((axial_scale * ki) / (dz * dz))
        asouth = an
        ap = (((ae + aw) + an) + asouth)
        rhs = ((3.0 * (film[(ie) - 1] - film[(iw) - 1])) / dtheta)
        for j in range(2, ((nz - 1)) + 1):
            old_value = pressure[(i) - 1, (j) - 1]
            candidate = ((((((ae * pressure[(ie) - 1, (j) - 1]) + (aw * pressure[(iw) - 1, (j) - 1])) + (an * pressure[(i) - 1, ((j + 1)) - 1])) + (asouth * pressure[(i) - 1, ((j - 1)) - 1])) - rhs) / ap)
            if ((candidate < 0.0) and (ap > 0.0)):
                candidate = 0.0
            updated = (old_value + (relaxation_factor * (candidate - old_value)))
            if (updated < 0.0):
                updated = 0.0
            pressure[(i) - 1, (j) - 1] = updated
            difference = abs((updated - old_value))
            if (difference > update_residual):
                update_residual = difference
    return pressure, update_residual
