"""Generated from Fortran by fpy-migrate. Do not edit by hand."""

import math

import numpy as np
import numpy.typing as npt

FloatArray = npt.NDArray[np.float64]
IntArray = npt.NDArray[np.int64]
BoolArray = npt.NDArray[np.bool_]

def compute_film(ntheta: int, eccentricity: float) -> FloatArray:
    # Source: /mnt/data/fortran-python-migrator/samples/migration_units/pressure_solver.f90:7-20
    film = np.empty((ntheta,), dtype=np.float64)
    pi = (4.0 * math.atan(1.0))
    dtheta = ((2.0 * pi) / float(ntheta))
    for i in range(1, (ntheta) + 1):
        theta = (float((i - 1)) * dtheta)
        film[(i) - 1] = (1.0 + (eccentricity * math.cos(theta)))
    return film

def periodic_neighbors(i: int, ntheta: int) -> tuple[int, int]:
    # Source: /mnt/data/fortran-python-migrator/samples/migration_units/pressure_solver.f90:22-36
    if (i > 1):
        iw = (i - 1)
    else:
        iw = ntheta
    if (i < ntheta):
        ie = (i + 1)
    else:
        ie = 1
    return iw, ie

def sor_sweep(ntheta: int, nz: int, film: FloatArray, pressure: FloatArray, dtheta: float, dz: float, axial_scale: float, relaxation_factor: float) -> tuple[FloatArray, float]:
    # Source: /mnt/data/fortran-python-migrator/samples/migration_units/pressure_solver.f90:38-73
    update_residual = 0.0
    for i in range(1, (ntheta) + 1):
        iw, ie = periodic_neighbors(i, ntheta)
        ki = (film[(i) - 1] ** 3)
        ae = ((0.5 * (ki + (film[(ie) - 1] ** 3))) / (dtheta * dtheta))
        aw = ((0.5 * (ki + (film[(iw) - 1] ** 3))) / (dtheta * dtheta))
        an = ((axial_scale * ki) / (dz * dz))
        asouth = an
        ap = (((ae + aw) + an) + asouth)
        rhs = ((3.0 * (film[(ie) - 1] - film[(iw) - 1])) / dtheta)
        for j in range(2, ((nz - 1)) + 1):
            old_value = pressure[(i) - 1, (j) - 1]
            candidate = ((((((ae * pressure[(ie) - 1, (j) - 1]) + (aw * pressure[(iw) - 1, (j) - 1])) + (an * pressure[(i) - 1, ((j + 1)) - 1])) + (asouth * pressure[(i) - 1, ((j - 1)) - 1])) - rhs) / ap)
            if ((candidate < 0.0) and (ap > 0.0)):
                candidate = 0.0
            updated = (old_value + (relaxation_factor * (candidate - old_value)))
            if (updated < 0.0):
                updated = 0.0
            pressure[(i) - 1, (j) - 1] = updated
            difference = abs((updated - old_value))
            if (difference > update_residual):
                update_residual = difference
    return pressure, update_residual

def solve_pressure(ntheta: int, nz: int, eccentricity: float, relaxation_factor: float, tolerance: float, max_iterations: int, axial_scale: float) -> tuple[FloatArray, FloatArray, int, float, bool]:
    # Source: /mnt/data/fortran-python-migrator/samples/migration_units/pressure_solver.f90:75-105
    pressure = np.empty((ntheta, nz), dtype=np.float64)
    film = np.empty((ntheta,), dtype=np.float64)
    pi = (4.0 * math.atan(1.0))
    dtheta = ((2.0 * pi) / float(ntheta))
    dz = (1.0 / float((nz - 1)))
    pressure[...] = 0.0
    film = compute_film(ntheta, eccentricity)
    iterations = 0
    update_residual = 0.0
    converged = False
    for iteration in range(1, (max_iterations) + 1):
        pressure, update_residual = sor_sweep(ntheta, nz, film, pressure, dtheta, dz, axial_scale, relaxation_factor)
        iterations = iteration
        if (update_residual <= tolerance):
            converged = True
            break
    return pressure, film, iterations, update_residual, converged
