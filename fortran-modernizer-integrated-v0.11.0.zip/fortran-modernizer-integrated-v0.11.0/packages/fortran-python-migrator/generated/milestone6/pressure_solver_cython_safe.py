# cython: language_level=3, boundscheck=True, wraparound=True, initializedcheck=True, cdivision=True
"""Generated Cython safe kernel from Fortran by fpy-migrate."""

import math

import cython
import numpy as np

@cython.boundscheck(True)
@cython.wraparound(True)
@cython.initializedcheck(True)
@cython.cdivision(True)
def compute_film(ntheta: cython.int, eccentricity: cython.double):
    # Source: /mnt/data/fortran-python-migrator/samples/migration_units/pressure_solver.f90:7-20
    film: cython.double[:]
    i: cython.int
    pi: cython.double
    dtheta: cython.double
    theta: cython.double
    film = np.empty((ntheta,), dtype=np.float64)
    pi = (4.0 * math.atan(1.0))
    dtheta = ((2.0 * pi) / float(ntheta))
    for i in range(1, (ntheta) + 1):
        theta = (float((i - 1)) * dtheta)
        film[(i) - 1] = (1.0 + (eccentricity * math.cos(theta)))
    return film

@cython.boundscheck(True)
@cython.wraparound(True)
@cython.initializedcheck(True)
@cython.cdivision(True)
def periodic_neighbors(i: cython.int, ntheta: cython.int):
    # Source: /mnt/data/fortran-python-migrator/samples/migration_units/pressure_solver.f90:22-36
    iw: cython.int
    ie: cython.int
    if (i > 1):
        iw = (i - 1)
    else:
        iw = ntheta
    if (i < ntheta):
        ie = (i + 1)
    else:
        ie = 1
    return iw, ie

@cython.boundscheck(True)
@cython.wraparound(True)
@cython.initializedcheck(True)
@cython.cdivision(True)
def sor_sweep(ntheta: cython.int, nz: cython.int, film: cython.double[:], pressure: cython.double[:, :], dtheta: cython.double, dz: cython.double, axial_scale: cython.double, relaxation_factor: cython.double):
    # Source: /mnt/data/fortran-python-migrator/samples/migration_units/pressure_solver.f90:38-73
    update_residual: cython.double
    i: cython.int
    j: cython.int
    iw: cython.int
    ie: cython.int
    ki: cython.double
    ae: cython.double
    aw: cython.double
    an: cython.double
    asouth: cython.double
    ap: cython.double
    rhs: cython.double
    old_value: cython.double
    candidate: cython.double
    updated: cython.double
    difference: cython.double
    update_residual = 0.0
    for i in range(1, (ntheta) + 1):
        iw, ie = periodic_neighbors(i, ntheta)
        ki = (film[(i) - 1] ** 3)
        ae = ((0.5 * (ki + (film[(ie) - 1] ** 3))) / (dtheta * dtheta))
        aw = ((0.5 * (ki + (film[(iw) - 1] ** 3))) / (dtheta * dtheta))
        an = ((axial_scale * ki) / (dz * dz))
        asouth = an
        ap = (((ae + aw) + an) + asouth)
        rhs = ((3.0 * (film[(ie) - 1] - film[(iw) - 1])) / dtheta)
        for j in range(2, ((nz - 1)) + 1):
            old_value = pressure[(i) - 1, (j) - 1]
            candidate = ((((((ae * pressure[(ie) - 1, (j) - 1]) + (aw * pressure[(iw) - 1, (j) - 1])) + (an * pressure[(i) - 1, ((j + 1)) - 1])) + (asouth * pressure[(i) - 1, ((j - 1)) - 1])) - rhs) / ap)
            if ((candidate < 0.0) and (ap > 0.0)):
                candidate = 0.0
            updated = (old_value + (relaxation_factor * (candidate - old_value)))
            if (updated < 0.0):
                updated = 0.0
            pressure[(i) - 1, (j) - 1] = updated
            difference = abs((updated - old_value))
            if (difference > update_residual):
                update_residual = difference
    return pressure, update_residual

@cython.boundscheck(True)
@cython.wraparound(True)
@cython.initializedcheck(True)
@cython.cdivision(True)
def solve_pressure(ntheta: cython.int, nz: cython.int, eccentricity: cython.double, relaxation_factor: cython.double, tolerance: cython.double, max_iterations: cython.int, axial_scale: cython.double):
    # Source: /mnt/data/fortran-python-migrator/samples/migration_units/pressure_solver.f90:75-105
    pressure: cython.double[:, :]
    film: cython.double[:]
    iterations: cython.int
    update_residual: cython.double
    converged: cython.bint
    iteration: cython.int
    pi: cython.double
    dtheta: cython.double
    dz: cython.double
    pressure = np.empty((ntheta, nz), dtype=np.float64, order='F')
    film = np.empty((ntheta,), dtype=np.float64)
    pi = (4.0 * math.atan(1.0))
    dtheta = ((2.0 * pi) / float(ntheta))
    dz = (1.0 / float((nz - 1)))
    pressure[...] = 0.0
    film = compute_film(ntheta, eccentricity)
    iterations = 0
    update_residual = 0.0
    converged = False
    for iteration in range(1, (max_iterations) + 1):
        pressure, update_residual = sor_sweep(ntheta, nz, film, pressure, dtheta, dz, axial_scale, relaxation_factor)
        iterations = iteration
        if (update_residual <= tolerance):
            converged = True
            break
    return pressure, film, iterations, update_residual, converged
