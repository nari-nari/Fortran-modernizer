subroutine program_journal_bearing_legacy_numeric(iterations, residual, load, pmax, hmin, friction)
  implicit none
  integer, parameter :: ntheta = 36
  integer, parameter :: nz = 17
  integer, intent(out) :: iterations
  real(8), intent(out) :: residual
  real(8), intent(out) :: load
  real(8), intent(out) :: pmax
  real(8), intent(out) :: hmin
  real(8), intent(out) :: friction
  real(8) :: p(ntheta, nz)
  real(8) :: h(ntheta)
  real(8) :: theta(ntheta)
  common /field/ p, h, theta

  call init_geometry
  call solve_reynolds(iterations, residual)
  call compute_metrics(load, pmax, hmin, friction)
end subroutine program_journal_bearing_legacy_numeric
