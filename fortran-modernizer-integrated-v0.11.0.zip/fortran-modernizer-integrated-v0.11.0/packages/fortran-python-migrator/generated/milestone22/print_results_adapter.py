from __future__ import annotations


def print_results(
    iterations: int,
    residual: float,
    load: float,
    pmax: float,
    hmin: float,
    friction: float,
) -> None:
    print(f"iterations={iterations}")
    print(f"residual={residual:.16E}")
    print(f"load={load:.16E}")
    print(f"max_pressure={pmax:.16E}")
    print(f"min_film={hmin:.16E}")
    print(f"friction={friction:.16E}")
