"""Generated from Fortran by fpy-migrate. Do not edit by hand."""

import math

import numpy as np
import numpy.typing as npt

FloatArray = npt.NDArray[np.float64]
IntArray = npt.NDArray[np.int64]
BoolArray = npt.NDArray[np.bool_]

def periodic_neighbors(i: int, ntheta: int) -> tuple[int, int]:
    # Source: /mnt/data/fortran-python-migrator/samples/migration_units/sor_sweep.f90:7-21
    if (i > 1):
        iw = (i - 1)
    else:
        iw = ntheta
    if (i < ntheta):
        ie = (i + 1)
    else:
        ie = 1
    return iw, ie

def sor_sweep(ntheta: int, nz: int, film: FloatArray, pressure: FloatArray, dtheta: float, dz: float, axial_scale: float, relaxation_factor: float) -> tuple[FloatArray, float]:
    # Source: /mnt/data/fortran-python-migrator/samples/migration_units/sor_sweep.f90:23-58
    update_residual = 0.0
    for i in range(1, (ntheta) + 1):
        iw, ie = periodic_neighbors(i, ntheta)
        ki = (film[(i) - 1] ** 3)
        ae = ((0.5 * (ki + (film[(ie) - 1] ** 3))) / (dtheta * dtheta))
        aw = ((0.5 * (ki + (film[(iw) - 1] ** 3))) / (dtheta * dtheta))
        an = ((axial_scale * ki) / (dz * dz))
        asouth = an
        ap = (((ae + aw) + an) + asouth)
        rhs = ((3.0 * (film[(ie) - 1] - film[(iw) - 1])) / dtheta)
        for j in range(2, ((nz - 1)) + 1):
            old_value = pressure[(i) - 1, (j) - 1]
            candidate = ((((((ae * pressure[(ie) - 1, (j) - 1]) + (aw * pressure[(iw) - 1, (j) - 1])) + (an * pressure[(i) - 1, ((j + 1)) - 1])) + (asouth * pressure[(i) - 1, ((j - 1)) - 1])) - rhs) / ap)
            if ((candidate < 0.0) and (ap > 0.0)):
                candidate = 0.0
            updated = (old_value + (relaxation_factor * (candidate - old_value)))
            if (updated < 0.0):
                updated = 0.0
            pressure[(i) - 1, (j) - 1] = updated
            difference = abs((updated - old_value))
            if (difference > update_residual):
                update_residual = difference
    return pressure, update_residual
