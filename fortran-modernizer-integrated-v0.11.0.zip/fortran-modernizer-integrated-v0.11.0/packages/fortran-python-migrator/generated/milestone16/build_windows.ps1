$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
if (-not (Test-Path "$Root\.venv")) {
    if ($env:PYTHON_BIN) {
        & $env:PYTHON_BIN -m venv "$Root\.venv"
    } else {
        & py -3 -m venv "$Root\.venv"
    }
}
$Py = "$Root\.venv\Scripts\python.exe"
$Pip = "$Root\.venv\Scripts\pip.exe"
$Wheels = Get-ChildItem "$Root\wheelhouse" -Filter *.whl -ErrorAction SilentlyContinue
if ($Wheels) {
    & $Pip install --no-index --find-links "$Root\wheelhouse" -r "$Root\requirements-build.txt"
} else {
    & $Pip install -r "$Root\requirements-build.txt"
}
& $Py "$Root\tools\build_native.py"
& $Py "$Root\tools\generate_notices.py"
& $Py "$Root\launcher.py" --self-check

$Dist = "$Root\dist"
if (Test-Path $Dist) { Remove-Item -Recurse -Force $Dist }
& $Py -m nuitka `
    --mode=standalone `
    --output-dir=$Dist `
    --output-filename=lubrication_hybrid.exe `
    --include-package=numpy `
    "$Root\launcher.py"

$Standalone = "$Dist\launcher.dist"
$Exe = "$Standalone\lubrication_hybrid.exe"
if (-not (Test-Path $Exe)) { throw "Nuitka output was not found: $Exe" }
Copy-Item -Recurse -Force "$Root\payload" "$Standalone\payload"
Copy-Item -Force "$Root\distribution_manifest.json" "$Standalone\distribution_manifest.json"
Copy-Item -Force "$Root\LICENSE" "$Standalone\LICENSE"
if (Test-Path "$Root\THIRD_PARTY_NOTICES.generated.md") {
    Copy-Item -Force "$Root\THIRD_PARTY_NOTICES.generated.md" "$Standalone\THIRD_PARTY_NOTICES.generated.md"
}
if (Test-Path "$Root\third_party_inventory.json") {
    Copy-Item -Force "$Root\third_party_inventory.json" "$Standalone\third_party_inventory.json"
}
if (Test-Path "$Root\licenses") {
    Copy-Item -Recurse -Force "$Root\licenses" "$Standalone\licenses"
}
& $Exe --self-check
Write-Host "Windows standalone build passed: $Exe"
