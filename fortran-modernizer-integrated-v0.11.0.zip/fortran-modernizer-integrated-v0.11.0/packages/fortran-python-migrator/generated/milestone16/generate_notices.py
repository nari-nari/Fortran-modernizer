from __future__ import annotations

from importlib import metadata
from hashlib import sha256
import json
from pathlib import Path
import shutil
from datetime import datetime, timezone


def _root() -> Path:
    return Path(__file__).resolve().parents[1]


def _requirement_name(value: str) -> str:
    for token in ("<", ">", "=", "!", "~", "["):
        value = value.split(token, 1)[0]
    return value.strip()


def _copy_license_files(dist, destination: Path) -> list[str]:
    output: list[str] = []
    package_dir = destination / str(dist.metadata.get("Name", dist.metadata["Name"])).replace(" ", "_")
    package_dir.mkdir(parents=True, exist_ok=True)
    for item in dist.files or []:
        name = Path(str(item)).name.lower()
        if not any(token in name for token in ("license", "licence", "copying", "notice")):
            continue
        source = dist.locate_file(item)
        if not source.is_file() or source.stat().st_size > 5 * 1024 * 1024:
            continue
        target = package_dir / Path(str(item)).name
        if target.exists():
            target = package_dir / f"{sha256(str(item).encode()).hexdigest()[:8]}_{target.name}"
        shutil.copy2(source, target)
        output.append(target.relative_to(_root()).as_posix())
    if not output:
        package_dir.rmdir()
    return output


def _record(name: str, scope: str) -> dict[str, object]:
    try:
        dist = metadata.distribution(name)
    except metadata.PackageNotFoundError:
        return {"name": name, "scope": scope, "installed": False}
    meta = dist.metadata
    raw_license = meta.get("License-Expression") or meta.get("License") or "UNKNOWN"
    raw_license = raw_license.strip() if isinstance(raw_license, str) else "UNKNOWN"
    classifiers = [item for item in meta.get_all("Classifier", []) if item.startswith("License ::")]
    if len(raw_license) > 500:
        license_value = "SEE_COPIED_LICENSE_FILES_OR_PACKAGE_METADATA"
        license_sha256 = sha256(raw_license.encode("utf-8")).hexdigest()
    else:
        license_value = raw_license
        license_sha256 = None
    license_files = _copy_license_files(dist, _root() / "licenses")
    return {
        "name": meta.get("Name", name),
        "version": dist.version,
        "scope": scope,
        "installed": True,
        "license": license_value,
        "license_metadata_sha256": license_sha256,
        "license_classifiers": classifiers,
        "license_files": license_files,
        "homepage": meta.get("Project-URL") or meta.get("Home-page"),
    }


def main() -> int:
    root = _root()
    licenses = root / "licenses"
    if licenses.exists():
        shutil.rmtree(licenses)
    manifest = json.loads((root / "distribution_manifest.json").read_text(encoding="utf-8"))
    runtime = [_requirement_name(item) for item in manifest["runtime_requirements"]]
    build = [_requirement_name(item) for item in manifest["build_requirements"]]
    requested: dict[str, dict[str, object]] = {}
    for scope, names in (("runtime", runtime), ("build", build)):
        for name in names:
            key = name.lower()
            item = requested.setdefault(key, {"name": name, "scopes": []})
            scopes = item["scopes"]
            if scope not in scopes:
                scopes.append(scope)
    records = [
        _record(str(item["name"]), ",".join(item["scopes"]))
        for item in requested.values()
    ]
    payload = {
        "schema_version": "1.0",
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "packages": records,
    }
    (root / "third_party_inventory.json").write_text(
        json.dumps(payload, indent=2) + "\n", encoding="utf-8"
    )
    lines = ["# Third-Party Notices", "", "Generated from installed package metadata.", ""]
    for item in records:
        if not item.get("installed"):
            lines.append(f"- **{item['name']}** ({item['scope']}): not installed at notice-generation time")
            continue
        classifiers = "; ".join(item.get("license_classifiers", []))
        suffix = f"; {classifiers}" if classifiers else ""
        files = ", ".join(item.get("license_files", []))
        file_note = f"; copied files: {files}" if files else ""
        lines.append(
            f"- **{item['name']} {item['version']}** ({item['scope']}): "
            f"{item['license']}{suffix}{file_note}"
        )
    lines.extend([
        "",
        "This inventory is an aid, not a substitute for reviewing the license files",
        "distributed by each dependency and the organization's legal/compliance process.",
        "",
    ])
    (root / "THIRD_PARTY_NOTICES.generated.md").write_text("\n".join(lines), encoding="utf-8")
    print(json.dumps(payload, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
