from __future__ import annotations

import argparse
import importlib.util
import json
import os
from pathlib import Path
import platform
import sys
from types import ModuleType


def _root() -> Path:
    return Path(__file__).resolve().parent


def _load(name: str, relative_path: str) -> ModuleType:
    path = (_root() / relative_path).resolve()
    if not path.is_file():
        raise FileNotFoundError(path)
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise ImportError(f"cannot load module: {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def _manifest() -> dict[str, object]:
    return json.loads((_root() / "distribution_manifest.json").read_text(encoding="utf-8"))


def _load_application() -> tuple[ModuleType, ModuleType, dict[str, object]]:
    manifest = _manifest()
    runtime = _load("fpy_packaged_hybrid_runtime", str(manifest["hybrid_runtime"]))
    adapter = _load("fpy_packaged_app_adapter", str(manifest["app_adapter"]))
    return runtime, adapter, manifest


def _self_check(runtime: ModuleType, adapter: ModuleType, manifest: dict[str, object]) -> dict[str, object]:
    import numpy as np

    result: dict[str, object] = {
        "status": "PASS",
        "app_name": manifest["app_name"],
        "target": manifest["target"],
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "python_bits": 64 if sys.maxsize > 2**32 else 32,
        "numpy": np.__version__,
        "kernels": list(runtime.available_kernels()),
        "eligible_kernels": list(runtime.eligible_kernels()),
    }
    if hasattr(adapter, "self_check"):
        app_result = adapter.self_check(runtime)
        result["application"] = app_result
        if isinstance(app_result, dict) and app_result.get("status") not in {None, "PASS"}:
            result["status"] = "FAIL"
    return result


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--self-check", action="store_true")
    known, remaining = parser.parse_known_args(argv)
    try:
        runtime, adapter, manifest = _load_application()
        if known.self_check:
            result = _self_check(runtime, adapter, manifest)
            print(json.dumps(result, indent=2))
            return 0 if result["status"] == "PASS" else 2
        if not hasattr(adapter, "run"):
            raise AttributeError("app adapter must define run(runtime, argv)")
        return int(adapter.run(runtime, remaining) or 0)
    except Exception as exc:
        print(f"APPLICATION FAILED: {type(exc).__name__}: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
