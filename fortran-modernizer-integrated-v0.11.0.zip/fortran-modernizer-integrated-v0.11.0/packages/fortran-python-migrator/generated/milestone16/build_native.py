from __future__ import annotations

from datetime import datetime, timezone
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import sysconfig
from time import perf_counter


def _root() -> Path:
    return Path(__file__).resolve().parents[1]


def _compile(source: Path, module_name: str, build_root: Path, optimized: bool) -> dict[str, object]:
    build_root.mkdir(parents=True, exist_ok=True)
    for child in (build_root / "lib", build_root / "temp"):
        if child.exists():
            shutil.rmtree(child)
    copied_source = build_root / f"{module_name}.py"
    shutil.copy2(source, copied_source)
    checks = not optimized
    compile_args = "['/O2'] if os.name == 'nt' else ['-O3']" if optimized else "[]"
    setup_path = build_root / "setup_generated_kernel.py"
    setup_path.write_text("\n".join([
        "import os",
        "from Cython.Build import cythonize",
        "from setuptools import Extension, setup",
        "",
        f"extra_compile_args = {compile_args}",
        f"extensions = [Extension({module_name!r}, [{str(copied_source)!r}], extra_compile_args=extra_compile_args)]",
        "setup(",
        "    name='packaged-generated-cython-kernel',",
        "    ext_modules=cythonize(",
        "        extensions,",
        "        compiler_directives={",
        "            'language_level': 3,",
        f"            'boundscheck': {checks!r},",
        f"            'wraparound': {checks!r},",
        f"            'initializedcheck': {checks!r},",
        "            'cdivision': True,",
        "        },",
        "        force=True,",
        "    ),",
        ")",
        "",
    ]), encoding="utf-8")
    build_lib = build_root / "lib"
    start = perf_counter()
    completed = subprocess.run([
        sys.executable,
        str(setup_path),
        "build_ext",
        "--build-lib", str(build_lib),
        "--build-temp", str(build_root / "temp"),
    ], cwd=build_root, capture_output=True, text=True)
    elapsed = perf_counter() - start
    if completed.returncode:
        raise RuntimeError(
            f"Cython build failed for {module_name}:\n{completed.stdout}\n{completed.stderr}"
        )
    suffix = sysconfig.get_config_var("EXT_SUFFIX")
    expected = build_lib / f"{module_name}{suffix}"
    if not expected.is_file():
        matches = list(build_lib.glob(f"{module_name}.*"))
        raise RuntimeError(f"compiled extension was not produced: {matches}")
    return {
        "module_name": module_name,
        "extension": expected.relative_to(_root()).as_posix(),
        "bytes": expected.stat().st_size,
        "build_seconds": elapsed,
    }


def main() -> int:
    root = _root()
    manifest = json.loads((root / "distribution_manifest.json").read_text(encoding="utf-8"))
    records = []
    for item in manifest["native_extensions"]:
        source = root / item["source"]
        build_root = root / item["build_directory"]
        records.append(_compile(
            source,
            item["module_name"],
            build_root,
            optimized=item["backend"] == "cython-optimized",
        ))
    report = {
        "schema_version": "1.0",
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "platform": sys.platform,
        "python": sys.version.split()[0],
        "extensions": records,
    }
    (root / "native_build_report.json").write_text(
        json.dumps(report, indent=2) + "\n", encoding="utf-8"
    )
    print(json.dumps(report, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
