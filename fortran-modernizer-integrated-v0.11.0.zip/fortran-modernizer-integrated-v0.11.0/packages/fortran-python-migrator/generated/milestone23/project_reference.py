"""Generated from Fortran by fpy-migrate. Do not edit by hand."""

from dataclasses import dataclass
import math

import numpy as np
import numpy.typing as npt

FloatArray = npt.NDArray[np.float64]
IntArray = npt.NDArray[np.int64]
BoolArray = npt.NDArray[np.bool_]

@dataclass
class CommonFieldState:
    # Fortran common: field
    p: FloatArray
    h: FloatArray
    theta: FloatArray

def init_geometry(state_common_field: CommonFieldState) -> None:
    # Source: /tmp/m23_worker_file_final/generated_application/source_project/journal_bearing_normalized.f90:15-29
    ntheta = 36
    nz = 17
    pi = math.acos((-1.0))
    ecc = 0.6
    for i in range(1, (ntheta) + 1):
        state_common_field.theta[(i) - 1] = (((2.0 * pi) * float((i - 1))) / float(ntheta))
        state_common_field.h[(i) - 1] = (1.0 + (ecc * math.cos(state_common_field.theta[(i) - 1])))
    return None

def solve_reynolds(state_common_field: CommonFieldState) -> tuple[int, float]:
    # Source: /tmp/m23_worker_file_final/generated_application/source_project/journal_bearing_normalized.f90:31-76
    ntheta = 36
    nz = 17
    maxit = 25000
    omega = 1.55
    toler = 1e-10
    aspect = 0.5
    pi = math.acos((-1.0))
    dtheta = ((2.0 * pi) / float(ntheta))
    dz = (1.0 / float((nz - 1)))
    for j in range(1, (nz) + 1):
        for i in range(1, (ntheta) + 1):
            state_common_field.p[(i) - 1, (j) - 1] = 0.0
    residual = np.finfo(np.float64).max
    for iterations in range(1, (maxit) + 1):
        residual = 0.0
        for j in range(2, ((nz - 1)) + 1):
            for i in range(1, (ntheta) + 1):
                ip = (i + 1)
                if (ip > ntheta):
                    ip = 1
                im = (i - 1)
                if (im < 1):
                    im = ntheta
                hplus = (0.5 * (state_common_field.h[(i) - 1] + state_common_field.h[(ip) - 1]))
                hminus = (0.5 * (state_common_field.h[(i) - 1] + state_common_field.h[(im) - 1]))
                ae = ((hplus ** 3) / (dtheta ** 2))
                aw = ((hminus ** 3) / (dtheta ** 2))
                az = (((aspect ** 2) * (state_common_field.h[(i) - 1] ** 3)) / (dz ** 2))
                ap = ((ae + aw) + (2.0 * az))
                rhs = (-((6.0 * 0.6) * math.sin(state_common_field.theta[(i) - 1])))
                pstar = (((((ae * state_common_field.p[(ip) - 1, (j) - 1]) + (aw * state_common_field.p[(im) - 1, (j) - 1])) + (az * (state_common_field.p[(i) - 1, ((j + 1)) - 1] + state_common_field.p[(i) - 1, ((j - 1)) - 1]))) - rhs) / ap)
                updated = max(0.0, (state_common_field.p[(i) - 1, (j) - 1] + (omega * (pstar - state_common_field.p[(i) - 1, (j) - 1]))))
                change = abs((updated - state_common_field.p[(i) - 1, (j) - 1]))
                residual = max(residual, change)
                state_common_field.p[(i) - 1, (j) - 1] = updated
        if (residual < toler):
            break
    return iterations, residual

def compute_metrics(state_common_field: CommonFieldState) -> tuple[float, float, float, float]:
    # Source: /tmp/m23_worker_file_final/generated_application/source_project/journal_bearing_normalized.f90:78-111
    ntheta = 36
    nz = 17
    pi = math.acos((-1.0))
    dtheta = ((2.0 * pi) / float(ntheta))
    dz = (1.0 / float((nz - 1)))
    loadx = 0.0
    loady = 0.0
    for j in range(2, ((nz - 1)) + 1):
        for i in range(1, (ntheta) + 1):
            loadx = (loadx + (((state_common_field.p[(i) - 1, (j) - 1] * math.cos(state_common_field.theta[(i) - 1])) * dtheta) * dz))
            loady = (loady + (((state_common_field.p[(i) - 1, (j) - 1] * math.sin(state_common_field.theta[(i) - 1])) * dtheta) * dz))
    load = math.sqrt(((loadx ** 2) + (loady ** 2)))
    pmax = 0.0
    for j in range(1, (nz) + 1):
        for i in range(1, (ntheta) + 1):
            pmax = max(pmax, state_common_field.p[(i) - 1, (j) - 1])
    hmin = state_common_field.h[(1) - 1]
    friction = 0.0
    for i in range(1, (ntheta) + 1):
        hmin = min(hmin, state_common_field.h[(i) - 1])
        friction = (friction + (dtheta / state_common_field.h[(i) - 1]))
    return load, pmax, hmin, friction

def program_journal_bearing_legacy_numeric(state_common_field: CommonFieldState) -> tuple[int, float, float, float, float, float]:
    # Source: /tmp/m23_worker_file_final/generated_application/source_project/generated_main_numeric_wrapper.f90:1-19
    ntheta = 36
    nz = 17
    init_geometry(state_common_field)
    iterations, residual = solve_reynolds(state_common_field)
    load, pmax, hmin, friction = compute_metrics(state_common_field)
    return iterations, residual, load, pmax, hmin, friction
