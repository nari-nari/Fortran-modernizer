"""Generated Python orchestration for a Fortran main program."""

from __future__ import annotations

import argparse
from dataclasses import asdict, dataclass
import importlib.util
import json
import os
from pathlib import Path
import numpy as np
import sys
from typing import Mapping

_ROOT = Path(__file__).resolve().parent

def _load(name: str, relative_path: str):
    path = (_ROOT / relative_path).resolve()
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise ImportError(path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module

_RUNTIME = _load('fpy_orchestration_runtime', 'hybrid/hybrid_project.py')
_ADAPTER_PRINT_RESULTS = _load('fpy_adapter_print_results', 'adapters/print_results.py')

@dataclass(frozen=True)
class AnalysisResult:
    iterations: int
    residual: float
    load: float
    pmax: float
    hmin: float
    friction: float

def run_with_state(
    *,
    backend: str = 'python',
    backend_overrides: Mapping[str, str] | None = None,
    run_adapters: bool = True,
) -> tuple[AnalysisResult, dict[str, object]]:
    state_common_field = _RUNTIME.CommonFieldState(p=np.zeros((36, 17), dtype=np.float64), h=np.zeros((36,), dtype=np.float64), theta=np.zeros((36,), dtype=np.float64))
    iterations, residual, load, pmax, hmin, friction = _RUNTIME.program_journal_bearing_legacy_numeric(state_common_field, backend=backend, backend_overrides=backend_overrides)
    result = AnalysisResult(iterations=iterations, residual=residual, load=load, pmax=pmax, hmin=hmin, friction=friction)
    if run_adapters:
        _ADAPTER_PRINT_RESULTS.print_results(result.iterations, result.residual, result.load, result.pmax, result.hmin, result.friction)
    states = {
        'common_field': state_common_field,
    }
    return result, states

def main(
    *,
    backend: str = 'python',
    backend_overrides: Mapping[str, str] | None = None,
    run_adapters: bool = True,
) -> AnalysisResult:
    result, _ = run_with_state(
        backend=backend,
        backend_overrides=backend_overrides,
        run_adapters=run_adapters,
    )
    return result

def _write_state_snapshot(path: str | Path, states: Mapping[str, object]) -> None:
    payload: dict[str, np.ndarray] = {}
    for group_name, state in states.items():
        for field_name, value in vars(state).items():
            payload[f'{group_name}__{field_name}'] = np.asarray(value)
    np.savez(Path(path), **payload)

def _cli() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument('--backend', choices=['python', 'cython-safe', 'cython-optimized', 'fortran'], default='python')
    parser.add_argument('--json', action='store_true')
    parser.add_argument('--no-adapters', action='store_true')
    parser.add_argument('--state-output')
    parser.add_argument('--result-output')
    args = parser.parse_args()
    result, states = run_with_state(backend=args.backend, run_adapters=not args.no_adapters)
    if args.state_output:
        _write_state_snapshot(args.state_output, states)
    result_payload = asdict(result)
    if args.result_output:
        Path(args.result_output).write_text(json.dumps(result_payload, indent=2) + '\n', encoding='utf-8')
    if args.json:
        print(json.dumps(result_payload, indent=2))
    return 0

if __name__ == '__main__':
    _exit_code = _cli()
    if os.environ.get('FPY_FORCE_PROCESS_EXIT') == '1':
        sys.stdout.flush()
        sys.stderr.flush()
        os._exit(_exit_code)
    raise SystemExit(_exit_code)
