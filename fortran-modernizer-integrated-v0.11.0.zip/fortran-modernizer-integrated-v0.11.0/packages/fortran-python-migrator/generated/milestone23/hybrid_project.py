"""Generated project-level Python/Cython/Fortran hybrid runtime."""

from contextvars import ContextVar
import importlib.machinery
import importlib.util
from pathlib import Path
import sys
from types import ModuleType
from typing import Literal, Mapping

import numpy as np

BackendName = Literal['python', 'cython-safe', 'cython-optimized', 'fortran']
DEFAULT_BACKEND: BackendName = 'python'
ELIGIBLE_PROCEDURES = ('init_geometry', 'solve_reynolds', 'compute_metrics')
EXTRACTED_PROCEDURES = ('init_geometry', 'solve_reynolds', 'compute_metrics')
FULL_EXTRACTED_PROCEDURES = ('init_geometry', 'solve_reynolds', 'compute_metrics')
PARTIAL_EXTRACTED_PROCEDURES = ()
PYTHON_ONLY_PROCEDURES = ('program_journal_bearing_legacy_numeric',)
_ROOT = Path(__file__).resolve().parent
_MODULE_CACHE: dict[str, ModuleType] = {}
_BACKEND_CONTEXT: ContextVar[tuple[BackendName, dict[str, BackendName]]] = ContextVar(
    'fpy_hybrid_backend', default=(DEFAULT_BACKEND, {})
)

def _resolve_module_path(name: str, relative_path: str) -> Path:
    path = (_ROOT / relative_path).resolve()
    if path.exists():
        return path
    candidates: list[Path] = []
    for suffix in importlib.machinery.EXTENSION_SUFFIXES:
        candidates.extend(_ROOT.rglob(f'{name}{suffix}'))
    candidates.extend(_ROOT.rglob(f'{name}.py'))
    files = sorted({item.resolve() for item in candidates if item.is_file()}, key=lambda item: (len(item.parts), str(item)))
    if not files:
        raise FileNotFoundError(path)
    return files[0]

def _load_module(name: str, relative_path: str) -> ModuleType:
    if name in _MODULE_CACHE:
        return _MODULE_CACHE[name]
    path = _resolve_module_path(name, relative_path)
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise ImportError(f'cannot load generated module: {path}')
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    _MODULE_CACHE[name] = module
    return module

_REFERENCE = _load_module('fpy_hybrid_reference', 'project_reference.py')
_FULL_WRAPPER_PATHS = {'init_geometry': 'kernels/init_geometry/init_geometry_state_wrapper.py', 'solve_reynolds': 'kernels/solve_reynolds/solve_reynolds_state_wrapper.py', 'compute_metrics': 'kernels/compute_metrics/compute_metrics_state_wrapper.py'}
_FULL_WRAPPERS = {
    name: _load_module(f'fpy_hybrid_wrapper_{name}', path)
    for name, path in _FULL_WRAPPER_PATHS.items()
}
_PARTIAL_SPECS = {}
_PARTIAL_BACKENDS = {
    procedure: {
        backend: _load_module(spec['module_names'][backend], path)
        for backend, path in spec['artifacts'].items()
    }
    for procedure, spec in _PARTIAL_SPECS.items()
}

def _backend_for(procedure: str) -> BackendName:
    default, overrides = _BACKEND_CONTEXT.get()
    return overrides.get(procedure, default)

def available_kernels() -> tuple[str, ...]:
    return EXTRACTED_PROCEDURES

def eligible_kernels() -> tuple[str, ...]:
    return ELIGIBLE_PROCEDURES

def call_kernel(procedure: str, *args, backend: BackendName | None = None, **kwargs):
    if procedure not in FULL_EXTRACTED_PROCEDURES:
        raise ValueError('direct call_kernel is limited to full-procedure kernels')
    wrapper = _FULL_WRAPPERS[procedure]
    selected = backend or _backend_for(procedure)
    return getattr(wrapper, procedure)(*args, backend=selected, **kwargs)

CommonFieldState = _REFERENCE.CommonFieldState

def _dispatch_init_geometry(state_common_field):
    return call_kernel('init_geometry', state_common_field)

_REFERENCE.init_geometry = _dispatch_init_geometry
def _dispatch_solve_reynolds(state_common_field):
    return call_kernel('solve_reynolds', state_common_field)

_REFERENCE.solve_reynolds = _dispatch_solve_reynolds
def _dispatch_compute_metrics(state_common_field):
    return call_kernel('compute_metrics', state_common_field)

_REFERENCE.compute_metrics = _dispatch_compute_metrics

def program_journal_bearing_legacy_numeric(state_common_field, *, backend: BackendName = DEFAULT_BACKEND, backend_overrides: Mapping[str, BackendName] | None = None):
    overrides = dict(backend_overrides or {})
    unknown = sorted(set(overrides) - set(EXTRACTED_PROCEDURES))
    if unknown:
        raise ValueError(f'backend override refers to non-kernel procedures: {unknown}')
    token = _BACKEND_CONTEXT.set((backend, overrides))
    try:
        return _REFERENCE.program_journal_bearing_legacy_numeric(state_common_field)
    finally:
        _BACKEND_CONTEXT.reset(token)
