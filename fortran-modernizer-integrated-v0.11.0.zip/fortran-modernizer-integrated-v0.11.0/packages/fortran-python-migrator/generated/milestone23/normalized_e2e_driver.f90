program fpy_e2e_normalized
  implicit none
  integer, parameter :: ntheta = 36
  integer, parameter :: nz = 17
  real(8) :: p(ntheta, nz)
  real(8) :: h(ntheta)
  real(8) :: theta(ntheta)
  real(8) :: residual
  real(8) :: load
  real(8) :: pmax
  real(8) :: hmin
  real(8) :: friction
  integer :: iterations
  integer :: fpy_i, fpy_j

  common /field/ p, h, theta

  call init_geometry
  call solve_reynolds(iterations, residual)
  call compute_metrics(load, pmax, hmin, friction)
  write(*,'(A)') 'FPY_E2E_V1'
  write(*,'(A,I0)') 'SCALAR iterations integer ', iterations
  write(*,'(A,ES26.17E3)') 'SCALAR residual real ', residual
  write(*,'(A,ES26.17E3)') 'SCALAR load real ', load
  write(*,'(A,ES26.17E3)') 'SCALAR pmax real ', pmax
  write(*,'(A,ES26.17E3)') 'SCALAR hmin real ', hmin
  write(*,'(A,ES26.17E3)') 'SCALAR friction real ', friction
  write(*,'(A)') 'ARRAY common_field__p 2 36 17'
  do fpy_j = 1, 17
    do fpy_i = 1, 36
      write(*,'(ES26.17E3)') p(fpy_i,fpy_j)
    end do
  end do
  write(*,'(A)') 'ARRAY common_field__h 1 36'
  do fpy_i = 1, 36
    write(*,'(ES26.17E3)') h(fpy_i)
  end do
  write(*,'(A)') 'ARRAY common_field__theta 1 36'
  do fpy_i = 1, 36
    write(*,'(ES26.17E3)') theta(fpy_i)
  end do
  write(*,'(A)') 'END_FPY_E2E'
end program fpy_e2e_normalized
