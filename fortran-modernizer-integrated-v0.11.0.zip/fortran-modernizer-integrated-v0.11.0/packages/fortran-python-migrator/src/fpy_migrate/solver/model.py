from __future__ import annotations

from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Literal

import numpy as np
import numpy.typing as npt

FloatArray = npt.NDArray[np.float64]
SolverBackendName = Literal["python", "cython-safe", "cython-optimized", "fortran"]


@dataclass(frozen=True)
class PressureSolverCase:
    ntheta: int = 32
    nz: int = 9
    eccentricity: float = 0.60
    relaxation_factor: float = 1.35
    tolerance: float = 1.0e-11
    max_iterations: int = 20_000
    axial_scale: float = 0.20

    def validate(self) -> None:
        if self.ntheta < 4:
            raise ValueError("ntheta must be at least 4")
        if self.nz < 3:
            raise ValueError("nz must be at least 3")
        if not 0.0 <= self.eccentricity < 1.0:
            raise ValueError("eccentricity must satisfy 0 <= value < 1")
        if not 0.0 < self.relaxation_factor < 2.0:
            raise ValueError("relaxation_factor must satisfy 0 < value < 2")
        if self.tolerance <= 0.0:
            raise ValueError("tolerance must be positive")
        if self.max_iterations <= 0:
            raise ValueError("max_iterations must be positive")
        if self.axial_scale <= 0.0:
            raise ValueError("axial_scale must be positive")

    def arguments(self) -> tuple[int, int, float, float, float, int, float]:
        self.validate()
        return (
            self.ntheta,
            self.nz,
            self.eccentricity,
            self.relaxation_factor,
            self.tolerance,
            self.max_iterations,
            self.axial_scale,
        )


@dataclass(frozen=True)
class PressureSolverResult:
    pressure: FloatArray
    film: FloatArray
    iterations: int
    update_residual: float
    converged: bool

    def summary(self) -> dict[str, int | float | bool]:
        return {
            "iterations": self.iterations,
            "update_residual": self.update_residual,
            "converged": self.converged,
            "maximum_pressure": float(np.max(self.pressure)),
            "minimum_film_thickness": float(np.min(self.film)),
            "pressure_sum": float(np.sum(self.pressure, dtype=np.float64)),
        }


@dataclass(frozen=True)
class LubricationAnalysisResult:
    pressure: FloatArray
    film: FloatArray
    iterations: int
    update_residual: float
    converged: bool
    equation_residual: float
    load_x: float
    load_y: float
    load_magnitude: float
    dimensionless_friction: float
    maximum_pressure: float
    minimum_film_thickness: float

    def summary(self) -> dict[str, int | float | bool]:
        return {
            "iterations": self.iterations,
            "update_residual": self.update_residual,
            "converged": self.converged,
            "equation_residual": self.equation_residual,
            "load_x": self.load_x,
            "load_y": self.load_y,
            "load_magnitude": self.load_magnitude,
            "dimensionless_friction": self.dimensionless_friction,
            "maximum_pressure": self.maximum_pressure,
            "minimum_film_thickness": self.minimum_film_thickness,
            "pressure_sum": float(np.sum(self.pressure, dtype=np.float64)),
        }


@dataclass(frozen=True)
class SolverBuildManifest:
    schema_version: str
    source: str
    procedure: str
    artifacts: dict[str, dict[str, str]]

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    def artifact(self, backend: SolverBackendName) -> dict[str, str]:
        try:
            return self.artifacts[backend]
        except KeyError as exc:
            raise ValueError(f"backend is not present in build manifest: {backend}") from exc


@dataclass(frozen=True)
class SolverRunConfiguration:
    backend: SolverBackendName
    manifest: Path
    case: PressureSolverCase
    output_directory: Path
