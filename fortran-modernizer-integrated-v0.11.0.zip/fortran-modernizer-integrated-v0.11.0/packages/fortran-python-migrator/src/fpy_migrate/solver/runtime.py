from __future__ import annotations

import csv
import json
from pathlib import Path
import subprocess
import tempfile
import tomllib
from typing import Any

import numpy as np

from fpy_migrate.backends import load_generated_backend

from .model import (
    PressureSolverCase,
    PressureSolverResult,
    SolverBuildManifest,
    SolverRunConfiguration,
)


def load_solver_manifest(path: str | Path) -> SolverBuildManifest:
    manifest_path = Path(path).resolve()
    data = json.loads(manifest_path.read_text(encoding="utf-8"))
    if data.get("schema_version") != "1.0":
        raise ValueError(f"unsupported solver manifest version: {data.get('schema_version')!r}")
    return SolverBuildManifest(
        schema_version="1.0",
        source=str(data["source"]),
        procedure=str(data["procedure"]),
        artifacts={str(key): dict(value) for key, value in data["artifacts"].items()},
    )


def load_solver_run_configuration(path: str | Path) -> SolverRunConfiguration:
    config_path = Path(path).resolve()
    data = tomllib.loads(config_path.read_text(encoding="utf-8"))
    solver = data.get("solver", {})
    case_data = data.get("case", {})
    output_data = data.get("output", {})
    manifest = _resolve_from(config_path, solver.get("manifest"))
    output_directory = _resolve_from(config_path, output_data.get("directory", "solver_output"))
    case = PressureSolverCase(
        ntheta=int(case_data.get("ntheta", 32)),
        nz=int(case_data.get("nz", 9)),
        eccentricity=float(case_data.get("eccentricity", 0.60)),
        relaxation_factor=float(case_data.get("relaxation_factor", 1.35)),
        tolerance=float(case_data.get("tolerance", 1.0e-11)),
        max_iterations=int(case_data.get("max_iterations", 20_000)),
        axial_scale=float(case_data.get("axial_scale", 0.20)),
    )
    backend = str(solver.get("backend", "cython-optimized"))
    if backend not in {"python", "cython-safe", "cython-optimized", "fortran"}:
        raise ValueError(f"unsupported solver backend: {backend}")
    case.validate()
    return SolverRunConfiguration(
        backend=backend,  # type: ignore[arg-type]
        manifest=manifest,
        case=case,
        output_directory=output_directory,
    )


def run_configured_solver(config: SolverRunConfiguration) -> PressureSolverResult:
    manifest = load_solver_manifest(config.manifest)
    artifact = manifest.artifact(config.backend)
    artifact_path = _manifest_artifact_path(config.manifest, artifact["path"])
    if config.backend == "fortran":
        result = _run_fortran(artifact_path, config.case)
    else:
        backend_kind = "python" if config.backend == "python" else "cython"
        backend = load_generated_backend(
            backend_kind,
            artifact_path,
            module_name=artifact.get("module_name"),
        )
        values = backend.call(manifest.procedure, *config.case.arguments())
        if not isinstance(values, tuple) or len(values) != 5:
            raise RuntimeError(
                f"generated solver returned an unexpected result: {type(values).__name__}"
            )
        result = PressureSolverResult(
            pressure=np.asarray(values[0], dtype=np.float64),
            film=np.asarray(values[1], dtype=np.float64),
            iterations=int(values[2]),
            update_residual=float(values[3]),
            converged=bool(values[4]),
        )
    write_solver_result(result, config.output_directory)
    return result


def write_solver_result(result: PressureSolverResult, output_directory: str | Path) -> Path:
    output = Path(output_directory)
    output.mkdir(parents=True, exist_ok=True)
    (output / "summary.json").write_text(
        json.dumps(result.summary(), indent=2) + "\n", encoding="utf-8"
    )
    with (output / "pressure.csv").open("w", newline="", encoding="utf-8") as stream:
        writer = csv.writer(stream)
        writer.writerow(["i", "j", "pressure"])
        for i in range(result.pressure.shape[0]):
            for j in range(result.pressure.shape[1]):
                writer.writerow([i + 1, j + 1, f"{result.pressure[i, j]:.17e}"])
    with (output / "film.csv").open("w", newline="", encoding="utf-8") as stream:
        writer = csv.writer(stream)
        writer.writerow(["i", "film"])
        for i, value in enumerate(result.film, start=1):
            writer.writerow([i, f"{value:.17e}"])
    return output


def _run_fortran(executable: Path, case: PressureSolverCase) -> PressureSolverResult:
    if not executable.exists():
        raise FileNotFoundError(executable)
    with tempfile.TemporaryDirectory(prefix="fpy-solver-") as temporary:
        output = Path(temporary)
        subprocess.run(
            [str(executable), *(str(value) for value in case.arguments()), str(output)],
            check=True,
            capture_output=True,
            text=True,
        )
        summary = _read_key_values(output / "summary.txt")
        pressure = np.zeros((case.ntheta, case.nz), dtype=np.float64)
        for row in _read_csv_rows(output / "pressure.csv"):
            i, j, value = int(row[0]), int(row[1]), float(row[2])
            pressure[i - 1, j - 1] = value
        film = np.zeros(case.ntheta, dtype=np.float64)
        for row in _read_csv_rows(output / "film.csv"):
            i, value = int(row[0]), float(row[1])
            film[i - 1] = value
    return PressureSolverResult(
        pressure=pressure,
        film=film,
        iterations=int(summary["iterations"]),
        update_residual=float(summary["update_residual"]),
        converged=bool(int(summary["converged"])),
    )


def _read_key_values(path: Path) -> dict[str, str]:
    values: dict[str, str] = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        if "=" not in line:
            continue
        key, value = line.split("=", maxsplit=1)
        values[key.strip()] = value.strip()
    return values


def _read_csv_rows(path: Path) -> list[list[str]]:
    with path.open(newline="", encoding="utf-8") as stream:
        return [row for row in csv.reader(stream) if row]


def _resolve_from(config_path: Path, value: Any) -> Path:
    if not isinstance(value, str) or not value:
        raise ValueError(f"configuration path is missing or invalid: {value!r}")
    path = Path(value)
    if not path.is_absolute():
        path = config_path.parent / path
    return path.resolve()


def _manifest_artifact_path(manifest_path: Path, value: str) -> Path:
    path = Path(value)
    if not path.is_absolute():
        path = manifest_path.resolve().parent / path
    return path.resolve()
