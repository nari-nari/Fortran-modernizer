from __future__ import annotations

import json
from pathlib import Path
import shutil
import subprocess

from fpy_migrate.ir import build_project_ir
from fpy_migrate.kernels import build_cython_extension
from fpy_migrate.translate import generate_cython, generate_python, write_cython, write_python

from .model import SolverBuildManifest


def build_solver_backends(
    source: str | Path,
    *,
    procedure: str,
    build_directory: str | Path,
    fortran_driver: str | Path | None = None,
) -> tuple[SolverBuildManifest, Path]:
    return _build_backend_bundle(
        source,
        procedure=procedure,
        build_directory=build_directory,
        fortran_driver=fortran_driver,
        stem="solver",
    )


def build_analysis_backends(
    source: str | Path,
    *,
    procedure: str = "solve_analysis",
    build_directory: str | Path,
    fortran_driver: str | Path | None = None,
) -> tuple[SolverBuildManifest, Path]:
    return _build_backend_bundle(
        source,
        procedure=procedure,
        build_directory=build_directory,
        fortran_driver=fortran_driver,
        stem="analysis",
    )


def _build_backend_bundle(
    source: str | Path,
    *,
    procedure: str,
    build_directory: str | Path,
    fortran_driver: str | Path | None,
    stem: str,
) -> tuple[SolverBuildManifest, Path]:
    source_path = Path(source).resolve()
    build_root = Path(build_directory).resolve()
    build_root.mkdir(parents=True, exist_ok=True)

    project = build_project_ir(source_path, procedure=procedure)
    python_source = write_python(
        generate_python(project, procedure=procedure),
        build_root / f"generated_{stem}_python.py",
    )
    safe_source = write_cython(
        generate_cython(project, procedure=procedure, safety_mode="safe"),
        build_root / f"generated_{stem}_cython_safe.py",
    )
    optimized_source = write_cython(
        generate_cython(project, procedure=procedure, safety_mode="optimized"),
        build_root / f"generated_{stem}_cython_optimized.py",
    )
    safe_module = f"generated_{stem}_cython_safe"
    optimized_module = f"generated_{stem}_cython_optimized"
    safe_built = build_cython_extension(
        safe_source,
        safe_module,
        build_root / "cython_safe",
        safety_mode="safe",
    )
    optimized_built = build_cython_extension(
        optimized_source,
        optimized_module,
        build_root / "cython_optimized",
        safety_mode="optimized",
    )

    artifacts: dict[str, dict[str, str]] = {
        "python": {"path": _relative_path(python_source, build_root)},
        "cython-safe": {
            "path": _relative_path(safe_built.extension, build_root),
            "module_name": safe_built.module_name,
        },
        "cython-optimized": {
            "path": _relative_path(optimized_built.extension, build_root),
            "module_name": optimized_built.module_name,
        },
    }

    if fortran_driver is not None:
        if shutil.which("gfortran") is None:
            raise RuntimeError("gfortran is required to build the Fortran backend")
        driver_path = Path(fortran_driver).resolve()
        executable = build_root / f"{stem}_fortran"
        subprocess.run(
            [
                "gfortran",
                "-std=f2008",
                "-O3",
                str(source_path),
                str(driver_path),
                "-o",
                str(executable),
            ],
            check=True,
            capture_output=True,
            text=True,
            cwd=build_root,
        )
        artifacts["fortran"] = {"path": _relative_path(executable, build_root)}

    manifest = SolverBuildManifest(
        schema_version="1.0",
        source=str(source_path),
        procedure=procedure.lower(),
        artifacts=artifacts,
    )
    manifest_path = build_root / f"{stem}_manifest.json"
    manifest_path.write_text(json.dumps(manifest.to_dict(), indent=2) + "\n", encoding="utf-8")
    for backend in artifacts:
        _write_run_configuration(build_root, backend, manifest_path.name, stem)
    return manifest, manifest_path

def _write_run_configuration(
    build_root: Path, backend: str, manifest_name: str = "solver_manifest.json", stem: str = "solver"
) -> Path:
    config_prefix = "" if stem == "solver" else f"{stem}_"
    path = build_root / f"run_{config_prefix}{backend}.toml"
    path.write_text(
        "\n".join(
            [
                "[solver]",
                f"backend = {backend!r}",
                f"manifest = {manifest_name!r}",
                "",
                "[case]",
                "ntheta = 32",
                "nz = 9",
                "eccentricity = 0.60",
                "relaxation_factor = 1.35",
                "tolerance = 1.0e-11",
                "max_iterations = 20000",
                "axial_scale = 0.20",
                "",
                "[output]",
                f"directory = 'output_{backend}'" if stem == "solver" else f"directory = 'output_{stem}_{backend}'",
                "",
            ]
        ),
        encoding="utf-8",
    )
    return path


def _relative_path(path: Path, root: Path) -> str:
    return str(path.resolve().relative_to(root.resolve()))
