from __future__ import annotations

import csv
import json
from pathlib import Path
import subprocess
import tempfile

import numpy as np

from fpy_migrate.backends import load_generated_backend

from .model import (
    LubricationAnalysisResult,
    PressureSolverCase,
    SolverRunConfiguration,
)
from .runtime import load_solver_manifest


_RESULT_LENGTH = 12


def run_configured_analysis(config: SolverRunConfiguration) -> LubricationAnalysisResult:
    manifest = load_solver_manifest(config.manifest)
    artifact = manifest.artifact(config.backend)
    artifact_path = _manifest_artifact_path(config.manifest, artifact["path"])
    if config.backend == "fortran":
        result = _run_fortran_analysis(artifact_path, config.case)
    else:
        backend_kind = "python" if config.backend == "python" else "cython"
        backend = load_generated_backend(
            backend_kind,
            artifact_path,
            module_name=artifact.get("module_name"),
        )
        values = backend.call(manifest.procedure, *config.case.arguments())
        if not isinstance(values, tuple) or len(values) != _RESULT_LENGTH:
            raise RuntimeError(
                "generated analysis returned an unexpected result: "
                f"{type(values).__name__}, expected {_RESULT_LENGTH} outputs"
            )
        result = LubricationAnalysisResult(
            pressure=np.asarray(values[0], dtype=np.float64),
            film=np.asarray(values[1], dtype=np.float64),
            iterations=int(values[2]),
            update_residual=float(values[3]),
            converged=bool(values[4]),
            equation_residual=float(values[5]),
            load_x=float(values[6]),
            load_y=float(values[7]),
            load_magnitude=float(values[8]),
            dimensionless_friction=float(values[9]),
            maximum_pressure=float(values[10]),
            minimum_film_thickness=float(values[11]),
        )
    write_analysis_result(result, config.output_directory)
    return result


def write_analysis_result(
    result: LubricationAnalysisResult,
    output_directory: str | Path,
) -> Path:
    output = Path(output_directory)
    output.mkdir(parents=True, exist_ok=True)
    (output / "summary.json").write_text(
        json.dumps(result.summary(), indent=2) + "\n", encoding="utf-8"
    )
    with (output / "pressure.csv").open("w", newline="", encoding="utf-8") as stream:
        writer = csv.writer(stream)
        writer.writerow(["i", "j", "pressure"])
        for i in range(result.pressure.shape[0]):
            for j in range(result.pressure.shape[1]):
                writer.writerow([i + 1, j + 1, f"{result.pressure[i, j]:.17e}"])
    with (output / "film.csv").open("w", newline="", encoding="utf-8") as stream:
        writer = csv.writer(stream)
        writer.writerow(["i", "film"])
        for i, value in enumerate(result.film, start=1):
            writer.writerow([i, f"{value:.17e}"])
    return output


def _run_fortran_analysis(
    executable: Path,
    case: PressureSolverCase,
) -> LubricationAnalysisResult:
    if not executable.exists():
        raise FileNotFoundError(executable)
    with tempfile.TemporaryDirectory(prefix="fpy-analysis-") as temporary:
        output = Path(temporary)
        subprocess.run(
            [str(executable), *(str(value) for value in case.arguments()), str(output)],
            check=True,
            capture_output=True,
            text=True,
        )
        summary = _read_key_values(output / "summary.txt")
        pressure = np.zeros((case.ntheta, case.nz), dtype=np.float64)
        for row in _read_csv_rows(output / "pressure.csv"):
            i, j, value = int(row[0]), int(row[1]), float(row[2])
            pressure[i - 1, j - 1] = value
        film = np.zeros(case.ntheta, dtype=np.float64)
        for row in _read_csv_rows(output / "film.csv"):
            i, value = int(row[0]), float(row[1])
            film[i - 1] = value
    return LubricationAnalysisResult(
        pressure=pressure,
        film=film,
        iterations=int(summary["iterations"]),
        update_residual=float(summary["update_residual"]),
        converged=bool(int(summary["converged"])),
        equation_residual=float(summary["equation_residual"]),
        load_x=float(summary["load_x"]),
        load_y=float(summary["load_y"]),
        load_magnitude=float(summary["load_magnitude"]),
        dimensionless_friction=float(summary["dimensionless_friction"]),
        maximum_pressure=float(summary["maximum_pressure"]),
        minimum_film_thickness=float(summary["minimum_film_thickness"]),
    )


def _read_key_values(path: Path) -> dict[str, str]:
    values: dict[str, str] = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        if "=" not in line:
            continue
        key, value = line.split("=", maxsplit=1)
        values[key.strip()] = value.strip()
    return values


def _read_csv_rows(path: Path) -> list[list[str]]:
    with path.open(newline="", encoding="utf-8") as stream:
        return [row for row in csv.reader(stream) if row]


def _manifest_artifact_path(manifest_path: Path, value: str) -> Path:
    path = Path(value)
    if not path.is_absolute():
        path = manifest_path.resolve().parent / path
    return path.resolve()
