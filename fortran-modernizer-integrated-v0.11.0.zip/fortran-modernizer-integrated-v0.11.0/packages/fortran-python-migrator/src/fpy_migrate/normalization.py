from __future__ import annotations

import shutil
import subprocess
from pathlib import Path


def normalize_with_findent(
    source: str | Path,
    output: str | Path,
    *,
    executable: str | None = None,
) -> Path:
    """Convert fixed-form Fortran to free form using the external findent CLI."""
    source_path = Path(source)
    output_path = Path(output)
    command = executable or shutil.which("findent")
    if not command:
        raise RuntimeError("findent executable was not found on PATH")

    completed = subprocess.run(
        [command, "-ifixed", "-ofree", "-Rr"],
        input=source_path.read_text(encoding="utf-8", errors="replace"),
        text=True,
        capture_output=True,
        check=True,
    )
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(completed.stdout, encoding="utf-8")
    return output_path
