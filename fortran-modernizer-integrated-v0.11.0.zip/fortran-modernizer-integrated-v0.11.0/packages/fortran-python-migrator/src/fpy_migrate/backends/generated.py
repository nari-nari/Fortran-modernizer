from __future__ import annotations

from dataclasses import dataclass
import importlib.util
from pathlib import Path
from types import ModuleType
from typing import Any, Callable, Literal

import numpy as np


BackendName = Literal["python", "cython"]


@dataclass(frozen=True)
class GeneratedKernelBackend:
    name: BackendName
    module: ModuleType

    def procedure(self, name: str) -> Callable[..., Any]:
        try:
            value = getattr(self.module, name)
        except AttributeError as exc:
            raise ValueError(f"procedure is not available in {self.name} backend: {name}") from exc
        if not callable(value):
            raise TypeError(f"backend attribute is not callable: {name}")
        return value

    def call(self, procedure: str, *args: Any, **kwargs: Any) -> Any:
        result = self.procedure(procedure)(*args, **kwargs)
        return _normalise_result(result)


def load_generated_backend(
    backend: BackendName,
    module_path: str | Path,
    module_name: str | None = None,
) -> GeneratedKernelBackend:
    path = Path(module_path).resolve()
    if not path.exists():
        raise FileNotFoundError(path)
    resolved_name = module_name or f"fpy_generated_{backend}_{abs(hash(path))}"
    spec = importlib.util.spec_from_file_location(resolved_name, path)
    if spec is None or spec.loader is None:
        raise ImportError(f"cannot create import specification for {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return GeneratedKernelBackend(name=backend, module=module)


def _normalise_result(value: Any) -> Any:
    """Present generated Python and Cython outputs through the same API.

    Cython typed-memoryview return values are converted to NumPy views without
    copying. Tuples are normalised recursively; scalar values are unchanged.
    """

    if isinstance(value, tuple):
        return tuple(_normalise_result(item) for item in value)
    if isinstance(value, np.ndarray):
        return value
    if hasattr(value, "shape") and hasattr(value, "strides"):
        return np.asarray(value)
    return value
