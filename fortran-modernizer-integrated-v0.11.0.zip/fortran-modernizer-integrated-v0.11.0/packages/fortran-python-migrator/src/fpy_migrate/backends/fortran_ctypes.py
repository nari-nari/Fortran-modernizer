from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import shutil
import subprocess
import sys

from fpy_migrate.ir.model import ConstantIR, ExpressionIR, ProcedureIR, ProjectIR, SymbolIR
from fpy_migrate.translate.fortran_codegen import generate_fortran_kernel, write_fortran
from fpy_migrate.translate.intrinsics import (
    infer_expression_category,
    normalize_intrinsic,
    python_huge_expression,
    python_intrinsic_target,
)


@dataclass(frozen=True)
class FortranKernelBuild:
    procedure: str
    bind_name: str
    module_name: str
    source: Path
    library: Path
    wrapper: Path


def build_fortran_kernel_backend(
    project: ProjectIR,
    *,
    procedure: str,
    build_directory: str | Path,
    optimization: str = "-O3",
) -> FortranKernelBuild:
    if shutil.which("gfortran") is None:
        raise RuntimeError("gfortran is required to build the Fortran kernel backend")

    root = Path(build_directory).resolve()
    root.mkdir(parents=True, exist_ok=True)
    proc = project.procedure(procedure)
    bind_name = f"fpy_{proc.name}"
    generated = generate_fortran_kernel(project, proc.name, bind_name=bind_name)
    source = write_fortran(generated, root / f"{proc.name}_fortran.f90")
    suffix = ".dll" if sys.platform.startswith("win") else ".dylib" if sys.platform == "darwin" else ".so"
    library = root / f"lib{proc.name}_fortran{suffix}"
    command = ["gfortran", "-std=f2008", "-ffree-line-length-none", optimization, "-shared"]
    if not sys.platform.startswith("win"):
        command.append("-fPIC")
    command.extend([str(source), "-o", str(library)])
    subprocess.run(command, check=True, capture_output=True, text=True, cwd=root)

    module_name = f"{proc.name}_fortran"
    wrapper = root / f"{module_name}.py"
    wrapper.write_text(
        generate_fortran_ctypes_wrapper(
            project,
            procedure=proc.name,
            library_path=library.name,
            bind_name=bind_name,
        ),
        encoding="utf-8",
    )
    return FortranKernelBuild(
        procedure=proc.name,
        bind_name=bind_name,
        module_name=module_name,
        source=source,
        library=library,
        wrapper=wrapper,
    )


def generate_fortran_ctypes_wrapper(
    project: ProjectIR,
    *,
    procedure: str,
    library_path: str,
    bind_name: str,
) -> str:
    proc = project.procedure(procedure)
    symbols = {item.name: item for item in proc.symbols}
    inputs = [name for name in proc.arguments if symbols[name].intent != "out"]
    outputs = [symbols[name] for name in proc.arguments if symbols[name].intent in {"out", "inout"}]

    lines = [
        '"""Generated ctypes adapter for a C-interoperable Fortran kernel."""',
        "",
        "import ctypes",
        "import math",
        "from pathlib import Path",
        "",
        "import numpy as np",
        "",
        "_ROOT = Path(__file__).resolve().parent",
        f"_LIBRARY_NAME = {library_path!r}",
        "_LIBRARY_PATH = (_ROOT / _LIBRARY_NAME).resolve()",
        "if not _LIBRARY_PATH.exists():",
        "    candidates = sorted(_ROOT.rglob(_LIBRARY_NAME))",
        "    if not candidates:",
        "        raise FileNotFoundError(_LIBRARY_PATH)",
        "    _LIBRARY_PATH = candidates[0]",
        "_LIBRARY = ctypes.CDLL(str(_LIBRARY_PATH))",
        f"_FUNCTION = getattr(_LIBRARY, {bind_name!r})",
    ]
    argtypes: list[str] = []
    for name in proc.arguments:
        symbol = symbols[name]
        if symbol.rank:
            argtypes.append("ctypes.c_void_p")
            argtypes.extend("ctypes.c_int" for _ in range(symbol.rank))
        elif symbol.intent == "in":
            argtypes.append(_ctype_name(symbol))
        else:
            argtypes.append(f"ctypes.POINTER({_ctype_name(symbol)})")
    lines.extend([
        f"_FUNCTION.argtypes = [{', '.join(argtypes)}]",
        "_FUNCTION.restype = None",
        "",
        f"def {proc.name}({', '.join(inputs)}):",
    ])
    for constant in proc.constants:
        lines.append(
            f"    {constant.name} = "
            f"{_expr_python(constant.value, proc=proc)}"
        )
    if not proc.arguments:
        lines.append("    _FUNCTION()")
        lines.append("    return None")
        return "\n".join(lines) + "\n"

    prepared: dict[str, str] = {}
    original_names: dict[str, str] = {}
    for name in proc.arguments:
        symbol = symbols[name]
        if symbol.rank:
            variable = f"_array_{name}"
            original = f"_original_{name}"
            original_names[name] = original
            if symbol.intent == "out":
                shape = _shape_python(symbol, proc=proc)
                lines.append(
                    f"    {variable} = np.empty({shape}, dtype={_numpy_dtype(symbol)}, order='C')"
                )
                lines.append(f"    {original} = None")
            else:
                lines.append(f"    {original} = {name}")
                lines.append(
                    f"    {variable} = np.ascontiguousarray({name}, dtype={_numpy_dtype(symbol)})"
                )
                lines.append(
                    f"    if {variable}.ndim != {symbol.rank}: raise ValueError('{name} must have rank {symbol.rank}')"
                )
            prepared[name] = variable
        elif symbol.intent == "in":
            prepared[name] = f"{_ctype_name(symbol)}({name})"
        else:
            variable = f"_scalar_{name}"
            initial = name if symbol.intent == "inout" else _zero_literal(symbol)
            lines.append(f"    {variable} = {_ctype_name(symbol)}({initial})")
            prepared[name] = variable

    call_args: list[str] = []
    for name in proc.arguments:
        symbol = symbols[name]
        variable = prepared[name]
        if symbol.rank:
            call_args.append(f"ctypes.c_void_p({variable}.ctypes.data)")
            call_args.extend(f"ctypes.c_int({variable}.shape[{index}])" for index in range(symbol.rank))
        elif symbol.intent == "in":
            call_args.append(variable)
        else:
            call_args.append(f"ctypes.byref({variable})")
    lines.append(f"    _FUNCTION({', '.join(call_args)})")

    for symbol in outputs:
        if not symbol.rank or symbol.intent != "inout":
            continue
        variable = prepared[symbol.name]
        original = original_names[symbol.name]
        lines.extend([
            f"    if isinstance({original}, np.ndarray) and {original}.shape == {variable}.shape:",
            f"        {original}[...] = {variable}",
        ])

    if not outputs:
        lines.append("    return None")
    else:
        result_names: list[str] = []
        for symbol in outputs:
            if symbol.rank:
                result_names.append(prepared[symbol.name])
            else:
                result_names.append(f"{prepared[symbol.name]}.value")
        if len(result_names) == 1:
            lines.append(f"    return {result_names[0]}")
        else:
            lines.append(f"    return {', '.join(result_names)}")
    lines.append("")
    return "\n".join(lines)


def _ctype_name(symbol: SymbolIR) -> str:
    mapping = {
        "integer": "ctypes.c_int",
        "real": "ctypes.c_double",
        "logical": "ctypes.c_bool",
    }
    try:
        return mapping[symbol.type.category]
    except KeyError as exc:
        raise ValueError(f"unsupported ctypes scalar type: {symbol.type.category}") from exc


def _numpy_dtype(symbol: SymbolIR) -> str:
    mapping = {
        "integer": "np.int32",
        "real": "np.float64",
        "logical": "np.bool_",
    }
    try:
        return mapping[symbol.type.category]
    except KeyError as exc:
        raise ValueError(f"unsupported NumPy array type: {symbol.type.category}") from exc


def _zero_literal(symbol: SymbolIR) -> str:
    return "False" if symbol.type.category == "logical" else "0"


def _shape_python(symbol: SymbolIR, *, proc: ProcedureIR) -> str:
    if any(item is None for item in symbol.shape):
        raise ValueError(
            f"cannot allocate assumed-shape intent(out) array for Fortran backend: {symbol.name}"
        )
    values = [_expr_python(item, proc=proc) for item in symbol.shape]
    if symbol.rank == 1:
        return f"({values[0]},)"
    return f"({', '.join(values)})"


def _expr_python(
    expression: ExpressionIR | None, *, proc: ProcedureIR
) -> str:
    if expression is None:
        raise ValueError("missing output shape expression")
    symbols = {item.name: item for item in proc.symbols}
    constants = {item.name: item for item in proc.constants}
    if expression.kind == "name":
        return str(expression.value)
    if expression.kind == "literal":
        return repr(expression.value)
    if expression.kind == "binary":
        left, right = expression.arguments
        return (
            f"({_expr_python(left, proc=proc)} {expression.operator} "
            f"{_expr_python(right, proc=proc)})"
        )
    if expression.kind == "unary":
        (operand,) = expression.arguments
        if expression.operator == "not":
            return f"(not {_expr_python(operand, proc=proc)})"
        return f"({expression.operator}{_expr_python(operand, proc=proc)})"
    if expression.kind == "intrinsic":
        original_name = str(expression.value)
        name = normalize_intrinsic(original_name)
        args = expression.arguments
        if name == "real":
            return f"float({_expr_python(args[0], proc=proc)})"
        if name == "huge":
            category = infer_expression_category(args[0], symbols, constants)
            return python_huge_expression(category)
        target = python_intrinsic_target(name)
        if target is None:
            raise ValueError(
                f"unsupported intrinsic in Fortran wrapper expression: {original_name}"
            )
        rendered = ", ".join(_expr_python(item, proc=proc) for item in args)
        return f"{target}({rendered})"
    raise ValueError(f"unsupported output shape expression: {expression.kind}")

