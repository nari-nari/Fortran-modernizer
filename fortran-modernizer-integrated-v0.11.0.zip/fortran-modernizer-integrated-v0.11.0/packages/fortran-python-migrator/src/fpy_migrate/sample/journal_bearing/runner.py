from __future__ import annotations

import json
import shutil
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path

import numpy as np

from .case_io import read_case
from .cython_solver import solve_cython
from .models import JournalBearingResult
from .output_io import read_result, write_result
from .python_solver import solve_python


@dataclass(frozen=True)
class Comparison:
    reference: str
    candidate: str
    max_abs_pressure: float
    max_rel_pressure: float
    scalar_failures: tuple[str, ...]
    passed: bool

    def as_dict(self) -> dict[str, object]:
        return {
            "reference": self.reference,
            "candidate": self.candidate,
            "max_abs_pressure": self.max_abs_pressure,
            "max_rel_pressure": self.max_rel_pressure,
            "scalar_failures": list(self.scalar_failures),
            "passed": self.passed,
        }


def repository_root() -> Path:
    return Path(__file__).resolve().parents[4]


def sample_root() -> Path:
    return repository_root() / "samples/journal_bearing"


def build_fortran(build_dir: str | Path | None = None) -> dict[str, Path]:
    compiler = shutil.which("gfortran")
    if compiler is None:
        raise RuntimeError("gfortran is required to build Fortran sample backends")
    target = Path(build_dir) if build_dir else repository_root() / "build/sample/bin"
    target.mkdir(parents=True, exist_ok=True)

    modern = target / "journal_modern"
    legacy = target / "journal_legacy"
    commands = [
        [
            compiler,
            "-O2",
            "-std=f2008",
            "-Wall",
            "-Wextra",
            str(sample_root() / "fortran_reference/journal_bearing.f90"),
            "-o",
            str(modern),
        ],
        [
            compiler,
            "-O2",
            "-std=legacy",
            "-ffixed-line-length-none",
            "-Wall",
            "-Wextra",
            str(sample_root() / "fortran_legacy/journal_bearing_legacy.f"),
            "-o",
            str(legacy),
        ],
    ]
    for command in commands:
        subprocess.run(command, check=True, cwd=repository_root())
    return {"fortran-reference": modern, "fortran-legacy": legacy}


def build_cython() -> None:
    subprocess.run(
        [sys.executable, "setup.py", "build_ext", "--inplace"],
        check=True,
        cwd=repository_root(),
    )


def run_backend(
    backend: str,
    *,
    case_file: str | Path | None = None,
    output_dir: str | Path | None = None,
) -> JournalBearingResult:
    case_path = Path(case_file) if case_file else sample_root() / "cases/standard.nml"
    out = (
        Path(output_dir)
        if output_dir
        else repository_root() / "build/sample/runs" / backend
    )
    out.mkdir(parents=True, exist_ok=True)

    if backend == "python":
        result = solve_python(read_case(case_path))
        write_result(result, out)
        return result
    if backend == "cython":
        result = solve_cython(read_case(case_path))
        write_result(result, out)
        return result
    if backend in {"fortran-reference", "fortran-legacy"}:
        binaries = build_fortran()
        subprocess.run(
            [str(binaries[backend]), str(case_path.resolve()), str(out.resolve())],
            check=True,
            cwd=repository_root(),
        )
        return read_result(out)
    raise ValueError(f"unknown backend: {backend}")


def compare_results(
    reference_name: str,
    reference: JournalBearingResult,
    candidate_name: str,
    candidate: JournalBearingResult,
    *,
    rtol: float = 1.0e-10,
    atol: float = 1.0e-12,
) -> Comparison:
    delta = np.abs(reference.pressure - candidate.pressure)
    max_abs = float(np.max(delta))
    denominator = np.maximum(np.abs(reference.pressure), atol)
    max_rel = float(np.max(delta / denominator))
    scalar_failures: list[str] = []
    ref_summary = reference.summary()
    cand_summary = candidate.summary()
    for key in ref_summary:
        a = ref_summary[key]
        b = cand_summary[key]
        if key == "iterations":
            if a != b:
                scalar_failures.append(f"{key}: {a} != {b}")
            continue
        if not np.isclose(float(a), float(b), rtol=rtol, atol=atol):
            scalar_failures.append(f"{key}: {a} != {b}")
    passed = bool(np.allclose(reference.pressure, candidate.pressure, rtol=rtol, atol=atol))
    passed = passed and not scalar_failures
    return Comparison(
        reference=reference_name,
        candidate=candidate_name,
        max_abs_pressure=max_abs,
        max_rel_pressure=max_rel,
        scalar_failures=tuple(scalar_failures),
        passed=passed,
    )


def compare_all() -> list[Comparison]:
    build_cython()
    backends = ["fortran-reference", "fortran-legacy", "python", "cython"]
    results = {backend: run_backend(backend) for backend in backends}
    reference_name = "fortran-reference"
    comparisons = [
        compare_results(reference_name, results[reference_name], name, results[name])
        for name in backends
        if name != reference_name
    ]
    report = repository_root() / "build/sample/comparison.json"
    report.parent.mkdir(parents=True, exist_ok=True)
    report.write_text(
        json.dumps([item.as_dict() for item in comparisons], indent=2),
        encoding="utf-8",
    )
    return comparisons
