from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import numpy.typing as npt

FloatArray = npt.NDArray[np.float64]


@dataclass(frozen=True)
class JournalBearingCase:
    ntheta: int = 32
    nz: int = 9
    eccentricity: float = 0.60
    relaxation_factor: float = 1.35
    tolerance: float = 1.0e-11
    max_iterations: int = 20_000
    axial_scale: float = 0.20

    def validate(self) -> None:
        if self.ntheta < 4:
            raise ValueError("ntheta must be at least 4")
        if self.nz < 3:
            raise ValueError("nz must be at least 3")
        if not 0.0 <= self.eccentricity < 1.0:
            raise ValueError("eccentricity must satisfy 0 <= epsilon < 1")
        if not 0.0 < self.relaxation_factor < 2.0:
            raise ValueError("relaxation_factor must satisfy 0 < omega < 2")
        if self.tolerance <= 0.0:
            raise ValueError("tolerance must be positive")
        if self.max_iterations <= 0:
            raise ValueError("max_iterations must be positive")
        if self.axial_scale <= 0.0:
            raise ValueError("axial_scale must be positive")


@dataclass(frozen=True)
class JournalBearingResult:
    pressure: FloatArray
    film_thickness: FloatArray
    iterations: int
    update_residual: float
    equation_residual: float
    load_x: float
    load_y: float
    load_magnitude: float
    maximum_pressure: float
    minimum_film_thickness: float
    friction_indicator: float

    def summary(self) -> dict[str, float | int]:
        return {
            "iterations": self.iterations,
            "update_residual": self.update_residual,
            "equation_residual": self.equation_residual,
            "load_x": self.load_x,
            "load_y": self.load_y,
            "load_magnitude": self.load_magnitude,
            "maximum_pressure": self.maximum_pressure,
            "minimum_film_thickness": self.minimum_film_thickness,
            "friction_indicator": self.friction_indicator,
        }
