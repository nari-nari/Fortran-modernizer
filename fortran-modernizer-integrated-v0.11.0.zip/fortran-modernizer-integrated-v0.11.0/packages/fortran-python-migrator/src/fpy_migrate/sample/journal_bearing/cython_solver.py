from __future__ import annotations

from .models import JournalBearingCase, JournalBearingResult


def solve_cython(case: JournalBearingCase) -> JournalBearingResult:
    case.validate()
    try:
        from . import _cython_kernel
    except ImportError as exc:  # pragma: no cover - environment dependent
        raise RuntimeError(
            "Cython extension is not built. Run 'python setup.py build_ext --inplace'."
        ) from exc

    values = _cython_kernel.solve(
        case.ntheta,
        case.nz,
        case.eccentricity,
        case.relaxation_factor,
        case.tolerance,
        case.max_iterations,
        case.axial_scale,
    )
    return JournalBearingResult(
        pressure=values[0],
        film_thickness=values[1],
        iterations=int(values[2]),
        update_residual=float(values[3]),
        equation_residual=float(values[4]),
        load_x=float(values[5]),
        load_y=float(values[6]),
        load_magnitude=float(values[7]),
        maximum_pressure=float(values[8]),
        minimum_film_thickness=float(values[9]),
        friction_indicator=float(values[10]),
    )
