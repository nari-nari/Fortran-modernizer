from __future__ import annotations

import re
from pathlib import Path

from .models import JournalBearingCase

_ASSIGNMENT = re.compile(
    r"(?P<name>[A-Za-z_][A-Za-z0-9_]*)\s*=\s*(?P<value>[^,\n/]+)",
)


def read_case(path: str | Path) -> JournalBearingCase:
    text = Path(path).read_text(encoding="utf-8")
    raw: dict[str, str] = {
        match.group("name").lower(): match.group("value").strip()
        for match in _ASSIGNMENT.finditer(text)
    }

    required = {
        "ntheta",
        "nz",
        "eccentricity",
        "relaxation_factor",
        "tolerance",
        "max_iterations",
        "axial_scale",
    }
    missing = sorted(required - raw.keys())
    if missing:
        raise ValueError(f"missing case values: {', '.join(missing)}")

    def real(name: str) -> float:
        return float(raw[name].replace("D", "E").replace("d", "e"))

    case = JournalBearingCase(
        ntheta=int(raw["ntheta"]),
        nz=int(raw["nz"]),
        eccentricity=real("eccentricity"),
        relaxation_factor=real("relaxation_factor"),
        tolerance=real("tolerance"),
        max_iterations=int(raw["max_iterations"]),
        axial_scale=real("axial_scale"),
    )
    case.validate()
    return case
