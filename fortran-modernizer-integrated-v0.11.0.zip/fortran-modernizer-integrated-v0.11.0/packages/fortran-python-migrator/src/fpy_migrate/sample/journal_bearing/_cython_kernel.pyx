# cython: language_level=3, cdivision=True
import numpy as np
cimport numpy as cnp
cimport cython
from libc.math cimport cos, sin, sqrt, fabs

ctypedef cnp.float64_t DTYPE_t


@cython.boundscheck(False)
@cython.wraparound(False)
cpdef tuple solve(
    int ntheta,
    int nz,
    double eccentricity,
    double relaxation_factor,
    double tolerance,
    int max_iterations,
    double axial_scale,
):
    cdef double pi = 4.0 * __import__('math').atan(1.0)
    cdef double dtheta = 2.0 * pi / ntheta
    cdef double dz = 1.0 / (nz - 1)
    cdef cnp.ndarray[DTYPE_t, ndim=2, mode='fortran'] pressure = \
        np.zeros((ntheta, nz), dtype=np.float64, order='F')
    cdef cnp.ndarray[DTYPE_t, ndim=1] film = \
        np.empty(ntheta, dtype=np.float64)
    cdef double[:, ::1] pview
    cdef double[::1] hview = film
    # NumPy Fortran arrays are not C-contiguous in both dimensions; use generic view.
    cdef double[:, :] p = pressure
    cdef int i, j, iw, ie, iteration, iterations = 0
    cdef double theta, ki, ke, kw, ae, aw, an, ass, ap, rhs
    cdef double old_value, candidate, updated, difference
    cdef double update_residual = 1.0e300
    cdef double equation_residual = 0.0
    cdef double local, load_x = 0.0, load_y = 0.0
    cdef double load_magnitude, maximum_pressure = 0.0
    cdef double minimum_film_thickness = 1.0e300
    cdef double friction_indicator = 0.0

    for i in range(ntheta):
        theta = i * dtheta
        hview[i] = 1.0 + eccentricity * cos(theta)
        if hview[i] < minimum_film_thickness:
            minimum_film_thickness = hview[i]

    for iteration in range(1, max_iterations + 1):
        update_residual = 0.0
        for i in range(ntheta):
            iw = i - 1 if i > 0 else ntheta - 1
            ie = i + 1 if i < ntheta - 1 else 0
            ki = hview[i] * hview[i] * hview[i]
            ke = 0.5 * (ki + hview[ie] * hview[ie] * hview[ie])
            kw = 0.5 * (ki + hview[iw] * hview[iw] * hview[iw])
            ae = ke / (dtheta * dtheta)
            aw = kw / (dtheta * dtheta)
            an = axial_scale * ki / (dz * dz)
            ass = an
            ap = ae + aw + an + ass
            rhs = 3.0 * (hview[ie] - hview[iw]) / dtheta
            for j in range(1, nz - 1):
                old_value = p[i, j]
                candidate = (
                    ae * p[ie, j]
                    + aw * p[iw, j]
                    + an * p[i, j + 1]
                    + ass * p[i, j - 1]
                    - rhs
                ) / ap
                if candidate < 0.0:
                    candidate = 0.0
                updated = old_value + relaxation_factor * (candidate - old_value)
                if updated < 0.0:
                    updated = 0.0
                p[i, j] = updated
                difference = fabs(updated - old_value)
                if difference > update_residual:
                    update_residual = difference
        iterations = iteration
        if update_residual <= tolerance:
            break

    for i in range(ntheta):
        iw = i - 1 if i > 0 else ntheta - 1
        ie = i + 1 if i < ntheta - 1 else 0
        ki = hview[i] * hview[i] * hview[i]
        ae = 0.5 * (ki + hview[ie] * hview[ie] * hview[ie]) / (dtheta * dtheta)
        aw = 0.5 * (ki + hview[iw] * hview[iw] * hview[iw]) / (dtheta * dtheta)
        an = axial_scale * ki / (dz * dz)
        ass = an
        ap = ae + aw + an + ass
        rhs = 3.0 * (hview[ie] - hview[iw]) / dtheta
        theta = i * dtheta
        friction_indicator += 1.0 / hview[i]
        for j in range(nz):
            if p[i, j] > maximum_pressure:
                maximum_pressure = p[i, j]
            load_x += p[i, j] * cos(theta) * dtheta * dz
            load_y += p[i, j] * sin(theta) * dtheta * dz
            if j > 0 and j < nz - 1 and p[i, j] > 0.0:
                local = fabs(
                    ae * p[ie, j]
                    + aw * p[iw, j]
                    + an * p[i, j + 1]
                    + ass * p[i, j - 1]
                    - ap * p[i, j]
                    - rhs
                )
                if local > equation_residual:
                    equation_residual = local

    friction_indicator *= dtheta
    load_magnitude = sqrt(load_x * load_x + load_y * load_y)
    return (
        pressure,
        film,
        iterations,
        update_residual,
        equation_residual,
        load_x,
        load_y,
        load_magnitude,
        maximum_pressure,
        minimum_film_thickness,
        friction_indicator,
    )
