from __future__ import annotations

import csv
from pathlib import Path

import numpy as np

from .models import JournalBearingResult


def write_result(result: JournalBearingResult, output_dir: str | Path) -> None:
    output = Path(output_dir)
    output.mkdir(parents=True, exist_ok=True)
    with (output / "summary.txt").open("w", encoding="utf-8") as handle:
        for key, value in result.summary().items():
            if isinstance(value, int):
                handle.write(f"{key}={value}\n")
            else:
                handle.write(f"{key}={value:.17e}\n")

    ntheta, nz = result.pressure.shape
    with (output / "pressure.csv").open("w", encoding="utf-8", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(["i", "j", "pressure"])
        for i in range(ntheta):
            for j in range(nz):
                writer.writerow([i + 1, j + 1, f"{result.pressure[i, j]:.17e}"])


def read_result(output_dir: str | Path) -> JournalBearingResult:
    output = Path(output_dir)
    summary: dict[str, float | int] = {}
    for line in (output / "summary.txt").read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        key, value = line.split("=", 1)
        if key == "iterations":
            summary[key] = int(value)
        else:
            summary[key] = float(value.replace("D", "E"))

    rows: list[tuple[int, int, float]] = []
    with (output / "pressure.csv").open("r", encoding="utf-8", newline="") as handle:
        reader = csv.DictReader(handle)
        for row in reader:
            rows.append((int(row["i"]), int(row["j"]), float(row["pressure"])))
    ntheta = max(row[0] for row in rows)
    nz = max(row[1] for row in rows)
    pressure = np.zeros((ntheta, nz), dtype=np.float64, order="F")
    for i, j, value in rows:
        pressure[i - 1, j - 1] = value

    # Film is not required for cross-backend output comparisons.
    film = np.empty(0, dtype=np.float64)
    return JournalBearingResult(
        pressure=pressure,
        film_thickness=film,
        iterations=int(summary["iterations"]),
        update_residual=float(summary["update_residual"]),
        equation_residual=float(summary["equation_residual"]),
        load_x=float(summary["load_x"]),
        load_y=float(summary["load_y"]),
        load_magnitude=float(summary["load_magnitude"]),
        maximum_pressure=float(summary["maximum_pressure"]),
        minimum_film_thickness=float(summary["minimum_film_thickness"]),
        friction_indicator=float(summary["friction_indicator"]),
    )
