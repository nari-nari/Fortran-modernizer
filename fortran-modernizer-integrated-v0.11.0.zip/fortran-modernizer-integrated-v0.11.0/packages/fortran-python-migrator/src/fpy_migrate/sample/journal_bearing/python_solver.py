from __future__ import annotations

import math

import numpy as np

from .models import JournalBearingCase, JournalBearingResult


def solve_python(case: JournalBearingCase) -> JournalBearingResult:
    """Faithful loop-based reference implementation of the FDM/SOR solver."""
    case.validate()

    ntheta = case.ntheta
    nz = case.nz
    dtheta = 2.0 * math.pi / float(ntheta)
    dz = 1.0 / float(nz - 1)

    pressure = np.zeros((ntheta, nz), dtype=np.float64, order="F")
    film = np.empty(ntheta, dtype=np.float64)
    for i in range(ntheta):
        theta = float(i) * dtheta
        film[i] = 1.0 + case.eccentricity * math.cos(theta)

    update_residual = math.inf
    iterations = 0
    for iteration in range(1, case.max_iterations + 1):
        update_residual = 0.0
        for i in range(ntheta):
            iw = i - 1 if i > 0 else ntheta - 1
            ie = i + 1 if i < ntheta - 1 else 0
            ki = film[i] ** 3
            ke = 0.5 * (ki + film[ie] ** 3)
            kw = 0.5 * (ki + film[iw] ** 3)
            ae = ke / (dtheta * dtheta)
            aw = kw / (dtheta * dtheta)
            an = case.axial_scale * ki / (dz * dz)
            ass = an
            ap = ae + aw + an + ass
            rhs = 3.0 * (film[ie] - film[iw]) / dtheta

            for j in range(1, nz - 1):
                old_value = pressure[i, j]
                candidate = (
                    ae * pressure[ie, j]
                    + aw * pressure[iw, j]
                    + an * pressure[i, j + 1]
                    + ass * pressure[i, j - 1]
                    - rhs
                ) / ap
                if candidate < 0.0:
                    candidate = 0.0
                updated = old_value + case.relaxation_factor * (
                    candidate - old_value
                )
                if updated < 0.0:
                    updated = 0.0
                pressure[i, j] = updated
                difference = abs(updated - old_value)
                if difference > update_residual:
                    update_residual = difference

        iterations = iteration
        if update_residual <= case.tolerance:
            break

    equation_residual = _equation_residual(case, pressure, film)
    load_x, load_y, load_magnitude = _load(pressure, dtheta, dz)
    friction_indicator = 0.0
    for i in range(ntheta):
        friction_indicator += 1.0 / film[i]
    friction_indicator *= dtheta

    return JournalBearingResult(
        pressure=pressure,
        film_thickness=film,
        iterations=iterations,
        update_residual=update_residual,
        equation_residual=equation_residual,
        load_x=load_x,
        load_y=load_y,
        load_magnitude=load_magnitude,
        maximum_pressure=float(np.max(pressure)),
        minimum_film_thickness=float(np.min(film)),
        friction_indicator=friction_indicator,
    )


def _equation_residual(
    case: JournalBearingCase,
    pressure: np.ndarray,
    film: np.ndarray,
) -> float:
    ntheta, nz = pressure.shape
    dtheta = 2.0 * math.pi / float(ntheta)
    dz = 1.0 / float(nz - 1)
    result = 0.0
    for i in range(ntheta):
        iw = i - 1 if i > 0 else ntheta - 1
        ie = i + 1 if i < ntheta - 1 else 0
        ki = film[i] ** 3
        ae = 0.5 * (ki + film[ie] ** 3) / (dtheta * dtheta)
        aw = 0.5 * (ki + film[iw] ** 3) / (dtheta * dtheta)
        an = case.axial_scale * ki / (dz * dz)
        ass = an
        ap = ae + aw + an + ass
        rhs = 3.0 * (film[ie] - film[iw]) / dtheta
        for j in range(1, nz - 1):
            if pressure[i, j] <= 0.0:
                continue
            local = abs(
                ae * pressure[ie, j]
                + aw * pressure[iw, j]
                + an * pressure[i, j + 1]
                + ass * pressure[i, j - 1]
                - ap * pressure[i, j]
                - rhs
            )
            if local > result:
                result = local
    return result


def _load(
    pressure: np.ndarray,
    dtheta: float,
    dz: float,
) -> tuple[float, float, float]:
    load_x = 0.0
    load_y = 0.0
    ntheta, nz = pressure.shape
    for i in range(ntheta):
        theta = float(i) * dtheta
        for j in range(nz):
            load_x += pressure[i, j] * math.cos(theta) * dtheta * dz
            load_y += pressure[i, j] * math.sin(theta) * dtheta * dz
    return load_x, load_y, math.sqrt(load_x * load_x + load_y * load_y)
