"""Verification-driven Fortran-to-Python migration support."""

__version__ = "0.23.0"
