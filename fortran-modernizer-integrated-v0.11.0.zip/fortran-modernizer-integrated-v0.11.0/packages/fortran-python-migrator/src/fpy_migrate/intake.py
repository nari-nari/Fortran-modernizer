from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator


def repository_root() -> Path:
    return Path(__file__).resolve().parents[2]


def load_refactor_report(path: str | Path) -> dict[str, Any]:
    errors = validate_refactor_report(path)
    if errors:
        joined = "\n".join(errors)
        raise ValueError(f"invalid refactoring report:\n{joined}")
    return json.loads(Path(path).read_text(encoding="utf-8"))


def validate_refactor_report(path: str | Path) -> list[str]:
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    schema_path = repository_root() / "schemas/refactor_report.schema.json"
    schema = json.loads(schema_path.read_text(encoding="utf-8"))
    validator = Draft202012Validator(schema)
    errors = sorted(validator.iter_errors(data), key=lambda item: list(item.path))
    return [f"{'/'.join(map(str, error.path)) or '<root>'}: {error.message}" for error in errors]


def procedure_handoff(report: dict[str, Any], procedure: str) -> dict[str, Any] | None:
    lowered = procedure.lower()
    for item in report.get("program_units", []):
        if str(item.get("name", "")).lower() == lowered:
            return item
    return None


def symbols_for_procedure(report: dict[str, Any], procedure: str) -> list[dict[str, Any]]:
    lowered = procedure.lower()
    return [
        item
        for item in report.get("symbols", [])
        if str(item.get("program_unit", "")).lower() == lowered
    ]
