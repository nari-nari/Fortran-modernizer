from __future__ import annotations

from dataclasses import dataclass, replace
from pathlib import Path
from typing import Iterable

from fparser.common.readfortran import FortranFileReader
from fparser.common.sourceinfo import FortranFormat
from fparser.two.Fortran2003 import (
    Add_Operand,
    And_Operand,
    Assignment_Stmt,
    Block_Nonlabel_Do_Construct,
    Call_Stmt,
    Common_Stmt,
    Data_Ref,
    Else_If_Stmt,
    Else_Stmt,
    Entity_Decl,
    Exit_Stmt,
    Equiv_Operand,
    If_Construct,
    If_Stmt,
    If_Then_Stmt,
    Int_Literal_Constant,
    Intrinsic_Function_Reference,
    Level_2_Expr,
    Level_2_Unary_Expr,
    Level_4_Expr,
    Logical_Literal_Constant,
    Main_Program,
    Module,
    Mult_Operand,
    Name,
    Or_Operand,
    Parenthesis,
    Part_Ref,
    Real_Literal_Constant,
    Subroutine_Subprogram,
    Type_Declaration_Stmt,
)
from fparser.two.parser import ParserFactory
from fparser.two.utils import walk

from fpy_migrate.intake import load_refactor_report, procedure_handoff, symbols_for_procedure

from .model import (
    AssignmentIR,
    CallIR,
    ConstantIR,
    DoLoopIR,
    ExpressionIR,
    ExitIR,
    IfIR,
    ProcedureIR,
    ProjectIR,
    SourceSpan,
    StateGroupIR,
    StatementIR,
    SymbolIR,
    TypeIR,
)


class UnsupportedFortranError(ValueError):
    """Raised when the current safe subset cannot represent a Fortran construct."""


@dataclass(frozen=True)
class _ModuleContext:
    state_group: StateGroupIR | None
    constants: tuple[ConstantIR, ...]


@dataclass(frozen=True)
class _ProcedureInventory:
    name: str
    node: Subroutine_Subprogram
    source_path: Path
    arguments: tuple[str, ...]
    calls: tuple[str, ...]
    source_span: SourceSpan
    module_context: _ModuleContext | None


@dataclass(frozen=True)
class _MainProgramInventory:
    name: str
    node: Main_Program
    source_path: Path
    calls: tuple[str, ...]
    source_span: SourceSpan


@dataclass(frozen=True)
class _CommonDeclaration:
    unit_name: str
    unit_kind: str
    source_span: SourceSpan
    fields: tuple[SymbolIR, ...]


def build_project_ir(
    source: str | Path,
    procedure: str | None = None,
    refactor_report: str | Path | None = None,
) -> ProjectIR:
    source_paths = _discover_source_paths(source)
    handoff = load_refactor_report(refactor_report) if refactor_report is not None else None

    inventories: dict[str, _ProcedureInventory] = {}
    main_programs: dict[str, _MainProgramInventory] = {}
    common_declarations: dict[str, list[_CommonDeclaration]] = {}
    module_groups: list[StateGroupIR] = []
    source_order: list[str] = []
    all_unit_names: dict[str, tuple[str, Path]] = {}

    for source_path in source_paths:
        fixed = source_path.suffix.lower() in {".f", ".for", ".ftn"}
        reader = FortranFileReader(str(source_path))
        reader.set_format(FortranFormat(not fixed, False))
        tree = ParserFactory().create(std="f2008")(reader)

        module_contexts, file_module_groups = _module_state_contexts(tree, source_path)
        for group in file_module_groups:
            if any(item.name == group.name for item in module_groups):
                raise UnsupportedFortranError(f"duplicate module state group: {group.name}")
            module_groups.append(group)

        for node in walk(tree, Main_Program):
            inventory = _inventory_main_program(node, source_path)
            _register_unit_name(
                inventory.name,
                "main program",
                source_path,
                all_unit_names,
            )
            main_programs[inventory.name] = inventory
            _merge_common_declarations(
                common_declarations,
                _inventory_common_declarations(
                    node,
                    source_path,
                    unit_name=inventory.name,
                    unit_kind="main_program",
                ),
            )

        for node in walk(tree, Subroutine_Subprogram):
            module_context = module_contexts.get(id(node))
            inventory = _inventory_procedure(node, source_path, module_context)
            _register_unit_name(
                inventory.name,
                "subroutine",
                source_path,
                all_unit_names,
            )
            inventories[inventory.name] = inventory
            _merge_common_declarations(
                common_declarations,
                _inventory_common_declarations(
                    node,
                    source_path,
                    unit_name=inventory.name,
                    unit_kind="subroutine",
                ),
            )
            source_order.append(inventory.name)

    if not inventories:
        raise ValueError(f"no subroutines found in {source}")

    if procedure is None:
        selected_names = source_order
    else:
        root = procedure.lower()
        if root in main_programs:
            raise UnsupportedFortranError(
                f"{procedure} is a main program; main-program orchestration is not "
                "supported until milestone 22"
            )
        if root not in inventories:
            raise ValueError(f"subroutine not found: {procedure}")
        selected_names = _inventory_dependency_order(root, inventories)

    built_by_name: dict[str, ProcedureIR] = {}
    for name in selected_names:
        inventory = inventories[name]
        built, _ = _build_procedure(
            inventory.node,
            inventory.source_path,
            inventory.module_context,
        )
        if handoff is not None:
            built = _cross_check_handoff(built, handoff)
        built_by_name[name] = built

    common_groups, built_by_name = _consolidate_common_inventory(
        common_declarations, built_by_name
    )

    selected = tuple(built_by_name[name] for name in selected_names)
    _validate_calls(selected, built_by_name)
    referenced_groups = {
        group for item in selected for group in item.state_groups
    }
    all_groups = {item.name: item for item in (*module_groups, *common_groups)}
    selected_groups = tuple(
        all_groups[name] for name in sorted(referenced_groups) if name in all_groups
    )
    return ProjectIR(
        schema_version="1.2",
        source_files=tuple(str(item) for item in source_paths),
        procedures=selected,
        state_groups=selected_groups,
    )


def _discover_source_paths(source: str | Path) -> tuple[Path, ...]:
    source_path = Path(source).resolve()
    if source_path.is_file():
        return (source_path,)
    if not source_path.is_dir():
        raise FileNotFoundError(source_path)
    suffixes = {".f", ".for", ".ftn", ".f90", ".f95", ".f03", ".f08"}
    paths = tuple(
        sorted(
            (item.resolve() for item in source_path.rglob("*") if item.is_file() and item.suffix.lower() in suffixes),
            key=lambda item: item.as_posix(),
        )
    )
    if not paths:
        raise ValueError(f"no Fortran source files found in {source_path}")
    return paths


def _register_unit_name(
    name: str,
    kind: str,
    source_path: Path,
    registered: dict[str, tuple[str, Path]],
) -> None:
    previous = registered.get(name)
    if previous is not None:
        previous_kind, previous_path = previous
        raise UnsupportedFortranError(
            f"duplicate program-unit name: {name} "
            f"({previous_kind} in {previous_path}, {kind} in {source_path})"
        )
    registered[name] = (kind, source_path)


def _inventory_procedure(
    node: Subroutine_Subprogram,
    source_path: Path,
    module_context: _ModuleContext | None,
) -> _ProcedureInventory:
    start_stmt = node.content[0]
    end_stmt = node.content[-1]
    name = str(start_stmt.items[1]).lower()
    dummy_args = start_stmt.items[2]
    arguments = tuple(
        str(item).lower() for item in (dummy_args.items if dummy_args else ())
    )
    execution_part = node.content[2]
    calls = _inventory_calls(execution_part)
    start_line = _line(start_stmt, 1)
    return _ProcedureInventory(
        name=name,
        node=node,
        source_path=source_path,
        arguments=arguments,
        calls=calls,
        source_span=SourceSpan(
            str(source_path),
            start_line,
            _line(end_stmt, start_line),
        ),
        module_context=module_context,
    )


def _inventory_main_program(
    node: Main_Program,
    source_path: Path,
) -> _MainProgramInventory:
    start_stmt = node.content[0]
    end_stmt = node.content[-1]
    name_node = start_stmt.items[1]
    name = str(name_node).lower() if name_node is not None else "__main__"
    start_line = _line(start_stmt, 1)
    return _MainProgramInventory(
        name=name,
        node=node,
        source_path=source_path,
        calls=_inventory_calls(node.content[2]),
        source_span=SourceSpan(
            str(source_path),
            start_line,
            _line(end_stmt, start_line),
        ),
    )


def _inventory_calls(execution_part: object) -> tuple[str, ...]:
    calls: list[str] = []
    seen: set[str] = set()
    for call in walk(execution_part, Call_Stmt):
        name = str(call.items[0]).lower()
        if name not in seen:
            seen.add(name)
            calls.append(name)
    return tuple(calls)


def _merge_common_declarations(
    target: dict[str, list[_CommonDeclaration]],
    additions: dict[str, _CommonDeclaration],
) -> None:
    for group_name, declaration in additions.items():
        target.setdefault(group_name, []).append(declaration)


def _inventory_common_declarations(
    node: Subroutine_Subprogram | Main_Program,
    source_path: Path,
    *,
    unit_name: str,
    unit_kind: str,
) -> dict[str, _CommonDeclaration]:
    """Collect COMMON layout without translating the executable body.

    This pass intentionally tolerates unsupported executable statements and
    unrelated declaration attributes.  It only requires enough declaration
    information to prove that COMMON storage position, type, rank, and shape
    are consistent across the whole source set.
    """

    specification_part = node.content[1]
    declarations: dict[str, SymbolIR] = {}
    common_statements: list[Common_Stmt] = []
    for item in getattr(specification_part, "content", ()):
        if isinstance(item, Common_Stmt):
            common_statements.append(item)
            continue
        if not isinstance(item, Type_Declaration_Stmt):
            continue
        for symbol in _inventory_declared_symbols(item):
            if symbol.name in declarations:
                raise UnsupportedFortranError(
                    f"{source_path}:{_line(item, 1)}: duplicate declaration of "
                    f"{symbol.name} in {unit_name}"
                )
            declarations[symbol.name] = symbol

    output: dict[str, _CommonDeclaration] = {}
    for statement in common_statements:
        for block_name, objects in statement.items[0]:
            source_name = str(block_name).lower() if block_name is not None else "blank"
            group_name = f"common_{source_name}"
            fields: list[SymbolIR] = []
            for obj in objects.items:
                if not isinstance(obj, Name):
                    raise UnsupportedFortranError(
                        f"{source_path}:{_line(statement, 1)}: unsupported COMMON "
                        f"object in {unit_name}: {obj}"
                    )
                local_name = str(obj).lower()
                original = declarations.get(local_name)
                if original is None:
                    raise UnsupportedFortranError(
                        f"{source_path}:{_line(statement, 1)}: COMMON symbol "
                        f"{local_name} has no explicit declaration in {unit_name}"
                    )
                fields.append(
                    replace(
                        original,
                        role="state",
                        state_group=group_name,
                        state_field=local_name,
                    )
                )
            if group_name in output:
                raise UnsupportedFortranError(
                    f"COMMON block {source_name} is declared more than once in {unit_name}"
                )
            line = _line(statement, 1)
            output[group_name] = _CommonDeclaration(
                unit_name=unit_name,
                unit_kind=unit_kind,
                source_span=SourceSpan(str(source_path), line, line),
                fields=tuple(fields),
            )
    return output


def _inventory_declared_symbols(stmt: Type_Declaration_Stmt) -> tuple[SymbolIR, ...]:
    type_node, attributes, entities = stmt.items
    type_ir = _build_type(type_node)
    is_parameter = False
    if attributes is not None:
        is_parameter = any(
            str(attribute).strip().lower() == "parameter"
            for attribute in attributes.items
        )
    if is_parameter:
        return ()

    output: list[SymbolIR] = []
    for entity in entities.items:
        if not isinstance(entity, Entity_Decl):
            continue
        name = str(entity.items[0]).lower()
        shape_node = entity.items[1]
        shape: list[ExpressionIR | None] = []
        if shape_node is not None:
            for dimension in shape_node.items:
                lower, upper = dimension.items
                if lower is not None:
                    raise UnsupportedFortranError(
                        f"explicit non-unit lower bounds are not supported in COMMON "
                        f"inventory: {entity}"
                    )
                shape.append(_build_expression(upper) if upper is not None else None)
        output.append(
            SymbolIR(
                name=name,
                type=type_ir,
                rank=len(shape),
                shape=tuple(shape),
                role="local",
            )
        )
    return tuple(output)


def _module_state_contexts(
    tree: object, source_path: Path
) -> tuple[dict[int, _ModuleContext], tuple[StateGroupIR, ...]]:
    contexts: dict[int, _ModuleContext] = {}
    groups: list[StateGroupIR] = []
    for module in walk(tree, Module):
        module_name = str(module.content[0].items[1]).lower()
        group_name = f"module_{module_name}"
        spec_part = module.content[1]
        fields: list[SymbolIR] = []
        constants: list[ConstantIR] = []
        for item in getattr(spec_part, "content", ()):
            if not isinstance(item, Type_Declaration_Stmt):
                continue
            declared, attributes, declared_constants = _build_symbols(
                item, (), role="state", state_group=group_name, source_path=source_path
            )
            if "parameter" in attributes:
                constants.extend(declared_constants)
            else:
                fields.extend(declared)
        ordered_constants = _order_constants(tuple(constants), context=f"module {module_name}")
        group: StateGroupIR | None = None
        if fields:
            group = StateGroupIR(
                name=group_name,
                source_kind="module",
                source_name=module_name,
                fields=tuple(fields),
                source_span=SourceSpan(
                    str(source_path),
                    _line(module.content[0], 1),
                    _line(module.content[-1], _line(module.content[0], 1)),
                ),
            )
            groups.append(group)
        context = _ModuleContext(group, ordered_constants)
        for subroutine in walk(module, Subroutine_Subprogram):
            contexts[id(subroutine)] = context
    return contexts, tuple(groups)


def _build_procedure(
    node: Subroutine_Subprogram,
    source_path: Path,
    module_context: _ModuleContext | None = None,
) -> tuple[ProcedureIR, dict[str, tuple[SymbolIR, ...]]]:
    start_stmt = node.content[0]
    end_stmt = node.content[-1]
    name = str(start_stmt.items[1]).lower()
    dummy_args = start_stmt.items[2]
    arguments = tuple(str(item).lower() for item in (dummy_args.items if dummy_args else ()))

    start_line = _line(start_stmt, 1)
    end_line = _line(end_stmt, start_line)
    symbols: list[SymbolIR] = []
    constants: list[ConstantIR] = list(module_context.constants) if module_context else []
    common_statements: list[Common_Stmt] = []
    spec_part = node.content[1]
    for item in getattr(spec_part, "content", ()):
        class_name = type(item).__name__
        if class_name in {"Use_Stmt", "Implicit_Part", "Implicit_Stmt"}:
            continue
        if isinstance(item, Common_Stmt):
            common_statements.append(item)
            continue
        if not isinstance(item, Type_Declaration_Stmt):
            raise UnsupportedFortranError(
                f"{source_path}:{_line(item, start_line)}: unsupported specification node "
                f"{class_name} in {name}"
            )
        declared, attributes, declared_constants = _build_symbols(
            item, arguments, source_path=source_path
        )
        if "parameter" in attributes:
            constants.extend(declared_constants)
        else:
            symbols.extend(declared)

    common_groups: dict[str, tuple[SymbolIR, ...]] = {}
    if common_statements:
        by_name = {item.name: item for item in symbols}
        for statement in common_statements:
            for block_name, objects in statement.items[0]:
                source_name = str(block_name).lower() if block_name is not None else "blank"
                group_name = f"common_{source_name}"
                group_fields: list[SymbolIR] = []
                for position, obj in enumerate(objects.items):
                    if not isinstance(obj, Name):
                        raise UnsupportedFortranError(
                            f"unsupported COMMON object in {name}: {obj}"
                        )
                    local_name = str(obj).lower()
                    try:
                        original = by_name[local_name]
                    except KeyError as exc:
                        raise UnsupportedFortranError(
                            f"COMMON symbol {local_name} has no explicit declaration in {name}"
                        ) from exc
                    state_symbol = replace(
                        original,
                        role="state",
                        state_group=group_name,
                        state_field=local_name,
                    )
                    symbols[symbols.index(original)] = state_symbol
                    by_name[local_name] = state_symbol
                    group_fields.append(state_symbol)
                if group_name in common_groups:
                    raise UnsupportedFortranError(
                        f"COMMON block {source_name} is declared more than once in {name}"
                    )
                common_groups[group_name] = tuple(group_fields)

    state_groups: list[str] = list(common_groups)
    module_group = module_context.state_group if module_context else None
    if module_group is not None:
        declared_names = {item.name for item in symbols}
        for field in module_group.fields:
            if field.name in declared_names:
                raise UnsupportedFortranError(
                    f"{name}: local declaration shadows module state symbol {field.name}"
                )
            symbols.append(field)
        state_groups.append(module_group.name)

    constant_names = [item.name for item in constants]
    duplicates = sorted(
        name for name in set(constant_names) if constant_names.count(name) > 1
    )
    if duplicates:
        raise UnsupportedFortranError(
            f"{source_path}:{start_line}: duplicate named constants in {name}: {duplicates}"
        )
    collisions = sorted(set(constant_names) & {item.name for item in symbols})
    if collisions:
        raise UnsupportedFortranError(
            f"{source_path}:{start_line}: constants collide with variables in {name}: {collisions}"
        )
    ordered_constants = _order_constants(tuple(constants), context=name)

    missing = sorted(set(arguments) - {item.name for item in symbols})
    if missing:
        raise UnsupportedFortranError(
            f"{source_path}:{start_line}: arguments without explicit declarations: {missing}"
        )

    execution_part = node.content[2]
    statements = tuple(
        _build_statement(item, source_path) for item in getattr(execution_part, "content", ())
    )
    _validate_symbol_references(
        name, tuple(symbols), ordered_constants, statements
    )
    return (
        ProcedureIR(
            name=name,
            source_span=SourceSpan(str(source_path), start_line, end_line),
            arguments=arguments,
            symbols=tuple(symbols),
            statements=statements,
            constants=ordered_constants,
            state_groups=tuple(state_groups),
        ),
        common_groups,
    )


def _build_symbols(
    stmt: Type_Declaration_Stmt,
    arguments: tuple[str, ...],
    *,
    role: str | None = None,
    state_group: str | None = None,
    source_path: Path | None = None,
) -> tuple[list[SymbolIR], set[str], list[ConstantIR]]:
    type_node, attributes, entities = stmt.items
    type_ir = _build_type(type_node)
    intent: str | None = None
    accepted_attributes: set[str] = set()
    if attributes is not None:
        for attribute in attributes.items:
            if type(attribute).__name__ == "Intent_Attr_Spec":
                intent = str(attribute.items[1]).lower()
                accepted_attributes.add("intent")
                continue
            attribute_name = str(attribute).strip().lower()
            if attribute_name in {"allocatable", "parameter", "save", "public", "private"}:
                accepted_attributes.add(attribute_name)
                continue
            raise UnsupportedFortranError(f"unsupported declaration attribute: {attribute}")

    output: list[SymbolIR] = []
    constants: list[ConstantIR] = []
    is_parameter = "parameter" in accepted_attributes
    for entity in entities.items:
        if not isinstance(entity, Entity_Decl):
            raise UnsupportedFortranError(f"unsupported entity declaration: {entity}")
        name = str(entity.items[0]).lower()
        shape_node = entity.items[1]
        shape: tuple[ExpressionIR | None, ...] = ()
        if shape_node is not None:
            dimensions: list[ExpressionIR | None] = []
            for dimension in shape_node.items:
                lower, upper = dimension.items
                if lower is not None:
                    raise UnsupportedFortranError(
                        f"explicit non-unit lower bounds are not supported yet: {entity}"
                    )
                if upper is None:
                    dimensions.append(None)
                else:
                    dimensions.append(_build_expression(upper))
            shape = tuple(dimensions)
        initialization = entity.items[3]
        if is_parameter:
            if shape:
                raise UnsupportedFortranError(
                    f"array PARAMETER constants are not supported yet: {entity}"
                )
            if initialization is None:
                raise UnsupportedFortranError(
                    f"PARAMETER constant requires an initializer: {entity}"
                )
            value_node = initialization.items[1]
            constants.append(
                ConstantIR(
                    name=name,
                    type=type_ir,
                    value=_build_expression(value_node),
                    source_span=(
                        _span_for_node(stmt, source_path) if source_path is not None else None
                    ),
                )
            )
            continue
        if initialization is not None:
            raise UnsupportedFortranError(
                f"initialized non-PARAMETER declarations are not supported yet: {entity}"
            )
        symbol_role = role or ("argument" if name in arguments else "local")
        output.append(
            SymbolIR(
                name=name,
                type=type_ir,
                intent=intent,  # type: ignore[arg-type]
                rank=len(shape),
                shape=shape,
                role=symbol_role,  # type: ignore[arg-type]
                state_group=state_group,
                state_field=name if state_group is not None else None,
            )
        )
    return output, accepted_attributes, constants


def _consolidate_common_inventory(
    declarations: dict[str, list[_CommonDeclaration]],
    built_by_name: dict[str, ProcedureIR],
) -> tuple[tuple[StateGroupIR, ...], dict[str, ProcedureIR]]:
    groups: list[StateGroupIR] = []
    updated = dict(built_by_name)
    for group_name, entries in declarations.items():
        canonical = entries[0].fields
        for declaration in entries[1:]:
            fields = declaration.fields
            if len(fields) != len(canonical):
                raise UnsupportedFortranError(
                    f"{group_name}: COMMON member count mismatch in "
                    f"{declaration.unit_name}"
                )
            for position, (expected, actual) in enumerate(
                zip(canonical, fields, strict=True), start=1
            ):
                if (
                    expected.type != actual.type
                    or expected.rank != actual.rank
                    or expected.shape != actual.shape
                ):
                    raise UnsupportedFortranError(
                        f"{group_name}: incompatible COMMON member at position "
                        f"{position} in {declaration.unit_name}"
                    )

        canonical_fields = tuple(
            replace(item, state_field=item.name) for item in canonical
        )
        canonical_names = tuple(item.name for item in canonical_fields)
        declarations_by_unit = {item.unit_name: item for item in entries}
        for procedure_name, procedure in tuple(updated.items()):
            declaration = declarations_by_unit.get(procedure_name)
            if declaration is None:
                continue
            aliases = {
                item.name: canonical_names[index]
                for index, item in enumerate(declaration.fields)
            }
            new_symbols = tuple(
                replace(symbol, state_field=aliases[symbol.name])
                if symbol.state_group == group_name
                else symbol
                for symbol in procedure.symbols
            )
            updated[procedure_name] = replace(procedure, symbols=new_symbols)

        source_name = group_name.removeprefix("common_")
        groups.append(
            StateGroupIR(
                name=group_name,
                source_kind="common",
                source_name=source_name,
                fields=canonical_fields,
                source_span=entries[0].source_span,
            )
        )
    return tuple(groups), updated


def _validate_symbol_references(
    procedure_name: str,
    symbols: tuple[SymbolIR, ...],
    constants: tuple[ConstantIR, ...],
    statements: tuple[StatementIR, ...],
) -> None:
    declared = {item.name for item in symbols}
    constant_names = {item.name for item in constants}

    def check_expression(expression: ExpressionIR, loop_variables: set[str]) -> None:
        if expression.kind in {"name", "array_ref"}:
            name = str(expression.value)
            if name not in declared and name not in constant_names and name not in loop_variables:
                raise UnsupportedFortranError(
                    f"{procedure_name}: unresolved symbol reference {name}; "
                    "module parameters/constants require explicit migration support"
                )
        if expression.kind == "intrinsic" and str(expression.value) in {"real", "dble"}:
            # A second REAL argument is a compile-time kind selector, not a
            # runtime symbol that must become a Python variable.
            if expression.arguments:
                check_expression(expression.arguments[0], loop_variables)
            return
        for argument in expression.arguments:
            check_expression(argument, loop_variables)
        for index in expression.indices:
            check_expression(index, loop_variables)

    def visit(items: tuple[StatementIR, ...], loop_variables: set[str]) -> None:
        for statement in items:
            if isinstance(statement, AssignmentIR):
                check_expression(statement.target, loop_variables)
                check_expression(statement.value, loop_variables)
            elif isinstance(statement, CallIR):
                for argument in statement.arguments:
                    check_expression(argument, loop_variables)
            elif isinstance(statement, IfIR):
                check_expression(statement.condition, loop_variables)
                visit(statement.body, loop_variables)
                visit(statement.else_body, loop_variables)
            elif isinstance(statement, DoLoopIR):
                if statement.variable not in declared:
                    raise UnsupportedFortranError(
                        f"{procedure_name}: DO variable {statement.variable} is not declared"
                    )
                check_expression(statement.start, loop_variables)
                check_expression(statement.stop, loop_variables)
                check_expression(statement.step, loop_variables)
                visit(statement.body, loop_variables | {statement.variable})

    for symbol in symbols:
        for extent in symbol.shape:
            if extent is not None:
                check_expression(extent, set())
    visit(statements, set())


def _expression_names(expression: ExpressionIR) -> set[str]:
    names: set[str] = set()
    if expression.kind in {"name", "array_ref"}:
        names.add(str(expression.value))
    if expression.kind == "intrinsic" and str(expression.value) in {"real", "dble"}:
        arguments = expression.arguments[:1]
    else:
        arguments = expression.arguments
    for argument in arguments:
        names.update(_expression_names(argument))
    for index in expression.indices:
        names.update(_expression_names(index))
    return names


def _order_constants(
    constants: tuple[ConstantIR, ...], *, context: str
) -> tuple[ConstantIR, ...]:
    if not constants:
        return ()
    by_name = {item.name: item for item in constants}
    unknown: dict[str, set[str]] = {}
    dependencies: dict[str, set[str]] = {}
    for item in constants:
        names = _expression_names(item.value)
        dependencies[item.name] = names & set(by_name)
        missing = names - set(by_name)
        if missing:
            unknown[item.name] = missing
    if unknown:
        details = "; ".join(
            f"{name} -> {sorted(values)}" for name, values in sorted(unknown.items())
        )
        raise UnsupportedFortranError(
            f"{context}: named constants reference non-constant symbols: {details}"
        )

    ordered: list[ConstantIR] = []
    visiting: list[str] = []
    visited: set[str] = set()

    def visit(name: str) -> None:
        if name in visited:
            return
        if name in visiting:
            cycle_start = visiting.index(name)
            cycle = (*visiting[cycle_start:], name)
            raise UnsupportedFortranError(
                f"{context}: cyclic PARAMETER dependency: {' -> '.join(cycle)}"
            )
        visiting.append(name)
        for dependency in dependencies[name]:
            visit(dependency)
        visiting.pop()
        visited.add(name)
        ordered.append(by_name[name])

    for item in constants:
        visit(item.name)
    return tuple(ordered)


def _build_type(node: object) -> TypeIR:
    class_name = type(node).__name__
    if class_name == "Intrinsic_Type_Spec":
        original_category = str(node.items[0]).lower()
        if original_category == "double precision":
            return TypeIR(category="real", kind="double_precision")
        if original_category not in {"integer", "real", "logical", "character"}:
            raise UnsupportedFortranError(f"unsupported intrinsic type: {node}")
        if node.items[1] is None:
            kind = None
        else:
            selector = node.items[1]
            kind = (
                str(selector.items[1]).lower()
                if getattr(selector, "items", None)
                else str(selector).lower()
            )
        return TypeIR(category=original_category, kind=kind)  # type: ignore[arg-type]
    if class_name == "Declaration_Type_Spec" and str(node.items[0]).upper() == "TYPE":
        return TypeIR(category="derived", derived_name=str(node.items[1]).lower())
    raise UnsupportedFortranError(f"unsupported declaration type: {node}")


def _build_statement(node: object, source_path: Path) -> StatementIR:
    if isinstance(node, Assignment_Stmt):
        return AssignmentIR(
            target=_build_expression(node.items[0]),
            value=_build_expression(node.items[2]),
            source_span=_span_for_node(node, source_path),
        )
    if isinstance(node, Block_Nonlabel_Do_Construct):
        start_stmt = node.content[0]
        loop_control = start_stmt.items[1]
        if loop_control.items[0] is not None or loop_control.items[2] is not None:
            raise UnsupportedFortranError(f"unsupported DO loop control: {start_stmt}")
        variable, bounds = loop_control.items[1]
        if len(bounds) not in {2, 3}:
            raise UnsupportedFortranError(f"unsupported DO bounds: {start_stmt}")
        step = _build_expression(bounds[2]) if len(bounds) == 3 else ExpressionIR("literal", 1)
        body = tuple(_build_statement(item, source_path) for item in node.content[1:-1])
        return DoLoopIR(
            variable=str(variable).lower(),
            start=_build_expression(bounds[0]),
            stop=_build_expression(bounds[1]),
            step=step,
            body=body,
            source_span=SourceSpan(
                str(source_path),
                _line(start_stmt, 1),
                _line(node.content[-1], _line(start_stmt, 1)),
            ),
        )
    if isinstance(node, If_Construct):
        return _build_if_construct(node, source_path)
    if isinstance(node, If_Stmt):
        return IfIR(
            condition=_build_expression(node.items[0]),
            body=(_build_statement(node.items[1], source_path),),
            source_span=_span_for_node(node, source_path),
        )
    if isinstance(node, Exit_Stmt):
        construct_name = node.items[1] if len(node.items) > 1 else None
        if construct_name is not None:
            raise UnsupportedFortranError(
                f"named EXIT statements are not supported yet: {node}"
            )
        return ExitIR(source_span=_span_for_node(node, source_path))
    if isinstance(node, Call_Stmt):
        arguments_node = node.items[1]
        arguments: list[ExpressionIR] = []
        if arguments_node is not None:
            for item in arguments_node.items:
                if type(item).__name__ == "Actual_Arg_Spec":
                    keyword, value = item.items
                    if keyword is not None:
                        raise UnsupportedFortranError(
                            f"keyword actual arguments are not supported yet: {node}"
                        )
                    item = value
                arguments.append(_build_expression(item))
        return CallIR(
            procedure=str(node.items[0]).lower(),
            arguments=tuple(arguments),
            source_span=_span_for_node(node, source_path),
        )
    raise UnsupportedFortranError(
        f"{source_path}:{_line(node, 1)}: unsupported executable node {type(node).__name__}: {node}"
    )


def _build_if_construct(node: If_Construct, source_path: Path) -> IfIR:
    first = node.content[0]
    if not isinstance(first, If_Then_Stmt):
        raise UnsupportedFortranError(f"unexpected IF construct start: {first}")

    branches: list[tuple[ExpressionIR, tuple[StatementIR, ...]]] = []
    current_condition = _build_expression(first.items[0])
    current_body: list[StatementIR] = []
    else_body: list[StatementIR] = []
    in_else = False

    for item in node.content[1:-1]:
        if isinstance(item, Else_If_Stmt):
            if in_else:
                raise UnsupportedFortranError(f"ELSE IF after ELSE is not supported: {node}")
            branches.append((current_condition, tuple(current_body)))
            current_condition = _build_expression(item.items[0])
            current_body = []
            continue
        if isinstance(item, Else_Stmt):
            if in_else:
                raise UnsupportedFortranError(f"duplicate ELSE is not supported: {node}")
            branches.append((current_condition, tuple(current_body)))
            current_body = []
            in_else = True
            continue
        built = _build_statement(item, source_path)
        if in_else:
            else_body.append(built)
        else:
            current_body.append(built)

    if not in_else:
        branches.append((current_condition, tuple(current_body)))

    nested_else: tuple[StatementIR, ...] = tuple(else_body)
    span = SourceSpan(
        str(source_path),
        _line(node.content[0], 1),
        _line(node.content[-1], _line(node.content[0], 1)),
    )
    for condition, body in reversed(branches):
        nested_else = (
            IfIR(
                condition=condition,
                body=body,
                else_body=nested_else,
                source_span=span,
            ),
        )
    return nested_else[0]  # type: ignore[return-value]


def _build_expression(node: object) -> ExpressionIR:
    if isinstance(node, Name):
        return ExpressionIR("name", value=str(node).lower())
    if isinstance(node, Int_Literal_Constant):
        return ExpressionIR("literal", value=int(str(node.items[0])))
    if isinstance(node, Real_Literal_Constant):
        return ExpressionIR(
            "literal",
            value=float(str(node.items[0]).replace("D", "E").replace("d", "e")),
        )
    if isinstance(node, Logical_Literal_Constant):
        return ExpressionIR("literal", value=str(node.items[0]).upper() == ".TRUE.")
    if isinstance(node, (Level_2_Expr, Add_Operand, Mult_Operand, Level_4_Expr, Or_Operand, Equiv_Operand)):
        left, operator, right = node.items
        return ExpressionIR(
            "binary",
            operator=_normalise_operator(str(operator)),
            arguments=(_build_expression(left), _build_expression(right)),
        )
    if isinstance(node, (Level_2_Unary_Expr, And_Operand)) and len(node.items) == 2:
        operator, operand = node.items
        return ExpressionIR(
            "unary",
            operator=_normalise_operator(str(operator)),
            arguments=(_build_expression(operand),),
        )
    if isinstance(node, Parenthesis):
        return _build_expression(node.items[1])
    if isinstance(node, Intrinsic_Function_Reference):
        name = str(node.items[0]).lower()
        args_node = node.items[1]
        args = tuple(_build_expression(item) for item in args_node.items)
        return ExpressionIR("intrinsic", value=name, arguments=args)
    if isinstance(node, Part_Ref):
        name = str(node.items[0]).lower()
        indices = tuple(_build_expression(item) for item in node.items[1].items)
        return ExpressionIR("array_ref", value=name, indices=indices)
    if isinstance(node, Data_Ref):
        raise UnsupportedFortranError(
            f"derived-type component references are not supported in milestone 3: {node}"
        )
    raise UnsupportedFortranError(
        f"unsupported expression node {type(node).__name__}: {node}"
    )


def _normalise_operator(operator: str) -> str:
    upper = operator.strip().upper()
    mapping = {
        ".AND.": "and",
        ".OR.": "or",
        ".NOT.": "not",
        ".EQV.": "==",
        ".NEQV.": "!=",
        ".EQ.": "==",
        ".NE.": "!=",
        ".LT.": "<",
        ".LE.": "<=",
        ".GT.": ">",
        ".GE.": ">=",
        "/=": "!=",
    }
    return mapping.get(upper, operator.strip())


def _called_procedures(statements: Iterable[StatementIR]) -> tuple[str, ...]:
    result: list[str] = []
    seen: set[str] = set()

    def add(name: str) -> None:
        if name not in seen:
            seen.add(name)
            result.append(name)

    def visit(items: Iterable[StatementIR]) -> None:
        for statement in items:
            if isinstance(statement, CallIR):
                add(statement.procedure)
            elif isinstance(statement, DoLoopIR):
                visit(statement.body)
            elif isinstance(statement, IfIR):
                visit(statement.body)
                visit(statement.else_body)

    visit(statements)
    return tuple(result)


def _dependency_order(root: str, procedures: dict[str, ProcedureIR]) -> list[str]:
    ordered: list[str] = []
    visiting: set[str] = set()
    visited: set[str] = set()

    def visit(name: str) -> None:
        if name in visited:
            return
        if name in visiting:
            raise UnsupportedFortranError(f"recursive call cycle is not supported yet: {name}")
        if name not in procedures:
            raise UnsupportedFortranError(f"unresolved called subroutine: {name}")
        visiting.add(name)
        for dependency in _called_procedures(procedures[name].statements):
            visit(dependency)
        visiting.remove(name)
        visited.add(name)
        ordered.append(name)

    visit(root)
    return ordered


def _inventory_dependency_order(
    root: str,
    procedures: dict[str, _ProcedureInventory],
) -> list[str]:
    """Return dependency-first order without translating executable bodies."""

    ordered: list[str] = []
    visiting: list[str] = []
    visited: set[str] = set()

    def visit(name: str) -> None:
        if name in visited:
            return
        if name in visiting:
            cycle_start = visiting.index(name)
            cycle = (*visiting[cycle_start:], name)
            raise UnsupportedFortranError(
                f"recursive call cycle is not supported yet: {' -> '.join(cycle)}"
            )
        inventory = procedures.get(name)
        if inventory is None:
            caller = visiting[-1] if visiting else root
            raise UnsupportedFortranError(
                f"{caller}: unresolved called subroutine {name}"
            )
        visiting.append(name)
        for dependency in inventory.calls:
            visit(dependency)
        visiting.pop()
        visited.add(name)
        ordered.append(name)

    visit(root)
    return ordered


def _validate_calls(
    selected: tuple[ProcedureIR, ...],
    all_procedures: dict[str, ProcedureIR],
) -> None:
    for caller in selected:
        for call in _walk_calls(caller.statements):
            callee = all_procedures.get(call.procedure)
            if callee is None:
                raise UnsupportedFortranError(
                    f"{caller.name}: unresolved called subroutine {call.procedure}"
                )
            if len(call.arguments) != len(callee.arguments):
                raise UnsupportedFortranError(
                    f"{caller.name}: argument count mismatch calling {callee.name}: "
                    f"actual={len(call.arguments)}, dummy={len(callee.arguments)}"
                )
            for formal_name, actual in zip(callee.arguments, call.arguments, strict=True):
                formal = callee.symbol(formal_name)
                if formal.intent in {"out", "inout"} and actual.kind not in {"name", "array_ref"}:
                    raise UnsupportedFortranError(
                        f"{caller.name}: output actual argument for {callee.name}.{formal_name} "
                        f"is not assignable: {actual}"
                    )


def _walk_calls(statements: Iterable[StatementIR]) -> Iterable[CallIR]:
    for statement in statements:
        if isinstance(statement, CallIR):
            yield statement
        elif isinstance(statement, DoLoopIR):
            yield from _walk_calls(statement.body)
        elif isinstance(statement, IfIR):
            yield from _walk_calls(statement.body)
            yield from _walk_calls(statement.else_body)


def _line(node: object, default: int) -> int:
    item = getattr(node, "item", None)
    span = getattr(item, "span", None)
    return int(span[0]) if span else default


def _span_for_node(node: object, source_path: Path) -> SourceSpan:
    line = _line(node, 1)
    return SourceSpan(str(source_path), line, line)


def _cross_check_handoff(procedure: ProcedureIR, report: dict[str, object]) -> ProcedureIR:
    unit = procedure_handoff(report, procedure.name)
    if unit is None:
        raise UnsupportedFortranError(
            f"refactoring report does not contain program unit {procedure.name}"
        )
    report_arguments = tuple(str(item).lower() for item in unit.get("arguments", []))
    if report_arguments and report_arguments != procedure.arguments:
        raise UnsupportedFortranError(
            f"handoff argument mismatch for {procedure.name}: "
            f"AST={procedure.arguments}, report={report_arguments}"
        )

    report_symbols = {
        str(item.get("name", "")).lower(): item
        for item in symbols_for_procedure(report, procedure.name)
    }
    diagnostics: list[str] = []
    for symbol in procedure.symbols:
        external = report_symbols.get(symbol.name)
        if external is None:
            diagnostics.append(f"handoff has no symbol entry for {symbol.name}")
            continue
        checks = {
            "category": symbol.type.category,
            "intent": symbol.intent,
            "rank": symbol.rank,
        }
        for key, expected in checks.items():
            actual = external.get(key)
            if actual is not None and actual != expected:
                raise UnsupportedFortranError(
                    f"handoff symbol mismatch for {procedure.name}.{symbol.name}.{key}: "
                    f"AST={expected!r}, report={actual!r}"
                )
    return ProcedureIR(
        name=procedure.name,
        source_span=procedure.source_span,
        arguments=procedure.arguments,
        symbols=procedure.symbols,
        statements=procedure.statements,
        constants=procedure.constants,
        state_groups=procedure.state_groups,
        status="AUTO" if not diagnostics else "REVIEW_REQUIRED",
        diagnostics=tuple(diagnostics),
    )
