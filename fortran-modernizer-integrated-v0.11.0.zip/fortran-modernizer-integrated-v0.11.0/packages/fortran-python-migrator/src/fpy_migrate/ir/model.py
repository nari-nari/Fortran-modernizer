from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any, Literal


@dataclass(frozen=True)
class SourceSpan:
    file: str
    start_line: int
    end_line: int


@dataclass(frozen=True)
class TypeIR:
    category: Literal["integer", "real", "logical", "character", "derived"]
    kind: str | None = None
    derived_name: str | None = None


@dataclass(frozen=True)
class ConstantIR:
    name: str
    type: TypeIR
    value: "ExpressionIR"
    source_span: SourceSpan | None = None


@dataclass(frozen=True)
class SymbolIR:
    name: str
    type: TypeIR
    intent: Literal["in", "out", "inout"] | None = None
    rank: int = 0
    # None denotes an assumed-shape extent (":").
    shape: tuple["ExpressionIR | None", ...] = ()
    role: Literal["argument", "local", "state"] = "local"
    # State symbols retain their local Fortran name while mapping to a
    # canonical Python state field. This permits compatible COMMON aliases.
    state_group: str | None = None
    state_field: str | None = None


@dataclass(frozen=True)
class StateGroupIR:
    name: str
    source_kind: Literal["module", "common"]
    source_name: str
    fields: tuple[SymbolIR, ...]
    source_span: SourceSpan | None = None


@dataclass(frozen=True)
class ExpressionIR:
    kind: Literal[
        "name",
        "literal",
        "binary",
        "unary",
        "intrinsic",
        "array_ref",
    ]
    value: str | int | float | bool | None = None
    operator: str | None = None
    arguments: tuple["ExpressionIR", ...] = ()
    indices: tuple["ExpressionIR", ...] = ()


@dataclass(frozen=True)
class AssignmentIR:
    kind: Literal["assignment"] = "assignment"
    target: ExpressionIR = field(default_factory=lambda: ExpressionIR("name", value=""))
    value: ExpressionIR = field(default_factory=lambda: ExpressionIR("literal", value=0))
    source_span: SourceSpan | None = None


@dataclass(frozen=True)
class DoLoopIR:
    kind: Literal["do"] = "do"
    variable: str = ""
    start: ExpressionIR = field(default_factory=lambda: ExpressionIR("literal", value=1))
    stop: ExpressionIR = field(default_factory=lambda: ExpressionIR("literal", value=1))
    step: ExpressionIR = field(default_factory=lambda: ExpressionIR("literal", value=1))
    body: tuple["StatementIR", ...] = ()
    source_span: SourceSpan | None = None


@dataclass(frozen=True)
class IfIR:
    kind: Literal["if"] = "if"
    condition: ExpressionIR = field(default_factory=lambda: ExpressionIR("literal", value=True))
    body: tuple["StatementIR", ...] = ()
    else_body: tuple["StatementIR", ...] = ()
    source_span: SourceSpan | None = None


@dataclass(frozen=True)
class CallIR:
    kind: Literal["call"] = "call"
    procedure: str = ""
    arguments: tuple[ExpressionIR, ...] = ()
    source_span: SourceSpan | None = None


@dataclass(frozen=True)
class ExitIR:
    kind: Literal["exit"] = "exit"
    source_span: SourceSpan | None = None


StatementIR = AssignmentIR | DoLoopIR | IfIR | CallIR | ExitIR


@dataclass(frozen=True)
class ProcedureIR:
    name: str
    source_span: SourceSpan
    arguments: tuple[str, ...]
    symbols: tuple[SymbolIR, ...]
    statements: tuple[StatementIR, ...]
    constants: tuple[ConstantIR, ...] = ()
    state_groups: tuple[str, ...] = ()
    status: Literal["AUTO", "REVIEW_REQUIRED", "BLOCKED"] = "AUTO"
    diagnostics: tuple[str, ...] = ()

    def constant(self, name: str) -> ConstantIR:
        lowered = name.lower()
        for item in self.constants:
            if item.name.lower() == lowered:
                return item
        raise KeyError(name)

    def symbol(self, name: str) -> SymbolIR:
        lowered = name.lower()
        for item in self.symbols:
            if item.name.lower() == lowered:
                return item
        raise KeyError(name)


@dataclass(frozen=True)
class ProjectIR:
    schema_version: str
    source_files: tuple[str, ...]
    procedures: tuple[ProcedureIR, ...]
    state_groups: tuple[StateGroupIR, ...] = ()

    def procedure(self, name: str) -> ProcedureIR:
        lowered = name.lower()
        for item in self.procedures:
            if item.name.lower() == lowered:
                return item
        raise KeyError(name)

    def state_group(self, name: str) -> StateGroupIR:
        lowered = name.lower()
        for item in self.state_groups:
            if item.name.lower() == lowered:
                return item
        raise KeyError(name)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)
