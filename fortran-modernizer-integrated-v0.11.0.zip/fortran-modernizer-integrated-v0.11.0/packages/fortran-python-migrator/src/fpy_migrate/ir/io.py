from __future__ import annotations

import json
from pathlib import Path

from jsonschema import Draft202012Validator

from .model import ProjectIR


def repository_root() -> Path:
    return Path(__file__).resolve().parents[3]


def write_project_ir(project: ProjectIR, path: str | Path) -> Path:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(project.to_dict(), indent=2), encoding="utf-8")
    return target


def validate_migration_ir(path: str | Path) -> list[str]:
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    schema = json.loads(
        (repository_root() / "schemas/migration_ir.schema.json").read_text(encoding="utf-8")
    )
    validator = Draft202012Validator(schema)
    errors = sorted(validator.iter_errors(data), key=lambda item: list(item.path))
    return [f"{'/'.join(map(str, error.path)) or '<root>'}: {error.message}" for error in errors]
