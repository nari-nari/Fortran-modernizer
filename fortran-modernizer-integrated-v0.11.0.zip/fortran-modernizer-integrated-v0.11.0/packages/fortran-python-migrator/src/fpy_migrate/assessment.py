from __future__ import annotations

import json
import re
from dataclasses import asdict, dataclass
from pathlib import Path

from fparser.common.readfortran import FortranFileReader
from fparser.common.sourceinfo import FortranFormat
from fparser.two.parser import ParserFactory

_FORTRAN_SUFFIXES = {".f", ".for", ".ftn", ".f90", ".f95", ".f03", ".f08"}
_BLOCKED_PATTERNS = {
    "equivalence": re.compile(r"\bEQUIVALENCE\b", re.IGNORECASE),
    "entry": re.compile(r"^\s*ENTRY\b", re.IGNORECASE | re.MULTILINE),
    "alternate_return": re.compile(r"CALL\s+\w+\s*\([^)]*\*\s*\d", re.IGNORECASE),
    "cray_pointer": re.compile(r"\bPOINTER\s*\(\s*\w+\s*,", re.IGNORECASE),
}
_REVIEW_PATTERNS = {
    "common": re.compile(r"\bCOMMON\b", re.IGNORECASE),
    "implicit_typing": re.compile(r"\bIMPLICIT\s+(?!NONE)", re.IGNORECASE),
    "goto": re.compile(r"\bGO\s*TO\b|\bGOTO\b", re.IGNORECASE),
    "save": re.compile(r"\bSAVE\b", re.IGNORECASE),
    "formatted_io": re.compile(r"\bFORMAT\s*\(", re.IGNORECASE),
}


@dataclass(frozen=True)
class FileAssessment:
    path: str
    source_form: str
    parse_succeeded: bool
    status: str
    blockers: tuple[str, ...]
    review_items: tuple[str, ...]
    parse_error: str | None = None


@dataclass(frozen=True)
class AssessmentReport:
    schema_version: str
    root: str
    files: tuple[FileAssessment, ...]

    def to_dict(self) -> dict[str, object]:
        return {
            "schema_version": self.schema_version,
            "root": self.root,
            "files": [asdict(item) for item in self.files],
        }


def assess_tree(root: str | Path) -> AssessmentReport:
    root_path = Path(root).resolve()
    files = sorted(
        path for path in root_path.rglob("*") if path.suffix.lower() in _FORTRAN_SUFFIXES
    )
    assessments = tuple(_assess_file(path, root_path) for path in files)
    return AssessmentReport(schema_version="1.0", root=str(root_path), files=assessments)


def write_report(report: AssessmentReport, path: str | Path) -> None:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(report.to_dict(), indent=2), encoding="utf-8")


def _assess_file(path: Path, root: Path) -> FileAssessment:
    text = path.read_text(encoding="utf-8", errors="replace")
    fixed = path.suffix.lower() in {".f", ".for", ".ftn"}
    source_form = "fixed" if fixed else "free"
    blockers = tuple(name for name, pattern in _BLOCKED_PATTERNS.items() if pattern.search(text))
    review = tuple(name for name, pattern in _REVIEW_PATTERNS.items() if pattern.search(text))
    parse_error: str | None = None
    parse_succeeded = False
    try:
        reader = FortranFileReader(str(path))
        reader.set_format(FortranFormat(not fixed, False))
        parser = ParserFactory().create(std="f2008")
        parser(reader)
        parse_succeeded = True
    except Exception as exc:  # fparser emits multiple exception classes
        parse_error = f"{type(exc).__name__}: {exc}"

    if not parse_succeeded or blockers:
        status = "BLOCKED"
    elif review:
        status = "REVIEW_REQUIRED"
    else:
        status = "READY"
    return FileAssessment(
        path=str(path.relative_to(root)),
        source_form=source_form,
        parse_succeeded=parse_succeeded,
        status=status,
        blockers=blockers,
        review_items=review,
        parse_error=parse_error,
    )
