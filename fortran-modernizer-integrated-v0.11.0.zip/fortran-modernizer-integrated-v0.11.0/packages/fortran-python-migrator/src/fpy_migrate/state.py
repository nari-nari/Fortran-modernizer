from __future__ import annotations

from dataclasses import asdict, dataclass
import json
from pathlib import Path

from fpy_migrate.ir.model import ProjectIR


@dataclass(frozen=True)
class StateFieldReport:
    name: str
    category: str
    kind: str | None
    rank: int
    shape: tuple[str | None, ...]


@dataclass(frozen=True)
class StateGroupReport:
    name: str
    source_kind: str
    source_name: str
    fields: tuple[StateFieldReport, ...]
    procedures: tuple[str, ...]
    python_class: str
    cython_strategy: str


@dataclass(frozen=True)
class StateMigrationReport:
    schema_version: str
    groups: tuple[StateGroupReport, ...]

    def to_dict(self) -> dict[str, object]:
        return {
            "schema_version": self.schema_version,
            "groups": [asdict(item) for item in self.groups],
        }


def analyze_state_migration(project: ProjectIR) -> StateMigrationReport:
    groups: list[StateGroupReport] = []
    for group in project.state_groups:
        procedures = tuple(
            item.name for item in project.procedures if group.name in item.state_groups
        )
        fields = tuple(
            StateFieldReport(
                name=item.state_field or item.name,
                category=item.type.category,
                kind=item.type.kind,
                rank=item.rank,
                shape=tuple(_shape_text(extent) for extent in item.shape),
            )
            for item in group.fields
        )
        groups.append(
            StateGroupReport(
                name=group.name,
                source_kind=group.source_kind,
                source_name=group.source_name,
                fields=fields,
                procedures=procedures,
                python_class=_state_class(group.name),
                cython_strategy=(
                    "keep this state wrapper in Python and pass individual NumPy arrays or "
                    "scalars into extracted Cython kernels"
                ),
            )
        )
    return StateMigrationReport(schema_version="1.0", groups=tuple(groups))


def write_state_migration_report(
    report: StateMigrationReport, output: str | Path
) -> Path:
    path = Path(output)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(report.to_dict(), indent=2) + "\n", encoding="utf-8")
    return path


def _shape_text(extent) -> str | None:
    if extent is None:
        return None
    if extent.kind == "literal":
        return str(extent.value)
    if extent.kind == "name":
        return str(extent.value)
    return extent.kind


def _state_class(group_name: str) -> str:
    parts = [item for item in group_name.replace("-", "_").split("_") if item]
    return "".join(item[:1].upper() + item[1:] for item in parts) + "State"
