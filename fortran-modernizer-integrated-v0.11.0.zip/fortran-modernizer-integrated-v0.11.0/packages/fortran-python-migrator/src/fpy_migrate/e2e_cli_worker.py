from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import sys

from fpy_migrate.e2e_acceptance import E2EAcceptanceError, verify_e2e_acceptance
from fpy_migrate.ir import UnsupportedFortranError
from fpy_migrate.orchestration import OrchestrationError
from fpy_migrate.refactor_bridge import RefactorBridgeError


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Isolated worker for the E2E native-build acceptance gate.")
    parser.add_argument("legacy_source")
    parser.add_argument("normalized_source")
    parser.add_argument("--program", required=True)
    parser.add_argument("--adapter-config", required=True)
    parser.add_argument("--handoff", required=True)
    parser.add_argument("--handoff-procedure", required=True)
    parser.add_argument("--build-directory", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--rtol", type=float, default=1.0e-12)
    parser.add_argument("--atol", type=float, default=1.0e-13)
    parser.add_argument("--without-fortran-backend", action="store_true")
    return parser


def main() -> int:
    args = _parser().parse_args()
    try:
        output = verify_e2e_acceptance(
            args.legacy_source,
            args.normalized_source,
            program=args.program,
            adapter_config=args.adapter_config,
            handoff=args.handoff,
            handoff_procedure=args.handoff_procedure,
            build_directory=args.build_directory,
            output=args.output,
            rtol=args.rtol,
            atol=args.atol,
            include_fortran=not args.without_fortran_backend,
        )
    except (
        E2EAcceptanceError,
        OrchestrationError,
        RefactorBridgeError,
        UnsupportedFortranError,
        ValueError,
    ) as exc:
        print(f"BLOCKED: {exc}", file=sys.stderr, flush=True)
        return 2
    payload = json.loads(Path(output).read_text(encoding="utf-8"))
    print(json.dumps({
        "output": str(output),
        "status": payload["status"],
        "available_backends": payload["generated_application"]["available_backends"],
        "state_fields": payload["state_fields"],
    }, indent=2), flush=True)
    return 0


if __name__ == "__main__":
    code = main()
    sys.stdout.flush()
    sys.stderr.flush()
    # Generated native modules can make CPython teardown nondeterministic on
    # some hosted Linux runners. All acceptance artifacts are already flushed.
    os._exit(code)
