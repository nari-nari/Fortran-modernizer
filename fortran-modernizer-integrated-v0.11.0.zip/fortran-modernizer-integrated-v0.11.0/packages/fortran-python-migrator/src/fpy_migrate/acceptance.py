from __future__ import annotations

import csv
import json
import re
from collections import Counter, defaultdict
from dataclasses import asdict, dataclass, replace
from pathlib import Path
from typing import Any, Iterable, Mapping

from jsonschema import Draft202012Validator

from fparser.common.readfortran import FortranFileReader
from fparser.common.sourceinfo import FortranFormat
from fparser.two.Fortran2003 import Subroutine_Subprogram
from fparser.two.parser import ParserFactory
from fparser.two.utils import walk

from .assessment import _FORTRAN_SUFFIXES
from .intake import load_refactor_report, repository_root
from .ir.builder import (
    UnsupportedFortranError,
    _build_procedure,
    _module_state_contexts,
    build_project_ir,
)
from .ir.model import CallIR, DoLoopIR, IfIR, ProcedureIR, StatementIR


@dataclass(frozen=True)
class AcceptanceFinding:
    severity: str
    category: str
    message: str
    source_file: str
    line: int
    procedure: str | None = None


@dataclass(frozen=True)
class AcceptanceFile:
    path: str
    source_form: str
    parse_succeeded: bool
    status: str
    procedure_count: int
    parse_error: str | None
    blocker_count: int
    review_count: int


@dataclass(frozen=True)
class AcceptanceProcedure:
    name: str
    source_file: str
    start_line: int
    end_line: int
    status: str
    ir_build_succeeded: bool
    arguments: tuple[str, ...]
    calls: tuple[str, ...]
    external_calls: tuple[str, ...]
    blocked_dependencies: tuple[str, ...]
    loop_count: int
    array_symbol_count: int
    state_groups: tuple[str, ...]
    blockers: tuple[str, ...]
    review_items: tuple[str, ...]
    recommended_action: str
    migration_rank: int | None = None


@dataclass(frozen=True)
class UnsupportedConstructSummary:
    category: str
    severity: str
    occurrences: int
    procedure_count: int
    file_count: int
    examples: tuple[str, ...]


@dataclass(frozen=True)
class AcceptanceReport:
    schema_version: str
    root: str
    root_procedure: str | None
    status: str
    summary: Mapping[str, int]
    rates: Mapping[str, float]
    project_ir_build: Mapping[str, Any]
    files: tuple[AcceptanceFile, ...]
    procedures: tuple[AcceptanceProcedure, ...]
    findings: tuple[AcceptanceFinding, ...]
    unsupported_constructs: tuple[UnsupportedConstructSummary, ...]
    call_graph: tuple[Mapping[str, Any], ...]
    migration_order: tuple[str, ...]
    recommended_vertical_slice: Mapping[str, Any]
    fortran_retention_candidates: tuple[str, ...]
    refactor_report: Mapping[str, Any] | None

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


# These patterns describe the current safe Migration IR, not all constructs that
# fparser or a Fortran compiler can parse.
_PATTERN_SPECS: tuple[tuple[str, str, re.Pattern[str], str], ...] = (
    ("preprocessor", "blocking", re.compile(r"^\s*#", re.MULTILINE), "preprocessor-aware discovery is not implemented"),
    ("include", "review", re.compile(r"^\s*INCLUDE\s*['\"]", re.IGNORECASE | re.MULTILINE), "INCLUDE files must be expanded or supplied explicitly"),
    ("equivalence", "blocking", re.compile(r"\bEQUIVALENCE\b", re.IGNORECASE), "storage association cannot be represented safely"),
    ("entry", "blocking", re.compile(r"^\s*ENTRY\b", re.IGNORECASE | re.MULTILINE), "ENTRY points are unsupported"),
    ("alternate_return", "blocking", re.compile(r"CALL\s+\w+\s*\([^)]*\*\s*\d", re.IGNORECASE), "alternate returns are unsupported"),
    ("cray_pointer", "blocking", re.compile(r"\bPOINTER\s*\(\s*\w+\s*,", re.IGNORECASE), "Cray pointers are unsupported"),
    ("derived_type_component", "blocking", re.compile(r"\b[A-Z]\w*\s*%\s*[A-Z]\w*", re.IGNORECASE), "derived-type component references are unsupported"),
    ("select_case", "blocking", re.compile(r"\bSELECT\s+CASE\b", re.IGNORECASE), "SELECT CASE is not represented in the current IR"),
    ("goto", "blocking", re.compile(r"\bGO\s*TO\b|\bGOTO\b", re.IGNORECASE), "unstructured control flow is unsupported"),
    ("cycle", "blocking", re.compile(r"^\s*CYCLE\b", re.IGNORECASE | re.MULTILINE), "CYCLE is unsupported"),
    ("named_exit", "blocking", re.compile(r"^\s*EXIT\s+\w+", re.IGNORECASE | re.MULTILINE), "named EXIT is unsupported"),
    ("unbounded_do", "blocking", re.compile(r"^\s*DO\s*(?:!.*)?$", re.IGNORECASE | re.MULTILINE), "unbounded DO is unsupported"),
    ("labelled_do", "blocking", re.compile(r"^\s*DO\s+\d+\s+\w+\s*=", re.IGNORECASE | re.MULTILINE), "labelled DO is unsupported"),
    ("array_section", "blocking", re.compile(r"\w+\s*\([^\n)]*:[^\n)]*\)", re.IGNORECASE), "array sections require explicit migration support"),
    ("pointer", "blocking", re.compile(r"\bPOINTER\b", re.IGNORECASE), "Fortran pointers are unsupported"),
    ("polymorphism", "blocking", re.compile(r"\bCLASS\s*\(", re.IGNORECASE), "polymorphic entities are unsupported"),
    ("procedure_pointer", "blocking", re.compile(r"\bPROCEDURE\s*\([^)]*\)\s*,?\s*POINTER", re.IGNORECASE), "procedure pointers are unsupported"),
    ("block_data", "blocking", re.compile(r"\bBLOCK\s+DATA\b", re.IGNORECASE), "BLOCK DATA requires dedicated state initialization support"),
    ("data_statement", "review", re.compile(r"^\s*DATA\b", re.IGNORECASE | re.MULTILINE), "DATA initialization must be made explicit"),
    ("save", "review", re.compile(r"\bSAVE\b", re.IGNORECASE), "persistent local state needs an explicit Python owner"),
    ("implicit_typing", "review", re.compile(r"\bIMPLICIT\s+(?!NONE)", re.IGNORECASE), "implicit typing should be eliminated before migration"),
    ("common", "review", re.compile(r"\bCOMMON\b", re.IGNORECASE), "COMMON is supported only after layout consistency is established"),
    ("formatted_io", "review", re.compile(r"\bFORMAT\s*\(|\b(?:READ|WRITE)\s*\([^\n]*\d+", re.IGNORECASE), "formatted I/O should remain in the orchestration layer"),
    ("allocatable", "review", re.compile(r"\bALLOCATABLE\b|\bALLOCATE\s*\(", re.IGNORECASE), "allocation ownership must be made explicit"),
    ("openmp", "review", re.compile(r"^\s*!\$OMP", re.IGNORECASE | re.MULTILINE), "OpenMP directives are not translated automatically"),
)

_SUBROUTINE_START = re.compile(r"^\s*(?:RECURSIVE\s+|PURE\s+|ELEMENTAL\s+|MODULE\s+)*SUBROUTINE\s+(\w+)", re.IGNORECASE)
_SUBROUTINE_END = re.compile(r"^\s*END\s*(?:SUBROUTINE)?\b", re.IGNORECASE)
_CALL = re.compile(r"\bCALL\s+([A-Z]\w*)", re.IGNORECASE)


def diagnose_project(
    source: str | Path,
    *,
    procedure: str | None = None,
    refactor_report: str | Path | None = None,
) -> AcceptanceReport:
    root_path = Path(source).resolve()
    source_paths = _discover_source_paths(root_path)
    findings: list[AcceptanceFinding] = []
    files: list[AcceptanceFile] = []
    built: dict[str, ProcedureIR] = {}
    procedure_records: dict[str, AcceptanceProcedure] = {}
    source_texts: dict[str, str] = {}

    for path in source_paths:
        rel = _relative(path, root_path)
        text = path.read_text(encoding="utf-8", errors="replace")
        source_texts[rel] = text
        fixed = path.suffix.lower() in {".f", ".for", ".ftn"}
        source_form = "fixed" if fixed else "free"
        file_findings = _scan_findings(text, rel)
        findings.extend(file_findings)
        parse_error: str | None = None
        parsed_procedures = 0
        try:
            reader = FortranFileReader(str(path))
            reader.set_format(FortranFormat(not fixed, False))
            tree = ParserFactory().create(std="f2008")(reader)
            module_contexts, _ = _module_state_contexts(tree, path)
            nodes = tuple(walk(tree, Subroutine_Subprogram))
            parsed_procedures = len(nodes)
            for node in nodes:
                name, start, end = _node_identity(node)
                local_findings = tuple(
                    item for item in file_findings if start <= item.line <= end
                )
                try:
                    proc_ir, _ = _build_procedure(node, path, module_contexts.get(id(node)))
                    built[name] = proc_ir
                    calls = tuple(dict.fromkeys(_calls_from_ir(proc_ir.statements)))
                    blockers = tuple(sorted({item.category for item in local_findings if item.severity == "blocking"}))
                    reviews = tuple(sorted({item.category for item in local_findings if item.severity == "review"}))
                    status = "BLOCKED" if blockers else ("REVIEW_REQUIRED" if reviews else "READY")
                    procedure_records[name] = AcceptanceProcedure(
                        name=name,
                        source_file=rel,
                        start_line=start,
                        end_line=end,
                        status=status,
                        ir_build_succeeded=True,
                        arguments=proc_ir.arguments,
                        calls=calls,
                        external_calls=(),
                        blocked_dependencies=(),
                        loop_count=_count_loops(proc_ir.statements),
                        array_symbol_count=sum(item.rank > 0 for item in proc_ir.symbols),
                        state_groups=proc_ir.state_groups,
                        blockers=blockers,
                        review_items=reviews,
                        recommended_action=_action(status, blockers, reviews),
                    )
                except (UnsupportedFortranError, ValueError) as exc:
                    message = str(exc)
                    findings.append(AcceptanceFinding(
                        "blocking", "migration_ir", message, rel, start, name
                    ))
                    raw_calls = tuple(sorted(set(_CALL.findall(_slice_lines(text, start, end).lower()))))
                    blockers = tuple(sorted({"migration_ir", *(item.category for item in local_findings if item.severity == "blocking")}))
                    reviews = tuple(sorted({item.category for item in local_findings if item.severity == "review"}))
                    procedure_records[name] = AcceptanceProcedure(
                        name=name,
                        source_file=rel,
                        start_line=start,
                        end_line=end,
                        status="BLOCKED",
                        ir_build_succeeded=False,
                        arguments=(),
                        calls=raw_calls,
                        external_calls=(),
                        blocked_dependencies=(),
                        loop_count=len(re.findall(r"^\s*DO\b", _slice_lines(text, start, end), re.IGNORECASE | re.MULTILINE)),
                        array_symbol_count=0,
                        state_groups=(),
                        blockers=blockers,
                        review_items=reviews,
                        recommended_action=f"refactor or retain in Fortran: {message}",
                    )
            file_status = _file_status(rel, procedure_records, file_findings)
        except Exception as exc:  # fparser exposes several parser exception types
            parse_error = f"{type(exc).__name__}: {exc}"
            findings.append(AcceptanceFinding("blocking", "parse_failure", parse_error, rel, 1, None))
            for name, start, end in _rough_subroutines(text):
                raw_calls = tuple(sorted(set(value.lower() for value in _CALL.findall(_slice_lines(text, start, end)))))
                procedure_records.setdefault(name, AcceptanceProcedure(
                    name=name,
                    source_file=rel,
                    start_line=start,
                    end_line=end,
                    status="BLOCKED",
                    ir_build_succeeded=False,
                    arguments=(),
                    calls=raw_calls,
                    external_calls=(),
                    blocked_dependencies=(),
                    loop_count=0,
                    array_symbol_count=0,
                    state_groups=(),
                    blockers=("parse_failure",),
                    review_items=(),
                    recommended_action="normalise or isolate this program unit before migration",
                ))
            file_status = "BLOCKED"

        blockers = sum(item.source_file == rel and item.severity == "blocking" for item in findings)
        reviews = sum(item.source_file == rel and item.severity == "review" for item in findings)
        files.append(AcceptanceFile(
            path=rel,
            source_form=source_form,
            parse_succeeded=parse_error is None,
            status=file_status,
            procedure_count=parsed_procedures or len([item for item in procedure_records.values() if item.source_file == rel]),
            parse_error=parse_error,
            blocker_count=blockers,
            review_count=reviews,
        ))

    known = set(procedure_records)
    for name, record in tuple(procedure_records.items()):
        external = tuple(sorted(set(record.calls) - known))
        if external:
            for callee in external:
                findings.append(AcceptanceFinding(
                    "blocking", "unresolved_external_call",
                    f"{name} calls {callee}, which is outside the discovered source set",
                    record.source_file, record.start_line, name,
                ))
            procedure_records[name] = replace(
                record,
                status="BLOCKED",
                external_calls=external,
                blockers=tuple(sorted(set(record.blockers) | {"unresolved_external_call"})),
                recommended_action="supply the called source or keep this orchestration path in Fortran",
            )

    # Block callers whose required dependency is blocked. Iterate to a fixed point.
    changed = True
    while changed:
        changed = False
        for name, record in tuple(procedure_records.items()):
            blocked_deps = tuple(sorted(
                callee for callee in record.calls
                if callee in procedure_records and procedure_records[callee].status == "BLOCKED"
            ))
            if blocked_deps and (record.status != "BLOCKED" or record.blocked_dependencies != blocked_deps):
                procedure_records[name] = replace(
                    record,
                    status="BLOCKED",
                    blocked_dependencies=blocked_deps,
                    blockers=tuple(sorted(set(record.blockers) | {"blocked_dependency"})),
                    recommended_action="migrate or retain blocked dependencies first: " + ", ".join(blocked_deps),
                )
                changed = True

    # Recompute file status after blocked-dependency and external-call propagation.
    files = [
        replace(
            item,
            status=(
                "BLOCKED"
                if any(proc.source_file == item.path and proc.status == "BLOCKED" for proc in procedure_records.values())
                else (
                    "REVIEW_REQUIRED"
                    if any(proc.source_file == item.path and proc.status == "REVIEW_REQUIRED" for proc in procedure_records.values())
                    or item.review_count
                    else "READY"
                )
            ),
        )
        for item in files
    ]

    root_name = procedure.lower() if procedure else None
    migration_order = _migration_order(root_name, procedure_records)
    rank_by_name = {name: index + 1 for index, name in enumerate(migration_order)}
    procedures = tuple(
        replace(item, migration_rank=rank_by_name.get(item.name))
        for item in sorted(procedure_records.values(), key=lambda item: (item.source_file, item.start_line, item.name))
    )

    project_ir: dict[str, Any]
    try:
        project = build_project_ir(source, procedure=procedure, refactor_report=refactor_report)
        project_ir = {
            "status": "PASS",
            "procedure_count": len(project.procedures),
            "state_group_count": len(project.state_groups),
            "message": None,
        }
    except (UnsupportedFortranError, ValueError, FileNotFoundError) as exc:
        project_ir = {
            "status": "BLOCKED",
            "procedure_count": 0,
            "state_group_count": 0,
            "message": str(exc),
        }
        findings.append(AcceptanceFinding("blocking", "project_ir", str(exc), _relative(source_paths[0], root_path), 1, root_name))

    refactor_summary: Mapping[str, Any] | None = None
    if refactor_report is not None:
        payload = load_refactor_report(refactor_report)
        diagnostics = payload.get("diagnostics", [])
        blocking = sum(
            str(item.get("severity", item.get("level", ""))).lower() in {"error", "fatal", "blocking"}
            or str(item.get("status", "")).lower() in {"blocked", "blocking"}
            for item in diagnostics
        )
        refactor_summary = {
            "path": str(Path(refactor_report).resolve()),
            "producer": payload.get("producer"),
            "producer_version": payload.get("producer_version"),
            "program_unit_count": len(payload.get("program_units", [])),
            "diagnostic_count": len(diagnostics),
            "blocking_diagnostic_count": blocking,
        }

    unsupported = _summarise_findings(findings)
    counts = Counter(item.status for item in procedures)
    file_counts = Counter(item.status for item in files)
    total_files = len(files)
    total_procs = len(procedures)
    parse_files = sum(item.parse_succeeded for item in files)
    ir_procs = sum(item.ir_build_succeeded for item in procedures)
    migratable = counts["READY"] + counts["REVIEW_REQUIRED"]
    summary = {
        "source_files": total_files,
        "parsed_files": parse_files,
        "procedures": total_procs,
        "ready_procedures": counts["READY"],
        "review_required_procedures": counts["REVIEW_REQUIRED"],
        "blocked_procedures": counts["BLOCKED"],
        "ready_files": file_counts["READY"],
        "review_required_files": file_counts["REVIEW_REQUIRED"],
        "blocked_files": file_counts["BLOCKED"],
        "findings": len(findings),
        "blocking_findings": sum(item.severity == "blocking" for item in findings),
        "review_findings": sum(item.severity == "review" for item in findings),
    }
    rates = {
        "file_parse_rate": _ratio(parse_files, total_files),
        "procedure_ir_build_rate": _ratio(ir_procs, total_procs),
        "procedure_migratable_rate": _ratio(migratable, total_procs),
        "procedure_ready_rate": _ratio(counts["READY"], total_procs),
    }
    status = "BLOCKED" if counts["BLOCKED"] or project_ir["status"] == "BLOCKED" else (
        "REVIEW_REQUIRED" if counts["REVIEW_REQUIRED"] else "READY"
    )
    graph = tuple(
        {"caller": name, "callee": callee, "resolved": callee in known}
        for name in sorted(procedure_records)
        for callee in procedure_records[name].calls
    )
    vertical = _vertical_slice(root_name, procedure_records, migration_order)
    retention = tuple(sorted(item.name for item in procedures if item.status == "BLOCKED"))
    return AcceptanceReport(
        schema_version="1.0",
        root=str(root_path),
        root_procedure=root_name,
        status=status,
        summary=summary,
        rates=rates,
        project_ir_build=project_ir,
        files=tuple(files),
        procedures=procedures,
        findings=tuple(findings),
        unsupported_constructs=unsupported,
        call_graph=graph,
        migration_order=migration_order,
        recommended_vertical_slice=vertical,
        fortran_retention_candidates=retention,
        refactor_report=refactor_summary,
    )


def write_acceptance_report(report: AcceptanceReport, path: str | Path) -> Path:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(report.to_dict(), indent=2), encoding="utf-8")
    return target


def validate_acceptance_report(path: str | Path) -> list[str]:
    payload = json.loads(Path(path).read_text(encoding="utf-8"))
    schema = json.loads(
        (repository_root() / "schemas/project_acceptance.schema.json").read_text(encoding="utf-8")
    )
    validator = Draft202012Validator(schema)
    errors = sorted(validator.iter_errors(payload), key=lambda item: list(item.path))
    return [f"{'/'.join(map(str, error.path)) or '<root>'}: {error.message}" for error in errors]


def write_procedure_csv(report: AcceptanceReport, path: str | Path) -> Path:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=[
            "migration_rank", "name", "status", "source_file", "start_line", "end_line",
            "ir_build_succeeded", "loop_count", "array_symbol_count", "calls",
            "external_calls", "blocked_dependencies", "blockers", "review_items",
            "recommended_action",
        ])
        writer.writeheader()
        for item in report.procedures:
            payload = asdict(item)
            for key in ("calls", "external_calls", "blocked_dependencies", "blockers", "review_items"):
                payload[key] = ";".join(payload[key])
            payload.pop("arguments", None)
            payload.pop("state_groups", None)
            writer.writerow(payload)
    return target


def write_construct_csv(report: AcceptanceReport, path: str | Path) -> Path:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=[
            "category", "severity", "occurrences", "procedure_count", "file_count", "examples"
        ])
        writer.writeheader()
        for item in report.unsupported_constructs:
            payload = asdict(item)
            payload["examples"] = ";".join(payload["examples"])
            writer.writerow(payload)
    return target


def _discover_source_paths(root: Path) -> tuple[Path, ...]:
    if root.is_file():
        return (root,)
    if not root.is_dir():
        raise FileNotFoundError(root)
    paths = tuple(sorted(
        (item.resolve() for item in root.rglob("*") if item.is_file() and item.suffix.lower() in _FORTRAN_SUFFIXES),
        key=lambda item: item.as_posix(),
    ))
    if not paths:
        raise ValueError(f"no Fortran source files found in {root}")
    return paths


def _relative(path: Path, root: Path) -> str:
    if root.is_file():
        return path.name
    return str(path.relative_to(root))


def _scan_findings(text: str, source_file: str) -> list[AcceptanceFinding]:
    findings: list[AcceptanceFinding] = []
    proc_ranges = _rough_subroutines(text)
    for category, severity, pattern, message in _PATTERN_SPECS:
        for match in pattern.finditer(text):
            line = text.count("\n", 0, match.start()) + 1
            proc = next((name for name, start, end in proc_ranges if start <= line <= end), None)
            findings.append(AcceptanceFinding(severity, category, message, source_file, line, proc))
    return findings


def _rough_subroutines(text: str) -> tuple[tuple[str, int, int], ...]:
    lines = text.splitlines()
    output: list[tuple[str, int, int]] = []
    active: tuple[str, int] | None = None
    for number, line in enumerate(lines, start=1):
        start_match = _SUBROUTINE_START.match(line)
        if start_match and active is None:
            active = (start_match.group(1).lower(), number)
            continue
        if active is not None and _SUBROUTINE_END.match(line):
            output.append((active[0], active[1], number))
            active = None
    if active is not None:
        output.append((active[0], active[1], len(lines)))
    return tuple(output)


def _node_identity(node: Subroutine_Subprogram) -> tuple[str, int, int]:
    start = node.content[0]
    end = node.content[-1]
    name = str(start.items[1]).lower()
    start_line = int(getattr(getattr(start, "item", None), "span", (1, 1))[0])
    end_line = int(getattr(getattr(end, "item", None), "span", (start_line, start_line))[0])
    return name, start_line, end_line


def _slice_lines(text: str, start: int, end: int) -> str:
    return "\n".join(text.splitlines()[start - 1:end])


def _calls_from_ir(statements: Iterable[StatementIR]) -> list[str]:
    calls: list[str] = []
    for statement in statements:
        if isinstance(statement, CallIR):
            calls.append(statement.procedure.lower())
        elif isinstance(statement, DoLoopIR):
            calls.extend(_calls_from_ir(statement.body))
        elif isinstance(statement, IfIR):
            calls.extend(_calls_from_ir(statement.body))
            calls.extend(_calls_from_ir(statement.else_body))
    return calls


def _count_loops(statements: Iterable[StatementIR]) -> int:
    total = 0
    for statement in statements:
        if isinstance(statement, DoLoopIR):
            total += 1 + _count_loops(statement.body)
        elif isinstance(statement, IfIR):
            total += _count_loops(statement.body) + _count_loops(statement.else_body)
    return total


def _file_status(path: str, procedures: Mapping[str, AcceptanceProcedure], findings: Iterable[AcceptanceFinding]) -> str:
    statuses = [item.status for item in procedures.values() if item.source_file == path]
    local_findings = [item for item in findings if item.source_file == path]
    if "BLOCKED" in statuses or any(item.severity == "blocking" for item in local_findings):
        return "BLOCKED"
    if "REVIEW_REQUIRED" in statuses or any(item.severity == "review" for item in local_findings):
        return "REVIEW_REQUIRED"
    return "READY"


def _migration_order(root: str | None, procedures: Mapping[str, AcceptanceProcedure]) -> tuple[str, ...]:
    starts = [root] if root in procedures else sorted(procedures)
    visited: set[str] = set()
    active: set[str] = set()
    order: list[str] = []

    def visit(name: str) -> None:
        if name in visited:
            return
        if name in active:
            return
        active.add(name)
        for callee in procedures[name].calls:
            if callee in procedures:
                visit(callee)
        active.remove(name)
        visited.add(name)
        order.append(name)

    for name in starts:
        visit(name)
    for name in sorted(procedures):
        visit(name)
    return tuple(order)


def _vertical_slice(root: str | None, procedures: Mapping[str, AcceptanceProcedure], order: tuple[str, ...]) -> Mapping[str, Any]:
    if root is None or root not in procedures:
        ready = [name for name in order if procedures[name].status == "READY"]
        selected = ready[:1]
        return {
            "root": selected[0] if selected else None,
            "procedures": selected,
            "status": "READY" if selected else "BLOCKED",
            "reason": "selected the first leaf-level READY procedure" if selected else "no READY procedure is available",
        }
    closure: set[str] = set()

    def collect(name: str) -> None:
        if name in closure or name not in procedures:
            return
        closure.add(name)
        for callee in procedures[name].calls:
            collect(callee)

    collect(root)
    selected = [name for name in order if name in closure]
    blocked = [name for name in selected if procedures[name].status == "BLOCKED"]
    return {
        "root": root,
        "procedures": selected,
        "status": "BLOCKED" if blocked else ("REVIEW_REQUIRED" if any(procedures[name].status == "REVIEW_REQUIRED" for name in selected) else "READY"),
        "blocked_procedures": blocked,
        "reason": "dependencies are ordered before callers; resolve blocked procedures before migrating the slice",
    }


def _summarise_findings(findings: Iterable[AcceptanceFinding]) -> tuple[UnsupportedConstructSummary, ...]:
    grouped: dict[tuple[str, str], list[AcceptanceFinding]] = defaultdict(list)
    for item in findings:
        grouped[(item.category, item.severity)].append(item)
    summaries = []
    for (category, severity), items in sorted(grouped.items()):
        examples = tuple(
            f"{item.source_file}:{item.line}" + (f" ({item.procedure})" if item.procedure else "")
            for item in items[:5]
        )
        summaries.append(UnsupportedConstructSummary(
            category=category,
            severity=severity,
            occurrences=len(items),
            procedure_count=len({item.procedure for item in items if item.procedure}),
            file_count=len({item.source_file for item in items}),
            examples=examples,
        ))
    return tuple(summaries)


def _action(status: str, blockers: tuple[str, ...], reviews: tuple[str, ...]) -> str:
    if status == "READY":
        return "build Migration IR and establish a Fortran/Python regression case"
    if status == "REVIEW_REQUIRED":
        return "normalise and review before conversion: " + ", ".join(reviews)
    return "refactor or retain in Fortran: " + ", ".join(blockers)


def _ratio(numerator: int, denominator: int) -> float:
    return float(numerator / denominator) if denominator else 0.0
