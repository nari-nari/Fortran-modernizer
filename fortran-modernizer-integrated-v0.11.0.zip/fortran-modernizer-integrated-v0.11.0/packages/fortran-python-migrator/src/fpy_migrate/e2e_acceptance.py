from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass
import hashlib
import json
import math
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
from typing import Any, Mapping

from jsonschema import Draft202012Validator
import numpy as np

from .acceptance import diagnose_project, write_acceptance_report
from .intake import repository_root
from .orchestration import (
    OrchestrationError,
    _evaluate_constants,
    _evaluate_expression,
    _fortran_declaration,
    _fortran_expr,
    _fortran_type,
    analyze_orchestration,
    build_orchestration,
    load_generated_application,
)
from .refactor_bridge import RefactorBridgeError, verify_refactor_connection


class E2EAcceptanceError(RuntimeError):
    """Raised when an end-to-end migration acceptance gate cannot be satisfied."""


def _checkpoint(root: Path, name: str) -> None:
    (root / "e2e_progress.log").open("a", encoding="utf-8").write(name + "\n")


@dataclass(frozen=True)
class SourceFingerprint:
    root: str
    aggregate_sha256: str
    files: tuple[dict[str, object], ...]

    def to_dict(self) -> dict[str, object]:
        return {
            "root": self.root,
            "aggregate_sha256": self.aggregate_sha256,
            "files": list(self.files),
        }


@dataclass(frozen=True)
class Snapshot:
    scalars: dict[str, int | float | bool]
    states: dict[str, np.ndarray]


@dataclass(frozen=True)
class Comparison:
    passed: bool
    scalar_differences: dict[str, dict[str, object]]
    state_differences: dict[str, dict[str, object]]
    finite: bool

    def to_dict(self) -> dict[str, object]:
        return {
            "passed": self.passed,
            "finite": self.finite,
            "scalar_differences": self.scalar_differences,
            "state_differences": self.state_differences,
        }


def fingerprint_source(path: str | Path) -> SourceFingerprint:
    source = Path(path).resolve()
    if not source.exists():
        raise E2EAcceptanceError(f"source path does not exist: {source}")
    if source.is_file():
        paths = (source,)
        root = source.parent
    else:
        paths = tuple(
            item
            for item in sorted(source.rglob("*"))
            if item.is_file()
            and "__MACOSX" not in item.parts
            and not item.name.startswith("._")
        )
        root = source
    records: list[dict[str, object]] = []
    aggregate = hashlib.sha256()
    for item in paths:
        relative = item.relative_to(root).as_posix()
        digest = hashlib.sha256(item.read_bytes()).hexdigest()
        size = item.stat().st_size
        records.append({"path": relative, "sha256": digest, "size": size})
        aggregate.update(relative.encode("utf-8"))
        aggregate.update(b"\0")
        aggregate.update(digest.encode("ascii"))
        aggregate.update(b"\n")
    if not records:
        raise E2EAcceptanceError(f"source path contains no files: {source}")
    return SourceFingerprint(str(source), aggregate.hexdigest(), tuple(records))


def validate_e2e_report(path: str | Path) -> list[str]:
    payload = json.loads(Path(path).read_text(encoding="utf-8"))
    schema = json.loads(
        (repository_root() / "schemas/e2e_acceptance.schema.json").read_text(
            encoding="utf-8"
        )
    )
    errors = sorted(
        Draft202012Validator(schema).iter_errors(payload),
        key=lambda item: list(item.path),
    )
    return [
        f"{'/'.join(map(str, item.path)) or '<root>'}: {item.message}"
        for item in errors
    ]


def verify_e2e_acceptance(
    legacy_source: str | Path,
    normalized_source: str | Path,
    *,
    program: str,
    adapter_config: str | Path,
    handoff: str | Path,
    handoff_procedure: str,
    build_directory: str | Path,
    output: str | Path,
    rtol: float = 1.0e-12,
    atol: float = 1.0e-13,
    include_fortran: bool = True,
) -> Path:
    root = Path(build_directory).resolve()
    if root.exists():
        shutil.rmtree(root)
    root.mkdir(parents=True)
    _checkpoint(root, "start")

    legacy_fp = fingerprint_source(legacy_source)
    _checkpoint(root, "fingerprint_legacy")
    normalized_fp = fingerprint_source(normalized_source)
    _checkpoint(root, "fingerprint_normalized")
    handoff_path = Path(handoff).resolve()
    handoff_payload = json.loads(handoff_path.read_text(encoding="utf-8"))
    fingerprint_gate = _verify_fingerprint_contract(
        handoff_payload, legacy_fp, normalized_fp
    )
    if not fingerprint_gate["passed"]:
        raise E2EAcceptanceError(
            "source fingerprint does not match the canonical refactoring hand-off"
        )

    connection_path = verify_refactor_connection(
        normalized_source,
        handoff_path,
        root / "refactor_connection.json",
        procedure=handoff_procedure,
    )
    connection = json.loads(connection_path.read_text(encoding="utf-8"))
    _checkpoint(root, "connection")
    if connection["status"] != "PASS":
        raise E2EAcceptanceError(
            f"refactoring hand-off connection is {connection['status']}"
        )

    legacy_acceptance = diagnose_project(legacy_source)
    legacy_acceptance_path = write_acceptance_report(
        legacy_acceptance, root / "legacy_source_acceptance.json"
    )
    _checkpoint(root, "legacy_source_diagnostic")
    if legacy_acceptance.status != "BLOCKED":
        raise E2EAcceptanceError(
            "raw legacy source was expected to remain BLOCKED before normalization"
        )

    negative_controls = _run_negative_controls(
        normalized_source,
        handoff_path,
        handoff_procedure,
        root / "negative_controls",
    )
    _checkpoint(root, "negative_controls")
    if not all(item["passed"] for item in negative_controls.values()):
        raise E2EAcceptanceError("one or more negative acceptance controls failed")

    _checkpoint(root, "before_analyze_orchestration")
    plan, inventory, project = analyze_orchestration(
        normalized_source,
        program=program,
        adapter_config=adapter_config,
        refactor_report=handoff_path,
    )

    _checkpoint(root, "after_analyze_orchestration")
    app_root = root / "generated_application"
    manifest, manifest_path = build_orchestration(
        normalized_source,
        program=program,
        adapter_config=adapter_config,
        build_directory=app_root,
        refactor_report=handoff_path,
        default_backend="python",
        include_fortran=include_fortran,
    )
    _checkpoint(root, "orchestration_built")
    available_backends = tuple(manifest.available_backends)
    application = app_root / manifest.artifacts["application"]
    module = load_generated_application(
        application,
        module_name=f"fpy_e2e_application_{abs(hash(str(root)))}",
    )
    raw_backend_results: dict[str, dict[str, object]] = {}
    snapshots_root = root / "backend_snapshots"
    snapshots_root.mkdir(parents=True, exist_ok=True)
    for backend in available_backends:
        result, states = module.run_with_state(backend=backend, run_adapters=False)
        snapshot_path = snapshots_root / f"{backend}.npz"
        state_payload: dict[str, np.ndarray] = {}
        for group_name, state in states.items():
            for field_name, value in vars(state).items():
                state_payload[f"{group_name}__{field_name}"] = np.asarray(value).copy()
        np.savez(snapshot_path, **state_payload)
        raw_backend_results[backend] = {
            "scalars": {
                field: getattr(result, field)
                for field in result.__dataclass_fields__
            },
            "state_path": str(snapshot_path),
        }
    _checkpoint(root, "backends_worker_done")

    baseline_root = root / "fortran_baselines"
    legacy = _build_and_run_fortran_baseline(
        legacy_source,
        baseline_root / "legacy",
        plan=plan,
        inventory=inventory,
        project=project,
        program=program,
        label="legacy",
    )
    _checkpoint(root, "legacy_baseline")
    normalized = _build_and_run_fortran_baseline(
        normalized_source,
        baseline_root / "normalized",
        plan=plan,
        inventory=inventory,
        project=project,
        program=program,
        label="normalized",
    )
    _checkpoint(root, "normalized_baseline")
    _write_snapshot(legacy, baseline_root / "legacy_snapshot.npz")
    _write_snapshot(normalized, baseline_root / "normalized_snapshot.npz")

    normalized_vs_legacy = compare_snapshots(legacy, normalized, rtol=rtol, atol=atol)
    if not normalized_vs_legacy.passed:
        raise E2EAcceptanceError(
            "normalized Fortran does not match the original legacy Fortran baseline"
        )
    _checkpoint(root, "baseline_comparison")

    backend_results: dict[str, dict[str, object]] = {}
    for backend in available_backends:
        _checkpoint(root, f"compare_backend_{backend}")
        item = raw_backend_results[backend]
        snapshot_path = Path(item["state_path"])
        with np.load(snapshot_path, allow_pickle=False) as payload:
            states = {name: np.asarray(payload[name]).copy() for name in payload.files}
        snapshot = Snapshot(dict(item["scalars"]), states)
        comparison = compare_snapshots(legacy, snapshot, rtol=rtol, atol=atol)
        if not comparison.passed:
            raise E2EAcceptanceError(
                f"generated backend {backend} does not match legacy Fortran"
            )
        backend_results[backend] = {
            "snapshot": str(snapshot_path.relative_to(root)),
            "scalars": snapshot.scalars,
            "comparison_to_legacy": comparison.to_dict(),
        }

    _checkpoint(root, "all_backends_compared")
    report = {
        "schema_version": "1.0",
        "status": "PASS",
        "program": program.lower(),
        "handoff_procedure": handoff_procedure.lower(),
        "inputs": {
            "legacy_source": str(Path(legacy_source).resolve()),
            "normalized_source": str(Path(normalized_source).resolve()),
            "adapter_config": str(Path(adapter_config).resolve()),
            "handoff": str(handoff_path),
        },
        "fingerprints": {
            "legacy": legacy_fp.to_dict(),
            "normalized": normalized_fp.to_dict(),
            "gate": fingerprint_gate,
        },
        "legacy_migration_gate": {
            "expected": "BLOCKED",
            "observed": legacy_acceptance.status,
            "passed": legacy_acceptance.status == "BLOCKED",
            "report": str(legacy_acceptance_path.relative_to(root)),
        },
        "handoff": {
            "connection_report": str(connection_path.relative_to(root)),
            "status": connection["status"],
            "coverage": connection["coverage"],
            "negative_controls": negative_controls,
        },
        "tolerances": {"rtol": rtol, "atol": atol},
        "fortran_baselines": {
            "legacy_snapshot": "fortran_baselines/legacy_snapshot.npz",
            "normalized_snapshot": "fortran_baselines/normalized_snapshot.npz",
            "legacy_scalars": legacy.scalars,
            "normalized_scalars": normalized.scalars,
            "normalized_vs_legacy": normalized_vs_legacy.to_dict(),
        },
        "generated_application": {
            "manifest": str(manifest_path.relative_to(root)),
            "available_backends": list(available_backends),
            "backends": backend_results,
        },
        "state_fields": {
            key: {"shape": list(value.shape), "dtype": str(value.dtype)}
            for key, value in legacy.states.items()
        },
        "artifacts": {
            "build_root": str(root),
            "report": str(Path(output).resolve()),
        },
    }
    _checkpoint(root, "report_constructed")
    target = Path(output).resolve()
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    _checkpoint(root, "report_written")
    errors = validate_e2e_report(target)
    if errors:
        raise E2EAcceptanceError(
            "generated E2E acceptance report failed schema validation: "
            + "; ".join(errors)
        )
    _checkpoint(root, "complete")
    return target


def compare_snapshots(
    expected: Snapshot,
    actual: Snapshot,
    *,
    rtol: float,
    atol: float,
) -> Comparison:
    scalar_differences: dict[str, dict[str, object]] = {}
    state_differences: dict[str, dict[str, object]] = {}
    passed = True
    finite = True

    if expected.scalars.keys() != actual.scalars.keys():
        passed = False
    for name in sorted(expected.scalars.keys() | actual.scalars.keys()):
        left = expected.scalars.get(name)
        right = actual.scalars.get(name)
        if left is None or right is None:
            scalar_differences[name] = {
                "passed": False,
                "expected": left,
                "actual": right,
                "reason": "missing scalar",
            }
            passed = False
            continue
        if isinstance(left, bool) or isinstance(right, bool):
            item_pass = bool(left) is bool(right)
            difference = 0.0 if item_pass else 1.0
        elif isinstance(left, int) and isinstance(right, int):
            item_pass = left == right
            difference = abs(left - right)
        else:
            left_float = float(left)
            right_float = float(right)
            finite = finite and math.isfinite(left_float) and math.isfinite(right_float)
            difference = abs(left_float - right_float)
            item_pass = math.isclose(left_float, right_float, rel_tol=rtol, abs_tol=atol)
        scalar_differences[name] = {
            "passed": item_pass,
            "expected": left,
            "actual": right,
            "absolute_difference": difference,
        }
        passed = passed and item_pass

    if expected.states.keys() != actual.states.keys():
        passed = False
    for name in sorted(expected.states.keys() | actual.states.keys()):
        left = expected.states.get(name)
        right = actual.states.get(name)
        if left is None or right is None:
            state_differences[name] = {
                "passed": False,
                "reason": "missing state field",
            }
            passed = False
            continue
        shape_match = left.shape == right.shape
        if not shape_match:
            state_differences[name] = {
                "passed": False,
                "expected_shape": list(left.shape),
                "actual_shape": list(right.shape),
            }
            passed = False
            continue
        left_float = np.asarray(left, dtype=np.float64)
        right_float = np.asarray(right, dtype=np.float64)
        field_finite = bool(np.isfinite(left_float).all() and np.isfinite(right_float).all())
        finite = finite and field_finite
        difference = np.abs(left_float - right_float)
        max_abs = float(np.max(difference)) if difference.size else 0.0
        denominator = np.maximum(np.abs(left_float), atol)
        max_rel = float(np.max(difference / denominator)) if difference.size else 0.0
        item_pass = field_finite and bool(
            np.allclose(left_float, right_float, rtol=rtol, atol=atol)
        )
        state_differences[name] = {
            "passed": item_pass,
            "shape": list(left.shape),
            "max_absolute_difference": max_abs,
            "max_relative_difference": max_rel,
        }
        passed = passed and item_pass
    return Comparison(passed and finite, scalar_differences, state_differences, finite)


def _verify_fingerprint_contract(
    handoff: Mapping[str, Any],
    legacy: SourceFingerprint,
    normalized: SourceFingerprint,
) -> dict[str, object]:
    expected = handoff.get("project", {}).get("source_fingerprints", {})
    expected_legacy = expected.get("legacy", {}).get("aggregate_sha256")
    expected_normalized = expected.get("normalized", {}).get("aggregate_sha256")
    if not expected_legacy or not expected_normalized:
        raise E2EAcceptanceError(
            "canonical hand-off must include project.source_fingerprints for legacy and normalized sources"
        )
    legacy_match = expected_legacy == legacy.aggregate_sha256
    normalized_match = expected_normalized == normalized.aggregate_sha256
    return {
        "passed": legacy_match and normalized_match,
        "legacy": {
            "expected": expected_legacy,
            "actual": legacy.aggregate_sha256,
            "matched": legacy_match,
        },
        "normalized": {
            "expected": expected_normalized,
            "actual": normalized.aggregate_sha256,
            "matched": normalized_match,
        },
    }


def _run_negative_controls(
    source: str | Path,
    handoff: Path,
    procedure: str,
    output_directory: Path,
) -> dict[str, dict[str, object]]:
    output_directory.mkdir(parents=True, exist_ok=True)
    base = json.loads(handoff.read_text(encoding="utf-8"))
    controls: dict[str, dict[str, object]] = {}

    mutations: dict[str, dict[str, Any]] = {}

    type_payload = deepcopy(base)
    type_symbol = next(
        (item for item in type_payload["symbols"] if item.get("category") == "real"),
        None,
    )
    if type_symbol is None:
        raise E2EAcceptanceError("cannot create type-mismatch negative control")
    type_symbol["category"] = "integer"
    mutations["type_mismatch"] = type_payload

    rank_payload = deepcopy(base)
    rank_symbol = next(
        (item for item in rank_payload["symbols"] if int(item.get("rank", 0)) > 0),
        None,
    )
    if rank_symbol is None:
        raise E2EAcceptanceError("cannot create rank-mismatch negative control")
    rank_symbol["rank"] = int(rank_symbol["rank"]) - 1
    mutations["rank_mismatch"] = rank_payload

    common_payload = deepcopy(base)
    declarations = [
        declaration
        for block in common_payload.get("common_blocks", [])
        for declaration in block.get("declarations", [])
        if len(declaration.get("members", [])) >= 2
    ]
    if not declarations:
        raise E2EAcceptanceError("cannot create COMMON-position negative control")
    members = declarations[0]["members"]
    members[0], members[1] = members[1], members[0]
    members[0]["position"] = 1
    members[1]["position"] = 2
    mutations["common_position_mismatch"] = common_payload

    for name, payload in mutations.items():
        report_path = output_directory / f"{name}_handoff.json"
        report_path.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
        connection_path = output_directory / f"{name}_connection.json"
        try:
            verify_refactor_connection(
                source,
                report_path,
                connection_path,
                procedure=procedure,
            )
            connection = json.loads(connection_path.read_text(encoding="utf-8"))
            observed = connection["status"]
        except (RefactorBridgeError, ValueError) as exc:
            observed = "BLOCKED"
            connection_path.write_text(
                json.dumps({"status": "BLOCKED", "error": str(exc)}, indent=2) + "\n",
                encoding="utf-8",
            )
        controls[name] = {
            "expected": "BLOCKED",
            "observed": observed,
            "passed": observed == "BLOCKED",
            "report": str(connection_path.relative_to(output_directory.parent)),
        }

    fingerprint_payload = deepcopy(base)
    fingerprint_payload["project"]["source_fingerprints"]["normalized"][
        "aggregate_sha256"
    ] = "0" * 64
    normalized_fp = fingerprint_source(source)
    expected = fingerprint_payload["project"]["source_fingerprints"]["normalized"][
        "aggregate_sha256"
    ]
    observed = "BLOCKED" if expected != normalized_fp.aggregate_sha256 else "PASS"
    controls["source_fingerprint_mismatch"] = {
        "expected": "BLOCKED",
        "observed": observed,
        "passed": observed == "BLOCKED",
    }
    return controls


def _build_and_run_fortran_baseline(
    source: str | Path,
    build_directory: Path,
    *,
    plan: Any,
    inventory: Any,
    project: Any,
    program: str,
    label: str,
) -> Snapshot:
    build_directory.mkdir(parents=True, exist_ok=True)
    staged = build_directory / "source"
    _stage_fortran_without_program(source, staged, program)
    driver = build_directory / "e2e_driver.f90"
    driver.write_text(
        _render_fortran_dump_driver(plan, inventory, project, label=label),
        encoding="utf-8",
    )
    source_files = tuple(
        item
        for item in sorted(staged.rglob("*"))
        if item.is_file() and item.suffix.lower() in {".f", ".for", ".ftn", ".f90", ".f95", ".f03", ".f08"}
    )
    if not source_files:
        raise E2EAcceptanceError(f"no Fortran sources found after staging {source}")
    include_dirs = sorted(
        {staged, *(item.parent for item in staged.rglob("*.inc"))},
        key=str,
    )
    executable = build_directory / f"{label}_baseline"
    command = [
        "gfortran",
        "-O2",
        "-std=legacy",
        "-ffixed-line-length-none",
        *(f"-I{item}" for item in include_dirs),
        *(str(item) for item in source_files),
        str(driver),
        "-o",
        str(executable),
    ]
    completed = subprocess.run(
        command,
        check=False,
        capture_output=True,
        text=True,
        timeout=120,
    )
    (build_directory / "compile_command.json").write_text(
        json.dumps(
            {
                "command": command,
                "returncode": completed.returncode,
                "stdout": completed.stdout,
                "stderr": completed.stderr,
            },
            indent=2,
        ) + "\n",
        encoding="utf-8",
    )
    if completed.returncode != 0:
        raise E2EAcceptanceError(
            f"failed to compile {label} Fortran baseline: {completed.stderr}"
        )
    run = subprocess.run(
        [str(executable)],
        check=True,
        capture_output=True,
        text=True,
        timeout=60,
    )
    (build_directory / "output.txt").write_text(run.stdout, encoding="utf-8")
    return _parse_fortran_snapshot(run.stdout)


def _stage_fortran_without_program(
    source: str | Path, target: Path, program: str
) -> None:
    source_path = Path(source).resolve()
    target.mkdir(parents=True, exist_ok=True)
    if source_path.is_file():
        files = (source_path,)
        source_root = source_path.parent
    else:
        files = tuple(
            item
            for item in sorted(source_path.rglob("*"))
            if item.is_file()
            and "__MACOSX" not in item.parts
            and not item.name.startswith("._")
        )
        source_root = source_path
    for item in files:
        relative = item.name if source_path.is_file() else item.relative_to(source_root)
        destination = target / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        if item.suffix.lower() in {".f", ".for", ".ftn", ".f90", ".f95", ".f03", ".f08"}:
            text = item.read_text(encoding="utf-8")
            stripped, found = _remove_program_text(text, program)
            destination.write_text(stripped if found else text, encoding="utf-8")
        else:
            shutil.copy2(item, destination)


def _remove_program_text(text: str, program: str) -> tuple[str, bool]:
    lines = text.splitlines(keepends=True)
    start_pattern = re.compile(rf"^\s*program\s+{re.escape(program)}\b", re.IGNORECASE)
    explicit_end = re.compile(
        rf"^\s*end\s+program(?:\s+{re.escape(program)})?\s*$", re.IGNORECASE
    )
    generic_end = re.compile(r"^\s*end\s*$", re.IGNORECASE)
    start: int | None = None
    end: int | None = None
    for index, line in enumerate(lines):
        code = line[6:] if len(line) >= 6 and line[:5].strip().isdigit() else line
        if start is None and start_pattern.match(code):
            start = index
            continue
        if start is not None and (explicit_end.match(code) or generic_end.match(code)):
            end = index
            break
    if start is None or end is None:
        return text, False
    return "".join(lines[:start] + lines[end + 1 :]), True


def _render_fortran_dump_driver(
    plan: Any, inventory: Any, project: Any, *, label: str
) -> str:
    lines = [f"program fpy_e2e_{_safe_name(label)}", "  implicit none"]
    for constant in inventory.constants:
        lines.append(
            f"  {_fortran_type(constant.type)}, parameter :: {constant.name} = "
            f"{_fortran_expr(constant.value)}"
        )
    for symbol in inventory.symbols:
        lines.append(f"  {_fortran_declaration(symbol)}")
    lines.extend(["  integer :: fpy_i, fpy_j", ""])
    for block_name, names in inventory.common_blocks:
        lines.append(f"  common /{block_name}/ {', '.join(names)}")
    lines.append("")
    for call in plan.numeric_calls:
        arguments = ", ".join(_fortran_expr(item) for item in call.arguments)
        suffix = f"({arguments})" if arguments else ""
        lines.append(f"  call {call.procedure}{suffix}")
    lines.append("  write(*,'(A)') 'FPY_E2E_V1'")
    symbol_by_name = {item.name: item for item in inventory.symbols}
    for field in plan.result_fields:
        if field.type.category == "integer":
            lines.append(
                f"  write(*,'(A,I0)') 'SCALAR {field.name} integer ', {field.name}"
            )
        elif field.type.category == "logical":
            lines.append(
                f"  write(*,'(A,L1)') 'SCALAR {field.name} logical ', {field.name}"
            )
        else:
            lines.append(
                f"  write(*,'(A,ES26.17E3)') 'SCALAR {field.name} real ', {field.name}"
            )
    constant_values = _evaluate_constants(inventory.constants)
    for group in project.state_groups:
        for field in group.fields:
            field_name = field.state_field or field.name
            symbol = next(
                (
                    item
                    for item in inventory.symbols
                    if item.state_group == group.name
                    and (item.state_field or item.name) == field_name
                ),
                symbol_by_name.get(field_name),
            )
            if symbol is None:
                raise E2EAcceptanceError(
                    f"cannot map state field {group.name}.{field_name} into the main program"
                )
            key = f"{group.name}__{field_name}"
            if symbol.rank == 0:
                format_spec = "I0" if symbol.type.category == "integer" else "ES26.17E3"
                lines.append(
                    f"  write(*,'(A,{format_spec})') 'STATE_SCALAR {key} {symbol.type.category} ', {symbol.name}"
                )
                continue
            dimensions = [
                int(_evaluate_expression(item, constant_values))
                for item in symbol.shape
                if item is not None
            ]
            if len(dimensions) != symbol.rank:
                raise E2EAcceptanceError(f"cannot resolve state shape for {key}")
            lines.append(
                f"  write(*,'(A)') 'ARRAY {key} {symbol.rank} {' '.join(map(str, dimensions))}'"
            )
            if symbol.rank == 1:
                lines.extend(
                    [
                        f"  do fpy_i = 1, {dimensions[0]}",
                        f"    write(*,'(ES26.17E3)') {symbol.name}(fpy_i)",
                        "  end do",
                    ]
                )
            elif symbol.rank == 2:
                lines.extend(
                    [
                        f"  do fpy_j = 1, {dimensions[1]}",
                        f"    do fpy_i = 1, {dimensions[0]}",
                        f"      write(*,'(ES26.17E3)') {symbol.name}(fpy_i,fpy_j)",
                        "    end do",
                        "  end do",
                    ]
                )
            else:
                raise E2EAcceptanceError(
                    f"E2E Fortran dump currently supports rank <= 2: {key}"
                )
    lines.extend(["  write(*,'(A)') 'END_FPY_E2E'", f"end program fpy_e2e_{_safe_name(label)}", ""])
    return "\n".join(lines)


def _parse_fortran_snapshot(text: str) -> Snapshot:
    lines = [item.strip() for item in text.splitlines() if item.strip()]
    try:
        index = lines.index("FPY_E2E_V1") + 1
    except ValueError as exc:
        raise E2EAcceptanceError("Fortran baseline did not emit FPY_E2E_V1") from exc
    scalars: dict[str, int | float | bool] = {}
    states: dict[str, np.ndarray] = {}
    while index < len(lines):
        line = lines[index]
        if line == "END_FPY_E2E":
            break
        if line.startswith("SCALAR ") or line.startswith("STATE_SCALAR "):
            parts = line.split(maxsplit=3)
            if len(parts) != 4:
                raise E2EAcceptanceError(f"invalid scalar line: {line}")
            marker, name, category, value = parts
            parsed: int | float | bool
            if category == "integer":
                parsed = int(value)
            elif category == "logical":
                parsed = value.upper().startswith("T")
            else:
                parsed = float(value.replace("D", "E"))
            if marker == "SCALAR":
                scalars[name] = parsed
            else:
                states[name] = np.asarray(parsed)
            index += 1
            continue
        if line.startswith("ARRAY "):
            parts = line.split()
            name = parts[1]
            rank = int(parts[2])
            shape = tuple(int(item) for item in parts[3:])
            if len(shape) != rank:
                raise E2EAcceptanceError(f"invalid ARRAY shape: {line}")
            count = math.prod(shape)
            values = [
                float(lines[index + 1 + offset].replace("D", "E"))
                for offset in range(count)
            ]
            states[name] = np.asarray(values, dtype=np.float64).reshape(shape, order="F")
            index += count + 1
            continue
        raise E2EAcceptanceError(f"unrecognised Fortran E2E line: {line}")
    return Snapshot(scalars, states)


def _write_snapshot(snapshot: Snapshot, path: Path) -> None:
    payload = {f"state__{name}": value for name, value in snapshot.states.items()}
    for name, value in snapshot.scalars.items():
        payload[f"scalar__{name}"] = np.asarray(value)
    path.parent.mkdir(parents=True, exist_ok=True)
    np.savez(path, **payload)


def _safe_name(value: str) -> str:
    return re.sub(r"[^a-zA-Z0-9_]", "_", value).lower()
