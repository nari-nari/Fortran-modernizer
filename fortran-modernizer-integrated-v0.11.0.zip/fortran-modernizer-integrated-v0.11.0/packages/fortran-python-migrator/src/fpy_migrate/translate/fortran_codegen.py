from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from fpy_migrate.ir.model import (
    AssignmentIR,
    CallIR,
    DoLoopIR,
    ExpressionIR,
    ExitIR,
    IfIR,
    ProcedureIR,
    ProjectIR,
    StatementIR,
    SymbolIR,
    TypeIR,
)
from fpy_migrate.translate.intrinsics import normalize_intrinsic


@dataclass(frozen=True)
class GeneratedFortran:
    source: str
    procedure: str
    bind_name: str


def generate_fortran_kernel(
    project: ProjectIR,
    procedure: str,
    *,
    bind_name: str | None = None,
) -> GeneratedFortran:
    """Generate a C-interoperable Fortran kernel for the supported Migration IR.

    Arrays are received as C pointers plus explicit dimensions.  The generated
    Fortran pointer view reverses dimensions and array indices, so a C-contiguous
    NumPy array keeps the same logical indexing as generated Python/Cython code.
    """

    proc = project.procedure(procedure)
    resolved_bind_name = bind_name or f"fpy_{proc.name}"
    generator = _FortranKernelGenerator(proc, resolved_bind_name)
    return GeneratedFortran(
        source=generator.render(),
        procedure=proc.name,
        bind_name=resolved_bind_name,
    )


def write_fortran(generated: GeneratedFortran, path: str | Path) -> Path:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(generated.source, encoding="utf-8")
    return target


class _FortranKernelGenerator:
    def __init__(self, procedure: ProcedureIR, bind_name: str):
        self.procedure = procedure
        self.bind_name = bind_name
        self.symbols = {item.name: item for item in procedure.symbols}
        self.c_array_arguments = {
            name for name in procedure.arguments if self.symbols[name].rank > 0
        }
        self.lines: list[str] = []

    def render(self) -> str:
        if any(isinstance(item, CallIR) for item in self._walk(self.procedure.statements)):
            raise ValueError(
                f"{self.procedure.name}: Fortran kernel generation requires a call-free IR body"
            )
        for symbol in self.procedure.symbols:
            if symbol.role == "local" and symbol.rank:
                raise ValueError(
                    f"{self.procedure.name}: local arrays are not supported by the Fortran C ABI yet: {symbol.name}"
                )

        abi_arguments: list[str] = []
        for name in self.procedure.arguments:
            symbol = self.symbols[name]
            if symbol.rank:
                abi_arguments.append(f"{name}_ptr")
                abi_arguments.extend(f"{name}_dim{index}" for index in range(1, symbol.rank + 1))
            else:
                abi_arguments.append(name)

        self.lines = [
            self._wrapped_subroutine_header(abi_arguments),
            "  use iso_c_binding, only: c_ptr, c_f_pointer, c_int, c_double, c_bool",
            "  implicit none",
        ]
        self._emit_constant_declarations()
        self._emit_argument_declarations()
        self._emit_local_declarations()
        self._emit_pointer_associations()
        for statement in self.procedure.statements:
            self._emit_statement(statement, indent=1)
        self.lines.append(f"end subroutine {self.procedure.name}_c")
        self.lines.append("")
        return "\n".join(self.lines)

    def _wrapped_subroutine_header(self, arguments: list[str]) -> str:
        prefix = f"subroutine {self.procedure.name}_c("
        suffix = f") bind(C, name=\"{self.bind_name}\")"
        if len(prefix) + len(", ".join(arguments)) + len(suffix) <= 118:
            return f"{prefix}{', '.join(arguments)}{suffix}"
        lines = [prefix + " &"]
        for index, argument in enumerate(arguments):
            comma = "," if index < len(arguments) - 1 else ""
            lines.append(f"  {argument}{comma} &")
        lines[-1] = lines[-1][:-2] + suffix
        return "\n".join(lines)

    def _emit_constant_declarations(self) -> None:
        for constant in self.procedure.constants:
            self.lines.append(
                f"  {self._type_decl_from_type(constant.type)}, parameter :: "
                f"{constant.name} = {self._expr(constant.value)}"
            )

    def _emit_argument_declarations(self) -> None:
        for name in self.procedure.arguments:
            symbol = self.symbols[name]
            if symbol.rank:
                self.lines.append(
                    f"  type(c_ptr), value, intent(in) :: {name}_ptr"
                )
                dims = ", ".join(f"{name}_dim{index}" for index in range(1, symbol.rank + 1))
                self.lines.append(
                    f"  integer(c_int), value, intent(in) :: {dims}"
                )
                shape = ", ".join(":" for _ in range(symbol.rank))
                self.lines.append(
                    f"  {self._type_decl(symbol)}, pointer :: {name}({shape})"
                )
                continue
            attrs = [self._type_decl(symbol)]
            if symbol.intent == "in":
                attrs.extend(["value", "intent(in)"])
            elif symbol.intent == "out":
                attrs.append("intent(out)")
            elif symbol.intent == "inout":
                attrs.append("intent(inout)")
            self.lines.append(f"  {', '.join(attrs)} :: {name}")

    def _emit_local_declarations(self) -> None:
        for symbol in self.procedure.symbols:
            if symbol.role != "local":
                continue
            self.lines.append(f"  {self._type_decl(symbol)} :: {symbol.name}")

    def _emit_pointer_associations(self) -> None:
        for name in self.procedure.arguments:
            symbol = self.symbols[name]
            if not symbol.rank:
                continue
            reversed_dims = ", ".join(
                f"{name}_dim{index}" for index in range(symbol.rank, 0, -1)
            )
            self.lines.append(
                f"  call c_f_pointer({name}_ptr, {name}, [{reversed_dims}])"
            )

    def _emit_statement(self, statement: StatementIR, indent: int) -> None:
        prefix = "  " * indent
        if isinstance(statement, AssignmentIR):
            self.lines.append(
                f"{prefix}{self._expr(statement.target)} = {self._expr(statement.value)}"
            )
            return
        if isinstance(statement, DoLoopIR):
            self.lines.append(
                f"{prefix}do {statement.variable} = {self._expr(statement.start)}, "
                f"{self._expr(statement.stop)}, {self._expr(statement.step)}"
            )
            for child in statement.body:
                self._emit_statement(child, indent + 1)
            self.lines.append(f"{prefix}end do")
            return
        if isinstance(statement, IfIR):
            self.lines.append(f"{prefix}if ({self._expr(statement.condition)}) then")
            for child in statement.body:
                self._emit_statement(child, indent + 1)
            if statement.else_body:
                self.lines.append(f"{prefix}else")
                for child in statement.else_body:
                    self._emit_statement(child, indent + 1)
            self.lines.append(f"{prefix}end if")
            return
        if isinstance(statement, ExitIR):
            self.lines.append(f"{prefix}exit")
            return
        if isinstance(statement, CallIR):
            raise ValueError(
                f"{self.procedure.name}: calls are not supported in generated Fortran kernels"
            )
        raise TypeError(type(statement))

    def _expr(self, expression: ExpressionIR) -> str:
        if expression.kind == "name":
            return str(expression.value)
        if expression.kind == "literal":
            if isinstance(expression.value, bool):
                return ".true." if expression.value else ".false."
            if isinstance(expression.value, float):
                text = f"{expression.value:.17g}"
                if "." not in text and "e" not in text.lower():
                    text += ".0"
                return f"{text}_c_double"
            return str(expression.value)
        if expression.kind == "binary":
            left, right = expression.arguments
            operators = {
                "and": ".and.",
                "or": ".or.",
                "==": "==",
                "!=": "/=",
            }
            operator = operators.get(str(expression.operator), str(expression.operator))
            return f"({self._expr(left)} {operator} {self._expr(right)})"
        if expression.kind == "unary":
            (operand,) = expression.arguments
            operator = ".not." if expression.operator == "not" else str(expression.operator)
            return f"({operator} {self._expr(operand)})"
        if expression.kind == "array_ref":
            name = str(expression.value)
            indices = list(expression.indices)
            if name in self.c_array_arguments and len(indices) > 1:
                indices.reverse()
            return f"{name}({', '.join(self._expr(item) for item in indices)})"
        if expression.kind == "intrinsic":
            original_name = str(expression.value).lower()
            name = normalize_intrinsic(original_name)
            if name == "real":
                first = self._expr(expression.arguments[0])
                return f"real({first}, c_double)"
            args = ", ".join(self._expr(item) for item in expression.arguments)
            if name not in {
                "acos", "atan", "cos", "sin", "sqrt", "abs", "max", "min", "huge"
            }:
                raise ValueError(
                    f"unsupported intrinsic for Fortran kernel generation: {original_name}"
                )
            return f"{name}({args})"
        raise ValueError(f"unsupported expression kind for Fortran generation: {expression.kind}")

    @staticmethod
    def _type_decl(symbol: SymbolIR) -> str:
        return _FortranKernelGenerator._type_decl_from_type(symbol.type)

    @staticmethod
    def _type_decl_from_type(type_ir: TypeIR) -> str:
        mapping = {
            "integer": "integer(c_int)",
            "real": "real(c_double)",
            "logical": "logical(c_bool)",
        }
        try:
            return mapping[type_ir.category]
        except KeyError as exc:
            raise ValueError(
                f"unsupported Fortran C ABI type: {type_ir.category}"
            ) from exc

    @staticmethod
    def _walk(statements: tuple[StatementIR, ...]):
        for statement in statements:
            yield statement
            if isinstance(statement, DoLoopIR):
                yield from _FortranKernelGenerator._walk(statement.body)
            elif isinstance(statement, IfIR):
                yield from _FortranKernelGenerator._walk(statement.body)
                yield from _FortranKernelGenerator._walk(statement.else_body)
