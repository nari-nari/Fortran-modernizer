from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import re

from fpy_migrate.ir.model import (
    AssignmentIR,
    CallIR,
    DoLoopIR,
    ExpressionIR,
    ExitIR,
    IfIR,
    ProcedureIR,
    ProjectIR,
    StateGroupIR,
    StatementIR,
    SymbolIR,
)
from fpy_migrate.translate.intrinsics import (
    infer_expression_category,
    normalize_intrinsic,
    python_huge_expression,
    python_intrinsic_target,
)


@dataclass(frozen=True)
class GeneratedPython:
    source: str
    procedure: str


def generate_python(project: ProjectIR, procedure: str | None = None) -> GeneratedPython:
    if procedure is None:
        if len(project.procedures) != 1:
            raise ValueError("exactly one root procedure must be selected for Python generation")
        root = project.procedures[0].name
    else:
        root = procedure.lower()
        if not any(item.name == root for item in project.procedures):
            raise ValueError(f"procedure not present in Migration IR: {procedure}")
    generator = _ModuleGenerator(project, root)
    return GeneratedPython(source=generator.render(), procedure=root)


def write_python(generated: GeneratedPython, path: str | Path) -> Path:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(generated.source, encoding="utf-8")
    return target


def _state_argument(group_name: str) -> str:
    return f"state_{re.sub(r'[^a-zA-Z0-9_]', '_', group_name).lower()}"


def _state_class(group_name: str) -> str:
    parts = [item for item in re.split(r"[^a-zA-Z0-9]+|_+", group_name) if item]
    return "".join(item[:1].upper() + item[1:] for item in parts) + "State"


class _ModuleGenerator:
    def __init__(self, project: ProjectIR, root: str):
        self.project = project
        self.root = root
        self.procedures = {item.name: item for item in project.procedures}
        self.state_groups = {item.name: item for item in project.state_groups}

    def render(self) -> str:
        lines = [
            '"""Generated from Fortran by fpy-migrate. Do not edit by hand."""',
            "",
            "from dataclasses import dataclass",
            "import math",
            "",
            "import numpy as np",
            "import numpy.typing as npt",
            "",
            "FloatArray = npt.NDArray[np.float64]",
            "IntArray = npt.NDArray[np.int64]",
            "BoolArray = npt.NDArray[np.bool_]",
            "",
        ]
        for group in self.project.state_groups:
            lines.extend(self._render_state_group(group))
            lines.append("")
        # build_project_ir returns dependencies before their callers.
        for procedure in self.project.procedures:
            procedure_lines = _ProcedureGenerator(
                procedure, self.procedures, self.state_groups
            ).render()
            lines.extend(procedure_lines)
            lines.append("")
        return "\n".join(lines)

    def _render_state_group(self, group: StateGroupIR) -> list[str]:
        lines = [
            "@dataclass",
            f"class {_state_class(group.name)}:",
            f"    # Fortran {group.source_kind}: {group.source_name}",
        ]
        if not group.fields:
            lines.append("    pass")
            return lines
        for field in group.fields:
            lines.append(f"    {field.state_field or field.name}: {self._python_type(field)}")
        return lines

    @staticmethod
    def _python_type(symbol: SymbolIR) -> str:
        if symbol.rank:
            mapping = {
                "real": "FloatArray",
                "integer": "IntArray",
                "logical": "BoolArray",
            }
            if symbol.type.category not in mapping:
                raise ValueError(f"unsupported Python state array type: {symbol.type.category}")
            return mapping[symbol.type.category]
        mapping = {"real": "float", "integer": "int", "logical": "bool"}
        if symbol.type.category not in mapping:
            raise ValueError(f"unsupported Python state scalar type: {symbol.type.category}")
        return mapping[symbol.type.category]


class _ProcedureGenerator:
    def __init__(
        self,
        procedure: ProcedureIR,
        procedures: dict[str, ProcedureIR],
        state_groups: dict[str, StateGroupIR],
    ):
        self.procedure = procedure
        self.procedures = procedures
        self.state_groups = state_groups
        self.symbols = {item.name: item for item in procedure.symbols}
        self.constants = {item.name: item for item in procedure.constants}
        self.lines: list[str] = []

    def render(self) -> list[str]:
        input_arguments = [
            name
            for name in self.procedure.arguments
            if self.symbols[name].intent != "out"
        ]
        declarations = [
            f"{_state_argument(group)}: {_state_class(group)}"
            for group in self.procedure.state_groups
        ]
        declarations.extend(self._argument_declaration(name) for name in input_arguments)
        args = ", ".join(declarations)
        return_type = self._return_type()
        self.lines = [f"def {self.procedure.name}({args}) -> {return_type}:"]
        self.lines.append(
            f"    # Source: {self.procedure.source_span.file}:"
            f"{self.procedure.source_span.start_line}-{self.procedure.source_span.end_line}"
        )
        self._emit_constants()
        self._emit_output_allocations()
        for statement in self.procedure.statements:
            self._emit_statement(statement, indent=1)
        outputs = self._outputs()
        if not outputs:
            self.lines.append("    return None")
        elif len(outputs) == 1:
            self.lines.append(f"    return {outputs[0].name}")
        else:
            self.lines.append(f"    return {', '.join(item.name for item in outputs)}")
        return self.lines

    def _emit_constants(self) -> None:
        for constant in self.procedure.constants:
            self.lines.append(f"    {constant.name} = {self._expr(constant.value)}")

    def _outputs(self) -> list[SymbolIR]:
        return [
            self.symbols[name]
            for name in self.procedure.arguments
            if self.symbols[name].intent in {"out", "inout"}
        ]

    def _argument_declaration(self, name: str) -> str:
        return f"{name}: {self._python_type(self.symbols[name])}"

    def _return_type(self) -> str:
        outputs = self._outputs()
        if not outputs:
            return "None"
        types = [self._python_type(item) for item in outputs]
        return types[0] if len(types) == 1 else f"tuple[{', '.join(types)}]"

    def _python_type(self, symbol: SymbolIR) -> str:
        if symbol.rank:
            mapping = {
                "real": "FloatArray",
                "integer": "IntArray",
                "logical": "BoolArray",
            }
            if symbol.type.category not in mapping:
                raise ValueError(f"unsupported Python array type: {symbol.type.category}")
            return mapping[symbol.type.category]
        mapping = {"real": "float", "integer": "int", "logical": "bool"}
        if symbol.type.category not in mapping:
            raise ValueError(f"unsupported Python scalar type: {symbol.type.category}")
        return mapping[symbol.type.category]

    def _emit_output_allocations(self) -> None:
        for symbol in self._outputs():
            if symbol.intent != "out" or symbol.rank == 0:
                continue
            if any(item is None for item in symbol.shape):
                raise ValueError(
                    f"cannot allocate assumed-shape intent(out) array {symbol.name}; "
                    "use intent(inout) or provide explicit extents"
                )
            dtype = {
                "real": "np.float64",
                "integer": "np.int64",
                "logical": "np.bool_",
            }.get(symbol.type.category)
            if dtype is None:
                raise ValueError(f"unsupported output array type: {symbol.type.category}")
            shape = ", ".join(self._expr(item) for item in symbol.shape if item is not None)
            if symbol.rank == 1:
                shape += ","
            self.lines.append(f"    {symbol.name} = np.empty(({shape}), dtype={dtype})")

    def _emit_statement(self, statement: StatementIR, indent: int) -> None:
        prefix = "    " * indent
        if isinstance(statement, AssignmentIR):
            target = self._assignment_target(statement.target)
            self.lines.append(f"{prefix}{target} = {self._expr(statement.value)}")
            return
        if isinstance(statement, DoLoopIR):
            start = self._expr(statement.start)
            stop = self._expr(statement.stop)
            step = self._expr(statement.step)
            if step == "1":
                self.lines.append(f"{prefix}for {statement.variable} in range({start}, ({stop}) + 1):")
            else:
                self.lines.append(
                    f"{prefix}for {statement.variable} in range({start}, "
                    f"({stop}) + (1 if ({step}) > 0 else -1), {step}):"
                )
            if statement.body:
                for child in statement.body:
                    self._emit_statement(child, indent + 1)
            else:
                self.lines.append(f"{prefix}    pass")
            return
        if isinstance(statement, IfIR):
            self.lines.append(f"{prefix}if {self._expr(statement.condition)}:")
            if statement.body:
                for child in statement.body:
                    self._emit_statement(child, indent + 1)
            else:
                self.lines.append(f"{prefix}    pass")
            if statement.else_body:
                self.lines.append(f"{prefix}else:")
                for child in statement.else_body:
                    self._emit_statement(child, indent + 1)
            return
        if isinstance(statement, ExitIR):
            self.lines.append(f"{prefix}break")
            return
        if isinstance(statement, CallIR):
            self._emit_call(statement, indent)
            return
        raise TypeError(type(statement))

    def _state_reference(self, symbol: SymbolIR) -> str:
        if not symbol.state_group or not symbol.state_field:
            raise ValueError(f"invalid state symbol metadata: {symbol.name}")
        return f"{_state_argument(symbol.state_group)}.{symbol.state_field}"

    def _name_reference(self, name: str) -> str:
        symbol = self.symbols.get(name)
        if symbol is not None and symbol.role == "state":
            return self._state_reference(symbol)
        return name

    def _assignment_target(self, expression: ExpressionIR) -> str:
        if expression.kind == "name":
            name = str(expression.value)
            symbol = self.symbols.get(name)
            base = self._name_reference(name)
            if symbol is not None and symbol.rank > 0:
                return f"{base}[...]"
            return base
        return self._expr(expression)

    def _emit_call(self, statement: CallIR, indent: int) -> None:
        prefix = "    " * indent
        try:
            callee = self.procedures[statement.procedure]
        except KeyError as exc:
            raise ValueError(f"unresolved called procedure in code generation: {statement.procedure}") from exc
        missing_groups = set(callee.state_groups) - set(self.procedure.state_groups)
        if missing_groups:
            raise ValueError(
                f"{self.procedure.name} cannot supply state groups required by {callee.name}: "
                f"{sorted(missing_groups)}"
            )
        inputs: list[ExpressionIR] = []
        outputs: list[ExpressionIR] = []
        for formal_name, actual in zip(callee.arguments, statement.arguments, strict=True):
            formal = callee.symbol(formal_name)
            if formal.intent != "out":
                inputs.append(actual)
            if formal.intent in {"out", "inout"}:
                outputs.append(actual)
        call_arguments = [_state_argument(group) for group in callee.state_groups]
        call_arguments.extend(self._expr(item) for item in inputs)
        call_text = f"{callee.name}({', '.join(call_arguments)})"
        if not outputs:
            self.lines.append(f"{prefix}{call_text}")
        elif len(outputs) == 1:
            self.lines.append(f"{prefix}{self._expr(outputs[0])} = {call_text}")
        else:
            targets = ", ".join(self._expr(item) for item in outputs)
            self.lines.append(f"{prefix}{targets} = {call_text}")

    def _expr(self, expression: ExpressionIR) -> str:
        if expression.kind == "name":
            return self._name_reference(str(expression.value))
        if expression.kind == "literal":
            return repr(expression.value)
        if expression.kind == "binary":
            left, right = expression.arguments
            return f"({self._expr(left)} {expression.operator} {self._expr(right)})"
        if expression.kind == "unary":
            (operand,) = expression.arguments
            if expression.operator == "not":
                return f"(not {self._expr(operand)})"
            return f"({expression.operator}{self._expr(operand)})"
        if expression.kind == "array_ref":
            indices = ", ".join(f"({self._expr(item)}) - 1" for item in expression.indices)
            return f"{self._name_reference(str(expression.value))}[{indices}]"
        if expression.kind == "intrinsic":
            original_name = str(expression.value)
            name = normalize_intrinsic(original_name)
            args = expression.arguments
            if name == "real":
                return f"float({self._expr(args[0])})"
            if name == "huge":
                category = infer_expression_category(args[0], self.symbols, self.constants)
                return python_huge_expression(category)
            target = python_intrinsic_target(name)
            if target is None:
                raise ValueError(
                    f"unsupported intrinsic for Python generation: {original_name}"
                )
            return f"{target}({', '.join(self._expr(item) for item in args)})"
        raise ValueError(f"unsupported expression kind: {expression.kind}")
