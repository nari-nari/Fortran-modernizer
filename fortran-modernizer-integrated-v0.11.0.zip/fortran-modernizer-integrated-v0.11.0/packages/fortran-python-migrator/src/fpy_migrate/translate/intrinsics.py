from __future__ import annotations

from collections.abc import Mapping

from fpy_migrate.ir.model import ConstantIR, ExpressionIR, SymbolIR


_INTRINSIC_ALIASES = {
    "dble": "real",
    "dacos": "acos",
    "datan": "atan",
    "dcos": "cos",
    "dsin": "sin",
    "dsqrt": "sqrt",
    "dabs": "abs",
}

_PYTHON_TARGETS = {
    "acos": "math.acos",
    "atan": "math.atan",
    "cos": "math.cos",
    "sin": "math.sin",
    "sqrt": "math.sqrt",
    "abs": "abs",
    "max": "max",
    "min": "min",
}


def normalize_intrinsic(name: str) -> str:
    lowered = name.lower()
    return _INTRINSIC_ALIASES.get(lowered, lowered)


def python_intrinsic_target(name: str) -> str | None:
    return _PYTHON_TARGETS.get(normalize_intrinsic(name))


def infer_expression_category(
    expression: ExpressionIR,
    symbols: Mapping[str, SymbolIR],
    constants: Mapping[str, ConstantIR],
) -> str:
    if expression.kind == "literal":
        if isinstance(expression.value, bool):
            return "logical"
        if isinstance(expression.value, int):
            return "integer"
        if isinstance(expression.value, float):
            return "real"
        raise ValueError(f"unsupported literal type: {expression.value!r}")
    if expression.kind in {"name", "array_ref"}:
        name = str(expression.value)
        if name in symbols:
            return symbols[name].type.category
        if name in constants:
            return constants[name].type.category
        raise ValueError(f"cannot infer type of unresolved name: {name}")
    if expression.kind == "unary":
        if expression.operator == "not":
            return "logical"
        return infer_expression_category(expression.arguments[0], symbols, constants)
    if expression.kind == "binary":
        if expression.operator in {"and", "or", "==", "!=", "<", "<=", ">", ">="}:
            return "logical"
        categories = {
            infer_expression_category(item, symbols, constants)
            for item in expression.arguments
        }
        return "real" if "real" in categories else "integer"
    if expression.kind == "intrinsic":
        name = normalize_intrinsic(str(expression.value))
        if name in {"real", "acos", "atan", "cos", "sin", "sqrt"}:
            return "real"
        if name == "huge":
            if len(expression.arguments) != 1:
                raise ValueError("HUGE requires exactly one argument")
            return infer_expression_category(expression.arguments[0], symbols, constants)
        if name == "abs":
            return infer_expression_category(expression.arguments[0], symbols, constants)
        if name in {"max", "min"}:
            categories = {
                infer_expression_category(item, symbols, constants)
                for item in expression.arguments
            }
            return "real" if "real" in categories else "integer"
    raise ValueError(f"cannot infer expression category: {expression}")


def python_huge_expression(category: str) -> str:
    if category == "real":
        return "np.finfo(np.float64).max"
    if category == "integer":
        # The generated integer ABI uses a C int / NumPy int32 contract.
        return "int(np.iinfo(np.int32).max)"
    raise ValueError(f"HUGE is not supported for category {category}")
