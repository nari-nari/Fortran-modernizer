from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Literal

from fpy_migrate.ir.model import (
    AssignmentIR,
    CallIR,
    DoLoopIR,
    ExpressionIR,
    ExitIR,
    IfIR,
    ProcedureIR,
    ProjectIR,
    StatementIR,
    SymbolIR,
)
from fpy_migrate.translate.intrinsics import (
    infer_expression_category,
    normalize_intrinsic,
    python_huge_expression,
    python_intrinsic_target,
)


CythonSafetyMode = Literal["safe", "optimized"]


@dataclass(frozen=True)
class GeneratedCython:
    source: str
    procedure: str
    safety_mode: CythonSafetyMode = "safe"


def generate_cython(
    project: ProjectIR,
    procedure: str | None = None,
    *,
    safety_mode: CythonSafetyMode = "safe",
) -> GeneratedCython:
    if safety_mode not in {"safe", "optimized"}:
        raise ValueError(f"unsupported Cython safety mode: {safety_mode}")
    if project.state_groups:
        raise ValueError(
            "state-object procedures are not compiled directly with Cython; "
            "extract explicit-array kernels and keep the state wrapper in Python"
        )
    if procedure is None:
        if len(project.procedures) != 1:
            raise ValueError("exactly one root procedure must be selected for Cython generation")
        root = project.procedures[0].name
    else:
        root = procedure.lower()
        if not any(item.name == root for item in project.procedures):
            raise ValueError(f"procedure not present in Migration IR: {procedure}")

    generator = _CythonModuleGenerator(project, root, safety_mode)
    return GeneratedCython(
        source=generator.render(),
        procedure=root,
        safety_mode=safety_mode,
    )


def write_cython(generated: GeneratedCython, path: str | Path) -> Path:
    target = Path(path)
    if target.suffix != ".py":
        raise ValueError("Cython Pure Python Mode output must use the .py suffix")
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(generated.source, encoding="utf-8")
    return target


class _CythonModuleGenerator:
    def __init__(self, project: ProjectIR, root: str, safety_mode: CythonSafetyMode):
        self.project = project
        self.root = root
        self.safety_mode = safety_mode
        self.procedures = {item.name: item for item in project.procedures}

    def render(self) -> str:
        checks = self.safety_mode == "safe"
        lines = [
            "# cython: language_level=3, "
            f"boundscheck={checks}, wraparound={checks}, "
            f"initializedcheck={checks}, cdivision=True",
            f'"""Generated Cython {self.safety_mode} kernel from Fortran by fpy-migrate."""',
            "",
            "import math",
            "",
            "import cython",
            "import numpy as np",
            "",
        ]
        for procedure in self.project.procedures:
            lines.extend(
                _CythonProcedureGenerator(
                    procedure,
                    self.procedures,
                    safety_mode=self.safety_mode,
                ).render()
            )
            lines.append("")
        return "\n".join(lines)


class _CythonProcedureGenerator:
    def __init__(
        self,
        procedure: ProcedureIR,
        procedures: dict[str, ProcedureIR],
        *,
        safety_mode: CythonSafetyMode,
    ):
        self.procedure = procedure
        self.procedures = procedures
        self.safety_mode = safety_mode
        self.symbols = {item.name: item for item in procedure.symbols}
        self.constants = {item.name: item for item in procedure.constants}
        self.lines: list[str] = []

    @property
    def optimized(self) -> bool:
        return self.safety_mode == "optimized"

    def render(self) -> list[str]:
        input_arguments = [
            name for name in self.procedure.arguments if self.symbols[name].intent != "out"
        ]
        args = ", ".join(self._argument_declaration(name) for name in input_arguments)
        checks = not self.optimized
        self.lines = [
            f"@cython.boundscheck({checks})",
            f"@cython.wraparound({checks})",
            f"@cython.initializedcheck({checks})",
            "@cython.cdivision(True)",
            f"def {self.procedure.name}({args}):",
            f"    # Source: {self.procedure.source_span.file}:"
            f"{self.procedure.source_span.start_line}-{self.procedure.source_span.end_line}",
        ]
        self._emit_constants()
        self._emit_local_declarations(input_arguments)
        self._emit_output_allocations()
        for statement in self.procedure.statements:
            self._emit_statement(statement, indent=1)
        outputs = self._outputs()
        if not outputs:
            self.lines.append("    return None")
        elif len(outputs) == 1:
            self.lines.append(f"    return {outputs[0].name}")
        else:
            self.lines.append(f"    return {', '.join(item.name for item in outputs)}")
        return self.lines

    def _emit_constants(self) -> None:
        type_mapping = {
            "real": "cython.double",
            "integer": "cython.int",
            "logical": "cython.bint",
        }
        for constant in self.procedure.constants:
            try:
                cython_type = type_mapping[constant.type.category]
            except KeyError as exc:
                raise ValueError(
                    f"unsupported Cython constant type: {constant.type.category}"
                ) from exc
            self.lines.append(
                f"    {constant.name}: {cython_type} = {self._expr(constant.value)}"
            )

    def _outputs(self) -> list[SymbolIR]:
        return [
            self.symbols[name]
            for name in self.procedure.arguments
            if self.symbols[name].intent in {"out", "inout"}
        ]

    def _argument_declaration(self, name: str) -> str:
        return f"{name}: {self._cython_type(self.symbols[name])}"

    def _emit_local_declarations(self, input_arguments: list[str]) -> None:
        input_set = set(input_arguments)
        for symbol in self.procedure.symbols:
            if symbol.name in input_set:
                continue
            if symbol.rank and symbol.role == "local":
                raise ValueError(
                    f"local arrays are not supported by Cython generation yet: {symbol.name}"
                )
            self.lines.append(f"    {symbol.name}: {self._cython_type(symbol)}")

    def _cython_type(self, symbol: SymbolIR) -> str:
        scalar = {
            "real": "cython.double",
            "integer": "cython.int",
            "logical": "cython.bint",
        }.get(symbol.type.category)
        if scalar is None:
            raise ValueError(f"unsupported Cython type: {symbol.type.category}")
        if symbol.rank == 0:
            return scalar
        if self.optimized:
            # The generated FDM loops advance the last Python index in the inner
            # loop. Requiring C-contiguous inputs makes that access unit-stride.
            if symbol.rank == 1:
                dimensions = "::1"
            else:
                dimensions = ", ".join(
                    [":"] * (symbol.rank - 1) + ["::1"]
                )
        else:
            dimensions = ", ".join(":" for _ in range(symbol.rank))
        return f"{scalar}[{dimensions}]"

    def _emit_output_allocations(self) -> None:
        for symbol in self._outputs():
            if symbol.intent != "out" or symbol.rank == 0:
                continue
            if any(item is None for item in symbol.shape):
                raise ValueError(
                    f"cannot allocate assumed-shape intent(out) array {symbol.name}; "
                    "use intent(inout) or provide explicit extents"
                )
            dtype = {
                "real": "np.float64",
                "integer": "np.int32",
                "logical": "np.bool_",
            }.get(symbol.type.category)
            if dtype is None:
                raise ValueError(f"unsupported output array type: {symbol.type.category}")
            shape = ", ".join(self._expr(item) for item in symbol.shape if item is not None)
            if symbol.rank == 1:
                shape += ","
            order = "" if self.optimized or symbol.rank < 2 else ", order='F'"
            self.lines.append(
                f"    {symbol.name} = np.empty(({shape}), dtype={dtype}{order})"
            )

    def _emit_statement(
        self,
        statement: StatementIR,
        indent: int,
        substitutions: dict[str, ExpressionIR] | None = None,
    ) -> None:
        prefix = "    " * indent
        if isinstance(statement, AssignmentIR):
            target = self._assignment_target(statement.target, substitutions)
            self.lines.append(
                f"{prefix}{target} = "
                f"{self._expr(statement.value, substitutions)}"
            )
            return
        if isinstance(statement, DoLoopIR):
            start = self._expr(statement.start, substitutions)
            stop = self._expr(statement.stop, substitutions)
            step = self._expr(statement.step, substitutions)
            variable = statement.variable
            if substitutions and variable in substitutions:
                variable = self._expr(substitutions[variable], substitutions)
            if step == "1":
                self.lines.append(f"{prefix}for {variable} in range({start}, ({stop}) + 1):")
            else:
                self.lines.append(
                    f"{prefix}for {variable} in range({start}, "
                    f"({stop}) + (1 if ({step}) > 0 else -1), {step}):"
                )
            if statement.body:
                for child in statement.body:
                    self._emit_statement(child, indent + 1, substitutions)
            else:
                self.lines.append(f"{prefix}    pass")
            return
        if isinstance(statement, IfIR):
            self.lines.append(
                f"{prefix}if {self._expr(statement.condition, substitutions)}:"
            )
            if statement.body:
                for child in statement.body:
                    self._emit_statement(child, indent + 1, substitutions)
            else:
                self.lines.append(f"{prefix}    pass")
            if statement.else_body:
                self.lines.append(f"{prefix}else:")
                for child in statement.else_body:
                    self._emit_statement(child, indent + 1, substitutions)
            return
        if isinstance(statement, ExitIR):
            self.lines.append(f"{prefix}break")
            return
        if isinstance(statement, CallIR):
            self._emit_call(statement, indent, substitutions)
            return
        raise TypeError(type(statement))

    def _assignment_target(
        self,
        expression: ExpressionIR,
        substitutions: dict[str, ExpressionIR] | None = None,
    ) -> str:
        expression = self._substitute_expression(expression, substitutions)
        if expression.kind == "name":
            symbol = self.symbols.get(str(expression.value))
            if symbol is not None and symbol.rank > 0:
                return f"{expression.value}[...]"
        return self._expr(expression)

    def _emit_call(
        self,
        statement: CallIR,
        indent: int,
        substitutions: dict[str, ExpressionIR] | None = None,
    ) -> None:
        prefix = "    " * indent
        try:
            callee = self.procedures[statement.procedure]
        except KeyError as exc:
            raise ValueError(
                f"unresolved called procedure in Cython generation: {statement.procedure}"
            ) from exc

        actual_arguments = tuple(
            self._substitute_expression(item, substitutions) for item in statement.arguments
        )
        if self.optimized and self._can_inline(callee):
            mapping = dict(zip(callee.arguments, actual_arguments, strict=True))
            self.lines.append(f"{prefix}# Inlined leaf call: {callee.name}")
            for child in callee.statements:
                self._emit_statement(child, indent, mapping)
            return

        inputs: list[ExpressionIR] = []
        outputs: list[ExpressionIR] = []
        for formal_name, actual in zip(callee.arguments, actual_arguments, strict=True):
            formal = callee.symbol(formal_name)
            if formal.intent != "out":
                inputs.append(actual)
            if formal.intent in {"out", "inout"}:
                outputs.append(actual)
        call_text = f"{callee.name}({', '.join(self._expr(item) for item in inputs)})"
        if not outputs:
            self.lines.append(f"{prefix}{call_text}")
        elif len(outputs) == 1:
            self.lines.append(f"{prefix}{self._expr(outputs[0])} = {call_text}")
        else:
            targets = ", ".join(self._expr(item) for item in outputs)
            self.lines.append(f"{prefix}{targets} = {call_text}")

    @staticmethod
    def _can_inline(procedure: ProcedureIR) -> bool:
        if procedure.constants:
            return False
        if any(symbol.rank for symbol in procedure.symbols):
            return False

        def supported(items: tuple[StatementIR, ...]) -> bool:
            for item in items:
                if isinstance(item, (DoLoopIR, CallIR)):
                    return False
                if isinstance(item, IfIR) and not (
                    supported(item.body) and supported(item.else_body)
                ):
                    return False
            return True

        return supported(procedure.statements)

    def _substitute_expression(
        self,
        expression: ExpressionIR,
        substitutions: dict[str, ExpressionIR] | None,
    ) -> ExpressionIR:
        if not substitutions:
            return expression
        if expression.kind == "name" and str(expression.value) in substitutions:
            return substitutions[str(expression.value)]
        if expression.kind in {"binary", "unary", "intrinsic"}:
            return ExpressionIR(
                kind=expression.kind,
                value=expression.value,
                operator=expression.operator,
                arguments=tuple(
                    self._substitute_expression(item, substitutions)
                    for item in expression.arguments
                ),
                indices=expression.indices,
            )
        if expression.kind == "array_ref":
            mapped_value = expression.value
            if str(expression.value) in substitutions:
                replacement = substitutions[str(expression.value)]
                if replacement.kind != "name":
                    raise ValueError("array substitution requires a named actual argument")
                mapped_value = replacement.value
            return ExpressionIR(
                kind="array_ref",
                value=mapped_value,
                indices=tuple(
                    self._substitute_expression(item, substitutions)
                    for item in expression.indices
                ),
            )
        return expression

    def _expr(
        self,
        expression: ExpressionIR | None,
        substitutions: dict[str, ExpressionIR] | None = None,
    ) -> str:
        if expression is None:
            raise ValueError("missing expression")
        expression = self._substitute_expression(expression, substitutions)
        if expression.kind == "name":
            return str(expression.value)
        if expression.kind == "literal":
            return repr(expression.value)
        if expression.kind == "binary":
            left, right = expression.arguments
            return f"({self._expr(left)} {expression.operator} {self._expr(right)})"
        if expression.kind == "unary":
            (operand,) = expression.arguments
            if expression.operator == "not":
                return f"(not {self._expr(operand)})"
            return f"({expression.operator}{self._expr(operand)})"
        if expression.kind == "array_ref":
            indices = ", ".join(
                f"({self._expr(item)}) - 1" for item in expression.indices
            )
            return f"{expression.value}[{indices}]"
        if expression.kind == "intrinsic":
            original_name = str(expression.value)
            name = normalize_intrinsic(original_name)
            args = expression.arguments
            if name == "real":
                return f"float({self._expr(args[0])})"
            if name == "huge":
                category = infer_expression_category(args[0], self.symbols, self.constants)
                return python_huge_expression(category)
            target = python_intrinsic_target(name)
            if target is None:
                raise ValueError(
                    f"unsupported intrinsic for Cython generation: {original_name}"
                )
            return f"{target}({', '.join(self._expr(item) for item in args)})"
        raise ValueError(f"unsupported expression kind: {expression.kind}")
