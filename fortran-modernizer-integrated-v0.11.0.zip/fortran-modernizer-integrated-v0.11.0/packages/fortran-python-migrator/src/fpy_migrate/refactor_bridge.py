from __future__ import annotations

import hashlib
import json
import re
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence

from jsonschema import Draft202012Validator

from .intake import repository_root, validate_refactor_report
from .ir import ProjectIR, build_project_ir
from .ir.model import CallIR, DoLoopIR, IfIR, StatementIR


class RefactorBridgeError(ValueError):
    """Raised when a refactoring-tool bundle cannot be normalised safely."""


@dataclass(frozen=True)
class BridgeIssue:
    severity: str
    category: str
    message: str
    procedure: str | None = None
    symbol: str | None = None
    source_file: str | None = None
    line: int | None = None


@dataclass(frozen=True)
class RefactorConnectionReport:
    schema_version: str
    status: str
    producer: str
    producer_version: str | None
    source: str
    root_procedure: str | None
    canonical_report: str
    discovered_report_files: tuple[str, ...]
    summary: Mapping[str, int]
    coverage: Mapping[str, float]
    issues: tuple[BridgeIssue, ...]

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


_COLLECTION_ALIASES: dict[str, tuple[str, ...]] = {
    "program_units": (
        "program_units", "programunits", "procedures", "procedure_inventory",
        "program_unit_inventory", "units",
    ),
    "symbols": (
        "symbols", "variables", "declarations", "symbol_inventory",
        "variable_inventory", "entities",
    ),
    "common_blocks": (
        "common_blocks", "commonblocks", "common_layouts", "common_inventory",
        "common_occurrences",
    ),
    "calls": (
        "calls", "call_edges", "callgraph_edges", "call_graph_edges",
        "edges",
    ),
    "diagnostics": (
        "diagnostics", "findings", "issues", "messages",
    ),
    "source_map": (
        "source_map", "sourcemap", "source_locations",
    ),
    "regression_cases": (
        "regression_cases", "test_cases", "reference_cases",
    ),
}


def import_refactor_bundle(
    bundle: str | Path,
    output: str | Path,
    *,
    producer: str = "fortran-refactor-tool",
    producer_version: str | None = None,
    project_root: str | Path | None = None,
) -> Path:
    bundle_path = Path(bundle)
    files = _json_files(bundle_path)
    if not files:
        raise RefactorBridgeError(f"no JSON reports found under {bundle_path}")

    loaded: list[tuple[Path, Any]] = []
    parse_errors: list[dict[str, Any]] = []
    for path in files:
        try:
            loaded.append((path, json.loads(path.read_text(encoding="utf-8"))))
        except (OSError, json.JSONDecodeError) as exc:
            parse_errors.append({
                "severity": "warning",
                "category": "report-parse",
                "message": f"could not parse {path}: {exc}",
                "source_file": str(path),
            })

    # A canonical hand-off file may already be present in the report bundle.
    for path, payload in loaded:
        if _looks_canonical(payload):
            canonical = dict(payload)
            canonical.setdefault("handoff_metadata", {})
            canonical["handoff_metadata"].update({
                "imported_from": str(bundle_path),
                "report_files": [str(item) for item in files],
                "canonical_source": str(path),
            })
            target = _write_json(canonical, output)
            errors = validate_refactor_report(target)
            if errors:
                raise RefactorBridgeError("canonical report failed validation:\n" + "\n".join(errors))
            return target

    collections: dict[str, list[tuple[Path, Any]]] = {key: [] for key in _COLLECTION_ALIASES}
    metadata: dict[str, Any] = {}
    for path, payload in loaded:
        _collect_aliases(payload, path, collections)
        if isinstance(payload, dict):
            metadata.update(_extract_metadata(payload))

    program_units = _normalise_program_units(collections["program_units"])
    symbols = _normalise_symbols(collections["symbols"])
    common_blocks = _normalise_common_blocks(collections["common_blocks"], symbols)
    calls = _normalise_calls(collections["calls"])
    diagnostics = _normalise_diagnostics(collections["diagnostics"])
    diagnostics.extend(parse_errors)

    if not program_units:
        raise RefactorBridgeError(
            "no program-unit inventory could be recognised; export a machine-readable "
            "procedure/program-unit report or provide a canonical hand-off JSON"
        )

    root = str(project_root or metadata.get("project_root") or metadata.get("root") or bundle_path)
    inferred_version = producer_version or _text(metadata, "version", "tool_version", "package_version")
    canonical = {
        "schema_version": "1.0",
        "producer": producer,
        "producer_version": inferred_version,
        "project": {"root": root},
        "program_units": program_units,
        "symbols": symbols,
        "common_blocks": common_blocks,
        "calls": calls,
        "diagnostics": diagnostics,
        "source_map": _normalise_passthrough(collections["source_map"]),
        "regression_cases": _normalise_passthrough(collections["regression_cases"]),
        "handoff_metadata": {
            "imported_from": str(bundle_path),
            "report_files": [str(item) for item in files],
            "collection_counts": {
                "program_units": len(program_units),
                "symbols": len(symbols),
                "common_blocks": len(common_blocks),
                "calls": len(calls),
                "diagnostics": len(diagnostics),
            },
        },
    }
    target = _write_json(canonical, output)
    errors = validate_refactor_report(target)
    if errors:
        raise RefactorBridgeError("normalised hand-off failed validation:\n" + "\n".join(errors))
    return target


def verify_refactor_connection(
    source: str | Path,
    report: str | Path,
    output: str | Path,
    *,
    procedure: str | None = None,
) -> Path:
    report_path = Path(report)
    errors = validate_refactor_report(report_path)
    if errors:
        raise RefactorBridgeError("invalid canonical hand-off:\n" + "\n".join(errors))
    payload = json.loads(report_path.read_text(encoding="utf-8"))
    project = build_project_ir(source, procedure=procedure)
    issues: list[BridgeIssue] = []
    _verify_source_hashes(Path(source), payload, issues)
    _evaluate_storage_overlays(payload.get("storage_overlays", []), issues)

    units: dict[str, dict[str, Any]] = {}
    for item in payload.get("program_units", []):
        for key in (item.get("name"), item.get("qualified_name"), item.get("scope_id")):
            if key:
                units[str(key).lower()] = item
    symbols_by_proc: dict[str, dict[str, dict[str, Any]]] = {}
    for item in payload.get("symbols", []):
        proc_keys = {
            str(item.get("program_unit", "")).lower(),
            str(item.get("qualified_program_unit", "")).lower(),
            str(item.get("scope_id", "")).lower(),
        }
        for proc in proc_keys - {""}:
            symbols_by_proc.setdefault(proc, {})[str(item.get("name", "")).lower()] = item

    matched_units = 0
    matched_symbols = 0
    expected_symbols = 0
    for proc in project.procedures:
        external = units.get(proc.name.lower())
        if external is None:
            issues.append(BridgeIssue("error", "program-unit-missing", f"report has no program unit {proc.name}", procedure=proc.name))
            continue
        matched_units += 1
        report_args = tuple(str(value).lower() for value in external.get("arguments", []))
        if report_args and report_args != proc.arguments:
            issues.append(BridgeIssue("error", "argument-mismatch", f"AST={proc.arguments}, report={report_args}", procedure=proc.name))
        _compare_source_span(proc, external, issues)

        external_symbols = symbols_by_proc.get(proc.name.lower(), {})
        for symbol in proc.symbols:
            expected_symbols += 1
            item = external_symbols.get(symbol.name.lower())
            if item is None:
                issues.append(BridgeIssue("warning", "symbol-missing", f"report has no symbol {proc.name}.{symbol.name}", procedure=proc.name, symbol=symbol.name))
                continue
            mismatches = []
            actual_category = _normalise_category(item.get("category") or item.get("type"))[0]
            if actual_category and actual_category != symbol.type.category:
                mismatches.append(f"category AST={symbol.type.category!r} report={actual_category!r}")
            if item.get("intent") is not None and _normalise_intent(item.get("intent")) != symbol.intent:
                mismatches.append(f"intent AST={symbol.intent!r} report={_normalise_intent(item.get('intent'))!r}")
            if item.get("rank") is not None and int(item.get("rank")) != symbol.rank:
                mismatches.append(f"rank AST={symbol.rank!r} report={item.get('rank')!r}")
            if mismatches:
                issues.append(BridgeIssue("error", "symbol-mismatch", "; ".join(mismatches), procedure=proc.name, symbol=symbol.name))
            else:
                matched_symbols += 1

    expected_calls = _project_calls(project)
    report_calls = {
        (str(item.get("caller", "")).lower(), str(item.get("callee", "")).lower())
        for item in payload.get("calls", [])
    }
    for caller, callee in sorted(expected_calls - report_calls):
        issues.append(BridgeIssue("warning", "call-missing", f"report has no call edge {caller} -> {callee}", procedure=caller))
    for caller, callee in sorted(report_calls - expected_calls):
        if caller in {item.name.lower() for item in project.procedures}:
            issues.append(BridgeIssue("warning", "call-report-only", f"report-only call edge {caller} -> {callee}", procedure=caller))

    matched_common, expected_common = _compare_common(project, payload.get("common_blocks", []), issues)
    for diagnostic in payload.get("diagnostics", []):
        severity = str(diagnostic.get("severity", diagnostic.get("level", ""))).lower()
        status = str(diagnostic.get("status", "")).lower()
        if severity in {"error", "fatal", "blocking"} or status in {"blocked", "blocking"}:
            issues.append(BridgeIssue(
                "error", "external-blocking-diagnostic",
                str(diagnostic.get("message", diagnostic.get("description", diagnostic))),
                procedure=_text(diagnostic, "program_unit", "procedure"),
                source_file=_text(diagnostic, "source_file", "file", "path"),
                line=_integer(diagnostic, "line", "start_line"),
            ))

    errors_count = sum(item.severity == "error" for item in issues)
    warnings_count = sum(item.severity == "warning" for item in issues)
    status = "BLOCKED" if errors_count else ("REVIEW_REQUIRED" if warnings_count else "PASS")
    report_files = tuple(
        str(item) for item in payload.get("handoff_metadata", {}).get("report_files", [])
    )
    result = RefactorConnectionReport(
        schema_version="1.0",
        status=status,
        producer=str(payload.get("producer", "unknown")),
        producer_version=payload.get("producer_version"),
        source=str(source),
        root_procedure=procedure,
        canonical_report=str(report_path),
        discovered_report_files=report_files,
        summary={
            "expected_program_units": len(project.procedures),
            "matched_program_units": matched_units,
            "expected_symbols": expected_symbols,
            "matched_symbols": matched_symbols,
            "expected_calls": len(expected_calls),
            "matched_calls": len(expected_calls & report_calls),
            "expected_common_members": expected_common,
            "matched_common_members": matched_common,
            "errors": errors_count,
            "warnings": warnings_count,
        },
        coverage={
            "program_units": _ratio(matched_units, len(project.procedures)),
            "symbols": _ratio(matched_symbols, expected_symbols),
            "calls": _ratio(len(expected_calls & report_calls), len(expected_calls)),
            "common_members": _ratio(matched_common, expected_common),
        },
        issues=tuple(issues),
    )
    target = _write_json(result.to_dict(), output)
    schema = json.loads((repository_root() / "schemas/refactor_connection.schema.json").read_text(encoding="utf-8"))
    serialised = json.loads(target.read_text(encoding="utf-8"))
    validation = list(Draft202012Validator(schema).iter_errors(serialised))
    if validation:
        details = "\n".join(f"{'/'.join(map(str, item.path)) or '<root>'}: {item.message}" for item in validation)
        raise RefactorBridgeError("connection report failed schema validation:\n" + details)
    return target


def _verify_source_hashes(
    source: Path,
    payload: Mapping[str, Any],
    issues: list[BridgeIssue],
) -> None:
    entries = payload.get("source_map", [])
    if not isinstance(entries, list):
        return
    source = source.expanduser().resolve()
    for item in entries:
        if not isinstance(item, Mapping) or not item.get("sha256"):
            continue
        relative = Path(str(item.get("source_file", "")))
        candidate = _resolve_handoff_source(source, relative)
        if candidate is None:
            issues.append(BridgeIssue(
                "error",
                "source-file-missing",
                f"handoff source file is absent from migration input: {relative}",
                source_file=str(relative),
            ))
            continue
        actual = _sha256(candidate)
        expected = str(item["sha256"]).lower()
        if actual != expected:
            issues.append(BridgeIssue(
                "error",
                "source-hash-mismatch",
                f"source SHA-256 differs for {relative}: report={expected}, actual={actual}",
                source_file=str(candidate),
            ))


def _resolve_handoff_source(source: Path, relative: Path) -> Path | None:
    if source.is_file():
        return source if source.name == relative.name else None
    direct = (source / relative).resolve()
    if direct.is_file():
        return direct
    matches = [item for item in source.rglob(relative.name) if item.is_file()]
    return matches[0].resolve() if len(matches) == 1 else None


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _evaluate_storage_overlays(
    overlays: Any,
    issues: list[BridgeIssue],
) -> None:
    if not isinstance(overlays, list):
        return
    for overlay in overlays:
        if not isinstance(overlay, Mapping):
            continue
        payload = overlay.get("payload") if isinstance(overlay.get("payload"), Mapping) else overlay
        migration_status = str(payload.get("migration_status", "")).lower()
        production_modified = payload.get("production_source_modified")
        if migration_status in {"blocked", "blocking"} or production_modified is False:
            issues.append(BridgeIssue(
                "error",
                "storage-overlay-blocked",
                "storage-overlay evidence does not prove that production EQUIVALENCE has been removed",
                procedure=_text(payload, "program_unit", "procedure"),
                source_file=_text(overlay, "report_file", "source_file"),
            ))


def _json_files(path: Path) -> list[Path]:
    if path.is_file():
        return [path] if path.suffix.lower() == ".json" else []
    return sorted(item for item in path.rglob("*.json") if item.is_file())


def _looks_canonical(payload: Any) -> bool:
    return isinstance(payload, dict) and {
        "schema_version", "producer", "project", "program_units", "symbols",
        "common_blocks", "calls", "diagnostics",
    }.issubset(payload)


def _normalise_key(value: str) -> str:
    return re.sub(r"[^a-z0-9]", "", value.lower())


def _collect_aliases(payload: Any, path: Path, output: dict[str, list[tuple[Path, Any]]]) -> None:
    if isinstance(payload, dict):
        for key, value in payload.items():
            normal = _normalise_key(str(key))
            for target, aliases in _COLLECTION_ALIASES.items():
                if normal in {_normalise_key(alias) for alias in aliases}:
                    if isinstance(value, list):
                        output[target].extend((path, item) for item in value)
                    elif isinstance(value, dict):
                        # Adjacency maps and named inventories are common report forms.
                        output[target].append((path, value))
            _collect_aliases(value, path, output)
    elif isinstance(payload, list):
        for item in payload:
            _collect_aliases(item, path, output)


def _extract_metadata(payload: dict[str, Any]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key in ("version", "tool_version", "package_version", "project_root", "root"):
        if key in payload and not isinstance(payload[key], (dict, list)):
            result[key] = payload[key]
    for nested in ("metadata", "project", "summary"):
        value = payload.get(nested)
        if isinstance(value, dict):
            result.update(_extract_metadata(value))
    return result


def _normalise_program_units(entries: Sequence[tuple[Path, Any]]) -> list[dict[str, Any]]:
    found: dict[tuple[str, str], dict[str, Any]] = {}
    for path, raw in entries:
        for item in _as_records(raw):
            name = _text(item, "name", "procedure", "program_unit", "unit_name", "symbol")
            if not name:
                continue
            kind = _normalise_unit_kind(_text(item, "kind", "unit_kind", "procedure_kind", "type"))
            if kind is None:
                continue
            source_file, start_line, end_line = _location(item, path)
            args_raw = _first(item, "arguments", "dummy_arguments", "args", "parameters") or []
            if isinstance(args_raw, str):
                arguments = [value.strip().lower() for value in args_raw.split(",") if value.strip()]
            elif isinstance(args_raw, list):
                arguments = [str(value.get("name") if isinstance(value, dict) else value).lower() for value in args_raw]
            else:
                arguments = []
            record = {
                "name": name.lower(), "kind": kind, "source_file": source_file,
                "start_line": start_line or 1, "end_line": end_line or start_line or 1,
                "arguments": arguments,
            }
            found[(record["name"], record["source_file"])] = record
    return sorted(found.values(), key=lambda item: (item["source_file"], item["start_line"], item["name"]))


def _normalise_symbols(entries: Sequence[tuple[Path, Any]]) -> list[dict[str, Any]]:
    found: dict[tuple[str, str], dict[str, Any]] = {}
    for path, raw in entries:
        for item in _as_records(raw):
            proc = _text(item, "program_unit", "procedure", "owner", "scope", "unit")
            name = _text(item, "name", "symbol", "variable", "entity")
            if not proc or not name:
                continue
            category, inferred_kind = _normalise_category(_first(item, "category", "type_category", "declared_type", "type"))
            if category is None:
                continue
            shape_raw = _first(item, "shape", "dimensions", "bounds")
            shape = _normalise_shape(shape_raw)
            rank_raw = _first(item, "rank", "array_rank")
            rank = int(rank_raw) if rank_raw is not None else len(shape)
            role = _normalise_role(_first(item, "role", "storage", "storage_class", "origin"))
            common_name = _text(item, "common_block", "common", "block_name")
            if common_name:
                role = "common"
            record = {
                "program_unit": proc.lower(), "name": name.lower(), "category": category,
                "kind": _first(item, "kind", "kind_name", "kind_value") or inferred_kind,
                "intent": _normalise_intent(_first(item, "intent", "argument_intent")),
                "rank": rank, "shape": shape, "role": role,
            }
            if common_name:
                record["common_block"] = common_name.lower().strip("/")
                position = _integer(item, "common_position", "position", "ordinal", "index")
                if position is not None:
                    record["common_position"] = position
            source_file, start_line, _ = _location(item, path)
            record["source_file"] = source_file
            if start_line:
                record["line"] = start_line
            found[(record["program_unit"], record["name"])] = record
    return sorted(found.values(), key=lambda item: (item["program_unit"], item["name"]))


def _normalise_common_blocks(entries: Sequence[tuple[Path, Any]], symbols: Sequence[dict[str, Any]]) -> list[dict[str, Any]]:
    blocks: dict[str, dict[str, Any]] = {}
    for path, raw in entries:
        for item in _as_records(raw):
            name = _text(item, "name", "common_block", "block", "block_name")
            if not name:
                continue
            name = name.lower().strip("/") or "__blank__"
            block = blocks.setdefault(name, {"name": name, "declarations": []})
            declarations = _first(item, "declarations", "occurrences", "layouts")
            if isinstance(declarations, list):
                for declaration in declarations:
                    normal = _normalise_common_declaration(declaration, path, name)
                    if normal:
                        block["declarations"].append(normal)
            else:
                normal = _normalise_common_declaration(item, path, name)
                if normal:
                    block["declarations"].append(normal)
    # Symbol inventories sometimes contain the only machine-readable COMMON layout.
    grouped: dict[tuple[str, str], list[dict[str, Any]]] = {}
    for symbol in symbols:
        common = symbol.get("common_block")
        if common:
            grouped.setdefault((common, symbol["program_unit"]), []).append(symbol)
    for (name, proc), members in grouped.items():
        block = blocks.setdefault(name, {"name": name, "declarations": []})
        if any(item.get("program_unit") == proc for item in block["declarations"]):
            continue
        members = sorted(members, key=lambda value: value.get("common_position", 10**9))
        block["declarations"].append({
            "program_unit": proc,
            "source_file": members[0].get("source_file", "<unknown>"),
            "line": members[0].get("line", 1),
            "members": [
                {
                    "position": int(member.get("common_position", index)),
                    "name": member["name"], "category": member["category"],
                    "kind": member.get("kind"), "rank": member["rank"],
                    "shape": member.get("shape", []),
                }
                for index, member in enumerate(members, start=1)
            ],
        })
    for block in blocks.values():
        unique: dict[tuple[str, str], dict[str, Any]] = {}
        for declaration in block["declarations"]:
            unique[(declaration.get("program_unit", ""), declaration.get("source_file", ""))] = declaration
        block["declarations"] = sorted(unique.values(), key=lambda item: (item.get("program_unit", ""), item.get("line", 0)))
    return sorted(blocks.values(), key=lambda item: item["name"])


def _normalise_common_declaration(item: Any, path: Path, block_name: str) -> dict[str, Any] | None:
    if not isinstance(item, dict):
        return None
    proc = _text(item, "program_unit", "procedure", "owner", "scope", "unit")
    members_raw = _first(item, "members", "variables", "entities", "layout")
    if not proc or not isinstance(members_raw, list):
        return None
    source_file, line, _ = _location(item, path)
    members = []
    for index, raw_member in enumerate(members_raw, start=1):
        if isinstance(raw_member, str):
            members.append({"position": index, "name": raw_member.lower(), "category": "real", "kind": None, "rank": 0, "shape": []})
            continue
        if not isinstance(raw_member, dict):
            continue
        name = _text(raw_member, "name", "symbol", "variable")
        category, inferred_kind = _normalise_category(_first(raw_member, "category", "type", "declared_type"))
        if not name or not category:
            continue
        shape = _normalise_shape(_first(raw_member, "shape", "dimensions", "bounds"))
        members.append({
            "position": _integer(raw_member, "position", "ordinal", "index") or index,
            "name": name.lower(), "category": category,
            "kind": _first(raw_member, "kind", "kind_name") or inferred_kind,
            "rank": _integer(raw_member, "rank", "array_rank") or len(shape),
            "shape": shape,
        })
    return {"program_unit": proc.lower(), "source_file": source_file, "line": line or 1, "members": members, "block": block_name}


def _normalise_calls(entries: Sequence[tuple[Path, Any]]) -> list[dict[str, Any]]:
    result: dict[tuple[str, str, str, int], dict[str, Any]] = {}
    for path, raw in entries:
        if isinstance(raw, dict) and not any(key in raw for key in ("caller", "callee", "from", "to")):
            for caller, callees in raw.items():
                if isinstance(callees, list):
                    for callee in callees:
                        item = {"caller": caller, "callee": callee.get("name") if isinstance(callee, dict) else callee}
                        record = _normalise_call(item, path)
                        if record:
                            result[(record["caller"], record["callee"], record.get("source_file", ""), record.get("line", 0))] = record
            continue
        for item in _as_records(raw):
            record = _normalise_call(item, path)
            if record:
                result[(record["caller"], record["callee"], record.get("source_file", ""), record.get("line", 0))] = record
    return sorted(result.values(), key=lambda item: (item["caller"], item["callee"], item.get("line", 0)))


def _normalise_call(item: Any, path: Path) -> dict[str, Any] | None:
    if not isinstance(item, dict):
        return None
    caller = _text(item, "caller", "from", "source", "calling_procedure")
    callee = _text(item, "callee", "to", "target", "called_procedure", "procedure")
    if not caller or not callee:
        return None
    source_file, line, _ = _location(item, path)
    return {"caller": caller.lower(), "callee": callee.lower(), "source_file": source_file, "line": line or 1}


def _normalise_diagnostics(entries: Sequence[tuple[Path, Any]]) -> list[dict[str, Any]]:
    result = []
    for path, raw in entries:
        for item in _as_records(raw):
            if not isinstance(item, dict):
                continue
            message = _text(item, "message", "description", "detail", "summary")
            if not message:
                continue
            source_file, line, _ = _location(item, path)
            result.append({
                "severity": str(_first(item, "severity", "level", "status") or "info").lower(),
                "code": _text(item, "code", "id", "rule"),
                "message": message,
                "program_unit": _text(item, "program_unit", "procedure", "unit"),
                "source_file": source_file,
                "line": line,
            })
    return result


def _normalise_passthrough(entries: Sequence[tuple[Path, Any]]) -> list[dict[str, Any]]:
    return [dict(item) for _, raw in entries for item in _as_records(raw) if isinstance(item, dict)]


def _normalise_unit_kind(value: str | None) -> str | None:
    if not value:
        return None
    text = value.lower().replace(" ", "_")
    if "block" in text and "data" in text:
        return "block_data"
    for kind in ("subroutine", "function", "module", "program"):
        if kind in text:
            return kind
    return None


def _normalise_category(value: Any) -> tuple[str | None, str | None]:
    if value is None:
        return None, None
    if isinstance(value, dict):
        value = value.get("category") or value.get("name") or value.get("type")
    text = str(value).strip().lower()
    if "double precision" in text or "real*8" in text or "real(8" in text or "real64" in text:
        return "real", "real64"
    if "real" in text:
        return "real", None
    if "integer" in text:
        return "integer", None
    if "logical" in text or "bool" in text:
        return "logical", None
    if "character" in text or "string" in text:
        return "character", None
    if "type(" in text or "derived" in text or "class(" in text:
        return "derived", None
    return None, None


def _normalise_intent(value: Any) -> str | None:
    if value is None:
        return None
    text = str(value).lower().replace(" ", "").replace("_", "")
    if text in {"in", "input", "readonly"}:
        return "in"
    if text in {"out", "output", "writeonly"}:
        return "out"
    if text in {"inout", "inputoutput", "readwrite"}:
        return "inout"
    return None


def _normalise_role(value: Any) -> str:
    text = str(value or "local").lower()
    if "arg" in text or "dummy" in text:
        return "argument"
    if "common" in text:
        return "common"
    if "module" in text or "global" in text:
        return "module"
    return "local"


def _normalise_shape(value: Any) -> list[Any]:
    if value is None:
        return []
    if isinstance(value, int):
        return [value]
    if isinstance(value, str):
        text = value.strip().strip("()")
        return [part.strip() for part in text.split(",") if part.strip()]
    if isinstance(value, list):
        return [item.get("extent", item.get("upper", ":")) if isinstance(item, dict) else item for item in value]
    return []


def _as_records(raw: Any) -> list[Any]:
    if isinstance(raw, list):
        return raw
    if isinstance(raw, dict):
        record_keys = {
            "name", "unit_name", "procedure", "program_unit", "variable",
            "symbol", "caller", "callee", "from", "to", "block_name",
            "common_block", "message", "description", "detail",
        }
        if {_normalise_key(str(key)) for key in raw} & {_normalise_key(key) for key in record_keys}:
            return [raw]
        # Named inventories often use the entity name as the mapping key.
        records = []
        for key, value in raw.items():
            if isinstance(value, dict):
                item = dict(value)
                item.setdefault("name", key)
                records.append(item)
        return records or [raw]
    return []


def _first(item: Mapping[str, Any], *keys: str) -> Any:
    normal = {_normalise_key(str(key)): value for key, value in item.items()}
    for key in keys:
        candidate = normal.get(_normalise_key(key))
        if candidate is not None:
            return candidate
    return None


def _text(item: Mapping[str, Any], *keys: str) -> str | None:
    value = _first(item, *keys)
    if value is None or isinstance(value, (dict, list)):
        return None
    text = str(value).strip()
    return text or None


def _integer(item: Mapping[str, Any], *keys: str) -> int | None:
    value = _first(item, *keys)
    try:
        return int(value) if value is not None else None
    except (TypeError, ValueError):
        return None


def _location(item: Mapping[str, Any], fallback_path: Path) -> tuple[str, int | None, int | None]:
    nested = _first(item, "source_span", "span", "location")
    merged = dict(item)
    if isinstance(nested, dict):
        merged.update(nested)
    source_file = _text(merged, "source_file", "file", "path", "filename") or str(fallback_path)
    start = _integer(merged, "start_line", "line", "line_start", "first_line")
    end = _integer(merged, "end_line", "line_end", "last_line") or start
    return source_file, start, end


def _compare_source_span(proc: Any, external: Mapping[str, Any], issues: list[BridgeIssue]) -> None:
    report_file = str(external.get("source_file", ""))
    if report_file and Path(report_file).name != Path(proc.source_span.file).name:
        issues.append(BridgeIssue("warning", "source-file-mismatch", f"AST={proc.source_span.file}, report={report_file}", procedure=proc.name))
    start = external.get("start_line")
    end = external.get("end_line")
    if start is not None and int(start) != proc.source_span.start_line:
        issues.append(BridgeIssue("warning", "source-start-line-mismatch", f"AST={proc.source_span.start_line}, report={start}", procedure=proc.name))
    if end is not None and int(end) != proc.source_span.end_line:
        issues.append(BridgeIssue("warning", "source-end-line-mismatch", f"AST={proc.source_span.end_line}, report={end}", procedure=proc.name))


def _project_calls(project: ProjectIR) -> set[tuple[str, str]]:
    return {
        (proc.name.lower(), call.procedure.lower())
        for proc in project.procedures
        for call in _walk_calls(proc.statements)
    }


def _walk_calls(statements: Iterable[StatementIR]) -> Iterable[CallIR]:
    for statement in statements:
        if isinstance(statement, CallIR):
            yield statement
        elif isinstance(statement, DoLoopIR):
            yield from _walk_calls(statement.body)
        elif isinstance(statement, IfIR):
            yield from _walk_calls(statement.body)
            yield from _walk_calls(statement.else_body)


def _compare_common(project: ProjectIR, report_blocks: Sequence[Mapping[str, Any]], issues: list[BridgeIssue]) -> tuple[int, int]:
    report_index: dict[tuple[str, str, int], Mapping[str, Any]] = {}
    for block in report_blocks:
        block_name = str(block.get("name", block.get("block", ""))).lower().strip("/")
        for declaration in block.get("declarations", []):
            proc = str(declaration.get("program_unit", "")).lower()
            for index, member in enumerate(declaration.get("members", []), start=1):
                position = int(member.get("position", index))
                report_index[(block_name, proc, position)] = member

    matched = 0
    expected = 0
    groups = {group.name: group for group in project.state_groups if group.source_kind == "common"}
    for proc in project.procedures:
        for group_name in proc.state_groups:
            group = groups.get(group_name)
            if group is None:
                continue
            block_name = group.source_name.lower().strip("/")
            for position, field in enumerate(group.fields, start=1):
                expected += 1
                member = report_index.get((block_name, proc.name.lower(), position))
                if member is None:
                    issues.append(BridgeIssue("warning", "common-member-missing", f"report has no /{block_name}/ position {position}", procedure=proc.name, symbol=field.name))
                    continue
                category, _ = _normalise_category(member.get("category") or member.get("type"))
                rank = int(member.get("rank", 0))
                if category != field.type.category or rank != field.rank:
                    issues.append(BridgeIssue("error", "common-member-mismatch", f"/{block_name}/ position {position}: AST=({field.type.category}, rank {field.rank}), report=({category}, rank {rank})", procedure=proc.name, symbol=field.name))
                else:
                    matched += 1
    return matched, expected


def _ratio(numerator: int, denominator: int) -> float:
    return 1.0 if denominator == 0 else numerator / denominator


def _write_json(payload: Any, output: str | Path) -> Path:
    target = Path(output)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return target
