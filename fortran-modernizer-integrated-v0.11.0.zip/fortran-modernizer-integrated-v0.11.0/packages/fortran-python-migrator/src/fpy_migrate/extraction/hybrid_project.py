from __future__ import annotations

from dataclasses import dataclass
import importlib.util
import json
from pathlib import Path
import re
import sys
from time import perf_counter
from types import ModuleType
from typing import Literal, TYPE_CHECKING

from fpy_migrate.ir import build_project_ir, write_project_ir
from fpy_migrate.ir.model import DoLoopIR, IfIR, ProcedureIR, ProjectIR, StateGroupIR, SymbolIR
from fpy_migrate.translate import generate_python, write_python

from .partial_loops import (
    PartialLoopBundle,
    PartialLoopExtraction,
    PartialLoopExtractionError,
    analyze_partial_loop,
    build_partial_loop_bundle_from_project,
)
from .state_kernels import (
    StateKernelBundle,
    StateKernelExtractionError,
    analyze_state_kernel,
    build_state_kernel_bundle_from_project,
)


if TYPE_CHECKING:
    from .profiling import ProfileSelectionReport

HybridCandidateStatus = Literal["AUTO", "PARTIAL_AUTO", "PYTHON_ONLY"]
HybridExtractionKind = Literal["full-procedure", "partial-loop"]


@dataclass(frozen=True)
class HybridKernelCandidate:
    procedure: str
    status: HybridCandidateStatus
    reason: str
    loop_count: int
    state_groups: tuple[str, ...]
    kernel_procedure: str | None = None
    extraction_kind: HybridExtractionKind | None = None
    loop_index: int | None = None
    selected: bool = True
    selection_reason: str = "statically eligible"
    profile_call_count: int | None = None
    profile_self_seconds: float | None = None
    profile_candidate_share: float | None = None
    profile_wall_share: float | None = None
    profile_case_count: int | None = None
    profile_observed_case_count: int | None = None
    profile_case_coverage: float | None = None
    profile_mean_candidate_share: float | None = None
    profile_max_candidate_share: float | None = None
    profile_weighted_candidate_share: float | None = None
    economics_build_seconds: float | None = None
    economics_bundle_bytes: int | None = None
    economics_optimized_extension_bytes: int | None = None
    economics_speedup: float | None = None
    economics_weighted_saved_seconds: float | None = None
    economics_break_even_runs: float | None = None
    economics_break_even_calls: float | None = None
    economics_cost_benefit_score: float | None = None

    def to_dict(self) -> dict[str, object]:
        return {
            "procedure": self.procedure,
            "status": self.status,
            "reason": self.reason,
            "loop_count": self.loop_count,
            "state_groups": list(self.state_groups),
            "kernel_procedure": self.kernel_procedure,
            "extraction_kind": self.extraction_kind,
            "loop_index": self.loop_index,
            "selected": self.selected,
            "selection_reason": self.selection_reason,
            "profile_call_count": self.profile_call_count,
            "profile_self_seconds": self.profile_self_seconds,
            "profile_candidate_share": self.profile_candidate_share,
            "profile_wall_share": self.profile_wall_share,
            "profile_case_count": self.profile_case_count,
            "profile_observed_case_count": self.profile_observed_case_count,
            "profile_case_coverage": self.profile_case_coverage,
            "profile_mean_candidate_share": self.profile_mean_candidate_share,
            "profile_max_candidate_share": self.profile_max_candidate_share,
            "profile_weighted_candidate_share": self.profile_weighted_candidate_share,
            "economics_build_seconds": self.economics_build_seconds,
            "economics_bundle_bytes": self.economics_bundle_bytes,
            "economics_optimized_extension_bytes": self.economics_optimized_extension_bytes,
            "economics_speedup": self.economics_speedup,
            "economics_weighted_saved_seconds": self.economics_weighted_saved_seconds,
            "economics_break_even_runs": self.economics_break_even_runs,
            "economics_break_even_calls": self.economics_break_even_calls,
            "economics_cost_benefit_score": self.economics_cost_benefit_score,
        }


@dataclass(frozen=True)
class HybridProjectPlan:
    schema_version: str
    root_procedure: str
    source_files: tuple[str, ...]
    dependency_order: tuple[str, ...]
    candidates: tuple[HybridKernelCandidate, ...]

    @property
    def eligible_procedures(self) -> tuple[str, ...]:
        return tuple(
            item.procedure
            for item in self.candidates
            if item.status in {"AUTO", "PARTIAL_AUTO"}
        )

    @property
    def full_extracted_procedures(self) -> tuple[str, ...]:
        return tuple(
            item.procedure
            for item in self.candidates
            if item.status == "AUTO" and item.selected
        )

    @property
    def partial_extracted_procedures(self) -> tuple[str, ...]:
        return tuple(
            item.procedure for item in self.candidates if item.status == "PARTIAL_AUTO" and item.selected
        )

    @property
    def extracted_procedures(self) -> tuple[str, ...]:
        accelerated = {"AUTO", "PARTIAL_AUTO"}
        return tuple(item.procedure for item in self.candidates if item.status in accelerated and item.selected)

    def candidate(self, procedure: str) -> HybridKernelCandidate:
        target = procedure.lower()
        for item in self.candidates:
            if item.procedure == target:
                return item
        raise KeyError(procedure)

    def to_dict(self) -> dict[str, object]:
        return {
            "schema_version": self.schema_version,
            "root_procedure": self.root_procedure,
            "source_files": list(self.source_files),
            "dependency_order": list(self.dependency_order),
            "eligible_procedures": list(self.eligible_procedures),
            "extracted_procedures": list(self.extracted_procedures),
            "full_extracted_procedures": list(self.full_extracted_procedures),
            "partial_extracted_procedures": list(self.partial_extracted_procedures),
            "candidates": [item.to_dict() for item in self.candidates],
        }


@dataclass(frozen=True)
class HybridProjectManifest:
    schema_version: str
    root_procedure: str
    source_files: tuple[str, ...]
    default_backend: str
    available_backends: tuple[str, ...]
    artifacts: dict[str, str]
    kernel_bundles: dict[str, str]
    partial_loop_bundles: dict[str, str]
    eligible_procedures: tuple[str, ...]
    extracted_procedures: tuple[str, ...]
    full_extracted_procedures: tuple[str, ...]
    partial_extracted_procedures: tuple[str, ...]
    python_only_procedures: tuple[str, ...]
    build_metrics: dict[str, dict[str, float | int]]

    def to_dict(self) -> dict[str, object]:
        return {
            "schema_version": self.schema_version,
            "root_procedure": self.root_procedure,
            "source_files": list(self.source_files),
            "default_backend": self.default_backend,
            "available_backends": list(self.available_backends),
            "artifacts": self.artifacts,
            "kernel_bundles": self.kernel_bundles,
            "partial_loop_bundles": self.partial_loop_bundles,
            "eligible_procedures": list(self.eligible_procedures),
            "extracted_procedures": list(self.extracted_procedures),
            "full_extracted_procedures": list(self.full_extracted_procedures),
            "partial_extracted_procedures": list(self.partial_extracted_procedures),
            "python_only_procedures": list(self.python_only_procedures),
            "build_metrics": self.build_metrics,
        }


def analyze_hybrid_project(
    project: ProjectIR,
    root_procedure: str,
    *,
    profile_report: "ProfileSelectionReport | str | Path | dict[str, object] | None" = None,
    min_profile_share: float = 0.0,
    min_profile_mean_share: float = 0.0,
    min_profile_max_share: float = 0.0,
    min_profile_cases: int = 1,
    min_profile_time_ms: float = 0.0,
    max_native_kernels: int | None = None,
    economics_report: "object | str | Path | dict[str, object] | None" = None,
    min_economics_speedup: float = 1.0,
    min_economics_saved_time_ms: float = 0.0,
    max_economics_build_seconds: float | None = None,
    max_economics_artifact_mb: float | None = None,
    max_economics_break_even_runs: float | None = None,
    max_economics_break_even_calls: float | None = None,
) -> HybridProjectPlan:
    """Classify reachable procedures for full or partial native generation.

    Full state-kernel extraction is preferred. If that is unavailable, the first
    safely extractable top-level DO loop is selected while the surrounding body
    remains in generated Python.
    """

    root = root_procedure.lower()
    project.procedure(root)
    candidates: list[HybridKernelCandidate] = []
    for procedure in project.procedures:
        loop_count = _count_loops(procedure)
        full_reason: str | None = None
        if procedure.state_groups:
            try:
                extraction = analyze_state_kernel(project, procedure.name)
            except StateKernelExtractionError as exc:
                full_reason = str(exc)
            else:
                candidates.append(
                    HybridKernelCandidate(
                        procedure=procedure.name,
                        status="AUTO",
                        reason="stateful numerical body can be extracted as an explicit kernel",
                        loop_count=extraction.loop_count,
                        state_groups=procedure.state_groups,
                        kernel_procedure=extraction.kernel_procedure,
                        extraction_kind="full-procedure",
                    )
                )
                continue
        else:
            full_reason = "procedure does not access COMMON/module state"

        partial, partial_reasons = _first_partial_extraction(project, procedure)
        if partial is not None:
            candidates.append(
                HybridKernelCandidate(
                    procedure=procedure.name,
                    status="PARTIAL_AUTO",
                    reason=(
                        "complete procedure remains in Python; top-level loop "
                        f"{partial.loop_index} is safely extractable"
                    ),
                    loop_count=loop_count,
                    state_groups=procedure.state_groups,
                    kernel_procedure=partial.kernel_procedure,
                    extraction_kind="partial-loop",
                    loop_index=partial.loop_index,
                )
            )
            continue

        detail = full_reason or "complete state-kernel extraction is unavailable"
        if partial_reasons:
            detail += "; partial-loop extraction blocked: " + " | ".join(partial_reasons)
        elif loop_count == 0:
            detail += "; no top-level DO loop is available"
        candidates.append(
            HybridKernelCandidate(
                procedure=procedure.name,
                status="PYTHON_ONLY",
                reason=detail,
                loop_count=loop_count,
                state_groups=procedure.state_groups,
                selected=False,
                selection_reason="not statically extractable",
            )
        )
    if profile_report is not None:
        from .profiling import load_hybrid_profile

        report = load_hybrid_profile(profile_report)
        if report.root_procedure != root:
            raise ValueError(
                f"profile root {report.root_procedure!r} does not match {root!r}"
            )
        candidates = _apply_profile_selection(
            candidates,
            report,
            min_profile_share=min_profile_share,
            min_profile_mean_share=min_profile_mean_share,
            min_profile_max_share=min_profile_max_share,
            min_profile_cases=min_profile_cases,
            min_profile_time_ms=min_profile_time_ms,
            max_native_kernels=max_native_kernels,
        )
    if economics_report is not None:
        from .economics import load_hybrid_economics

        economics = load_hybrid_economics(economics_report)
        if economics.root_procedure != root:
            raise ValueError(
                f"economics root {economics.root_procedure!r} does not match {root!r}"
            )
        if tuple(economics.source_files) != tuple(project.source_files):
            raise ValueError("economics report source files do not match the project")
        candidates = _apply_economics_selection(
            candidates,
            economics,
            min_speedup=min_economics_speedup,
            min_saved_time_ms=min_economics_saved_time_ms,
            max_build_seconds=max_economics_build_seconds,
            max_artifact_mb=max_economics_artifact_mb,
            max_break_even_runs=max_economics_break_even_runs,
            max_break_even_calls=max_economics_break_even_calls,
        )
    return HybridProjectPlan(
        schema_version="1.4",
        root_procedure=root,
        source_files=project.source_files,
        dependency_order=tuple(item.name for item in project.procedures),
        candidates=tuple(candidates),
    )



def _apply_profile_selection(
    candidates: list[HybridKernelCandidate],
    report: "ProfileSelectionReport",
    *,
    min_profile_share: float,
    min_profile_mean_share: float,
    min_profile_max_share: float,
    min_profile_cases: int,
    min_profile_time_ms: float,
    max_native_kernels: int | None,
) -> list[HybridKernelCandidate]:
    if not 0.0 <= min_profile_share <= 1.0:
        raise ValueError("min_profile_share must be between 0 and 1")
    if not 0.0 <= min_profile_mean_share <= 1.0:
        raise ValueError("min_profile_mean_share must be between 0 and 1")
    if not 0.0 <= min_profile_max_share <= 1.0:
        raise ValueError("min_profile_max_share must be between 0 and 1")
    if min_profile_cases < 1:
        raise ValueError("min_profile_cases must be positive")
    if min_profile_time_ms < 0.0:
        raise ValueError("min_profile_time_ms must be non-negative")
    if max_native_kernels is not None and max_native_kernels < 1:
        raise ValueError("max_native_kernels must be positive")

    eligible: list[tuple[HybridKernelCandidate, object]] = []
    for candidate in candidates:
        if candidate.status not in {"AUTO", "PARTIAL_AUTO"}:
            continue
        sample = report.sample(candidate.procedure)
        if sample is not None:
            eligible.append((candidate, sample))
    qualifying = [
        (candidate, sample)
        for candidate, sample in eligible
        if sample.candidate_share >= min_profile_share
        and getattr(sample, "mean_candidate_share", sample.candidate_share)
        >= min_profile_mean_share
        and getattr(sample, "max_candidate_share", sample.candidate_share)
        >= min_profile_max_share
        and getattr(sample, "observed_case_count", 1) >= min_profile_cases
        and sample.self_seconds * 1000.0 >= min_profile_time_ms
    ]
    qualifying.sort(key=lambda item: (-item[1].self_seconds, item[0].procedure))
    if max_native_kernels is not None:
        qualifying = qualifying[:max_native_kernels]
    fallback_eligible = [
        (candidate, sample)
        for candidate, sample in eligible
        if getattr(sample, "observed_case_count", 1) >= min_profile_cases
    ]
    if not qualifying and fallback_eligible:
        qualifying = [max(fallback_eligible, key=lambda item: item[1].self_seconds)]
    selected_names = {candidate.procedure for candidate, _ in qualifying}

    updated: list[HybridKernelCandidate] = []
    for candidate in candidates:
        sample = report.sample(candidate.procedure)
        selected = candidate.procedure in selected_names
        if candidate.status == "PYTHON_ONLY":
            reason = "not statically extractable"
            selected = False
        elif sample is None:
            reason = "no profile sample; retained in Python"
            selected = False
        elif selected:
            case_count = getattr(sample, "observed_case_count", 1)
            total_cases = getattr(sample, "case_count", 1)
            reason = (
                f"selected by profile: {sample.candidate_share:.3%} weighted share, "
                f"{getattr(sample, 'mean_candidate_share', sample.candidate_share):.3%} mean, "
                f"{getattr(sample, 'max_candidate_share', sample.candidate_share):.3%} max, "
                f"{case_count}/{total_cases} cases, "
                f"{sample.self_seconds * 1000.0:.3f} ms weighted self time"
            )
        else:
            case_count = getattr(sample, "observed_case_count", 1)
            total_cases = getattr(sample, "case_count", 1)
            reason = (
                f"below profile thresholds: {sample.candidate_share:.3%} weighted share, "
                f"{getattr(sample, 'mean_candidate_share', sample.candidate_share):.3%} mean, "
                f"{getattr(sample, 'max_candidate_share', sample.candidate_share):.3%} max, "
                f"{case_count}/{total_cases} cases, "
                f"{sample.self_seconds * 1000.0:.3f} ms weighted self time"
            )
        updated.append(
            HybridKernelCandidate(
                procedure=candidate.procedure,
                status=candidate.status,
                reason=candidate.reason,
                loop_count=candidate.loop_count,
                state_groups=candidate.state_groups,
                kernel_procedure=candidate.kernel_procedure,
                extraction_kind=candidate.extraction_kind,
                loop_index=candidate.loop_index,
                selected=selected,
                selection_reason=reason,
                profile_call_count=sample.call_count if sample else None,
                profile_self_seconds=sample.self_seconds if sample else None,
                profile_candidate_share=sample.candidate_share if sample else None,
                profile_wall_share=sample.wall_share if sample else None,
                profile_case_count=getattr(sample, "case_count", 1) if sample else None,
                profile_observed_case_count=(
                    getattr(sample, "observed_case_count", 1) if sample else None
                ),
                profile_case_coverage=(
                    getattr(sample, "case_coverage", 1.0) if sample else None
                ),
                profile_mean_candidate_share=(
                    getattr(sample, "mean_candidate_share", sample.candidate_share)
                    if sample
                    else None
                ),
                profile_max_candidate_share=(
                    getattr(sample, "max_candidate_share", sample.candidate_share)
                    if sample
                    else None
                ),
                profile_weighted_candidate_share=(
                    sample.candidate_share if sample else None
                ),
            )
        )
    return updated

def _apply_economics_selection(
    candidates: list[HybridKernelCandidate],
    report: object,
    *,
    min_speedup: float,
    min_saved_time_ms: float,
    max_build_seconds: float | None,
    max_artifact_mb: float | None,
    max_break_even_runs: float | None,
    max_break_even_calls: float | None,
) -> list[HybridKernelCandidate]:
    if min_speedup < 0.0:
        raise ValueError("min_economics_speedup must be non-negative")
    if min_saved_time_ms < 0.0:
        raise ValueError("min_economics_saved_time_ms must be non-negative")
    for name, value in {
        "max_economics_build_seconds": max_build_seconds,
        "max_economics_artifact_mb": max_artifact_mb,
        "max_economics_break_even_runs": max_break_even_runs,
        "max_economics_break_even_calls": max_break_even_calls,
    }.items():
        if value is not None and value < 0.0:
            raise ValueError(f"{name} must be non-negative")

    updated: list[HybridKernelCandidate] = []
    for candidate in candidates:
        sample = report.sample(candidate.procedure)
        selected = candidate.selected and candidate.status in {"AUTO", "PARTIAL_AUTO"}
        failures: list[str] = []
        if sample is None:
            selected = False
            failures.append("no economics sample")
        elif selected:
            if sample.speedup < min_speedup:
                failures.append(f"speedup {sample.speedup:.3f} < {min_speedup:.3f}")
            if sample.weighted_saved_seconds * 1000.0 < min_saved_time_ms:
                failures.append(
                    f"saved time {sample.weighted_saved_seconds * 1000.0:.3f} ms "
                    f"< {min_saved_time_ms:.3f} ms"
                )
            if max_build_seconds is not None and sample.build_seconds > max_build_seconds:
                failures.append(
                    f"build time {sample.build_seconds:.3f} s > {max_build_seconds:.3f} s"
                )
            artifact_mb = sample.optimized_extension_bytes / (1024.0 ** 2)
            if max_artifact_mb is not None and artifact_mb > max_artifact_mb:
                failures.append(
                    f"artifact {artifact_mb:.3f} MiB > {max_artifact_mb:.3f} MiB"
                )
            if max_break_even_runs is not None and (
                sample.break_even_runs is None or sample.break_even_runs > max_break_even_runs
            ):
                failures.append(
                    "break-even runs unavailable"
                    if sample.break_even_runs is None
                    else f"break-even {sample.break_even_runs:.1f} runs > {max_break_even_runs:.1f}"
                )
            if max_break_even_calls is not None and (
                sample.break_even_calls is None or sample.break_even_calls > max_break_even_calls
            ):
                failures.append(
                    "break-even calls unavailable"
                    if sample.break_even_calls is None
                    else f"break-even {sample.break_even_calls:.1f} calls > {max_break_even_calls:.1f}"
                )
            selected = not failures

        if sample is None:
            reason = candidate.selection_reason + "; economics: no sample"
        elif selected:
            reason = (
                candidate.selection_reason
                + f"; economics selected: {sample.speedup:.3f}x, "
                + f"{sample.weighted_saved_seconds * 1000.0:.3f} ms saved/run, "
                + f"{sample.build_seconds:.3f} s build, "
                + (
                    f"{sample.break_even_runs:.1f} break-even runs"
                    if sample.break_even_runs is not None
                    else "no finite break-even"
                )
            )
        else:
            reason = candidate.selection_reason + "; economics rejected: " + "; ".join(failures)

        updated.append(
            HybridKernelCandidate(
                **{
                    **candidate.__dict__,
                    "selected": selected,
                    "selection_reason": reason,
                    "economics_build_seconds": sample.build_seconds if sample else None,
                    "economics_bundle_bytes": sample.bundle_bytes if sample else None,
                    "economics_optimized_extension_bytes": (
                        sample.optimized_extension_bytes if sample else None
                    ),
                    "economics_speedup": sample.speedup if sample else None,
                    "economics_weighted_saved_seconds": (
                        sample.weighted_saved_seconds if sample else None
                    ),
                    "economics_break_even_runs": sample.break_even_runs if sample else None,
                    "economics_break_even_calls": sample.break_even_calls if sample else None,
                    "economics_cost_benefit_score": (
                        sample.cost_benefit_score if sample else None
                    ),
                }
            )
        )
    return updated


def _bundle_metrics(
    bundle_root: Path,
    optimized_extension: str,
    build_seconds: float,
) -> dict[str, float | int]:
    return {
        "build_seconds": build_seconds,
        "bundle_bytes": sum(
            item.stat().st_size for item in bundle_root.rglob("*") if item.is_file()
        ),
        "optimized_extension_bytes": (bundle_root / optimized_extension).stat().st_size,
    }


def write_hybrid_project_plan(plan: HybridProjectPlan, output: str | Path) -> Path:
    path = Path(output)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(plan.to_dict(), indent=2) + "\n", encoding="utf-8")
    return path


def build_hybrid_project(
    source: str | Path,
    *,
    root_procedure: str,
    build_directory: str | Path,
    refactor_report: str | Path | None = None,
    default_backend: str = "cython-optimized",
    include_fortran: bool = False,
    profile_report: "ProfileSelectionReport | str | Path | dict[str, object] | None" = None,
    min_profile_share: float = 0.0,
    min_profile_mean_share: float = 0.0,
    min_profile_max_share: float = 0.0,
    min_profile_cases: int = 1,
    min_profile_time_ms: float = 0.0,
    max_native_kernels: int | None = None,
    economics_report: "object | str | Path | dict[str, object] | None" = None,
    min_economics_speedup: float = 1.0,
    min_economics_saved_time_ms: float = 0.0,
    max_economics_build_seconds: float | None = None,
    max_economics_artifact_mb: float | None = None,
    max_economics_break_even_runs: float | None = None,
    max_economics_break_even_calls: float | None = None,
) -> tuple[HybridProjectManifest, Path]:
    """Build full state kernels and partial-loop kernels behind one registry."""

    if default_backend not in {"python", "cython-safe", "cython-optimized", "fortran"}:
        raise ValueError(f"unsupported default backend: {default_backend}")
    if default_backend == "fortran" and not include_fortran:
        raise ValueError("default_backend='fortran' requires include_fortran=True")
    root = Path(build_directory).resolve()
    root.mkdir(parents=True, exist_ok=True)
    project = build_project_ir(
        source,
        procedure=root_procedure,
        refactor_report=refactor_report,
    )
    plan = analyze_hybrid_project(
        project,
        root_procedure,
        profile_report=profile_report,
        min_profile_share=min_profile_share,
        min_profile_mean_share=min_profile_mean_share,
        min_profile_max_share=min_profile_max_share,
        min_profile_cases=min_profile_cases,
        min_profile_time_ms=min_profile_time_ms,
        max_native_kernels=max_native_kernels,
        economics_report=economics_report,
        min_economics_speedup=min_economics_speedup,
        min_economics_saved_time_ms=min_economics_saved_time_ms,
        max_economics_build_seconds=max_economics_build_seconds,
        max_economics_artifact_mb=max_economics_artifact_mb,
        max_economics_break_even_runs=max_economics_break_even_runs,
        max_economics_break_even_calls=max_economics_break_even_calls,
    )
    if not plan.extracted_procedures:
        raise ValueError("selection did not choose any native kernels")

    project_ir_path = write_project_ir(project, root / "hybrid_project.ir.json")
    plan_path = write_hybrid_project_plan(plan, root / "hybrid_project_plan.json")
    profile_path: Path | None = None
    if profile_report is not None:
        from .profiling import load_hybrid_profile, write_hybrid_profile

        profile_path = write_hybrid_profile(
            load_hybrid_profile(profile_report), root / "hybrid_profile.json"
        )
    economics_path: Path | None = None
    if economics_report is not None:
        from .economics import load_hybrid_economics, write_hybrid_economics

        economics_path = write_hybrid_economics(
            load_hybrid_economics(economics_report), root / "hybrid_economics.json"
        )

    full_bundles: dict[str, StateKernelBundle] = {}
    full_manifest_paths: dict[str, str] = {}
    build_metrics: dict[str, dict[str, float | int]] = {}
    for procedure in plan.full_extracted_procedures:
        kernel_root = root / "kernels" / procedure
        build_start = perf_counter()
        bundle, manifest_path = build_state_kernel_bundle_from_project(
            project,
            procedure=procedure,
            build_directory=kernel_root,
            include_fortran=include_fortran,
        )
        build_metrics[procedure] = _bundle_metrics(
            kernel_root, bundle.artifacts["cython_optimized_extension"], perf_counter() - build_start
        )
        full_bundles[procedure] = bundle
        full_manifest_paths[procedure] = _relative(manifest_path, root)

    transformed_project = project
    partial_extractions: dict[str, PartialLoopExtraction] = {}
    partial_bundles: dict[str, PartialLoopBundle] = {}
    partial_manifest_paths: dict[str, str] = {}
    for procedure in plan.partial_extracted_procedures:
        candidate = plan.candidate(procedure)
        assert candidate.loop_index is not None
        partial_root = root / "partial_loops" / procedure
        build_start = perf_counter()
        bundle, manifest_path = build_partial_loop_bundle_from_project(
            transformed_project,
            procedure=procedure,
            loop_index=candidate.loop_index,
            build_directory=partial_root,
            default_backend=default_backend,
            include_fortran=include_fortran,
        )
        build_metrics[procedure] = _bundle_metrics(
            partial_root, bundle.artifacts["cython_optimized_extension"], perf_counter() - build_start
        )
        extraction = analyze_partial_loop(
            transformed_project, procedure, loop_index=candidate.loop_index
        )
        transformed_project = extraction.wrapper_project
        partial_extractions[procedure] = extraction
        partial_bundles[procedure] = bundle
        partial_manifest_paths[procedure] = _relative(manifest_path, root)

    transformed_ir_path = write_project_ir(
        transformed_project, root / "hybrid_transformed.ir.json"
    )
    reference_path = write_python(
        generate_python(transformed_project, procedure=root_procedure),
        root / "project_reference.py",
    )

    runtime_path = root / "hybrid_project.py"
    runtime_path.write_text(
        generate_hybrid_runtime(
            transformed_project,
            plan,
            full_wrapper_paths={
                name: _relative(root / "kernels" / name / bundle.artifacts["wrapper"], root)
                for name, bundle in full_bundles.items()
            },
            partial_extractions=partial_extractions,
            partial_specs={
                name: {
                    "kernel_procedure": bundle.kernel_procedure,
                    "artifacts": {
                        "python": _relative(
                            root / "partial_loops" / name / bundle.artifacts["kernel_python"],
                            root,
                        ),
                        "cython-safe": _relative(
                            root
                            / "partial_loops"
                            / name
                            / bundle.artifacts["cython_safe_extension"],
                            root,
                        ),
                        "cython-optimized": _relative(
                            root
                            / "partial_loops"
                            / name
                            / bundle.artifacts["cython_optimized_extension"],
                            root,
                        ),
                        **({
                            "fortran": _relative(
                                root / "partial_loops" / name / bundle.artifacts["fortran_wrapper"],
                                root,
                            )
                        } if include_fortran else {}),
                    },
                    "module_names": bundle.module_names,
                }
                for name, bundle in partial_bundles.items()
            },
            reference_path=_relative(reference_path, root),
            default_backend=default_backend,
            available_backends=(
                "python", "cython-safe", "cython-optimized",
                *(("fortran",) if include_fortran else ()),
            ),
        ),
        encoding="utf-8",
    )

    manifest = HybridProjectManifest(
        schema_version="1.5",
        root_procedure=root_procedure.lower(),
        source_files=project.source_files,
        default_backend=default_backend,
        available_backends=(
            "python", "cython-safe", "cython-optimized",
            *(("fortran",) if include_fortran else ()),
        ),
        artifacts={
            "project_ir": _relative(project_ir_path, root),
            "transformed_ir": _relative(transformed_ir_path, root),
            "plan": _relative(plan_path, root),
            "reference_python": _relative(reference_path, root),
            "hybrid_runtime": _relative(runtime_path, root),
            **({"profile_report": _relative(profile_path, root)} if profile_path else {}),
            **({"economics_report": _relative(economics_path, root)} if economics_path else {}),
        },
        kernel_bundles=full_manifest_paths,
        partial_loop_bundles=partial_manifest_paths,
        eligible_procedures=plan.eligible_procedures,
        extracted_procedures=plan.extracted_procedures,
        full_extracted_procedures=plan.full_extracted_procedures,
        partial_extracted_procedures=plan.partial_extracted_procedures,
        python_only_procedures=tuple(
            item.procedure for item in plan.candidates if not item.selected
        ),
        build_metrics=build_metrics,
    )
    manifest_path = root / "hybrid_project_manifest.json"
    manifest_path.write_text(
        json.dumps(manifest.to_dict(), indent=2) + "\n", encoding="utf-8"
    )
    return manifest, manifest_path


def generate_hybrid_runtime(
    project: ProjectIR,
    plan: HybridProjectPlan,
    *,
    full_wrapper_paths: dict[str, str],
    partial_extractions: dict[str, PartialLoopExtraction],
    partial_specs: dict[str, dict[str, object]],
    reference_path: str,
    default_backend: str,
    available_backends: tuple[str, ...] = ("python", "cython-safe", "cython-optimized"),
) -> str:
    """Generate one backend registry for full procedures and internal loops."""

    root = project.procedure(plan.root_procedure)
    procedures = {item.name: item for item in project.procedures}
    lines = [
        '"""Generated project-level Python/Cython/Fortran hybrid runtime."""',
        "",
        "from contextvars import ContextVar",
        "import importlib.machinery",
        "import importlib.util",
        "from pathlib import Path",
        "import sys",
        "from types import ModuleType",
        "from typing import Literal, Mapping",
        "",
        "import numpy as np",
        "",
        f"BackendName = Literal[{', '.join(repr(name) for name in available_backends)}]",
        f"DEFAULT_BACKEND: BackendName = {default_backend!r}",
        f"ELIGIBLE_PROCEDURES = {plan.eligible_procedures!r}",
        f"EXTRACTED_PROCEDURES = {plan.extracted_procedures!r}",
        f"FULL_EXTRACTED_PROCEDURES = {plan.full_extracted_procedures!r}",
        f"PARTIAL_EXTRACTED_PROCEDURES = {plan.partial_extracted_procedures!r}",
        f"PYTHON_ONLY_PROCEDURES = {tuple(item.procedure for item in plan.candidates if not item.selected)!r}",
        "_ROOT = Path(__file__).resolve().parent",
        "_MODULE_CACHE: dict[str, ModuleType] = {}",
        "_BACKEND_CONTEXT: ContextVar[tuple[BackendName, dict[str, BackendName]]] = ContextVar(",
        "    'fpy_hybrid_backend', default=(DEFAULT_BACKEND, {})",
        ")",
        "",
        "def _resolve_module_path(name: str, relative_path: str) -> Path:",
        "    path = (_ROOT / relative_path).resolve()",
        "    if path.exists():",
        "        return path",
        "    candidates: list[Path] = []",
        "    for suffix in importlib.machinery.EXTENSION_SUFFIXES:",
        "        candidates.extend(_ROOT.rglob(f'{name}{suffix}'))",
        "    candidates.extend(_ROOT.rglob(f'{name}.py'))",
        "    files = sorted({item.resolve() for item in candidates if item.is_file()}, key=lambda item: (len(item.parts), str(item)))",
        "    if not files:",
        "        raise FileNotFoundError(path)",
        "    return files[0]",
        "",
        "def _load_module(name: str, relative_path: str) -> ModuleType:",
        "    if name in _MODULE_CACHE:",
        "        return _MODULE_CACHE[name]",
        "    path = _resolve_module_path(name, relative_path)",
        "    spec = importlib.util.spec_from_file_location(name, path)",
        "    if spec is None or spec.loader is None:",
        "        raise ImportError(f'cannot load generated module: {path}')",
        "    module = importlib.util.module_from_spec(spec)",
        "    sys.modules[name] = module",
        "    spec.loader.exec_module(module)",
        "    _MODULE_CACHE[name] = module",
        "    return module",
        "",
        f"_REFERENCE = _load_module('fpy_hybrid_reference', {reference_path!r})",
        f"_FULL_WRAPPER_PATHS = {full_wrapper_paths!r}",
        "_FULL_WRAPPERS = {",
        "    name: _load_module(f'fpy_hybrid_wrapper_{name}', path)",
        "    for name, path in _FULL_WRAPPER_PATHS.items()",
        "}",
        f"_PARTIAL_SPECS = {partial_specs!r}",
        "_PARTIAL_BACKENDS = {",
        "    procedure: {",
        "        backend: _load_module(spec['module_names'][backend], path)",
        "        for backend, path in spec['artifacts'].items()",
        "    }",
        "    for procedure, spec in _PARTIAL_SPECS.items()",
        "}",
        "",
        "def _backend_for(procedure: str) -> BackendName:",
        "    default, overrides = _BACKEND_CONTEXT.get()",
        "    return overrides.get(procedure, default)",
        "",
        "def available_kernels() -> tuple[str, ...]:",
        "    return EXTRACTED_PROCEDURES",
        "",
        "def eligible_kernels() -> tuple[str, ...]:",
        "    return ELIGIBLE_PROCEDURES",
        "",
        "def call_kernel(procedure: str, *args, backend: BackendName | None = None, **kwargs):",
        "    if procedure not in FULL_EXTRACTED_PROCEDURES:",
        "        raise ValueError('direct call_kernel is limited to full-procedure kernels')",
        "    wrapper = _FULL_WRAPPERS[procedure]",
        "    selected = backend or _backend_for(procedure)",
        "    return getattr(wrapper, procedure)(*args, backend=selected, **kwargs)",
        "",
    ]

    for group in project.state_groups:
        class_name = _state_class(group.name)
        lines.append(f"{class_name} = _REFERENCE.{class_name}")
    if project.state_groups:
        lines.append("")
    for group in project.state_groups:
        factory = _render_state_factory(group)
        if factory:
            lines.extend(factory)
            lines.append("")

    for procedure_name in plan.full_extracted_procedures:
        procedure = procedures[procedure_name]
        lines.extend(_render_full_dispatcher(procedure))
        lines.append("")
        lines.append(f"_REFERENCE.{procedure_name} = _dispatch_{procedure_name}")

    for source_name in plan.partial_extracted_procedures:
        extraction = partial_extractions[source_name]
        lines.append("")
        lines.extend(_render_partial_dispatcher(source_name, extraction))
        lines.append("")
        lines.append(
            f"_REFERENCE.{extraction.kernel_procedure} = "
            f"_dispatch_{extraction.kernel_procedure}"
        )

    lines.append("")
    lines.extend(_render_root_wrapper(root))
    lines.append("")
    return "\n".join(lines)


def load_hybrid_runtime(path: str | Path, module_name: str | None = None) -> ModuleType:
    runtime = Path(path).resolve()
    resolved_name = module_name or f"fpy_hybrid_runtime_{abs(hash(runtime))}"
    spec = importlib.util.spec_from_file_location(resolved_name, runtime)
    if spec is None or spec.loader is None:
        raise ImportError(f"cannot load hybrid runtime: {runtime}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[resolved_name] = module
    spec.loader.exec_module(module)
    return module


def _render_full_dispatcher(procedure: ProcedureIR) -> list[str]:
    symbols = {item.name: item for item in procedure.symbols}
    input_arguments = [
        name for name in procedure.arguments if symbols[name].intent != "out"
    ]
    declarations = [f"state_{_safe_name(name)}" for name in procedure.state_groups]
    declarations.extend(input_arguments)
    args = ", ".join(declarations)
    call_args = args
    return [
        f"def _dispatch_{procedure.name}({args}):",
        f"    return call_kernel({procedure.name!r}, {call_args})"
        if call_args
        else f"    return call_kernel({procedure.name!r})",
    ]


def _render_partial_dispatcher(
    source_procedure: str,
    extraction: PartialLoopExtraction,
) -> list[str]:
    kernel = extraction.kernel_project.procedure(extraction.kernel_procedure)
    outputs = [
        kernel.symbol(name)
        for name in kernel.arguments
        if kernel.symbol(name).intent in {"out", "inout"}
    ]
    lines = [
        f"def _dispatch_{kernel.name}(*args):",
        f"    selected = _backend_for({source_procedure!r})",
        f"    module = _PARTIAL_BACKENDS[{source_procedure!r}][selected]",
        f"    result = getattr(module, {kernel.name!r})(*args)",
    ]
    lines.extend(_render_result_normalization(outputs, indent=1))
    return lines


def _render_result_normalization(outputs: list[SymbolIR], *, indent: int) -> list[str]:
    prefix = "    " * indent
    if not outputs:
        return [f"{prefix}return None"]
    if len(outputs) == 1:
        return [f"{prefix}return {_normalize_expression('result', outputs[0])}"]
    lines = [f"{prefix}values = tuple(result)", f"{prefix}return ("]
    for index, symbol in enumerate(outputs):
        lines.append(f"{prefix}    {_normalize_expression(f'values[{index}]', symbol)},")
    lines.append(f"{prefix})")
    return lines


def _normalize_expression(value: str, symbol: SymbolIR) -> str:
    if symbol.rank:
        return f"np.asarray({value})"
    cast = {"real": "float", "integer": "int", "logical": "bool"}.get(
        symbol.type.category
    )
    if cast is None:
        raise ValueError(f"unsupported hybrid scalar output type: {symbol.type.category}")
    return f"{cast}({value})"


def _render_root_wrapper(root: ProcedureIR) -> list[str]:
    symbols = {item.name: item for item in root.symbols}
    input_arguments = [name for name in root.arguments if symbols[name].intent != "out"]
    state_arguments = [f"state_{_safe_name(name)}" for name in root.state_groups]
    declarations = [*state_arguments, *input_arguments]
    signature = ", ".join(
        [
            *declarations,
            "*",
            "backend: BackendName = DEFAULT_BACKEND",
            "backend_overrides: Mapping[str, BackendName] | None = None",
        ]
    )
    call = ", ".join(declarations)
    return [
        f"def {root.name}({signature}):",
        "    overrides = dict(backend_overrides or {})",
        "    unknown = sorted(set(overrides) - set(EXTRACTED_PROCEDURES))",
        "    if unknown:",
        "        raise ValueError(f'backend override refers to non-kernel procedures: {unknown}')",
        "    token = _BACKEND_CONTEXT.set((backend, overrides))",
        "    try:",
        f"        return _REFERENCE.{root.name}({call})"
        if call
        else f"        return _REFERENCE.{root.name}()",
        "    finally:",
        "        _BACKEND_CONTEXT.reset(token)",
    ]


def _render_state_factory(group: StateGroupIR) -> list[str] | None:
    values: list[str] = []
    for field in group.fields:
        if field.rank:
            dimensions: list[str] = []
            for extent in field.shape:
                if extent is None or extent.kind != "literal":
                    return None
                dimensions.append(str(extent.value))
            shape = ", ".join(dimensions)
            if field.rank == 1:
                shape += ","
            dtype = {
                "real": "np.float64",
                "integer": "np.int64",
                "logical": "np.bool_",
            }.get(field.type.category)
            if dtype is None:
                return None
            values.append(
                f"{field.state_field or field.name}=np.zeros(({shape}), dtype={dtype})"
            )
        else:
            default = {"real": "0.0", "integer": "0", "logical": "False"}.get(
                field.type.category
            )
            if default is None:
                return None
            values.append(f"{field.state_field or field.name}={default}")
    class_name = _state_class(group.name)
    return [
        f"def create_{_safe_name(group.name)}() -> {class_name}:",
        f"    return {class_name}({', '.join(values)})",
    ]


def _first_partial_extraction(
    project: ProjectIR,
    procedure: ProcedureIR,
) -> tuple[PartialLoopExtraction | None, tuple[str, ...]]:
    top_level_count = sum(isinstance(item, DoLoopIR) for item in procedure.statements)
    reasons: list[str] = []
    for loop_index in range(1, top_level_count + 1):
        try:
            return analyze_partial_loop(
                project, procedure.name, loop_index=loop_index
            ), tuple(reasons)
        except PartialLoopExtractionError as exc:
            reasons.append(f"loop {loop_index}: {exc}")
    return None, tuple(reasons)


def _count_loops(procedure: ProcedureIR) -> int:
    def visit(statements) -> int:
        total = 0
        for statement in statements:
            if isinstance(statement, DoLoopIR):
                total += 1 + visit(statement.body)
            elif isinstance(statement, IfIR):
                total += visit(statement.body) + visit(statement.else_body)
        return total

    return visit(procedure.statements)


def _state_class(group_name: str) -> str:
    parts = [item for item in re.split(r"[^a-zA-Z0-9]+|_+", group_name) if item]
    return "".join(item[:1].upper() + item[1:] for item in parts) + "State"


def _safe_name(value: str) -> str:
    return re.sub(r"[^a-zA-Z0-9_]", "_", value).lower()


def _relative(path: Path, root: Path) -> str:
    return path.resolve().relative_to(root.resolve()).as_posix()
