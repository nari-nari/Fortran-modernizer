from __future__ import annotations

from dataclasses import asdict, dataclass, replace
import importlib.util
import json
from pathlib import Path
import re
import sys
from types import ModuleType
from typing import Iterable, Literal

from fpy_migrate.backends import build_fortran_kernel_backend
from fpy_migrate.ir import build_project_ir, write_project_ir
from fpy_migrate.ir.model import (
    AssignmentIR,
    CallIR,
    DoLoopIR,
    ExpressionIR,
    ExitIR,
    IfIR,
    ProcedureIR,
    ProjectIR,
    StatementIR,
    SymbolIR,
)
from fpy_migrate.kernels import build_cython_extension
from fpy_migrate.translate import (
    generate_cython,
    generate_python,
    write_cython,
    write_python,
)


StateAccessMode = Literal["in", "out", "inout"]
class StateKernelExtractionError(ValueError):
    """Raised when a stateful procedure cannot be safely split into a kernel."""


@dataclass(frozen=True)
class StateKernelBinding:
    state_group: str
    state_field: str
    local_name: str
    kernel_name: str
    intent: StateAccessMode
    category: str
    kind: str | None
    rank: int
    shape: tuple[str | None, ...]

    def to_dict(self) -> dict[str, object]:
        return asdict(self)


@dataclass(frozen=True)
class StateKernelExtraction:
    source_procedure: str
    kernel_procedure: str
    status: Literal["AUTO", "BLOCKED"]
    loop_count: int
    bindings: tuple[StateKernelBinding, ...]
    explicit_arguments: tuple[str, ...]
    diagnostics: tuple[str, ...]
    kernel_project: ProjectIR

    def report_dict(self) -> dict[str, object]:
        return {
            "schema_version": "1.0",
            "source_procedure": self.source_procedure,
            "kernel_procedure": self.kernel_procedure,
            "status": self.status,
            "loop_count": self.loop_count,
            "bindings": [item.to_dict() for item in self.bindings],
            "explicit_arguments": list(self.explicit_arguments),
            "diagnostics": list(self.diagnostics),
        }


@dataclass(frozen=True)
class StateKernelBundle:
    schema_version: str
    source_file: str
    source_procedure: str
    kernel_procedure: str
    wrapper_procedure: str
    artifacts: dict[str, str]
    module_names: dict[str, str]
    bindings: tuple[StateKernelBinding, ...]

    def to_dict(self) -> dict[str, object]:
        return {
            "schema_version": self.schema_version,
            "source_file": self.source_file,
            "source_procedure": self.source_procedure,
            "kernel_procedure": self.kernel_procedure,
            "wrapper_procedure": self.wrapper_procedure,
            "artifacts": self.artifacts,
            "module_names": self.module_names,
            "bindings": [item.to_dict() for item in self.bindings],
        }


@dataclass
class _Access:
    read: bool = False
    write: bool = False

    @property
    def intent(self) -> StateAccessMode:
        if self.read and self.write:
            return "inout"
        if self.write:
            return "out"
        return "in"


def analyze_state_kernel(
    project: ProjectIR,
    procedure: str,
) -> StateKernelExtraction:
    """Extract a stateless explicit-argument kernel from a stateful procedure.

    The initial safe subset extracts the complete numerical body of one stateful
    procedure. Calls are deliberately blocked because a stateful call graph needs
    interprocedural alias and side-effect analysis before it can be compiled.
    """

    try:
        source_procedure = project.procedure(procedure)
    except KeyError as exc:
        raise StateKernelExtractionError(
            f"procedure is not present in Migration IR: {procedure}"
        ) from exc

    if not source_procedure.state_groups:
        raise StateKernelExtractionError(
            f"{source_procedure.name}: procedure does not use COMMON/module state"
        )

    calls = tuple(_walk_calls(source_procedure.statements))
    if calls:
        names = ", ".join(sorted({item.procedure for item in calls}))
        raise StateKernelExtractionError(
            f"{source_procedure.name}: state-kernel extraction does not yet support "
            f"procedure calls inside the extracted body: {names}"
        )

    loop_count = _count_loops(source_procedure.statements)
    if loop_count == 0:
        raise StateKernelExtractionError(
            f"{source_procedure.name}: no loop was found to extract"
        )

    state_symbols = {
        item.name: item for item in source_procedure.symbols if item.role == "state"
    }
    access = {name: _Access() for name in state_symbols}
    _collect_statement_access(source_procedure.statements, state_symbols, access)
    used_state_names = [name for name, item in access.items() if item.read or item.write]
    if not used_state_names:
        raise StateKernelExtractionError(
            f"{source_procedure.name}: state metadata exists but no state field is used"
        )

    occupied = {
        item.name for item in source_procedure.symbols if item.role != "state"
    }
    rename: dict[str, str] = {}
    bindings: list[StateKernelBinding] = []
    for local_name in used_state_names:
        symbol = state_symbols[local_name]
        assert symbol.state_group is not None and symbol.state_field is not None
        preferred = symbol.state_field
        kernel_name = _unique_kernel_name(preferred, symbol.state_group, occupied)
        occupied.add(kernel_name)
        rename[local_name] = kernel_name
        bindings.append(
            StateKernelBinding(
                state_group=symbol.state_group,
                state_field=symbol.state_field,
                local_name=local_name,
                kernel_name=kernel_name,
                intent=access[local_name].intent,
                category=symbol.type.category,
                kind=symbol.type.kind,
                rank=symbol.rank,
                shape=tuple(_shape_text(item) for item in symbol.shape),
            )
        )

    rewritten_statements = tuple(
        _rewrite_statement(item, rename) for item in source_procedure.statements
    )
    explicit_symbols = [
        replace(
            item,
            shape=tuple(
                _rewrite_expression(extent, rename) if extent is not None else None
                for extent in item.shape
            ),
            state_group=None,
            state_field=None,
        )
        for item in source_procedure.symbols
        if item.role != "state"
    ]
    binding_by_local = {item.local_name: item for item in bindings}
    state_argument_symbols = [
        SymbolIR(
            name=binding_by_local[name].kernel_name,
            type=state_symbols[name].type,
            intent=binding_by_local[name].intent,
            rank=state_symbols[name].rank,
            shape=tuple(
                _rewrite_expression(extent, rename) if extent is not None else None
                for extent in state_symbols[name].shape
            ),
            role="argument",
        )
        for name in used_state_names
    ]
    kernel_arguments = (*source_procedure.arguments, *(item.kernel_name for item in bindings))
    kernel_name = f"{source_procedure.name}_kernel"
    kernel_procedure = ProcedureIR(
        name=kernel_name,
        source_span=source_procedure.source_span,
        arguments=tuple(kernel_arguments),
        symbols=tuple((*explicit_symbols, *state_argument_symbols)),
        statements=rewritten_statements,
        constants=source_procedure.constants,
        state_groups=(),
        status="AUTO",
        diagnostics=(
            f"extracted from stateful procedure {source_procedure.name}",
            "state fields were converted to explicit numerical arguments",
        ),
    )
    kernel_project = ProjectIR(
        schema_version=project.schema_version,
        source_files=project.source_files,
        procedures=(kernel_procedure,),
        state_groups=(),
    )
    return StateKernelExtraction(
        source_procedure=source_procedure.name,
        kernel_procedure=kernel_name,
        status="AUTO",
        loop_count=loop_count,
        bindings=tuple(bindings),
        explicit_arguments=source_procedure.arguments,
        diagnostics=(
            "the complete supported numerical body is extracted as one stateless kernel",
            "the Python wrapper retains ownership of COMMON/module state",
            "Cython receives only scalar values and NumPy-compatible arrays",
        ),
        kernel_project=kernel_project,
    )


def write_state_kernel_report(
    extraction: StateKernelExtraction,
    output: str | Path,
) -> Path:
    path = Path(output)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(extraction.report_dict(), indent=2) + "\n", encoding="utf-8"
    )
    return path


def build_state_kernel_bundle(
    source: str | Path,
    *,
    procedure: str,
    build_directory: str | Path,
    refactor_report: str | Path | None = None,
    include_fortran: bool = False,
) -> tuple[StateKernelBundle, Path]:
    """Generate Python/Cython kernels, optional Fortran kernel, and a Python state adapter."""

    project = build_project_ir(
        source,
        procedure=procedure,
        refactor_report=refactor_report,
    )
    return build_state_kernel_bundle_from_project(
        project,
        procedure=procedure,
        build_directory=build_directory,
        include_fortran=include_fortran,
    )


def build_state_kernel_bundle_from_project(
    project: ProjectIR,
    *,
    procedure: str,
    build_directory: str | Path,
    include_fortran: bool = False,
) -> tuple[StateKernelBundle, Path]:
    """Build one state-kernel bundle from an already validated project IR."""

    root = Path(build_directory).resolve()
    root.mkdir(parents=True, exist_ok=True)
    extraction = analyze_state_kernel(project, procedure)
    kernel = extraction.kernel_procedure

    report_path = write_state_kernel_report(
        extraction, root / "state_kernel_extraction.json"
    )
    ir_path = write_project_ir(extraction.kernel_project, root / f"{kernel}.ir.json")

    python_path = write_python(
        generate_python(extraction.kernel_project, procedure=kernel),
        root / f"{kernel}_python.py",
    )
    safe_source = write_cython(
        generate_cython(
            extraction.kernel_project,
            procedure=kernel,
            safety_mode="safe",
        ),
        root / f"{kernel}_cython_safe.py",
    )
    optimized_source = write_cython(
        generate_cython(
            extraction.kernel_project,
            procedure=kernel,
            safety_mode="optimized",
        ),
        root / f"{kernel}_cython_optimized.py",
    )

    safe_module = _module_name(kernel, "safe")
    optimized_module = _module_name(kernel, "optimized")
    safe_built = build_cython_extension(
        safe_source,
        safe_module,
        root / "cython_safe_build",
        safety_mode="safe",
    )
    optimized_built = build_cython_extension(
        optimized_source,
        optimized_module,
        root / "cython_optimized_build",
        safety_mode="optimized",
    )

    wrapper_path = root / f"{extraction.source_procedure}_state_wrapper.py"
    artifacts = {
        "report": _relative(report_path, root),
        "kernel_ir": _relative(ir_path, root),
        "python": _relative(python_path, root),
        "cython_safe_source": _relative(safe_source, root),
        "cython_optimized_source": _relative(optimized_source, root),
        "cython_safe_extension": _relative(safe_built.extension, root),
        "cython_optimized_extension": _relative(optimized_built.extension, root),
        **({"cython_safe_build_report": _relative(safe_built.report, root)} if safe_built.report else {}),
        **({"cython_optimized_build_report": _relative(optimized_built.report, root)} if optimized_built.report else {}),
        "wrapper": _relative(wrapper_path, root),
    }
    module_names = {
        "python": f"{kernel}_python",
        "cython-safe": safe_module,
        "cython-optimized": optimized_module,
    }
    if include_fortran:
        fortran_built = build_fortran_kernel_backend(
            extraction.kernel_project,
            procedure=kernel,
            build_directory=root / "fortran_build",
        )
        artifacts.update({
            "fortran_source": _relative(fortran_built.source, root),
            "fortran_library": _relative(fortran_built.library, root),
            "fortran_wrapper": _relative(fortran_built.wrapper, root),
        })
        module_names["fortran"] = fortran_built.module_name
    wrapper_path.write_text(
        generate_state_wrapper(
            project,
            extraction,
            artifact_paths={
                "python": artifacts["python"],
                "cython-safe": artifacts["cython_safe_extension"],
                "cython-optimized": artifacts["cython_optimized_extension"],
                **({"fortran": artifacts["fortran_wrapper"]} if include_fortran else {}),
            },
            module_names=module_names,
        ),
        encoding="utf-8",
    )

    bundle = StateKernelBundle(
        schema_version="1.0",
        source_file=project.source_files[0] if len(project.source_files) == 1 else "<multi-file-project>",
        source_procedure=extraction.source_procedure,
        kernel_procedure=extraction.kernel_procedure,
        wrapper_procedure=extraction.source_procedure,
        artifacts=artifacts,
        module_names=module_names,
        bindings=extraction.bindings,
    )
    manifest_path = root / "state_kernel_manifest.json"
    manifest_path.write_text(
        json.dumps(bundle.to_dict(), indent=2) + "\n", encoding="utf-8"
    )
    return bundle, manifest_path


def generate_state_wrapper(
    project: ProjectIR,
    extraction: StateKernelExtraction,
    *,
    artifact_paths: dict[str, str],
    module_names: dict[str, str],
) -> str:
    source = project.procedure(extraction.source_procedure)
    kernel = extraction.kernel_project.procedure(extraction.kernel_procedure)
    source_symbols = {item.name: item for item in source.symbols}
    binding_by_kernel = {item.kernel_name: item for item in extraction.bindings}

    lines = [
        '"""Generated Python state wrapper and selectable numerical backends."""',
        "",
        "from dataclasses import dataclass",
        "import importlib.machinery",
        "import importlib.util",
        "from pathlib import Path",
        "import sys",
        "from types import ModuleType",
        "from typing import Literal",
        "",
        "import numpy as np",
        "import numpy.typing as npt",
        "",
        "FloatArray = npt.NDArray[np.float64]",
        "IntArray = npt.NDArray[np.int64]",
        "BoolArray = npt.NDArray[np.bool_]",
        f"BackendName = Literal[{', '.join(repr(name) for name in artifact_paths)}]",
        "",
    ]
    selected_groups = [project.state_group(name) for name in source.state_groups]
    for group in selected_groups:
        lines.extend(_render_state_class(group))
        lines.append("")

    lines.extend(
        [
            "_ROOT = Path(__file__).resolve().parent",
            f"_BACKEND_PATHS = {artifact_paths!r}",
            f"_BACKEND_MODULES = {module_names!r}",
            "_CACHE: dict[str, ModuleType] = {}",
            "",
            "def _resolve_backend_path(relative_path: str, module_name: str) -> Path:",
            "    path = (_ROOT / relative_path).resolve()",
            "    if path.exists():",
            "        return path",
            "    candidates: list[Path] = []",
            "    for suffix in importlib.machinery.EXTENSION_SUFFIXES:",
            "        candidates.extend(_ROOT.rglob(f'{module_name}{suffix}'))",
            "    candidates.extend(_ROOT.rglob(f'{module_name}.py'))",
            "    files = sorted({item.resolve() for item in candidates if item.is_file()}, key=lambda item: (len(item.parts), str(item)))",
            "    if not files:",
            "        raise FileNotFoundError(path)",
            "    return files[0]",
            "",
            "def _load_backend(backend: BackendName) -> ModuleType:",
            "    if backend in _CACHE:",
            "        return _CACHE[backend]",
            "    try:",
            "        relative_path = _BACKEND_PATHS[backend]",
            "        module_name = _BACKEND_MODULES[backend]",
            "    except KeyError as exc:",
            "        raise ValueError(f'unsupported state-kernel backend: {backend}') from exc",
            "    path = _resolve_backend_path(relative_path, module_name)",
            "    spec = importlib.util.spec_from_file_location(module_name, path)",
            "    if spec is None or spec.loader is None:",
            "        raise ImportError(f'cannot load generated backend: {path}')",
            "    module = importlib.util.module_from_spec(spec)",
            "    sys.modules[module_name] = module",
            "    spec.loader.exec_module(module)",
            "    _CACHE[backend] = module",
            "    return module",
            "",
        ]
    )

    input_arguments = [
        name for name in source.arguments if source_symbols[name].intent != "out"
    ]
    declarations = [
        f"state_{_safe_name(name)}: {_state_class(name)}" for name in source.state_groups
    ]
    declarations.extend(
        f"{name}: {_python_type(source_symbols[name])}" for name in input_arguments
    )
    declarations.append("*, backend: BackendName = 'python'")
    explicit_outputs = [
        source_symbols[name]
        for name in source.arguments
        if source_symbols[name].intent in {"out", "inout"}
    ]
    return_type = _return_type(explicit_outputs)
    lines.append(
        f"def {source.name}({', '.join(declarations)}) -> {return_type}:"
    )
    lines.append(
        f"    # Extracted kernel: {extraction.kernel_procedure}; state remains in Python."
    )
    lines.append("    module = _load_backend(backend)")
    lines.append(
        f"    kernel = getattr(module, {extraction.kernel_procedure!r})"
    )

    call_arguments: list[str] = []
    for argument in kernel.arguments:
        kernel_symbol = kernel.symbol(argument)
        if kernel_symbol.intent == "out":
            continue
        binding = binding_by_kernel.get(argument)
        if binding is None:
            source_expression = argument
        else:
            source_expression = (
                f"state_{_safe_name(binding.state_group)}.{binding.state_field}"
            )
        if kernel_symbol.rank:
            local_name = f"_kernel_input_{_safe_name(argument)}"
            lines.append(
                f"    {local_name} = np.ascontiguousarray({source_expression}) "
                f"if backend == 'cython-optimized' else {source_expression}"
            )
            call_arguments.append(local_name)
        else:
            call_arguments.append(source_expression)
    kernel_outputs = [
        kernel.symbol(name)
        for name in kernel.arguments
        if kernel.symbol(name).intent in {"out", "inout"}
    ]
    call = f"kernel({', '.join(call_arguments)})"
    if not kernel_outputs:
        lines.append(f"    {call}")
    elif len(kernel_outputs) == 1:
        lines.append(f"    _result_0 = {call}")
    else:
        names = ", ".join(f"_result_{index}" for index in range(len(kernel_outputs)))
        lines.append(f"    {names} = {call}")

    explicit_result_names: list[str] = []
    for index, output_symbol in enumerate(kernel_outputs):
        result_name = f"_result_{index}"
        binding = binding_by_kernel.get(output_symbol.name)
        if binding is not None:
            target = f"state_{_safe_name(binding.state_group)}.{binding.state_field}"
            if binding.rank:
                lines.append(f"    {target} = np.asarray({result_name})")
            else:
                lines.append(
                    f"    {target} = {_scalar_cast(binding.category)}({result_name})"
                )
        else:
            lines.append(f"    {output_symbol.name} = {result_name}")
            explicit_result_names.append(output_symbol.name)

    if not explicit_result_names:
        lines.append("    return None")
    elif len(explicit_result_names) == 1:
        lines.append(f"    return {explicit_result_names[0]}")
    else:
        lines.append(f"    return {', '.join(explicit_result_names)}")
    lines.append("")
    return "\n".join(lines)


def load_generated_wrapper(path: str | Path, module_name: str | None = None) -> ModuleType:
    wrapper = Path(path).resolve()
    resolved_name = module_name or f"fpy_state_wrapper_{abs(hash(wrapper))}"
    spec = importlib.util.spec_from_file_location(resolved_name, wrapper)
    if spec is None or spec.loader is None:
        raise ImportError(f"cannot load generated state wrapper: {wrapper}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[resolved_name] = module
    spec.loader.exec_module(module)
    return module


def _collect_statement_access(
    statements: Iterable[StatementIR],
    state_symbols: dict[str, SymbolIR],
    access: dict[str, _Access],
) -> None:
    for statement in statements:
        if isinstance(statement, AssignmentIR):
            _mark_target(statement.target, state_symbols, access)
            _mark_expression(statement.value, state_symbols, access)
        elif isinstance(statement, DoLoopIR):
            _mark_expression(statement.start, state_symbols, access)
            _mark_expression(statement.stop, state_symbols, access)
            _mark_expression(statement.step, state_symbols, access)
            _collect_statement_access(statement.body, state_symbols, access)
        elif isinstance(statement, IfIR):
            _mark_expression(statement.condition, state_symbols, access)
            _collect_statement_access(statement.body, state_symbols, access)
            _collect_statement_access(statement.else_body, state_symbols, access)
        elif isinstance(statement, CallIR):
            for argument in statement.arguments:
                _mark_expression(argument, state_symbols, access)
        elif isinstance(statement, ExitIR):
            continue
        else:  # pragma: no cover - StatementIR is closed but keep failure explicit.
            raise TypeError(type(statement))


def _mark_target(
    expression: ExpressionIR,
    state_symbols: dict[str, SymbolIR],
    access: dict[str, _Access],
) -> None:
    if expression.kind in {"name", "array_ref"}:
        name = str(expression.value)
        if name in state_symbols:
            access[name].write = True
        for index in expression.indices:
            _mark_expression(index, state_symbols, access)
        return
    _mark_expression(expression, state_symbols, access)


def _mark_expression(
    expression: ExpressionIR,
    state_symbols: dict[str, SymbolIR],
    access: dict[str, _Access],
) -> None:
    if expression.kind in {"name", "array_ref"}:
        name = str(expression.value)
        if name in state_symbols:
            access[name].read = True
    for item in expression.arguments:
        _mark_expression(item, state_symbols, access)
    for item in expression.indices:
        _mark_expression(item, state_symbols, access)


def _rewrite_statement(statement: StatementIR, rename: dict[str, str]) -> StatementIR:
    if isinstance(statement, AssignmentIR):
        return replace(
            statement,
            target=_rewrite_expression(statement.target, rename),
            value=_rewrite_expression(statement.value, rename),
        )
    if isinstance(statement, DoLoopIR):
        return replace(
            statement,
            start=_rewrite_expression(statement.start, rename),
            stop=_rewrite_expression(statement.stop, rename),
            step=_rewrite_expression(statement.step, rename),
            body=tuple(_rewrite_statement(item, rename) for item in statement.body),
        )
    if isinstance(statement, IfIR):
        return replace(
            statement,
            condition=_rewrite_expression(statement.condition, rename),
            body=tuple(_rewrite_statement(item, rename) for item in statement.body),
            else_body=tuple(
                _rewrite_statement(item, rename) for item in statement.else_body
            ),
        )
    if isinstance(statement, CallIR):
        return replace(
            statement,
            arguments=tuple(
                _rewrite_expression(item, rename) for item in statement.arguments
            ),
        )
    if isinstance(statement, ExitIR):
        return statement
    raise TypeError(type(statement))


def _rewrite_expression(expression: ExpressionIR, rename: dict[str, str]) -> ExpressionIR:
    value = expression.value
    if expression.kind in {"name", "array_ref"} and str(value) in rename:
        value = rename[str(value)]
    return replace(
        expression,
        value=value,
        arguments=tuple(
            _rewrite_expression(item, rename) for item in expression.arguments
        ),
        indices=tuple(_rewrite_expression(item, rename) for item in expression.indices),
    )


def _walk_calls(statements: Iterable[StatementIR]) -> Iterable[CallIR]:
    for statement in statements:
        if isinstance(statement, CallIR):
            yield statement
        elif isinstance(statement, DoLoopIR):
            yield from _walk_calls(statement.body)
        elif isinstance(statement, IfIR):
            yield from _walk_calls(statement.body)
            yield from _walk_calls(statement.else_body)


def _count_loops(statements: Iterable[StatementIR]) -> int:
    count = 0
    for statement in statements:
        if isinstance(statement, DoLoopIR):
            count += 1 + _count_loops(statement.body)
        elif isinstance(statement, IfIR):
            count += _count_loops(statement.body)
            count += _count_loops(statement.else_body)
    return count


def _unique_kernel_name(preferred: str, group: str, occupied: set[str]) -> str:
    if preferred not in occupied:
        return preferred
    prefixed = f"{_safe_name(group)}_{preferred}"
    if prefixed not in occupied:
        return prefixed
    index = 2
    while f"{prefixed}_{index}" in occupied:
        index += 1
    return f"{prefixed}_{index}"


def _safe_name(value: str) -> str:
    return re.sub(r"[^a-zA-Z0-9_]", "_", value).lower()


def _state_class(group_name: str) -> str:
    parts = [item for item in re.split(r"[^a-zA-Z0-9]+|_+", group_name) if item]
    return "".join(item[:1].upper() + item[1:] for item in parts) + "State"


def _render_state_class(group) -> list[str]:
    lines = [
        "@dataclass",
        f"class {_state_class(group.name)}:",
        f"    # Fortran {group.source_kind}: {group.source_name}",
    ]
    for field in group.fields:
        lines.append(
            f"    {field.state_field or field.name}: {_python_type(field)}"
        )
    if not group.fields:
        lines.append("    pass")
    return lines


def _python_type(symbol: SymbolIR) -> str:
    if symbol.rank:
        mapping = {
            "real": "FloatArray",
            "integer": "IntArray",
            "logical": "BoolArray",
        }
    else:
        mapping = {"real": "float", "integer": "int", "logical": "bool"}
    try:
        return mapping[symbol.type.category]
    except KeyError as exc:
        raise StateKernelExtractionError(
            f"unsupported state-kernel Python type: {symbol.type.category}"
        ) from exc


def _return_type(symbols: list[SymbolIR]) -> str:
    if not symbols:
        return "None"
    types = [_python_type(item) for item in symbols]
    return types[0] if len(types) == 1 else f"tuple[{', '.join(types)}]"


def _scalar_cast(category: str) -> str:
    return {"real": "float", "integer": "int", "logical": "bool"}[category]


def _shape_text(extent: ExpressionIR | None) -> str | None:
    if extent is None:
        return None
    if extent.kind in {"literal", "name"}:
        return str(extent.value)
    return extent.kind


def _module_name(kernel: str, mode: str) -> str:
    return f"fpy_{_safe_name(kernel)}_{mode}"


def _relative(path: Path, root: Path) -> str:
    return path.resolve().relative_to(root.resolve()).as_posix()
