from __future__ import annotations

from dataclasses import asdict, dataclass, replace
import importlib.util
import json
from pathlib import Path
import re
import sys
from types import ModuleType
from typing import Iterable, Literal

from fpy_migrate.backends import build_fortran_kernel_backend
from fpy_migrate.ir import build_project_ir, write_project_ir
from fpy_migrate.ir.model import (
    AssignmentIR,
    CallIR,
    DoLoopIR,
    ExpressionIR,
    ExitIR,
    IfIR,
    ProcedureIR,
    ProjectIR,
    SourceSpan,
    StatementIR,
    SymbolIR,
)
from fpy_migrate.kernels import build_cython_extension
from fpy_migrate.translate import generate_cython, generate_python, write_cython, write_python


AccessMode = Literal["in", "out", "inout"]


class PartialLoopExtractionError(ValueError):
    """Raised when an internal loop cannot be split safely from its procedure."""


@dataclass(frozen=True)
class PartialLoopBinding:
    source_name: str
    kernel_name: str
    source_role: Literal["argument", "local", "state"]
    intent: AccessMode
    category: str
    kind: str | None
    rank: int
    state_group: str | None = None
    state_field: str | None = None

    def to_dict(self) -> dict[str, object]:
        return asdict(self)


@dataclass(frozen=True)
class PartialLoopExtraction:
    source_procedure: str
    loop_index: int
    loop_source_span: SourceSpan
    kernel_procedure: str
    status: Literal["AUTO", "BLOCKED"]
    pre_statement_count: int
    post_statement_count: int
    bindings: tuple[PartialLoopBinding, ...]
    diagnostics: tuple[str, ...]
    kernel_project: ProjectIR
    wrapper_project: ProjectIR

    def report_dict(self) -> dict[str, object]:
        return {
            "schema_version": "1.0",
            "source_procedure": self.source_procedure,
            "loop_index": self.loop_index,
            "loop_source_span": asdict(self.loop_source_span),
            "kernel_procedure": self.kernel_procedure,
            "status": self.status,
            "pre_statement_count": self.pre_statement_count,
            "post_statement_count": self.post_statement_count,
            "bindings": [item.to_dict() for item in self.bindings],
            "diagnostics": list(self.diagnostics),
        }


@dataclass(frozen=True)
class PartialLoopBundle:
    schema_version: str
    source_procedure: str
    loop_index: int
    kernel_procedure: str
    default_backend: str
    artifacts: dict[str, str]
    module_names: dict[str, str]
    bindings: tuple[PartialLoopBinding, ...]

    def to_dict(self) -> dict[str, object]:
        return {
            "schema_version": self.schema_version,
            "source_procedure": self.source_procedure,
            "loop_index": self.loop_index,
            "kernel_procedure": self.kernel_procedure,
            "default_backend": self.default_backend,
            "artifacts": self.artifacts,
            "module_names": self.module_names,
            "bindings": [item.to_dict() for item in self.bindings],
        }


@dataclass
class _Access:
    read: bool = False
    write: bool = False
    first: Literal["read", "write"] | None = None

    def mark_read(self) -> None:
        if self.first is None:
            self.first = "read"
        self.read = True

    def mark_write(self) -> None:
        if self.first is None:
            self.first = "write"
        self.write = True


def analyze_partial_loop(
    project: ProjectIR,
    procedure: str,
    *,
    loop_index: int = 1,
) -> PartialLoopExtraction:
    """Extract one top-level DO loop and retain surrounding work in Python.

    This deliberately starts with top-level loops. Extracting nested regions safely
    requires control-flow region analysis and is left for a later milestone.
    """

    if loop_index < 1:
        raise PartialLoopExtractionError("loop_index is 1-based and must be positive")
    try:
        source = project.procedure(procedure)
    except KeyError as exc:
        raise PartialLoopExtractionError(
            f"procedure is not present in Migration IR: {procedure}"
        ) from exc

    top_level = [
        (position, item)
        for position, item in enumerate(source.statements)
        if isinstance(item, DoLoopIR)
    ]
    if loop_index > len(top_level):
        raise PartialLoopExtractionError(
            f"{source.name}: requested top-level loop {loop_index}, "
            f"but only {len(top_level)} loop(s) are available"
        )
    statement_position, selected_loop = top_level[loop_index - 1]

    calls = tuple(_walk_calls((selected_loop,)))
    if calls:
        names = ", ".join(sorted({item.procedure for item in calls}))
        raise PartialLoopExtractionError(
            f"{source.name}: selected loop contains procedure call(s): {names}; "
            "partial extraction blocks interprocedural side effects"
        )

    pre = source.statements[:statement_position]
    post = source.statements[statement_position + 1 :]
    symbols = {item.name: item for item in source.symbols}
    access = {name: _Access() for name in symbols}
    loop_variables = _loop_variables(selected_loop)
    _collect_access((selected_loop,), symbols, access, loop_variables=set())
    post_names = _referenced_names(post)
    definitely_defined = {
        item.name for item in source.symbols if item.role in {"argument", "state"}
    }
    definitely_defined.update(_unconditional_definitions(pre))

    referenced = [name for name, item in access.items() if item.read or item.write]
    if not referenced:
        raise PartialLoopExtractionError(
            f"{source.name}: selected loop has no migratable symbol references"
        )

    occupied = {item.name for item in source.symbols if item.role != "state"}
    rename: dict[str, str] = {}
    bindings: list[PartialLoopBinding] = []
    kernel_argument_symbols: list[SymbolIR] = []
    kernel_local_symbols: list[SymbolIR] = []
    actual_by_kernel: dict[str, str] = {}

    for loop_variable in sorted(loop_variables):
        try:
            loop_symbol = symbols[loop_variable]
        except KeyError as exc:  # build_project_ir normally catches this first.
            raise PartialLoopExtractionError(
                f"{source.name}: loop variable {loop_variable} is not declared"
            ) from exc
        kernel_local_symbols.append(
            replace(
                loop_symbol,
                role="local",
                intent=None,
                state_group=None,
                state_field=None,
            )
        )

    # Keep explicit arguments/bridge locals before shared-state fields. This
    # produces stable, readable kernels such as (n, bias, pressure, film).
    ordered_symbols = sorted(
        source.symbols,
        key=lambda item: (1 if item.role == "state" else 0, source.symbols.index(item)),
    )
    for symbol in ordered_symbols:
        name = symbol.name
        item_access = access[name]
        if name in loop_variables:
            continue
        if not (item_access.read or item_access.write):
            continue

        if symbol.role == "local" and symbol.rank:
            raise PartialLoopExtractionError(
                f"{source.name}: local array {name} is referenced by the selected loop; "
                "local-array lifetime extraction is not supported yet"
            )

        is_internal_temporary = (
            symbol.role == "local"
            and item_access.first == "write"
            and name not in post_names
            and name not in definitely_defined
        )
        if is_internal_temporary:
            kernel_local_symbols.append(
                replace(symbol, role="local", intent=None, state_group=None, state_field=None)
            )
            continue

        if symbol.role == "local" and item_access.first == "read" and name not in definitely_defined:
            raise PartialLoopExtractionError(
                f"{source.name}: local scalar {name} is read by the selected loop "
                "before an unconditional Python-side definition"
            )

        if symbol.role == "state":
            assert symbol.state_group is not None and symbol.state_field is not None
            preferred = symbol.state_field
            kernel_name = _unique_name(preferred, symbol.state_group, occupied)
            rename[name] = kernel_name
        else:
            kernel_name = name
        occupied.add(kernel_name)
        actual_by_kernel[kernel_name] = name

        intent = _bridge_intent(symbol, item_access)
        rewritten_shape = tuple(
            _rewrite_expression(extent, rename) if extent is not None else None
            for extent in symbol.shape
        )
        kernel_argument_symbols.append(
            SymbolIR(
                name=kernel_name,
                type=symbol.type,
                intent=intent,
                rank=symbol.rank,
                shape=rewritten_shape,
                role="argument",
            )
        )
        bindings.append(
            PartialLoopBinding(
                source_name=name,
                kernel_name=kernel_name,
                source_role=symbol.role,
                intent=intent,
                category=symbol.type.category,
                kind=symbol.type.kind,
                rank=symbol.rank,
                state_group=symbol.state_group,
                state_field=symbol.state_field,
            )
        )

    # Shape expressions can depend on a bridge name declared later. Rewrite them
    # once more after the full state-alias map is known.
    kernel_argument_symbols = [
        replace(
            item,
            shape=tuple(
                _rewrite_expression(extent, rename) if extent is not None else None
                for extent in item.shape
            ),
        )
        for item in kernel_argument_symbols
    ]
    kernel_local_symbols = [
        replace(
            item,
            shape=tuple(
                _rewrite_expression(extent, rename) if extent is not None else None
                for extent in item.shape
            ),
        )
        for item in kernel_local_symbols
    ]

    rewritten_loop = _rewrite_statement(selected_loop, rename)
    assert isinstance(rewritten_loop, DoLoopIR)
    kernel_name = f"{source.name}_loop_{loop_index}_kernel"
    kernel = ProcedureIR(
        name=kernel_name,
        source_span=selected_loop.source_span or source.source_span,
        arguments=tuple(item.name for item in kernel_argument_symbols),
        symbols=tuple((*kernel_argument_symbols, *kernel_local_symbols)),
        statements=(rewritten_loop,),
        constants=source.constants,
        state_groups=(),
        status="AUTO",
        diagnostics=(
            f"top-level loop {loop_index} extracted from {source.name}",
            "surrounding initialization and post-processing remain in Python",
        ),
    )
    kernel_project = ProjectIR(
        schema_version=project.schema_version,
        source_files=project.source_files,
        procedures=(kernel,),
        state_groups=(),
    )

    actual_arguments = tuple(
        ExpressionIR(kind="name", value=actual_by_kernel[name])
        for name in kernel.arguments
    )
    replacement_call = CallIR(
        procedure=kernel_name,
        arguments=actual_arguments,
        source_span=selected_loop.source_span,
    )
    transformed_source = replace(
        source,
        statements=(*pre, replacement_call, *post),
        diagnostics=(*source.diagnostics, f"loop {loop_index} delegated to {kernel_name}"),
    )
    wrapper_procedures: list[ProcedureIR] = []
    for item in project.procedures:
        if item.name == source.name:
            wrapper_procedures.extend((kernel, transformed_source))
        else:
            wrapper_procedures.append(item)
    wrapper_project = ProjectIR(
        schema_version=project.schema_version,
        source_files=project.source_files,
        procedures=tuple(wrapper_procedures),
        state_groups=project.state_groups,
    )

    return PartialLoopExtraction(
        source_procedure=source.name,
        loop_index=loop_index,
        loop_source_span=selected_loop.source_span or source.source_span,
        kernel_procedure=kernel_name,
        status="AUTO",
        pre_statement_count=len(pre),
        post_statement_count=len(post),
        bindings=tuple(bindings),
        diagnostics=(
            "only the selected top-level DO loop is compiled",
            "pre-loop and post-loop statements preserve source order in Python",
            "Cython receives explicit scalar/array arguments and no dataclass objects",
        ),
        kernel_project=kernel_project,
        wrapper_project=wrapper_project,
    )


def write_partial_loop_report(
    extraction: PartialLoopExtraction,
    output: str | Path,
) -> Path:
    path = Path(output)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(extraction.report_dict(), indent=2) + "\n", encoding="utf-8")
    return path


def build_partial_loop_bundle(
    source: str | Path,
    *,
    procedure: str,
    loop_index: int,
    build_directory: str | Path,
    refactor_report: str | Path | None = None,
    default_backend: Literal["python", "cython-safe", "cython-optimized", "fortran"] = "cython-optimized",
    include_fortran: bool = False,
) -> tuple[PartialLoopBundle, Path]:
    project = build_project_ir(
        source,
        procedure=procedure,
        refactor_report=refactor_report,
    )
    return build_partial_loop_bundle_from_project(
        project,
        procedure=procedure,
        loop_index=loop_index,
        build_directory=build_directory,
        default_backend=default_backend,
        include_fortran=include_fortran,
    )


def build_partial_loop_bundle_from_project(
    project: ProjectIR,
    *,
    procedure: str,
    loop_index: int,
    build_directory: str | Path,
    default_backend: Literal["python", "cython-safe", "cython-optimized", "fortran"] = "cython-optimized",
    include_fortran: bool = False,
) -> tuple[PartialLoopBundle, Path]:
    """Build one partial-loop bundle from an already validated project IR."""

    if default_backend not in {"python", "cython-safe", "cython-optimized", "fortran"}:
        raise ValueError(f"unsupported default backend: {default_backend}")
    if default_backend == "fortran" and not include_fortran:
        raise ValueError("default_backend='fortran' requires include_fortran=True")
    root = Path(build_directory).resolve()
    root.mkdir(parents=True, exist_ok=True)
    extraction = analyze_partial_loop(project, procedure, loop_index=loop_index)
    kernel = extraction.kernel_procedure

    report_path = write_partial_loop_report(extraction, root / "partial_loop_extraction.json")
    kernel_ir_path = write_project_ir(extraction.kernel_project, root / f"{kernel}.ir.json")
    wrapper_ir_path = write_project_ir(extraction.wrapper_project, root / "partial_wrapper.ir.json")

    kernel_python = write_python(
        generate_python(extraction.kernel_project, procedure=kernel),
        root / f"{kernel}_python.py",
    )
    safe_source = write_cython(
        generate_cython(extraction.kernel_project, procedure=kernel, safety_mode="safe"),
        root / f"{kernel}_cython_safe.py",
    )
    optimized_source = write_cython(
        generate_cython(extraction.kernel_project, procedure=kernel, safety_mode="optimized"),
        root / f"{kernel}_cython_optimized.py",
    )
    safe_module = _module_name(kernel, "safe")
    optimized_module = _module_name(kernel, "optimized")
    safe_built = build_cython_extension(
        safe_source, safe_module, root / "cython_safe_build", safety_mode="safe"
    )
    optimized_built = build_cython_extension(
        optimized_source,
        optimized_module,
        root / "cython_optimized_build",
        safety_mode="optimized",
    )

    wrapper_reference = write_python(
        generate_python(extraction.wrapper_project, procedure=extraction.source_procedure),
        root / "partial_wrapper_reference.py",
    )
    runtime_path = root / "partial_loop_runtime.py"
    artifacts = {
        "report": _relative(report_path, root),
        "kernel_ir": _relative(kernel_ir_path, root),
        "wrapper_ir": _relative(wrapper_ir_path, root),
        "kernel_python": _relative(kernel_python, root),
        "cython_safe_source": _relative(safe_source, root),
        "cython_optimized_source": _relative(optimized_source, root),
        "cython_safe_extension": _relative(safe_built.extension, root),
        "cython_optimized_extension": _relative(optimized_built.extension, root),
        **({"cython_safe_build_report": _relative(safe_built.report, root)} if safe_built.report else {}),
        **({"cython_optimized_build_report": _relative(optimized_built.report, root)} if optimized_built.report else {}),
        "wrapper_reference": _relative(wrapper_reference, root),
        "runtime": _relative(runtime_path, root),
    }
    module_names = {
        "python": f"{kernel}_python",
        "cython-safe": safe_module,
        "cython-optimized": optimized_module,
    }
    if include_fortran:
        fortran_built = build_fortran_kernel_backend(
            extraction.kernel_project,
            procedure=kernel,
            build_directory=root / "fortran_build",
        )
        artifacts.update({
            "fortran_source": _relative(fortran_built.source, root),
            "fortran_library": _relative(fortran_built.library, root),
            "fortran_wrapper": _relative(fortran_built.wrapper, root),
        })
        module_names["fortran"] = fortran_built.module_name
    runtime_path.write_text(
        generate_partial_loop_runtime(
            extraction,
            artifact_paths={
                "python": artifacts["kernel_python"],
                "cython-safe": artifacts["cython_safe_extension"],
                "cython-optimized": artifacts["cython_optimized_extension"],
                **({"fortran": artifacts["fortran_wrapper"]} if include_fortran else {}),
                "wrapper": artifacts["wrapper_reference"],
            },
            module_names=module_names,
            default_backend=default_backend,
        ),
        encoding="utf-8",
    )

    bundle = PartialLoopBundle(
        schema_version="1.0",
        source_procedure=extraction.source_procedure,
        loop_index=loop_index,
        kernel_procedure=kernel,
        default_backend=default_backend,
        artifacts=artifacts,
        module_names=module_names,
        bindings=extraction.bindings,
    )
    manifest_path = root / "partial_loop_manifest.json"
    manifest_path.write_text(json.dumps(bundle.to_dict(), indent=2) + "\n", encoding="utf-8")
    return bundle, manifest_path

def generate_partial_loop_runtime(
    extraction: PartialLoopExtraction,
    *,
    artifact_paths: dict[str, str],
    module_names: dict[str, str],
    default_backend: str,
) -> str:
    source = extraction.wrapper_project.procedure(extraction.source_procedure)
    kernel = extraction.kernel_project.procedure(extraction.kernel_procedure)
    symbols = {item.name: item for item in source.symbols}
    outputs = [
        kernel.symbol(name)
        for name in kernel.arguments
        if kernel.symbol(name).intent in {"out", "inout"}
    ]

    lines = [
        '"""Generated Python wrapper with a selectable compiled internal loop."""',
        "",
        "from contextvars import ContextVar",
        "import importlib.machinery",
        "import importlib.util",
        "from pathlib import Path",
        "import sys",
        "from types import ModuleType",
        "from typing import Literal",
        "",
        "import numpy as np",
        "",
        f"BackendName = Literal[{', '.join(repr(name) for name in module_names)}]",
        f"DEFAULT_BACKEND: BackendName = {default_backend!r}",
        "_ROOT = Path(__file__).resolve().parent",
        "_MODULE_CACHE: dict[str, ModuleType] = {}",
        "_BACKEND: ContextVar[BackendName] = ContextVar('fpy_partial_loop_backend', default=DEFAULT_BACKEND)",
        "",
        "def _resolve_module_path(name: str, relative_path: str) -> Path:",
        "    path = (_ROOT / relative_path).resolve()",
        "    if path.exists():",
        "        return path",
        "    candidates: list[Path] = []",
        "    for suffix in importlib.machinery.EXTENSION_SUFFIXES:",
        "        candidates.extend(_ROOT.rglob(f'{name}{suffix}'))",
        "    candidates.extend(_ROOT.rglob(f'{name}.py'))",
        "    files = sorted({item.resolve() for item in candidates if item.is_file()}, key=lambda item: (len(item.parts), str(item)))",
        "    if not files:",
        "        raise FileNotFoundError(path)",
        "    return files[0]",
        "",
        "def _load_module(name: str, relative_path: str) -> ModuleType:",
        "    if name in _MODULE_CACHE:",
        "        return _MODULE_CACHE[name]",
        "    path = _resolve_module_path(name, relative_path)",
        "    spec = importlib.util.spec_from_file_location(name, path)",
        "    if spec is None or spec.loader is None:",
        "        raise ImportError(f'cannot load generated module: {path}')",
        "    module = importlib.util.module_from_spec(spec)",
        "    sys.modules[name] = module",
        "    spec.loader.exec_module(module)",
        "    _MODULE_CACHE[name] = module",
        "    return module",
        "",
        f"_WRAPPER = _load_module('fpy_partial_wrapper', {artifact_paths['wrapper']!r})",
        f"_ARTIFACTS = { {key: artifact_paths[key] for key in module_names}!r}",
        f"_MODULE_NAMES = {module_names!r}",
        "_BACKENDS = {",
        "    name: _load_module(_MODULE_NAMES[name], path)",
        "    for name, path in _ARTIFACTS.items()",
        "}",
        "",
        f"def _dispatch_{kernel.name}(*args):",
        "    selected = _BACKEND.get()",
        f"    function = getattr(_BACKENDS[selected], {kernel.name!r})",
        "    result = function(*args)",
    ]
    lines.extend(_render_normalization(outputs, indent=1))
    lines.extend([
        "",
        f"_WRAPPER.{kernel.name} = _dispatch_{kernel.name}",
        "",
    ])

    for group in extraction.wrapper_project.state_groups:
        class_name = _state_class(group.name)
        lines.append(f"{class_name} = _WRAPPER.{class_name}")
    if extraction.wrapper_project.state_groups:
        lines.append("")
    for group in extraction.wrapper_project.state_groups:
        factory = _render_state_factory(group)
        if factory:
            lines.extend(factory)
            lines.append("")

    input_args = [name for name in source.arguments if symbols[name].intent != "out"]
    state_args = [f"state_{_safe_name(name)}" for name in source.state_groups]
    signature_items = [*state_args, *input_args, "*", "backend: BackendName = DEFAULT_BACKEND"]
    call_args = ", ".join((*state_args, *input_args))
    lines.extend([
        f"def {source.name}({', '.join(signature_items)}):",
        "    token = _BACKEND.set(backend)",
        "    try:",
        f"        return _WRAPPER.{source.name}({call_args})" if call_args else f"        return _WRAPPER.{source.name}()",
        "    finally:",
        "        _BACKEND.reset(token)",
        "",
    ])
    return "\n".join(lines)


def load_partial_loop_runtime(path: str | Path, module_name: str | None = None) -> ModuleType:
    runtime = Path(path).resolve()
    name = module_name or f"fpy_partial_loop_runtime_{abs(hash(runtime))}"
    spec = importlib.util.spec_from_file_location(name, runtime)
    if spec is None or spec.loader is None:
        raise ImportError(f"cannot load partial-loop runtime: {runtime}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def _render_normalization(outputs: list[SymbolIR], *, indent: int) -> list[str]:
    prefix = "    " * indent
    if not outputs:
        return [f"{prefix}return None"]
    if len(outputs) == 1:
        return [f"{prefix}return {_normalize_expression('result', outputs[0])}"]
    lines = [f"{prefix}values = tuple(result)", f"{prefix}return ("]
    for index, symbol in enumerate(outputs):
        lines.append(f"{prefix}    {_normalize_expression(f'values[{index}]', symbol)},")
    lines.append(f"{prefix})")
    return lines


def _normalize_expression(value: str, symbol: SymbolIR) -> str:
    if symbol.rank:
        return f"np.asarray({value})"
    cast = {"real": "float", "integer": "int", "logical": "bool"}.get(symbol.type.category)
    if cast is None:
        raise PartialLoopExtractionError(
            f"unsupported partial-loop scalar output type: {symbol.type.category}"
        )
    return f"{cast}({value})"


def _bridge_intent(symbol: SymbolIR, access: _Access) -> AccessMode:
    if not access.write:
        return "in"
    if symbol.role == "local" and access.first == "write":
        return "out"
    if symbol.role == "argument" and symbol.intent == "out" and access.first == "write":
        return "out"
    return "inout"


def _collect_access(
    statements: Iterable[StatementIR],
    symbols: dict[str, SymbolIR],
    access: dict[str, _Access],
    *,
    loop_variables: set[str],
) -> None:
    for statement in statements:
        if isinstance(statement, AssignmentIR):
            # Fortran evaluates the right-hand side before assigning the target.
            # Recording accesses in that order distinguishes x = x + 1 (inout)
            # from x = expression_without_x (out).
            _mark_expression(statement.value, symbols, access, loop_variables)
            _mark_target(statement.target, symbols, access, loop_variables)
        elif isinstance(statement, DoLoopIR):
            _mark_expression(statement.start, symbols, access, loop_variables)
            _mark_expression(statement.stop, symbols, access, loop_variables)
            _mark_expression(statement.step, symbols, access, loop_variables)
            _collect_access(
                statement.body,
                symbols,
                access,
                loop_variables=loop_variables | {statement.variable},
            )
        elif isinstance(statement, IfIR):
            _mark_expression(statement.condition, symbols, access, loop_variables)
            _collect_access(statement.body, symbols, access, loop_variables=loop_variables)
            _collect_access(statement.else_body, symbols, access, loop_variables=loop_variables)
        elif isinstance(statement, CallIR):
            for argument in statement.arguments:
                _mark_expression(argument, symbols, access, loop_variables)
        elif isinstance(statement, ExitIR):
            continue
        else:  # pragma: no cover
            raise TypeError(type(statement))


def _mark_target(
    expression: ExpressionIR,
    symbols: dict[str, SymbolIR],
    access: dict[str, _Access],
    loop_variables: set[str],
) -> None:
    if expression.kind in {"name", "array_ref"}:
        name = str(expression.value)
        if name in symbols and name not in loop_variables:
            access[name].mark_write()
        for index in expression.indices:
            _mark_expression(index, symbols, access, loop_variables)
        return
    _mark_expression(expression, symbols, access, loop_variables)


def _mark_expression(
    expression: ExpressionIR,
    symbols: dict[str, SymbolIR],
    access: dict[str, _Access],
    loop_variables: set[str],
) -> None:
    if expression.kind in {"name", "array_ref"}:
        name = str(expression.value)
        if name in symbols and name not in loop_variables:
            access[name].mark_read()
    for item in expression.arguments:
        _mark_expression(item, symbols, access, loop_variables)
    for item in expression.indices:
        _mark_expression(item, symbols, access, loop_variables)


def _referenced_names(statements: Iterable[StatementIR]) -> set[str]:
    names: set[str] = set()

    def expression(item: ExpressionIR) -> None:
        if item.kind in {"name", "array_ref"}:
            names.add(str(item.value))
        for child in item.arguments:
            expression(child)
        for child in item.indices:
            expression(child)

    for statement in statements:
        if isinstance(statement, AssignmentIR):
            expression(statement.target)
            expression(statement.value)
        elif isinstance(statement, DoLoopIR):
            expression(statement.start)
            expression(statement.stop)
            expression(statement.step)
            names.update(_referenced_names(statement.body))
        elif isinstance(statement, IfIR):
            expression(statement.condition)
            names.update(_referenced_names(statement.body))
            names.update(_referenced_names(statement.else_body))
        elif isinstance(statement, CallIR):
            for item in statement.arguments:
                expression(item)
    return names


def _unconditional_definitions(statements: Iterable[StatementIR]) -> set[str]:
    output: set[str] = set()
    for statement in statements:
        if isinstance(statement, AssignmentIR) and statement.target.kind in {"name", "array_ref"}:
            output.add(str(statement.target.value))
        # IF/DO/CALL definitions are not guaranteed in the initial safe subset.
    return output


def _loop_variables(loop: DoLoopIR) -> set[str]:
    output = {loop.variable}
    for statement in loop.body:
        if isinstance(statement, DoLoopIR):
            output.update(_loop_variables(statement))
        elif isinstance(statement, IfIR):
            for branch in (statement.body, statement.else_body):
                for child in branch:
                    if isinstance(child, DoLoopIR):
                        output.update(_loop_variables(child))
    return output


def _walk_calls(statements: Iterable[StatementIR]) -> Iterable[CallIR]:
    for statement in statements:
        if isinstance(statement, CallIR):
            yield statement
        elif isinstance(statement, DoLoopIR):
            yield from _walk_calls(statement.body)
        elif isinstance(statement, IfIR):
            yield from _walk_calls(statement.body)
            yield from _walk_calls(statement.else_body)


def _rewrite_statement(statement: StatementIR, rename: dict[str, str]) -> StatementIR:
    if isinstance(statement, AssignmentIR):
        return replace(
            statement,
            target=_rewrite_expression(statement.target, rename),
            value=_rewrite_expression(statement.value, rename),
        )
    if isinstance(statement, DoLoopIR):
        return replace(
            statement,
            start=_rewrite_expression(statement.start, rename),
            stop=_rewrite_expression(statement.stop, rename),
            step=_rewrite_expression(statement.step, rename),
            body=tuple(_rewrite_statement(item, rename) for item in statement.body),
        )
    if isinstance(statement, IfIR):
        return replace(
            statement,
            condition=_rewrite_expression(statement.condition, rename),
            body=tuple(_rewrite_statement(item, rename) for item in statement.body),
            else_body=tuple(_rewrite_statement(item, rename) for item in statement.else_body),
        )
    if isinstance(statement, CallIR):
        return replace(
            statement,
            arguments=tuple(_rewrite_expression(item, rename) for item in statement.arguments),
        )
    if isinstance(statement, ExitIR):
        return statement
    raise TypeError(type(statement))


def _rewrite_expression(expression: ExpressionIR, rename: dict[str, str]) -> ExpressionIR:
    value = expression.value
    if expression.kind in {"name", "array_ref"} and str(value) in rename:
        value = rename[str(value)]
    return replace(
        expression,
        value=value,
        arguments=tuple(_rewrite_expression(item, rename) for item in expression.arguments),
        indices=tuple(_rewrite_expression(item, rename) for item in expression.indices),
    )


def _unique_name(preferred: str, group: str, occupied: set[str]) -> str:
    if preferred not in occupied:
        return preferred
    prefixed = f"{_safe_name(group)}_{preferred}"
    if prefixed not in occupied:
        return prefixed
    index = 2
    while f"{prefixed}_{index}" in occupied:
        index += 1
    return f"{prefixed}_{index}"


def _safe_name(value: str) -> str:
    return re.sub(r"[^a-zA-Z0-9_]", "_", value).lower()


def _state_class(group_name: str) -> str:
    parts = [item for item in re.split(r"[^a-zA-Z0-9]+|_+", group_name) if item]
    return "".join(item[:1].upper() + item[1:] for item in parts) + "State"


def _render_state_factory(group) -> list[str] | None:
    values: list[str] = []
    for field in group.fields:
        if field.rank:
            dimensions: list[str] = []
            for extent in field.shape:
                if extent is None or extent.kind != "literal":
                    return None
                dimensions.append(str(extent.value))
            shape = ", ".join(dimensions)
            if field.rank == 1:
                shape += ","
            dtype = {"real": "np.float64", "integer": "np.int64", "logical": "np.bool_"}.get(field.type.category)
            if dtype is None:
                return None
            values.append(f"{field.state_field or field.name}=np.zeros(({shape}), dtype={dtype})")
        else:
            default = {"real": "0.0", "integer": "0", "logical": "False"}.get(field.type.category)
            if default is None:
                return None
            values.append(f"{field.state_field or field.name}={default}")
    return [
        f"def create_{_safe_name(group.name)}() -> {_state_class(group.name)}:",
        f"    return {_state_class(group.name)}({', '.join(values)})",
    ]


def _module_name(kernel: str, mode: str) -> str:
    return f"fpy_{_safe_name(kernel)}_{mode}"


def _relative(path: Path, root: Path) -> str:
    return path.resolve().relative_to(root.resolve()).as_posix()
