from __future__ import annotations

from dataclasses import dataclass
import importlib.util
import json
from pathlib import Path
import sys
from time import perf_counter
from types import ModuleType
from typing import Iterable

from .hybrid_project import build_hybrid_project, load_hybrid_runtime
from .profiling import (
    HybridProfileReport,
    HybridProfileSuiteReport,
    ProfileSelectionReport,
    load_hybrid_profile,
)


@dataclass(frozen=True)
class EconomicsCaseSample:
    case_name: str
    weight: float
    call_count_per_run: float
    baseline_seconds: float
    optimized_seconds: float
    speedup: float
    saved_seconds: float

    def to_dict(self) -> dict[str, object]:
        return {
            "case_name": self.case_name,
            "weight": self.weight,
            "call_count_per_run": self.call_count_per_run,
            "baseline_seconds": self.baseline_seconds,
            "optimized_seconds": self.optimized_seconds,
            "speedup": self.speedup,
            "saved_seconds": self.saved_seconds,
        }


@dataclass(frozen=True)
class KernelEconomicsSample:
    procedure: str
    kernel_procedure: str
    extraction_kind: str
    build_seconds: float
    bundle_bytes: int
    optimized_extension_bytes: int
    weighted_baseline_seconds: float
    weighted_optimized_seconds: float
    weighted_saved_seconds: float
    speedup: float
    weighted_calls_per_run: float
    saved_seconds_per_call: float | None
    break_even_runs: float | None
    break_even_calls: float | None
    savings_per_megabyte: float
    cost_benefit_score: float
    cases: tuple[EconomicsCaseSample, ...]

    def to_dict(self) -> dict[str, object]:
        return {
            "procedure": self.procedure,
            "kernel_procedure": self.kernel_procedure,
            "extraction_kind": self.extraction_kind,
            "build_seconds": self.build_seconds,
            "bundle_bytes": self.bundle_bytes,
            "optimized_extension_bytes": self.optimized_extension_bytes,
            "weighted_baseline_seconds": self.weighted_baseline_seconds,
            "weighted_optimized_seconds": self.weighted_optimized_seconds,
            "weighted_saved_seconds": self.weighted_saved_seconds,
            "speedup": self.speedup,
            "weighted_calls_per_run": self.weighted_calls_per_run,
            "saved_seconds_per_call": self.saved_seconds_per_call,
            "break_even_runs": self.break_even_runs,
            "break_even_calls": self.break_even_calls,
            "savings_per_megabyte": self.savings_per_megabyte,
            "cost_benefit_score": self.cost_benefit_score,
            "cases": [item.to_dict() for item in self.cases],
        }


@dataclass(frozen=True)
class HybridEconomicsReport:
    schema_version: str
    root_procedure: str
    source_files: tuple[str, ...]
    profile_kind: str
    profile_report: str
    build_manifest: str
    warmup_runs: int
    measured_runs: int
    samples: tuple[KernelEconomicsSample, ...]

    def sample(self, procedure: str) -> KernelEconomicsSample | None:
        target = procedure.lower()
        return next((item for item in self.samples if item.procedure == target), None)

    def to_dict(self) -> dict[str, object]:
        return {
            "schema_version": self.schema_version,
            "root_procedure": self.root_procedure,
            "source_files": list(self.source_files),
            "profile_kind": self.profile_kind,
            "profile_report": self.profile_report,
            "build_manifest": self.build_manifest,
            "warmup_runs": self.warmup_runs,
            "measured_runs": self.measured_runs,
            "samples": [item.to_dict() for item in self.samples],
        }


@dataclass(frozen=True)
class _EconomicsCase:
    name: str
    weight: float
    workload_file: str
    profile: HybridProfileReport


def benchmark_hybrid_economics(
    source: str | Path,
    *,
    root_procedure: str,
    profile_report: ProfileSelectionReport | str | Path | dict[str, object],
    build_directory: str | Path,
    warmup_runs: int = 2,
    measured_runs: int = 20,
    refactor_report: str | Path | None = None,
) -> tuple[HybridEconomicsReport, Path]:
    """Measure runtime benefit against Cython build and distribution costs.

    The generated all-kernel hybrid runtime is executed with every candidate left
    in Python for the baseline. One candidate at a time is then switched to the
    optimized Cython backend. This preserves the original orchestration and makes
    the measured delta attributable to the selected kernel.
    """

    if warmup_runs < 0:
        raise ValueError("warmup_runs must be non-negative")
    if measured_runs < 1:
        raise ValueError("measured_runs must be positive")

    profile = load_hybrid_profile(profile_report)
    root_name = root_procedure.lower()
    if profile.root_procedure != root_name:
        raise ValueError(
            f"profile root {profile.root_procedure!r} does not match {root_name!r}"
        )
    cases = _profile_cases(profile)
    total_weight = sum(item.weight for item in cases)
    if total_weight <= 0.0:
        raise ValueError("profile case weights must sum to a positive value")

    root = Path(build_directory).resolve()
    root.mkdir(parents=True, exist_ok=True)
    build_root = root / "all_kernels"
    manifest, manifest_path = build_hybrid_project(
        source,
        root_procedure=root_name,
        build_directory=build_root,
        refactor_report=refactor_report,
        default_backend="python",
    )
    if tuple(profile.source_files) != tuple(manifest.source_files):
        raise ValueError("economics profile source files do not match the built project")

    runtime = load_hybrid_runtime(
        build_root / manifest.artifacts["hybrid_runtime"],
        f"fpy_economics_runtime_{abs(hash(root))}",
    )
    workloads = {
        case.name: _load_module(
            Path(case.workload_file),
            f"fpy_economics_workload_{case.name}_{abs(hash(case.workload_file))}",
        )
        for case in cases
    }
    for name, module in workloads.items():
        if not callable(getattr(module, "run", None)):
            raise ValueError(f"economics workload {name!r} must define run(module)")

    baseline_by_case: dict[str, float] = {}
    for case in cases:
        baseline_by_case[case.name] = _benchmark_configuration(
            runtime,
            workloads[case.name],
            overrides={},
            warmup_runs=warmup_runs,
            measured_runs=measured_runs,
        )

    samples: list[KernelEconomicsSample] = []
    build_metrics = manifest.build_metrics
    for procedure in manifest.extracted_procedures:
        candidate_cases: list[EconomicsCaseSample] = []
        weighted_baseline = 0.0
        weighted_optimized = 0.0
        weighted_calls = 0.0
        profile_sample = profile.sample(procedure)
        if profile_sample is None:
            continue
        for case in cases:
            optimized = _benchmark_configuration(
                runtime,
                workloads[case.name],
                overrides={procedure: "cython-optimized"},
                warmup_runs=warmup_runs,
                measured_runs=measured_runs,
            )
            baseline = baseline_by_case[case.name]
            normalized_weight = case.weight / total_weight
            calls = _case_calls_per_run(case.profile, procedure)
            weighted_baseline += normalized_weight * baseline
            weighted_optimized += normalized_weight * optimized
            weighted_calls += normalized_weight * calls
            candidate_cases.append(
                EconomicsCaseSample(
                    case_name=case.name,
                    weight=case.weight,
                    call_count_per_run=calls,
                    baseline_seconds=baseline,
                    optimized_seconds=optimized,
                    speedup=(baseline / optimized if optimized > 0.0 else 0.0),
                    saved_seconds=baseline - optimized,
                )
            )

        saved = weighted_baseline - weighted_optimized
        metric = build_metrics[procedure]
        saved_per_call = saved / weighted_calls if saved > 0.0 and weighted_calls > 0.0 else None
        break_even_runs = metric["build_seconds"] / saved if saved > 0.0 else None
        break_even_calls = (
            metric["build_seconds"] / saved_per_call
            if saved_per_call is not None and saved_per_call > 0.0
            else None
        )
        extension_megabytes = max(metric["optimized_extension_bytes"] / (1024.0 ** 2), 1e-12)
        samples.append(
            KernelEconomicsSample(
                procedure=procedure,
                kernel_procedure=profile_sample.kernel_procedure,
                extraction_kind=profile_sample.extraction_kind,
                build_seconds=float(metric["build_seconds"]),
                bundle_bytes=int(metric["bundle_bytes"]),
                optimized_extension_bytes=int(metric["optimized_extension_bytes"]),
                weighted_baseline_seconds=weighted_baseline,
                weighted_optimized_seconds=weighted_optimized,
                weighted_saved_seconds=saved,
                speedup=(
                    weighted_baseline / weighted_optimized
                    if weighted_optimized > 0.0
                    else 0.0
                ),
                weighted_calls_per_run=weighted_calls,
                saved_seconds_per_call=saved_per_call,
                break_even_runs=break_even_runs,
                break_even_calls=break_even_calls,
                savings_per_megabyte=saved / extension_megabytes,
                cost_benefit_score=(
                    saved / metric["build_seconds"]
                    if metric["build_seconds"] > 0.0
                    else 0.0
                ),
                cases=tuple(candidate_cases),
            )
        )

    samples.sort(key=lambda item: (-item.cost_benefit_score, item.procedure))
    report = HybridEconomicsReport(
        schema_version="1.0",
        root_procedure=root_name,
        source_files=manifest.source_files,
        profile_kind="suite" if isinstance(profile, HybridProfileSuiteReport) else "single",
        profile_report=_report_reference(profile_report),
        build_manifest=str(manifest_path),
        warmup_runs=warmup_runs,
        measured_runs=measured_runs,
        samples=tuple(samples),
    )
    output = root / "hybrid_economics.json"
    write_hybrid_economics(report, output)
    return report, output


def write_hybrid_economics(report: HybridEconomicsReport, output: str | Path) -> Path:
    path = Path(output)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(report.to_dict(), indent=2) + "\n", encoding="utf-8")
    return path


def load_hybrid_economics(
    value: HybridEconomicsReport | str | Path | dict[str, object],
) -> HybridEconomicsReport:
    if isinstance(value, HybridEconomicsReport):
        return value
    if isinstance(value, (str, Path)):
        data = json.loads(Path(value).read_text(encoding="utf-8"))
    else:
        data = value
    samples = []
    for item in data["samples"]:
        cases = tuple(EconomicsCaseSample(**case) for case in item.get("cases", []))
        samples.append(
            KernelEconomicsSample(
                **{key: raw for key, raw in item.items() if key != "cases"},
                cases=cases,
            )
        )
    return HybridEconomicsReport(
        schema_version=str(data["schema_version"]),
        root_procedure=str(data["root_procedure"]),
        source_files=tuple(str(item) for item in data["source_files"]),
        profile_kind=str(data["profile_kind"]),
        profile_report=str(data["profile_report"]),
        build_manifest=str(data["build_manifest"]),
        warmup_runs=int(data["warmup_runs"]),
        measured_runs=int(data["measured_runs"]),
        samples=tuple(samples),
    )


def _profile_cases(profile: ProfileSelectionReport) -> tuple[_EconomicsCase, ...]:
    if isinstance(profile, HybridProfileSuiteReport):
        return tuple(
            _EconomicsCase(
                name=case.name,
                weight=case.weight,
                workload_file=case.report.workload_file,
                profile=case.report,
            )
            for case in profile.cases
        )
    return (
        _EconomicsCase(
            name="default",
            weight=1.0,
            workload_file=profile.workload_file,
            profile=profile,
        ),
    )


def _case_calls_per_run(
    report: HybridProfileReport,
    procedure: str,
) -> float:
    sample = report.sample(procedure)
    if sample is None or report.measured_runs <= 0:
        return 0.0
    return sample.call_count / report.measured_runs


def _benchmark_configuration(
    runtime: ModuleType,
    workload: ModuleType,
    *,
    overrides: dict[str, str],
    warmup_runs: int,
    measured_runs: int,
) -> float:
    run = workload.run
    for _ in range(warmup_runs):
        _invoke_workload(runtime, run, overrides)
    start = perf_counter()
    for _ in range(measured_runs):
        _invoke_workload(runtime, run, overrides)
    elapsed = perf_counter() - start
    return elapsed / measured_runs


def _invoke_workload(
    runtime: ModuleType,
    run: object,
    overrides: dict[str, str],
) -> object:
    token = runtime._BACKEND_CONTEXT.set(("python", dict(overrides)))
    try:
        return run(runtime._REFERENCE)
    finally:
        runtime._BACKEND_CONTEXT.reset(token)


def _load_module(path: Path, name: str) -> ModuleType:
    resolved = path.resolve()
    spec = importlib.util.spec_from_file_location(name, resolved)
    if spec is None or spec.loader is None:
        raise ImportError(f"cannot load workload: {resolved}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def _report_reference(value: object) -> str:
    if isinstance(value, (str, Path)):
        return str(Path(value).resolve())
    return "<in-memory-profile>"
