from __future__ import annotations

from dataclasses import dataclass
import importlib.util
import json
from pathlib import Path
import sys
from time import perf_counter_ns
from types import ModuleType
from typing import Callable, Iterable, Sequence

from fpy_migrate.ir import build_project_ir
from fpy_migrate.ir.model import ProjectIR
from fpy_migrate.translate import generate_python, write_python

from .hybrid_project import HybridProjectPlan, analyze_hybrid_project
from .partial_loops import analyze_partial_loop


@dataclass(frozen=True)
class ProfileSample:
    procedure: str
    kernel_procedure: str
    extraction_kind: str
    call_count: int
    inclusive_seconds: float
    self_seconds: float
    candidate_share: float
    wall_share: float

    def to_dict(self) -> dict[str, object]:
        return {
            "procedure": self.procedure,
            "kernel_procedure": self.kernel_procedure,
            "extraction_kind": self.extraction_kind,
            "call_count": self.call_count,
            "inclusive_seconds": self.inclusive_seconds,
            "self_seconds": self.self_seconds,
            "candidate_share": self.candidate_share,
            "wall_share": self.wall_share,
        }


@dataclass(frozen=True)
class HybridProfileReport:
    schema_version: str
    root_procedure: str
    source_files: tuple[str, ...]
    workload_file: str
    warmup_runs: int
    measured_runs: int
    wall_seconds: float
    candidate_seconds: float
    samples: tuple[ProfileSample, ...]

    def sample(self, procedure: str) -> ProfileSample | None:
        target = procedure.lower()
        return next((item for item in self.samples if item.procedure == target), None)

    def to_dict(self) -> dict[str, object]:
        return {
            "schema_version": self.schema_version,
            "root_procedure": self.root_procedure,
            "source_files": list(self.source_files),
            "workload_file": self.workload_file,
            "warmup_runs": self.warmup_runs,
            "measured_runs": self.measured_runs,
            "wall_seconds": self.wall_seconds,
            "candidate_seconds": self.candidate_seconds,
            "samples": [item.to_dict() for item in self.samples],
        }


@dataclass(frozen=True)
class ProfileCaseSample:
    case_name: str
    weight: float
    call_count: int
    self_seconds: float
    candidate_share: float
    wall_share: float

    def to_dict(self) -> dict[str, object]:
        return {
            "case_name": self.case_name,
            "weight": self.weight,
            "call_count": self.call_count,
            "self_seconds": self.self_seconds,
            "candidate_share": self.candidate_share,
            "wall_share": self.wall_share,
        }


@dataclass(frozen=True)
class AggregatedProfileSample:
    procedure: str
    kernel_procedure: str
    extraction_kind: str
    case_count: int
    observed_case_count: int
    call_count: int
    total_self_seconds: float
    weighted_self_seconds: float
    mean_candidate_share: float
    max_candidate_share: float
    weighted_candidate_share: float
    mean_wall_share: float
    max_wall_share: float
    weighted_wall_share: float
    cases: tuple[ProfileCaseSample, ...]

    @property
    def self_seconds(self) -> float:
        return self.weighted_self_seconds

    @property
    def candidate_share(self) -> float:
        return self.weighted_candidate_share

    @property
    def wall_share(self) -> float:
        return self.weighted_wall_share

    @property
    def case_coverage(self) -> float:
        return self.observed_case_count / self.case_count if self.case_count else 0.0

    def to_dict(self) -> dict[str, object]:
        return {
            "procedure": self.procedure,
            "kernel_procedure": self.kernel_procedure,
            "extraction_kind": self.extraction_kind,
            "case_count": self.case_count,
            "observed_case_count": self.observed_case_count,
            "case_coverage": self.case_coverage,
            "call_count": self.call_count,
            "total_self_seconds": self.total_self_seconds,
            "weighted_self_seconds": self.weighted_self_seconds,
            "mean_candidate_share": self.mean_candidate_share,
            "max_candidate_share": self.max_candidate_share,
            "weighted_candidate_share": self.weighted_candidate_share,
            "mean_wall_share": self.mean_wall_share,
            "max_wall_share": self.max_wall_share,
            "weighted_wall_share": self.weighted_wall_share,
            "cases": [item.to_dict() for item in self.cases],
        }


@dataclass(frozen=True)
class HybridProfileCase:
    name: str
    weight: float
    report: HybridProfileReport

    def to_dict(self) -> dict[str, object]:
        return {
            "name": self.name,
            "weight": self.weight,
            "report": self.report.to_dict(),
        }


@dataclass(frozen=True)
class HybridProfileSuiteReport:
    schema_version: str
    root_procedure: str
    source_files: tuple[str, ...]
    total_weight: float
    cases: tuple[HybridProfileCase, ...]
    samples: tuple[AggregatedProfileSample, ...]

    def sample(self, procedure: str) -> AggregatedProfileSample | None:
        target = procedure.lower()
        return next((item for item in self.samples if item.procedure == target), None)

    def to_dict(self) -> dict[str, object]:
        return {
            "schema_version": self.schema_version,
            "profile_kind": "suite",
            "root_procedure": self.root_procedure,
            "source_files": list(self.source_files),
            "total_weight": self.total_weight,
            "cases": [item.to_dict() for item in self.cases],
            "samples": [item.to_dict() for item in self.samples],
        }


ProfileSelectionReport = HybridProfileReport | HybridProfileSuiteReport


@dataclass
class _MutableStats:
    call_count: int = 0
    inclusive_ns: int = 0
    self_ns: int = 0


@dataclass
class _Frame:
    procedure: str
    start_ns: int
    child_ns: int = 0


def profile_hybrid_project(
    source: str | Path,
    *,
    root_procedure: str,
    workload: str | Path,
    build_directory: str | Path,
    warmup_runs: int = 1,
    measured_runs: int = 10,
    refactor_report: str | Path | None = None,
) -> tuple[HybridProfileReport, Path]:
    if warmup_runs < 0:
        raise ValueError("warmup_runs must be non-negative")
    if measured_runs < 1:
        raise ValueError("measured_runs must be positive")

    root = Path(build_directory).resolve()
    root.mkdir(parents=True, exist_ok=True)
    project = build_project_ir(source, procedure=root_procedure, refactor_report=refactor_report)
    static_plan = analyze_hybrid_project(project, root_procedure)
    transformed, target_functions = _prepare_profile_project(project, static_plan)
    reference_path = write_python(
        generate_python(transformed, procedure=root_procedure),
        root / "profile_reference.py",
    )
    reference = _load_module(reference_path, f"fpy_profile_reference_{abs(hash(reference_path))}")
    workload_path = Path(workload).resolve()
    workload_module = _load_module(
        workload_path, f"fpy_profile_workload_{abs(hash(workload_path))}"
    )
    run = getattr(workload_module, "run", None)
    if not callable(run):
        raise ValueError("profile workload must define callable run(reference_module)")

    for _ in range(warmup_runs):
        run(reference)

    stats = {name: _MutableStats() for name in target_functions}
    stack: list[_Frame] = []
    originals: dict[str, Callable[..., object]] = {}
    for source_procedure, function_name in target_functions.items():
        original = getattr(reference, function_name)
        originals[function_name] = original
        setattr(
            reference,
            function_name,
            _timed_wrapper(source_procedure, original, stats, stack),
        )

    wall_start = perf_counter_ns()
    try:
        for _ in range(measured_runs):
            run(reference)
    finally:
        wall_ns = perf_counter_ns() - wall_start
        for function_name, original in originals.items():
            setattr(reference, function_name, original)

    candidate_ns = sum(item.self_ns for item in stats.values())
    samples: list[ProfileSample] = []
    for candidate in static_plan.candidates:
        if candidate.status not in {"AUTO", "PARTIAL_AUTO"}:
            continue
        sample_stats = stats[candidate.procedure]
        samples.append(
            ProfileSample(
                procedure=candidate.procedure,
                kernel_procedure=candidate.kernel_procedure or candidate.procedure,
                extraction_kind=candidate.extraction_kind or "full-procedure",
                call_count=sample_stats.call_count,
                inclusive_seconds=sample_stats.inclusive_ns / 1e9,
                self_seconds=sample_stats.self_ns / 1e9,
                candidate_share=(sample_stats.self_ns / candidate_ns if candidate_ns else 0.0),
                wall_share=(sample_stats.self_ns / wall_ns if wall_ns else 0.0),
            )
        )
    samples.sort(key=lambda item: (-item.self_seconds, item.procedure))
    report = HybridProfileReport(
        schema_version="1.0",
        root_procedure=root_procedure.lower(),
        source_files=project.source_files,
        workload_file=str(workload_path),
        warmup_runs=warmup_runs,
        measured_runs=measured_runs,
        wall_seconds=wall_ns / 1e9,
        candidate_seconds=candidate_ns / 1e9,
        samples=tuple(samples),
    )
    output = root / "hybrid_profile.json"
    write_hybrid_profile(report, output)
    return report, output


def aggregate_hybrid_profiles(
    cases: Iterable[tuple[str, HybridProfileReport, float]],
) -> HybridProfileSuiteReport:
    normalized: list[HybridProfileCase] = []
    names: set[str] = set()
    for raw_name, report, raw_weight in cases:
        name = raw_name.strip()
        weight = float(raw_weight)
        if not name:
            raise ValueError("profile case name must not be empty")
        if name in names:
            raise ValueError(f"duplicate profile case name: {name}")
        if weight <= 0.0:
            raise ValueError(f"profile case weight must be positive: {name}")
        names.add(name)
        normalized.append(HybridProfileCase(name=name, weight=weight, report=report))
    if not normalized:
        raise ValueError("at least one profile case is required")

    root = normalized[0].report.root_procedure
    source_files = normalized[0].report.source_files
    for case in normalized[1:]:
        if case.report.root_procedure != root:
            raise ValueError(
                f"profile case {case.name!r} has root {case.report.root_procedure!r}; "
                f"expected {root!r}"
            )
        if tuple(case.report.source_files) != tuple(source_files):
            raise ValueError(f"profile case {case.name!r} uses different source files")

    total_weight = sum(item.weight for item in normalized)
    procedures = sorted(
        {sample.procedure for case in normalized for sample in case.report.samples}
    )
    aggregated: list[AggregatedProfileSample] = []
    for procedure in procedures:
        case_samples: list[ProfileCaseSample] = []
        kernel_procedure: str | None = None
        extraction_kind: str | None = None
        call_count = 0
        total_self = 0.0
        weighted_self = 0.0
        weighted_candidate = 0.0
        weighted_wall = 0.0
        candidate_values: list[float] = []
        wall_values: list[float] = []
        for case in normalized:
            sample = case.report.sample(procedure)
            if sample is None:
                candidate_values.append(0.0)
                wall_values.append(0.0)
                continue
            if kernel_procedure is None:
                kernel_procedure = sample.kernel_procedure
                extraction_kind = sample.extraction_kind
            elif (
                kernel_procedure != sample.kernel_procedure
                or extraction_kind != sample.extraction_kind
            ):
                raise ValueError(
                    f"profile case {case.name!r} disagrees on extraction for {procedure}"
                )
            call_count += sample.call_count
            total_self += sample.self_seconds
            weighted_self += case.weight * sample.self_seconds
            weighted_candidate += case.weight * sample.candidate_share
            weighted_wall += case.weight * sample.wall_share
            candidate_values.append(sample.candidate_share)
            wall_values.append(sample.wall_share)
            case_samples.append(
                ProfileCaseSample(
                    case_name=case.name,
                    weight=case.weight,
                    call_count=sample.call_count,
                    self_seconds=sample.self_seconds,
                    candidate_share=sample.candidate_share,
                    wall_share=sample.wall_share,
                )
            )
        assert kernel_procedure is not None and extraction_kind is not None
        aggregated.append(
            AggregatedProfileSample(
                procedure=procedure,
                kernel_procedure=kernel_procedure,
                extraction_kind=extraction_kind,
                case_count=len(normalized),
                observed_case_count=len(case_samples),
                call_count=call_count,
                total_self_seconds=total_self,
                weighted_self_seconds=weighted_self / total_weight,
                mean_candidate_share=sum(candidate_values) / len(normalized),
                max_candidate_share=max(candidate_values),
                weighted_candidate_share=weighted_candidate / total_weight,
                mean_wall_share=sum(wall_values) / len(normalized),
                max_wall_share=max(wall_values),
                weighted_wall_share=weighted_wall / total_weight,
                cases=tuple(case_samples),
            )
        )
    aggregated.sort(key=lambda item: (-item.weighted_self_seconds, item.procedure))
    return HybridProfileSuiteReport(
        schema_version="1.0",
        root_procedure=root,
        source_files=source_files,
        total_weight=total_weight,
        cases=tuple(normalized),
        samples=tuple(aggregated),
    )


def profile_hybrid_suite(
    source: str | Path,
    *,
    root_procedure: str,
    cases: Sequence[tuple[str, str | Path, float]],
    build_directory: str | Path,
    warmup_runs: int = 1,
    measured_runs: int = 10,
    refactor_report: str | Path | None = None,
) -> tuple[HybridProfileSuiteReport, Path]:
    root = Path(build_directory).resolve()
    root.mkdir(parents=True, exist_ok=True)
    reports: list[tuple[str, HybridProfileReport, float]] = []
    for name, workload, weight in cases:
        report, _ = profile_hybrid_project(
            source,
            root_procedure=root_procedure,
            workload=workload,
            build_directory=root / "cases" / name,
            warmup_runs=warmup_runs,
            measured_runs=measured_runs,
            refactor_report=refactor_report,
        )
        reports.append((name, report, weight))
    suite = aggregate_hybrid_profiles(reports)
    output = root / "hybrid_profile_suite.json"
    write_hybrid_profile(suite, output)
    return suite, output


def write_hybrid_profile(report: ProfileSelectionReport, output: str | Path) -> Path:
    path = Path(output)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(report.to_dict(), indent=2) + "\n", encoding="utf-8")
    return path


def load_hybrid_profile(
    source: str | Path | dict[str, object] | ProfileSelectionReport,
) -> ProfileSelectionReport:
    if isinstance(source, (HybridProfileReport, HybridProfileSuiteReport)):
        return source
    payload = source if isinstance(source, dict) else json.loads(Path(source).read_text(encoding="utf-8"))
    if payload.get("profile_kind") == "suite" or "cases" in payload:
        cases = tuple(
            HybridProfileCase(
                name=str(item["name"]),
                weight=float(item["weight"]),
                report=load_hybrid_profile(item["report"]),
            )
            for item in payload["cases"]
        )
        if not all(isinstance(item.report, HybridProfileReport) for item in cases):
            raise ValueError("nested profile suites are not supported")
        samples = tuple(
            AggregatedProfileSample(
                procedure=str(item["procedure"]),
                kernel_procedure=str(item["kernel_procedure"]),
                extraction_kind=str(item["extraction_kind"]),
                case_count=int(item["case_count"]),
                observed_case_count=int(item["observed_case_count"]),
                call_count=int(item["call_count"]),
                total_self_seconds=float(item["total_self_seconds"]),
                weighted_self_seconds=float(item["weighted_self_seconds"]),
                mean_candidate_share=float(item["mean_candidate_share"]),
                max_candidate_share=float(item["max_candidate_share"]),
                weighted_candidate_share=float(item["weighted_candidate_share"]),
                mean_wall_share=float(item["mean_wall_share"]),
                max_wall_share=float(item["max_wall_share"]),
                weighted_wall_share=float(item["weighted_wall_share"]),
                cases=tuple(
                    ProfileCaseSample(
                        case_name=str(case_item["case_name"]),
                        weight=float(case_item["weight"]),
                        call_count=int(case_item["call_count"]),
                        self_seconds=float(case_item["self_seconds"]),
                        candidate_share=float(case_item["candidate_share"]),
                        wall_share=float(case_item["wall_share"]),
                    )
                    for case_item in item["cases"]
                ),
            )
            for item in payload["samples"]
        )
        return HybridProfileSuiteReport(
            schema_version=str(payload["schema_version"]),
            root_procedure=str(payload["root_procedure"]).lower(),
            source_files=tuple(str(item) for item in payload["source_files"]),
            total_weight=float(payload["total_weight"]),
            cases=cases,
            samples=samples,
        )
    samples = tuple(ProfileSample(**item) for item in payload["samples"])
    return HybridProfileReport(
        schema_version=str(payload["schema_version"]),
        root_procedure=str(payload["root_procedure"]).lower(),
        source_files=tuple(str(item) for item in payload["source_files"]),
        workload_file=str(payload["workload_file"]),
        warmup_runs=int(payload["warmup_runs"]),
        measured_runs=int(payload["measured_runs"]),
        wall_seconds=float(payload["wall_seconds"]),
        candidate_seconds=float(payload["candidate_seconds"]),
        samples=samples,
    )


def _prepare_profile_project(
    project: ProjectIR, plan: HybridProjectPlan
) -> tuple[ProjectIR, dict[str, str]]:
    transformed = project
    target_functions: dict[str, str] = {}
    for candidate in plan.candidates:
        if candidate.status == "AUTO":
            target_functions[candidate.procedure] = candidate.procedure
        elif candidate.status == "PARTIAL_AUTO":
            assert candidate.loop_index is not None
            extraction = analyze_partial_loop(
                transformed, candidate.procedure, loop_index=candidate.loop_index
            )
            transformed = extraction.wrapper_project
            target_functions[candidate.procedure] = extraction.kernel_procedure
    return transformed, target_functions


def _timed_wrapper(
    procedure: str,
    original: Callable[..., object],
    stats: dict[str, _MutableStats],
    stack: list[_Frame],
) -> Callable[..., object]:
    def wrapped(*args, **kwargs):
        frame = _Frame(procedure=procedure, start_ns=perf_counter_ns())
        stack.append(frame)
        try:
            return original(*args, **kwargs)
        finally:
            elapsed = perf_counter_ns() - frame.start_ns
            stack.pop()
            item = stats[procedure]
            item.call_count += 1
            item.inclusive_ns += elapsed
            item.self_ns += max(0, elapsed - frame.child_ns)
            if stack:
                stack[-1].child_ns += elapsed

    wrapped.__name__ = getattr(original, "__name__", procedure)
    wrapped.__doc__ = getattr(original, "__doc__", None)
    return wrapped


def _load_module(path: Path, name: str) -> ModuleType:
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise ImportError(f"cannot load module: {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module
