from __future__ import annotations

from dataclasses import dataclass
from hashlib import sha256
import json
from pathlib import Path
import shutil
from typing import Literal


DistributionTarget = Literal["linux-wsl", "windows-nuitka"]


class DistributionError(RuntimeError):
    """Raised when a distribution kit cannot be prepared or validated."""


@dataclass(frozen=True)
class NativeExtensionSpec:
    procedure: str
    backend: str
    source: str
    module_name: str
    build_directory: str

    def to_dict(self) -> dict[str, object]:
        return {
            "procedure": self.procedure,
            "backend": self.backend,
            "source": self.source,
            "module_name": self.module_name,
            "build_directory": self.build_directory,
        }


@dataclass(frozen=True)
class DistributionManifest:
    schema_version: str
    app_name: str
    target: DistributionTarget
    source_hybrid_manifest_sha256: str
    hybrid_root: str
    hybrid_manifest: str
    hybrid_runtime: str
    app_adapter: str
    launcher: str
    native_extensions: tuple[NativeExtensionSpec, ...]
    runtime_requirements: tuple[str, ...]
    build_requirements: tuple[str, ...]
    required_wheels: tuple[str, ...]
    excluded_binary_suffixes: tuple[str, ...]

    def to_dict(self) -> dict[str, object]:
        return {
            "schema_version": self.schema_version,
            "app_name": self.app_name,
            "target": self.target,
            "source_hybrid_manifest_sha256": self.source_hybrid_manifest_sha256,
            "hybrid_root": self.hybrid_root,
            "hybrid_manifest": self.hybrid_manifest,
            "hybrid_runtime": self.hybrid_runtime,
            "app_adapter": self.app_adapter,
            "launcher": self.launcher,
            "native_extensions": [item.to_dict() for item in self.native_extensions],
            "runtime_requirements": list(self.runtime_requirements),
            "build_requirements": list(self.build_requirements),
            "required_wheels": list(self.required_wheels),
            "excluded_binary_suffixes": list(self.excluded_binary_suffixes),
        }


_BINARY_SUFFIXES = (
    ".so",
    ".pyd",
    ".dll",
    ".dylib",
    ".o",
    ".obj",
    ".a",
    ".lib",
    ".pyc",
)
_EXCLUDED_DIRECTORY_NAMES = {
    "__pycache__",
    ".pytest_cache",
    "temp",
}


def prepare_distribution(
    hybrid_manifest: str | Path,
    app_adapter: str | Path,
    output_directory: str | Path,
    *,
    app_name: str,
    target: DistributionTarget,
) -> tuple[DistributionManifest, Path]:
    """Prepare a source distribution kit for WSL or a Windows Nuitka build.

    The kit intentionally excludes platform-specific extension binaries.  The
    generated ``tools/build_native.py`` recompiles every selected Cython source
    on the target platform before the application is packaged.
    """

    if target not in {"linux-wsl", "windows-nuitka"}:
        raise DistributionError(f"unsupported distribution target: {target}")
    source_manifest = Path(hybrid_manifest).resolve()
    adapter = Path(app_adapter).resolve()
    if not source_manifest.is_file():
        raise DistributionError(f"hybrid manifest does not exist: {source_manifest}")
    if not adapter.is_file():
        raise DistributionError(f"app adapter does not exist: {adapter}")
    if not app_name or any(item in app_name for item in "\\/:"):
        raise DistributionError("app_name must be a non-empty file-system-safe name")

    hybrid_data = _load_json(source_manifest)
    _validate_hybrid_manifest_shape(hybrid_data)
    source_root = source_manifest.parent
    runtime_relative = str(hybrid_data["artifacts"]["hybrid_runtime"])
    if not (source_root / runtime_relative).is_file():
        raise DistributionError(
            f"hybrid runtime referenced by manifest is missing: {runtime_relative}"
        )

    output = Path(output_directory).resolve()
    if output.exists():
        shutil.rmtree(output)
    payload_root = output / "payload"
    staged_hybrid = payload_root / "hybrid"
    tools_root = output / "tools"
    wheelhouse = output / "wheelhouse"
    staged_hybrid.parent.mkdir(parents=True, exist_ok=True)
    tools_root.mkdir(parents=True, exist_ok=True)
    wheelhouse.mkdir(parents=True, exist_ok=True)

    _copy_source_tree(source_root, staged_hybrid)
    staged_adapter = payload_root / "app_adapter.py"
    shutil.copy2(adapter, staged_adapter)

    native_specs = _discover_native_extensions(
        staged_hybrid,
        hybrid_data,
        hybrid_root_relative="payload/hybrid",
    )
    if not native_specs:
        raise DistributionError("hybrid build contains no selected Cython extensions")

    runtime_requirements = ("numpy>=2.0",)
    build_requirements = (
        "numpy>=2.0",
        "Cython>=3.0",
        "setuptools>=68",
        "wheel",
        "Nuitka>=4.0",
    )
    required_wheels = (
        "numpy",
        "Cython",
        "setuptools",
        "wheel",
        "Nuitka",
        "ordered-set",
        "zstandard",
    )
    manifest = DistributionManifest(
        schema_version="1.0",
        app_name=app_name,
        target=target,
        source_hybrid_manifest_sha256=_sha256(source_manifest),
        hybrid_root="payload/hybrid",
        hybrid_manifest="payload/hybrid/hybrid_project_manifest.json",
        hybrid_runtime=f"payload/hybrid/{runtime_relative}",
        app_adapter="payload/app_adapter.py",
        launcher="launcher.py",
        native_extensions=tuple(native_specs),
        runtime_requirements=runtime_requirements,
        build_requirements=build_requirements,
        required_wheels=required_wheels,
        excluded_binary_suffixes=_BINARY_SUFFIXES,
    )

    manifest_path = output / "distribution_manifest.json"
    manifest_path.write_text(
        json.dumps(manifest.to_dict(), indent=2) + "\n", encoding="utf-8"
    )
    (output / "launcher.py").write_text(_launcher_source(), encoding="utf-8")
    (tools_root / "build_native.py").write_text(
        _native_builder_source(), encoding="utf-8"
    )
    (tools_root / "generate_notices.py").write_text(
        _notice_generator_source(), encoding="utf-8"
    )
    (output / "build_wsl.sh").write_text(_wsl_build_script(), encoding="utf-8")
    (output / "build_windows.ps1").write_text(
        _windows_build_script(app_name), encoding="utf-8"
    )
    (output / "run_windows.bat").write_text(
        _windows_run_script(app_name), encoding="utf-8"
    )
    (output / "requirements-build.txt").write_text(
        "\n".join(build_requirements) + "\n", encoding="utf-8"
    )
    (output / "requirements-runtime.txt").write_text(
        "\n".join(runtime_requirements) + "\n", encoding="utf-8"
    )
    (wheelhouse / "README.md").write_text(
        "# Offline wheelhouse\n\nPlace compatible target-platform wheels listed in "
        "`../required_wheels.json` in this directory before running the build script.\n",
        encoding="utf-8",
    )
    (output / "required_wheels.json").write_text(
        json.dumps(
            {
                "schema_version": "1.0",
                "target": target,
                "packages": list(required_wheels),
                "note": (
                    "For a fully offline Windows build, place compatible x86_64 "
                    "wheels for the listed packages in wheelhouse/."
                ),
            },
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )
    (output / "README_DISTRIBUTION.md").write_text(
        _distribution_readme(app_name, target), encoding="utf-8"
    )
    (output / "THIRD_PARTY_NOTICES.md").write_text(
        _initial_notices(), encoding="utf-8"
    )
    (output / "LICENSE").write_text(
        (Path(__file__).resolve().parents[3] / "LICENSE").read_text(encoding="utf-8"),
        encoding="utf-8",
    )
    for executable in (output / "build_wsl.sh",):
        executable.chmod(0o755)

    errors = validate_distribution(output)
    if errors:
        raise DistributionError("invalid prepared distribution: " + "; ".join(errors))
    return manifest, manifest_path


def validate_distribution(root: str | Path) -> list[str]:
    base = Path(root).resolve()
    manifest_path = base / "distribution_manifest.json"
    if not manifest_path.is_file():
        return ["distribution_manifest.json is missing"]
    try:
        data = _load_json(manifest_path)
    except (OSError, json.JSONDecodeError) as exc:
        return [f"distribution manifest cannot be read: {exc}"]
    errors: list[str] = []
    required = {
        "schema_version",
        "app_name",
        "target",
        "hybrid_root",
        "hybrid_manifest",
        "hybrid_runtime",
        "app_adapter",
        "launcher",
        "native_extensions",
    }
    missing = sorted(required - set(data))
    if missing:
        errors.append(f"manifest fields are missing: {missing}")
        return errors
    for field in ("hybrid_manifest", "hybrid_runtime", "app_adapter", "launcher"):
        path = base / str(data[field])
        if not path.is_file():
            errors.append(f"referenced file is missing: {field}={data[field]}")
    for item in data.get("native_extensions", []):
        for field in ("source", "module_name", "build_directory", "backend"):
            if field not in item:
                errors.append(f"native extension field is missing: {field}")
        source = base / str(item.get("source", ""))
        if not source.is_file():
            errors.append(f"native extension source is missing: {source}")
    for binary in base.rglob("*"):
        if binary.is_file() and binary.suffix.lower() in _BINARY_SUFFIXES:
            errors.append(f"platform-specific binary leaked into source kit: {binary}")
    return errors


def _discover_native_extensions(
    staged_hybrid: Path,
    hybrid_data: dict[str, object],
    *,
    hybrid_root_relative: str,
) -> list[NativeExtensionSpec]:
    output: list[NativeExtensionSpec] = []
    for collection_name, manifest_name in (
        ("kernel_bundles", "state_kernel_manifest.json"),
        ("partial_loop_bundles", "partial_loop_manifest.json"),
    ):
        collection = hybrid_data.get(collection_name, {})
        if not isinstance(collection, dict):
            raise DistributionError(f"invalid hybrid manifest collection: {collection_name}")
        for procedure, relative_manifest in sorted(collection.items()):
            bundle_manifest_path = staged_hybrid / str(relative_manifest)
            if not bundle_manifest_path.is_file():
                raise DistributionError(
                    f"bundle manifest is missing for {procedure}: {bundle_manifest_path}"
                )
            bundle = _load_json(bundle_manifest_path)
            artifacts = bundle.get("artifacts", {})
            modules = bundle.get("module_names", {})
            if not isinstance(artifacts, dict) or not isinstance(modules, dict):
                raise DistributionError(f"invalid bundle manifest: {bundle_manifest_path}")
            bundle_root = bundle_manifest_path.parent
            bundle_root_relative = bundle_root.relative_to(staged_hybrid).as_posix()
            for backend, source_key, build_dir in (
                ("cython-safe", "cython_safe_source", "cython_safe_build"),
                ("cython-optimized", "cython_optimized_source", "cython_optimized_build"),
            ):
                source_relative = str(artifacts[source_key])
                source_path = bundle_root / source_relative
                if not source_path.is_file():
                    raise DistributionError(
                        f"Cython source is missing for {procedure}/{backend}: {source_path}"
                    )
                output.append(
                    NativeExtensionSpec(
                        procedure=str(procedure),
                        backend=backend,
                        source=(
                            f"{hybrid_root_relative}/{bundle_root_relative}/{source_relative}"
                        ),
                        module_name=str(modules[backend]),
                        build_directory=(
                            f"{hybrid_root_relative}/{bundle_root_relative}/{build_dir}"
                        ),
                    )
                )
    return output


def _copy_source_tree(source: Path, target: Path) -> None:
    def ignore(directory: str, names: list[str]) -> set[str]:
        ignored: set[str] = set()
        for name in names:
            path = Path(directory) / name
            if name in _EXCLUDED_DIRECTORY_NAMES:
                ignored.add(name)
            elif path.is_file() and path.suffix.lower() in _BINARY_SUFFIXES:
                ignored.add(name)
            elif path.is_file() and path.suffix.lower() == ".c":
                ignored.add(name)
        return ignored

    shutil.copytree(source, target, ignore=ignore)


def _validate_hybrid_manifest_shape(data: dict[str, object]) -> None:
    for field in ("artifacts", "kernel_bundles", "partial_loop_bundles"):
        if field not in data or not isinstance(data[field], dict):
            raise DistributionError(f"invalid hybrid manifest field: {field}")
    artifacts = data["artifacts"]
    assert isinstance(artifacts, dict)
    if "hybrid_runtime" not in artifacts:
        raise DistributionError("hybrid manifest does not identify hybrid_runtime")


def _load_json(path: Path) -> dict[str, object]:
    data = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        raise DistributionError(f"JSON object expected: {path}")
    return data


def _sha256(path: Path) -> str:
    digest = sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _launcher_source() -> str:
    return '''from __future__ import annotations

import argparse
import importlib.util
import json
import os
from pathlib import Path
import platform
import sys
from types import ModuleType


def _root() -> Path:
    return Path(__file__).resolve().parent


def _load(name: str, relative_path: str) -> ModuleType:
    path = (_root() / relative_path).resolve()
    if not path.is_file():
        raise FileNotFoundError(path)
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise ImportError(f"cannot load module: {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def _manifest() -> dict[str, object]:
    return json.loads((_root() / "distribution_manifest.json").read_text(encoding="utf-8"))


def _load_application() -> tuple[ModuleType, ModuleType, dict[str, object]]:
    manifest = _manifest()
    runtime = _load("fpy_packaged_hybrid_runtime", str(manifest["hybrid_runtime"]))
    adapter = _load("fpy_packaged_app_adapter", str(manifest["app_adapter"]))
    return runtime, adapter, manifest


def _self_check(runtime: ModuleType, adapter: ModuleType, manifest: dict[str, object]) -> dict[str, object]:
    import numpy as np

    result: dict[str, object] = {
        "status": "PASS",
        "app_name": manifest["app_name"],
        "target": manifest["target"],
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "python_bits": 64 if sys.maxsize > 2**32 else 32,
        "numpy": np.__version__,
        "kernels": list(runtime.available_kernels()),
        "eligible_kernels": list(runtime.eligible_kernels()),
    }
    if hasattr(adapter, "self_check"):
        app_result = adapter.self_check(runtime)
        result["application"] = app_result
        if isinstance(app_result, dict) and app_result.get("status") not in {None, "PASS"}:
            result["status"] = "FAIL"
    return result


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--self-check", action="store_true")
    known, remaining = parser.parse_known_args(argv)
    try:
        runtime, adapter, manifest = _load_application()
        if known.self_check:
            result = _self_check(runtime, adapter, manifest)
            print(json.dumps(result, indent=2))
            return 0 if result["status"] == "PASS" else 2
        if not hasattr(adapter, "run"):
            raise AttributeError("app adapter must define run(runtime, argv)")
        return int(adapter.run(runtime, remaining) or 0)
    except Exception as exc:
        print(f"APPLICATION FAILED: {type(exc).__name__}: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
'''


def _native_builder_source() -> str:
    return '''from __future__ import annotations

from datetime import datetime, timezone
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import sysconfig
from time import perf_counter


def _root() -> Path:
    return Path(__file__).resolve().parents[1]


def _compile(source: Path, module_name: str, build_root: Path, optimized: bool) -> dict[str, object]:
    build_root.mkdir(parents=True, exist_ok=True)
    for child in (build_root / "lib", build_root / "temp"):
        if child.exists():
            shutil.rmtree(child)
    copied_source = build_root / f"{module_name}.py"
    shutil.copy2(source, copied_source)
    checks = not optimized
    compile_args = "['/O2'] if os.name == 'nt' else ['-O3']" if optimized else "[]"
    setup_path = build_root / "setup_generated_kernel.py"
    setup_path.write_text("\\n".join([
        "import os",
        "from Cython.Build import cythonize",
        "from setuptools import Extension, setup",
        "",
        f"extra_compile_args = {compile_args}",
        f"extensions = [Extension({module_name!r}, [{str(copied_source)!r}], extra_compile_args=extra_compile_args)]",
        "setup(",
        "    name='packaged-generated-cython-kernel',",
        "    ext_modules=cythonize(",
        "        extensions,",
        "        compiler_directives={",
        "            'language_level': 3,",
        f"            'boundscheck': {checks!r},",
        f"            'wraparound': {checks!r},",
        f"            'initializedcheck': {checks!r},",
        "            'cdivision': True,",
        "        },",
        "        force=True,",
        "    ),",
        ")",
        "",
    ]), encoding="utf-8")
    build_lib = build_root / "lib"
    start = perf_counter()
    completed = subprocess.run([
        sys.executable,
        str(setup_path),
        "build_ext",
        "--build-lib", str(build_lib),
        "--build-temp", str(build_root / "temp"),
    ], cwd=build_root, capture_output=True, text=True)
    elapsed = perf_counter() - start
    if completed.returncode:
        raise RuntimeError(
            f"Cython build failed for {module_name}:\\n{completed.stdout}\\n{completed.stderr}"
        )
    suffix = sysconfig.get_config_var("EXT_SUFFIX")
    expected = build_lib / f"{module_name}{suffix}"
    if not expected.is_file():
        matches = list(build_lib.glob(f"{module_name}.*"))
        raise RuntimeError(f"compiled extension was not produced: {matches}")
    return {
        "module_name": module_name,
        "extension": expected.relative_to(_root()).as_posix(),
        "bytes": expected.stat().st_size,
        "build_seconds": elapsed,
    }


def main() -> int:
    root = _root()
    manifest = json.loads((root / "distribution_manifest.json").read_text(encoding="utf-8"))
    records = []
    for item in manifest["native_extensions"]:
        source = root / item["source"]
        build_root = root / item["build_directory"]
        records.append(_compile(
            source,
            item["module_name"],
            build_root,
            optimized=item["backend"] == "cython-optimized",
        ))
    report = {
        "schema_version": "1.0",
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "platform": sys.platform,
        "python": sys.version.split()[0],
        "extensions": records,
    }
    (root / "native_build_report.json").write_text(
        json.dumps(report, indent=2) + "\\n", encoding="utf-8"
    )
    print(json.dumps(report, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
'''


def _notice_generator_source() -> str:
    return '''from __future__ import annotations

from importlib import metadata
from hashlib import sha256
import json
from pathlib import Path
import shutil
from datetime import datetime, timezone


def _root() -> Path:
    return Path(__file__).resolve().parents[1]


def _requirement_name(value: str) -> str:
    for token in ("<", ">", "=", "!", "~", "["):
        value = value.split(token, 1)[0]
    return value.strip()


def _copy_license_files(dist, destination: Path) -> list[str]:
    output: list[str] = []
    package_dir = destination / str(dist.metadata.get("Name", dist.metadata["Name"])).replace(" ", "_")
    package_dir.mkdir(parents=True, exist_ok=True)
    for item in dist.files or []:
        name = Path(str(item)).name.lower()
        if not any(token in name for token in ("license", "licence", "copying", "notice")):
            continue
        source = dist.locate_file(item)
        if not source.is_file() or source.stat().st_size > 5 * 1024 * 1024:
            continue
        target = package_dir / Path(str(item)).name
        if target.exists():
            target = package_dir / f"{sha256(str(item).encode()).hexdigest()[:8]}_{target.name}"
        shutil.copy2(source, target)
        output.append(target.relative_to(_root()).as_posix())
    if not output:
        package_dir.rmdir()
    return output


def _record(name: str, scope: str) -> dict[str, object]:
    try:
        dist = metadata.distribution(name)
    except metadata.PackageNotFoundError:
        return {"name": name, "scope": scope, "installed": False}
    meta = dist.metadata
    raw_license = meta.get("License-Expression") or meta.get("License") or "UNKNOWN"
    raw_license = raw_license.strip() if isinstance(raw_license, str) else "UNKNOWN"
    classifiers = [item for item in meta.get_all("Classifier", []) if item.startswith("License ::")]
    if len(raw_license) > 500:
        license_value = "SEE_COPIED_LICENSE_FILES_OR_PACKAGE_METADATA"
        license_sha256 = sha256(raw_license.encode("utf-8")).hexdigest()
    else:
        license_value = raw_license
        license_sha256 = None
    license_files = _copy_license_files(dist, _root() / "licenses")
    return {
        "name": meta.get("Name", name),
        "version": dist.version,
        "scope": scope,
        "installed": True,
        "license": license_value,
        "license_metadata_sha256": license_sha256,
        "license_classifiers": classifiers,
        "license_files": license_files,
        "homepage": meta.get("Project-URL") or meta.get("Home-page"),
    }


def main() -> int:
    root = _root()
    licenses = root / "licenses"
    if licenses.exists():
        shutil.rmtree(licenses)
    manifest = json.loads((root / "distribution_manifest.json").read_text(encoding="utf-8"))
    runtime = [_requirement_name(item) for item in manifest["runtime_requirements"]]
    build = [_requirement_name(item) for item in manifest["build_requirements"]]
    requested: dict[str, dict[str, object]] = {}
    for scope, names in (("runtime", runtime), ("build", build)):
        for name in names:
            key = name.lower()
            item = requested.setdefault(key, {"name": name, "scopes": []})
            scopes = item["scopes"]
            if scope not in scopes:
                scopes.append(scope)
    records = [
        _record(str(item["name"]), ",".join(item["scopes"]))
        for item in requested.values()
    ]
    payload = {
        "schema_version": "1.0",
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "packages": records,
    }
    (root / "third_party_inventory.json").write_text(
        json.dumps(payload, indent=2) + "\\n", encoding="utf-8"
    )
    lines = ["# Third-Party Notices", "", "Generated from installed package metadata.", ""]
    for item in records:
        if not item.get("installed"):
            lines.append(f"- **{item['name']}** ({item['scope']}): not installed at notice-generation time")
            continue
        classifiers = "; ".join(item.get("license_classifiers", []))
        suffix = f"; {classifiers}" if classifiers else ""
        files = ", ".join(item.get("license_files", []))
        file_note = f"; copied files: {files}" if files else ""
        lines.append(
            f"- **{item['name']} {item['version']}** ({item['scope']}): "
            f"{item['license']}{suffix}{file_note}"
        )
    lines.extend([
        "",
        "This inventory is an aid, not a substitute for reviewing the license files",
        "distributed by each dependency and the organization's legal/compliance process.",
        "",
    ])
    (root / "THIRD_PARTY_NOTICES.generated.md").write_text("\\n".join(lines), encoding="utf-8")
    print(json.dumps(payload, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
'''


def _wsl_build_script() -> str:
    return '''#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PYTHON_BIN="${PYTHON_BIN:-python3}"
if [[ ! -d "$ROOT/.venv" ]]; then
  "$PYTHON_BIN" -m venv "$ROOT/.venv"
fi
PY="$ROOT/.venv/bin/python"
PIP="$ROOT/.venv/bin/pip"
if compgen -G "$ROOT/wheelhouse/*.whl" >/dev/null; then
  "$PIP" install --no-index --find-links "$ROOT/wheelhouse" -r "$ROOT/requirements-build.txt"
else
  "$PIP" install -r "$ROOT/requirements-build.txt"
fi
"$PY" "$ROOT/tools/build_native.py"
"$PY" "$ROOT/tools/generate_notices.py"
"$PY" "$ROOT/launcher.py" --self-check
printf '\nWSL/Linux development build passed.\n'
'''


def _windows_build_script(app_name: str) -> str:
    return f'''$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
if (-not (Test-Path "$Root\\.venv")) {{
    if ($env:PYTHON_BIN) {{
        & $env:PYTHON_BIN -m venv "$Root\\.venv"
    }} else {{
        & py -3 -m venv "$Root\\.venv"
    }}
}}
$Py = "$Root\\.venv\\Scripts\\python.exe"
$Pip = "$Root\\.venv\\Scripts\\pip.exe"
$Wheels = Get-ChildItem "$Root\\wheelhouse" -Filter *.whl -ErrorAction SilentlyContinue
if ($Wheels) {{
    & $Pip install --no-index --find-links "$Root\\wheelhouse" -r "$Root\\requirements-build.txt"
}} else {{
    & $Pip install -r "$Root\\requirements-build.txt"
}}
& $Py "$Root\\tools\\build_native.py"
& $Py "$Root\\tools\\generate_notices.py"
& $Py "$Root\\launcher.py" --self-check

$Dist = "$Root\\dist"
if (Test-Path $Dist) {{ Remove-Item -Recurse -Force $Dist }}
& $Py -m nuitka `
    --mode=standalone `
    --output-dir=$Dist `
    --output-filename={app_name}.exe `
    --include-package=numpy `
    "$Root\\launcher.py"

$Standalone = "$Dist\\launcher.dist"
$Exe = "$Standalone\\{app_name}.exe"
if (-not (Test-Path $Exe)) {{ throw "Nuitka output was not found: $Exe" }}
Copy-Item -Recurse -Force "$Root\\payload" "$Standalone\\payload"
Copy-Item -Force "$Root\\distribution_manifest.json" "$Standalone\\distribution_manifest.json"
Copy-Item -Force "$Root\\LICENSE" "$Standalone\\LICENSE"
if (Test-Path "$Root\\THIRD_PARTY_NOTICES.generated.md") {{
    Copy-Item -Force "$Root\\THIRD_PARTY_NOTICES.generated.md" "$Standalone\\THIRD_PARTY_NOTICES.generated.md"
}}
if (Test-Path "$Root\\third_party_inventory.json") {{
    Copy-Item -Force "$Root\\third_party_inventory.json" "$Standalone\\third_party_inventory.json"
}}
if (Test-Path "$Root\\licenses") {{
    Copy-Item -Recurse -Force "$Root\\licenses" "$Standalone\\licenses"
}}
& $Exe --self-check
Write-Host "Windows standalone build passed: $Exe"
'''


def _windows_run_script(app_name: str) -> str:
    return f'''@echo off
setlocal
set "ROOT=%~dp0"
set "EXE=%ROOT%dist\\launcher.dist\\{app_name}.exe"
if not exist "%EXE%" (
  echo Packaged executable not found: %EXE%
  echo Run build_windows.ps1 first.
  exit /b 2
)
"%EXE%" %*
exit /b %ERRORLEVEL%
'''


def _distribution_readme(app_name: str, target: str) -> str:
    return f'''# {app_name} distribution kit

Target: `{target}`

This directory contains source-only generated Python/Cython application files.
Platform-specific Cython extension modules are deliberately rebuilt on the
target operating system.

## WSL/Linux validation

```bash
./build_wsl.sh
```

The script creates `.venv`, builds all Cython backends, generates a dependency
inventory, and runs `launcher.py --self-check`.

## Windows x64 standalone build

Open PowerShell on Windows and run:

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\\build_windows.ps1
```

For a fully offline build, put compatible Windows x86-64 wheels listed in
`required_wheels.json` under `wheelhouse/` before running the script.
A supported Microsoft C/C++ Build Tools installation is also required to build
Cython extension modules.

The current standard Nuitka distribution uses AGPLv3 with a runtime exception
for created binaries. Review the exact Nuitka version, its runtime exception,
and your organization's compliance requirements before commercial release.
The build script generates an installed-package inventory but does not replace
legal review.

The expected executable is:

```text
dist\\launcher.dist\\{app_name}.exe
```

The first packaging target is Nuitka standalone-directory mode, not one-file
mode. After compiling the launcher, the script copies the generated hybrid
payload and target-native Cython extensions next to the executable. Keeping
these files visible makes diagnosis and license review more reliable. The
Python orchestration sources are therefore not yet treated as an IP-protection
boundary; only selected numerical kernels are native extensions.

## Application adapter contract

`payload/app_adapter.py` must provide:

```python
def run(runtime, argv: list[str]) -> int: ...
```

It may additionally provide:

```python
def self_check(runtime) -> dict[str, object]: ...
```
'''


def _initial_notices() -> str:
    return '''# Third-Party Notices

The final inventory is generated on the target build environment by:

```text
python tools/generate_notices.py
```

Review `THIRD_PARTY_NOTICES.generated.md`, `third_party_inventory.json`, and the
license files distributed with every dependency before external distribution.
'''
