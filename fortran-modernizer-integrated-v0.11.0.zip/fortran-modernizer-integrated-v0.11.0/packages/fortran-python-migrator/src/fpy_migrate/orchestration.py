from __future__ import annotations

import ast
from dataclasses import dataclass, replace
import json
from pathlib import Path
import re
import shutil
from typing import Any, Literal

from jsonschema import Draft202012Validator

from fparser.common.readfortran import FortranFileReader
from fparser.common.sourceinfo import FortranFormat
from fparser.two.Fortran2003 import (
    Call_Stmt,
    Common_Stmt,
    Main_Program,
    Name,
    Subroutine_Subprogram,
    Type_Declaration_Stmt,
)
from fparser.two.parser import ParserFactory
from fparser.two.utils import walk

from fpy_migrate.extraction.hybrid_project import build_hybrid_project
from fpy_migrate.ir import build_project_ir
from fpy_migrate.ir.builder import (
    UnsupportedFortranError,
    _build_expression,
    _build_symbols,
    _discover_source_paths,
    _order_constants,
)
from fpy_migrate.ir.model import ConstantIR, ExpressionIR, ProjectIR, SourceSpan, SymbolIR, TypeIR


class OrchestrationError(ValueError):
    """Raised when a main program cannot be converted without guessing."""


@dataclass(frozen=True)
class AdapterSpec:
    procedure: str
    source: str
    callable: str
    arguments: tuple[str, ...]
    mode: Literal["read_only"] = "read_only"

    def to_dict(self) -> dict[str, object]:
        return {
            "procedure": self.procedure,
            "source": self.source,
            "callable": self.callable,
            "arguments": list(self.arguments),
            "mode": self.mode,
        }


@dataclass(frozen=True)
class ProgramCall:
    procedure: str
    arguments: tuple[ExpressionIR, ...]
    kind: Literal["numeric", "adapter"]
    source_span: SourceSpan

    def to_dict(self) -> dict[str, object]:
        return {
            "procedure": self.procedure,
            "arguments": [_expression_to_dict(item) for item in self.arguments],
            "kind": self.kind,
            "source_span": {
                "file": self.source_span.file,
                "start_line": self.source_span.start_line,
                "end_line": self.source_span.end_line,
            },
        }


@dataclass(frozen=True)
class OrchestrationPlan:
    schema_version: str
    program: str
    source_files: tuple[str, ...]
    synthetic_root: str
    numeric_calls: tuple[ProgramCall, ...]
    adapter_calls: tuple[ProgramCall, ...]
    result_fields: tuple[SymbolIR, ...]
    adapters: tuple[AdapterSpec, ...]
    state_groups: tuple[str, ...]
    diagnostics: tuple[str, ...] = ()

    def to_dict(self) -> dict[str, object]:
        return {
            "schema_version": self.schema_version,
            "program": self.program,
            "source_files": list(self.source_files),
            "synthetic_root": self.synthetic_root,
            "numeric_calls": [item.to_dict() for item in self.numeric_calls],
            "adapter_calls": [item.to_dict() for item in self.adapter_calls],
            "result_fields": [_symbol_to_dict(item) for item in self.result_fields],
            "adapters": [item.to_dict() for item in self.adapters],
            "state_groups": list(self.state_groups),
            "diagnostics": list(self.diagnostics),
        }


@dataclass(frozen=True)
class OrchestrationManifest:
    schema_version: str
    program: str
    synthetic_root: str
    default_backend: str
    available_backends: tuple[str, ...]
    artifacts: dict[str, str]
    adapters: tuple[AdapterSpec, ...]
    result_fields: tuple[str, ...]

    def to_dict(self) -> dict[str, object]:
        return {
            "schema_version": self.schema_version,
            "program": self.program,
            "synthetic_root": self.synthetic_root,
            "default_backend": self.default_backend,
            "available_backends": list(self.available_backends),
            "artifacts": self.artifacts,
            "adapters": [item.to_dict() for item in self.adapters],
            "result_fields": list(self.result_fields),
        }


@dataclass(frozen=True)
class _ProgramInventory:
    name: str
    source_path: Path
    source_span: SourceSpan
    symbols: tuple[SymbolIR, ...]
    constants: tuple[ConstantIR, ...]
    common_blocks: tuple[tuple[str, tuple[str, ...]], ...]
    calls: tuple[tuple[str, tuple[ExpressionIR, ...], SourceSpan], ...]


@dataclass(frozen=True)
class _ProcedureSignature:
    name: str
    arguments: tuple[str, ...]
    symbols: tuple[SymbolIR, ...]
    source_path: Path

    def symbol(self, name: str) -> SymbolIR:
        target = name.lower()
        for item in self.symbols:
            if item.name == target:
                return item
        raise KeyError(name)


def load_adapter_config(path: str | Path) -> tuple[AdapterSpec, ...]:
    config_path = Path(path).resolve()
    schema_errors = validate_orchestration_document(config_path, kind="adapter-config")
    if schema_errors:
        raise OrchestrationError(
            "adapter config failed schema validation: " + "; ".join(schema_errors)
        )
    payload = json.loads(config_path.read_text(encoding="utf-8"))
    if payload.get("schema_version") != "1.0":
        raise OrchestrationError("adapter config schema_version must be '1.0'")
    raw = payload.get("adapters")
    if not isinstance(raw, dict) or not raw:
        raise OrchestrationError("adapter config must contain a non-empty adapters object")
    output: list[AdapterSpec] = []
    for procedure, item in raw.items():
        if not isinstance(item, dict):
            raise OrchestrationError(f"adapter {procedure} must be an object")
        source_value = item.get("source")
        callable_name = item.get("callable")
        arguments = item.get("arguments")
        mode = item.get("mode", "read_only")
        if not isinstance(source_value, str) or not source_value:
            raise OrchestrationError(f"adapter {procedure} requires source")
        if not isinstance(callable_name, str) or not callable_name:
            raise OrchestrationError(f"adapter {procedure} requires callable")
        if not isinstance(arguments, list) or not all(isinstance(v, str) for v in arguments):
            raise OrchestrationError(f"adapter {procedure} requires string arguments")
        if mode != "read_only":
            raise OrchestrationError(
                f"adapter {procedure}: only read_only adapters are supported in milestone 22"
            )
        source_path = (config_path.parent / source_value).resolve()
        _validate_adapter_python(source_path, callable_name, tuple(v.lower() for v in arguments))
        output.append(
            AdapterSpec(
                procedure=procedure.lower(),
                source=str(source_path),
                callable=callable_name,
                arguments=tuple(v.lower() for v in arguments),
                mode="read_only",
            )
        )
    return tuple(output)


def analyze_orchestration(
    source: str | Path,
    *,
    program: str,
    adapter_config: str | Path,
    refactor_report: str | Path | None = None,
) -> tuple[OrchestrationPlan, _ProgramInventory, ProjectIR]:
    source_paths = _discover_source_paths(source)
    programs, signatures = _inventory_source_set(source_paths)
    target = program.lower()
    if target not in programs:
        raise OrchestrationError(f"main program not found: {program}")
    inventory = programs[target]
    adapters = load_adapter_config(adapter_config)
    adapter_by_name = {item.procedure: item for item in adapters}

    numeric_calls: list[ProgramCall] = []
    adapter_calls: list[ProgramCall] = []
    adapter_phase = False
    numeric_projects: list[ProjectIR] = []
    assigned_names: set[str] = set()

    for procedure_name, arguments, span in inventory.calls:
        if procedure_name in adapter_by_name:
            adapter_phase = True
            spec = adapter_by_name[procedure_name]
            actual_names = _name_arguments(arguments, context=f"adapter {procedure_name}")
            if actual_names != spec.arguments:
                raise OrchestrationError(
                    f"adapter {procedure_name}: configured arguments {spec.arguments} do not "
                    f"match main-program call {actual_names}"
                )
            adapter_calls.append(ProgramCall(procedure_name, arguments, "adapter", span))
            continue
        if adapter_phase:
            raise OrchestrationError(
                f"numeric call {procedure_name} appears after an adapter call; "
                "interleaved I/O is not supported in milestone 22"
            )
        if procedure_name not in signatures:
            raise OrchestrationError(
                f"{target}: unresolved called subroutine {procedure_name}; configure a Python "
                "adapter or provide the Fortran procedure"
            )
        try:
            project = build_project_ir(
                source,
                procedure=procedure_name,
                refactor_report=refactor_report,
            )
        except (UnsupportedFortranError, ValueError) as exc:
            raise OrchestrationError(
                f"numeric procedure {procedure_name} is not migration-ready: {exc}"
            ) from exc
        callee = project.procedure(procedure_name)
        if len(arguments) != len(callee.arguments):
            raise OrchestrationError(
                f"{target}: argument count mismatch calling {procedure_name}: "
                f"actual={len(arguments)}, dummy={len(callee.arguments)}"
            )
        for formal_name, actual in zip(callee.arguments, arguments, strict=True):
            formal = callee.symbol(formal_name)
            if formal.intent in {"out", "inout"}:
                if actual.kind != "name":
                    raise OrchestrationError(
                        f"{target}: output actual for {procedure_name}.{formal_name} "
                        "must be a scalar name in milestone 22"
                    )
                assigned_names.add(str(actual.value))
        numeric_calls.append(ProgramCall(procedure_name, arguments, "numeric", span))
        numeric_projects.append(project)

    if not numeric_calls:
        raise OrchestrationError(f"{target}: no numeric calls found")
    if not adapter_calls:
        raise OrchestrationError(
            f"{target}: no configured trailing adapter calls found; use procedure-scoped "
            "translation instead"
        )

    symbol_by_name = {item.name: item for item in inventory.symbols}
    result_names: list[str] = []
    for call in adapter_calls:
        for name in _name_arguments(call.arguments, context=f"adapter {call.procedure}"):
            if name in result_names:
                continue
            symbol = symbol_by_name.get(name)
            if symbol is None:
                raise OrchestrationError(
                    f"adapter {call.procedure}: argument {name} is not declared in {target}"
                )
            if symbol.rank != 0:
                raise OrchestrationError(
                    f"adapter {call.procedure}: array result {name} is not supported yet"
                )
            if symbol.role == "state":
                raise OrchestrationError(
                    f"adapter {call.procedure}: direct scalar COMMON/module state argument "
                    f"{name} is not supported yet"
                )
            if name not in assigned_names:
                raise OrchestrationError(
                    f"adapter {call.procedure}: argument {name} is not assigned by a preceding "
                    "numeric call"
                )
            result_names.append(name)

    merged = _merge_projects(numeric_projects)
    state_groups = tuple(item.name for item in merged.state_groups)
    result_fields = tuple(replace(symbol_by_name[name], role="argument", intent="out") for name in result_names)
    synthetic_root = f"program_{_safe_name(target)}_numeric"
    plan = OrchestrationPlan(
        schema_version="1.0",
        program=target,
        source_files=tuple(str(item) for item in source_paths),
        synthetic_root=synthetic_root,
        numeric_calls=tuple(numeric_calls),
        adapter_calls=tuple(adapter_calls),
        result_fields=result_fields,
        adapters=tuple(adapter_by_name[item.procedure] for item in adapter_calls),
        state_groups=state_groups,
        diagnostics=(
            "main-program support is limited to top-level CALL sequences",
            "adapter calls must form a trailing suffix",
            "adapters are read-only in milestone 22",
        ),
    )
    return plan, inventory, merged


def validate_orchestration_document(
    path: str | Path,
    *,
    kind: Literal["plan", "manifest", "adapter-config"],
) -> list[str]:
    filenames = {
        "plan": "orchestration_plan.schema.json",
        "manifest": "orchestration_manifest.schema.json",
        "adapter-config": "python_adapter_config.schema.json",
    }
    payload = json.loads(Path(path).read_text(encoding="utf-8"))
    repository_root = Path(__file__).resolve().parents[2]
    schema = json.loads(
        (repository_root / "schemas" / filenames[kind]).read_text(encoding="utf-8")
    )
    validator = Draft202012Validator(schema)
    errors = sorted(validator.iter_errors(payload), key=lambda item: list(item.path))
    return [
        f"{'/'.join(map(str, error.path)) or '<root>'}: {error.message}"
        for error in errors
    ]


def write_orchestration_plan(plan: OrchestrationPlan, output: str | Path) -> Path:
    target = Path(output)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(plan.to_dict(), indent=2) + "\n", encoding="utf-8")
    errors = validate_orchestration_document(target, kind="plan")
    if errors:
        raise OrchestrationError("generated orchestration plan failed schema validation: " + "; ".join(errors))
    return target


def build_orchestration(
    source: str | Path,
    *,
    program: str,
    adapter_config: str | Path,
    build_directory: str | Path,
    refactor_report: str | Path | None = None,
    default_backend: str = "python",
    include_fortran: bool = False,
) -> tuple[OrchestrationManifest, Path]:
    plan, inventory, _ = analyze_orchestration(
        source,
        program=program,
        adapter_config=adapter_config,
        refactor_report=refactor_report,
    )
    root = Path(build_directory).resolve()
    if root.exists():
        shutil.rmtree(root)
    root.mkdir(parents=True)
    plan_path = write_orchestration_plan(plan, root / "orchestration_plan.json")

    staged = root / "source_project"
    staged.mkdir()
    _copy_source_set(source, staged)
    wrapper_path = staged / "generated_main_numeric_wrapper.f90"
    wrapper_path.write_text(
        _render_numeric_wrapper(plan, inventory), encoding="utf-8"
    )

    hybrid_root = root / "hybrid"
    hybrid_manifest, hybrid_manifest_path = build_hybrid_project(
        staged,
        root_procedure=plan.synthetic_root,
        build_directory=hybrid_root,
        refactor_report=None,
        default_backend=default_backend,
        include_fortran=include_fortran,
    )
    project = build_project_ir(staged, procedure=plan.synthetic_root, refactor_report=None)

    adapters_root = root / "adapters"
    adapters_root.mkdir()
    (adapters_root / "__init__.py").write_text("", encoding="utf-8")
    adapter_artifacts: dict[str, str] = {}
    for adapter in plan.adapters:
        target = adapters_root / f"{_safe_name(adapter.procedure)}.py"
        shutil.copy2(adapter.source, target)
        adapter_artifacts[adapter.procedure] = str(target.relative_to(root))

    app_path = root / "application.py"
    app_path.write_text(
        _render_application(plan, inventory, project, hybrid_manifest, adapter_artifacts),
        encoding="utf-8",
    )
    manifest = OrchestrationManifest(
        schema_version="1.0",
        program=plan.program,
        synthetic_root=plan.synthetic_root,
        default_backend=default_backend,
        available_backends=hybrid_manifest.available_backends,
        artifacts={
            "plan": str(plan_path.relative_to(root)),
            "synthetic_wrapper": str(wrapper_path.relative_to(root)),
            "hybrid_manifest": str(hybrid_manifest_path.relative_to(root)),
            "application": str(app_path.relative_to(root)),
            **{f"adapter_{name}": path for name, path in adapter_artifacts.items()},
        },
        adapters=tuple(
            replace(adapter, source=adapter_artifacts[adapter.procedure])
            for adapter in plan.adapters
        ),
        result_fields=tuple(item.name for item in plan.result_fields),
    )
    manifest_path = root / "orchestration_manifest.json"
    manifest_path.write_text(json.dumps(manifest.to_dict(), indent=2) + "\n", encoding="utf-8")
    errors = validate_orchestration_document(manifest_path, kind="manifest")
    if errors:
        raise OrchestrationError("generated orchestration manifest failed schema validation: " + "; ".join(errors))
    return manifest, manifest_path


def load_generated_application(path: str | Path, module_name: str | None = None):
    import importlib.util
    import sys

    target = Path(path).resolve()
    name = module_name or f"fpy_generated_application_{abs(hash(target))}"
    spec = importlib.util.spec_from_file_location(name, target)
    if spec is None or spec.loader is None:
        raise ImportError(target)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def _inventory_source_set(
    source_paths: tuple[Path, ...],
) -> tuple[dict[str, _ProgramInventory], dict[str, _ProcedureSignature]]:
    programs: dict[str, _ProgramInventory] = {}
    signatures: dict[str, _ProcedureSignature] = {}
    for source_path in source_paths:
        fixed = source_path.suffix.lower() in {".f", ".for", ".ftn"}
        reader = FortranFileReader(str(source_path))
        reader.set_format(FortranFormat(not fixed, False))
        tree = ParserFactory().create(std="f2008")(reader)
        for node in walk(tree, Main_Program):
            inventory = _inventory_program(node, source_path)
            if inventory.name in programs:
                raise OrchestrationError(f"duplicate main program: {inventory.name}")
            programs[inventory.name] = inventory
        for node in walk(tree, Subroutine_Subprogram):
            signature = _inventory_signature(node, source_path)
            if signature.name in signatures:
                raise OrchestrationError(f"duplicate subroutine: {signature.name}")
            signatures[signature.name] = signature
    return programs, signatures


def _inventory_program(node: Main_Program, source_path: Path) -> _ProgramInventory:
    start_stmt = node.content[0]
    name_node = start_stmt.items[1]
    name = str(name_node).lower() if name_node is not None else "__main__"
    symbols: list[SymbolIR] = []
    constants: list[ConstantIR] = []
    common_blocks: list[tuple[str, tuple[str, ...]]] = []
    for item in getattr(node.content[1], "content", ()):
        if type(item).__name__ in {"Implicit_Part", "Implicit_Stmt", "Use_Stmt"}:
            continue
        if isinstance(item, Common_Stmt):
            for block_name, objects in item.items[0]:
                source_name = str(block_name).lower() if block_name is not None else "blank"
                names: list[str] = []
                for obj in objects.items:
                    if not isinstance(obj, Name):
                        raise OrchestrationError(f"unsupported COMMON object in {name}: {obj}")
                    names.append(str(obj).lower())
                common_blocks.append((source_name, tuple(names)))
            continue
        if not isinstance(item, Type_Declaration_Stmt):
            raise OrchestrationError(
                f"{source_path}: unsupported main-program specification node "
                f"{type(item).__name__}"
            )
        declared, attrs, declared_constants = _build_symbols(
            item, (), source_path=source_path
        )
        if "parameter" in attrs:
            constants.extend(declared_constants)
        else:
            symbols.extend(declared)
    ordered_constants = _order_constants(tuple(constants), context=f"program {name}")
    by_name = {item.name: item for item in symbols}
    for block_name, names in common_blocks:
        for local_name in names:
            symbol = by_name.get(local_name)
            if symbol is None:
                raise OrchestrationError(
                    f"program {name}: COMMON symbol {local_name} has no declaration"
                )
            replacement = replace(
                symbol,
                role="state",
                state_group=f"common_{block_name}",
                state_field=local_name,
            )
            symbols[symbols.index(symbol)] = replacement
            by_name[local_name] = replacement

    calls: list[tuple[str, tuple[ExpressionIR, ...], SourceSpan]] = []
    for item in getattr(node.content[2], "content", ()):
        if not isinstance(item, Call_Stmt):
            raise OrchestrationError(
                f"program {name}: only top-level CALL statements are supported; "
                f"found {type(item).__name__}"
            )
        args_node = item.items[1]
        args = tuple(_build_expression(v) for v in (args_node.items if args_node else ()))
        line = _line(item, 1)
        calls.append(
            (
                str(item.items[0]).lower(),
                args,
                SourceSpan(str(source_path), line, line),
            )
        )
    start_line = _line(start_stmt, 1)
    return _ProgramInventory(
        name=name,
        source_path=source_path,
        source_span=SourceSpan(str(source_path), start_line, _line(node.content[-1], start_line)),
        symbols=tuple(symbols),
        constants=ordered_constants,
        common_blocks=tuple(common_blocks),
        calls=tuple(calls),
    )


def _inventory_signature(node: Subroutine_Subprogram, source_path: Path) -> _ProcedureSignature:
    start = node.content[0]
    name = str(start.items[1]).lower()
    dummy = start.items[2]
    arguments = tuple(str(v).lower() for v in (dummy.items if dummy else ()))
    symbols: list[SymbolIR] = []
    for item in getattr(node.content[1], "content", ()):
        if type(item).__name__ in {"Implicit_Part", "Implicit_Stmt", "Use_Stmt"}:
            continue
        if isinstance(item, Common_Stmt):
            continue
        if not isinstance(item, Type_Declaration_Stmt):
            continue
        declared, attrs, _ = _build_symbols(item, arguments, source_path=source_path)
        if "parameter" not in attrs:
            symbols.extend(declared)
    return _ProcedureSignature(name, arguments, tuple(symbols), source_path)


def _merge_projects(projects: list[ProjectIR]) -> ProjectIR:
    procedures = []
    seen: set[str] = set()
    state_groups: dict[str, Any] = {}
    source_files: list[str] = []
    for project in projects:
        for source_file in project.source_files:
            if source_file not in source_files:
                source_files.append(source_file)
        for procedure in project.procedures:
            if procedure.name not in seen:
                seen.add(procedure.name)
                procedures.append(procedure)
        for group in project.state_groups:
            previous = state_groups.get(group.name)
            if previous is not None and previous != group:
                raise OrchestrationError(f"inconsistent state group across numeric roots: {group.name}")
            state_groups[group.name] = group
    return ProjectIR(
        schema_version="1.2",
        source_files=tuple(source_files),
        procedures=tuple(procedures),
        state_groups=tuple(state_groups[name] for name in sorted(state_groups)),
    )


def _render_numeric_wrapper(plan: OrchestrationPlan, program: _ProgramInventory) -> str:
    result_names = tuple(item.name for item in plan.result_fields)
    lines = [f"subroutine {plan.synthetic_root}({', '.join(result_names)})", "  implicit none"]
    for constant in program.constants:
        lines.append(
            f"  {_fortran_type(constant.type)}, parameter :: {constant.name} = "
            f"{_fortran_expr(constant.value)}"
        )
    result_by_name = {item.name: item for item in plan.result_fields}
    for result in plan.result_fields:
        lines.append(f"  {_fortran_declaration(result, intent='out')}")
    for symbol in program.symbols:
        if symbol.name in result_by_name:
            continue
        lines.append(f"  {_fortran_declaration(symbol)}")
    for block_name, names in program.common_blocks:
        lines.append(f"  common /{block_name}/ {', '.join(names)}")
    lines.append("")
    for call in plan.numeric_calls:
        arguments = ", ".join(_fortran_expr(item) for item in call.arguments)
        suffix = f"({arguments})" if arguments else ""
        lines.append(f"  call {call.procedure}{suffix}")
    lines.append(f"end subroutine {plan.synthetic_root}")
    lines.append("")
    return "\n".join(lines)


def _render_application(
    plan: OrchestrationPlan,
    program: _ProgramInventory,
    project: ProjectIR,
    hybrid_manifest: Any,
    adapter_artifacts: dict[str, str],
) -> str:
    result_fields = plan.result_fields
    root = project.procedure(plan.synthetic_root)
    root_inputs = [
        name for name in root.arguments if root.symbol(name).intent != "out"
    ]
    if root_inputs:
        raise OrchestrationError(
            f"generated program wrapper unexpectedly requires input arguments: {root_inputs}"
        )
    lines = [
        '"""Generated Python orchestration for a Fortran main program."""',
        "",
        "from __future__ import annotations",
        "",
        "import argparse",
        "from dataclasses import asdict, dataclass",
        "import importlib.util",
        "import json",
        "import os",
        "from pathlib import Path",
        "import numpy as np",
        "import sys",
        "from typing import Mapping",
        "",
        "_ROOT = Path(__file__).resolve().parent",
        "",
        "def _load(name: str, relative_path: str):",
        "    path = (_ROOT / relative_path).resolve()",
        "    spec = importlib.util.spec_from_file_location(name, path)",
        "    if spec is None or spec.loader is None:",
        "        raise ImportError(path)",
        "    module = importlib.util.module_from_spec(spec)",
        "    sys.modules[name] = module",
        "    spec.loader.exec_module(module)",
        "    return module",
        "",
        "_RUNTIME = _load('fpy_orchestration_runtime', 'hybrid/hybrid_project.py')",
    ]
    for adapter in plan.adapters:
        relative = adapter_artifacts[adapter.procedure]
        lines.append(
            f"_ADAPTER_{_safe_name(adapter.procedure).upper()} = "
            f"_load('fpy_adapter_{_safe_name(adapter.procedure)}', {relative!r})"
        )
    lines.extend(["", "@dataclass(frozen=True)", "class AnalysisResult:"])
    for field in result_fields:
        lines.append(f"    {field.name}: {_python_scalar_type(field.type)}")
    lines.extend([
        "",
        "def run_with_state(",
        "    *,",
        f"    backend: str = {hybrid_manifest.default_backend!r},",
        "    backend_overrides: Mapping[str, str] | None = None,",
        "    run_adapters: bool = True,",
        ") -> tuple[AnalysisResult, dict[str, object]]:",
    ])
    state_vars: list[str] = []
    constant_values = _evaluate_constants(program.constants)
    for group in project.state_groups:
        variable = f"state_{_safe_name(group.name)}"
        state_vars.append(variable)
        values: list[str] = []
        for field in group.fields:
            field_name = field.state_field or field.name
            if field.rank:
                dimensions = tuple(
                    int(_evaluate_expression(extent, constant_values))
                    for extent in field.shape
                    if extent is not None
                )
                if len(dimensions) != field.rank:
                    raise OrchestrationError(
                        f"cannot resolve state shape for {group.name}.{field_name}"
                    )
                dtype = {
                    "real": "np.float64",
                    "integer": "np.int64",
                    "logical": "np.bool_",
                }.get(field.type.category)
                if dtype is None:
                    raise OrchestrationError(
                        f"unsupported state type for {group.name}.{field_name}"
                    )
                values.append(
                    f"{field_name}=np.zeros({dimensions!r}, dtype={dtype})"
                )
            else:
                default = {"real": "0.0", "integer": "0", "logical": "False"}.get(
                    field.type.category
                )
                if default is None:
                    raise OrchestrationError(
                        f"unsupported state type for {group.name}.{field_name}"
                    )
                values.append(f"{field_name}={default}")
        lines.append(
            f"    {variable} = _RUNTIME.{_state_class(group.name)}({', '.join(values)})"
        )
    call_args = ", ".join(state_vars)
    keyword_prefix = ", " if call_args else ""
    output_names = [item.name for item in result_fields]
    target = output_names[0] if len(output_names) == 1 else ", ".join(output_names)
    lines.append(
        f"    {target} = _RUNTIME.{plan.synthetic_root}({call_args}{keyword_prefix}"
        "backend=backend, backend_overrides=backend_overrides)"
    )
    lines.append(f"    result = AnalysisResult({', '.join(f'{name}={name}' for name in output_names)})")
    lines.append("    if run_adapters:")
    for call in plan.adapter_calls:
        adapter = next(item for item in plan.adapters if item.procedure == call.procedure)
        args = ", ".join(f"result.{name}" for name in adapter.arguments)
        lines.append(
            f"        _ADAPTER_{_safe_name(call.procedure).upper()}.{adapter.callable}({args})"
        )
    lines.append("    states = {")
    for group, variable in zip(project.state_groups, state_vars, strict=True):
        lines.append(f"        {group.name!r}: {variable},")
    lines.append("    }")
    lines.append("    return result, states")
    lines.extend([
        "",
        "def main(",
        "    *,",
        f"    backend: str = {hybrid_manifest.default_backend!r},",
        "    backend_overrides: Mapping[str, str] | None = None,",
        "    run_adapters: bool = True,",
        ") -> AnalysisResult:",
        "    result, _ = run_with_state(",
        "        backend=backend,",
        "        backend_overrides=backend_overrides,",
        "        run_adapters=run_adapters,",
        "    )",
        "    return result",
        "",
        "def _write_state_snapshot(path: str | Path, states: Mapping[str, object]) -> None:",
        "    payload: dict[str, np.ndarray] = {}",
        "    for group_name, state in states.items():",
        "        for field_name, value in vars(state).items():",
        "            payload[f'{group_name}__{field_name}'] = np.asarray(value)",
        "    np.savez(Path(path), **payload)",
        "",
        "def _cli() -> int:",
        "    parser = argparse.ArgumentParser()",
        f"    parser.add_argument('--backend', choices={list(hybrid_manifest.available_backends)!r}, default={hybrid_manifest.default_backend!r})",
        "    parser.add_argument('--json', action='store_true')",
        "    parser.add_argument('--no-adapters', action='store_true')",
        "    parser.add_argument('--state-output')",
        "    parser.add_argument('--result-output')",
        "    args = parser.parse_args()",
        "    result, states = run_with_state(backend=args.backend, run_adapters=not args.no_adapters)",
        "    if args.state_output:",
        "        _write_state_snapshot(args.state_output, states)",
        "    result_payload = asdict(result)",
        "    if args.result_output:",
        "        Path(args.result_output).write_text(json.dumps(result_payload, indent=2) + '\\n', encoding='utf-8')",
        "    if args.json:",
        "        print(json.dumps(result_payload, indent=2))",
        "    return 0",
        "",
        "if __name__ == '__main__':",
        "    _exit_code = _cli()",
        "    if os.environ.get('FPY_FORCE_PROCESS_EXIT') == '1':",
        "        sys.stdout.flush()",
        "        sys.stderr.flush()",
        "        os._exit(_exit_code)",
        "    raise SystemExit(_exit_code)",
        "",
    ])
    return "\n".join(lines)


def _evaluate_constants(constants: tuple[ConstantIR, ...]) -> dict[str, int | float | bool]:
    values: dict[str, int | float | bool] = {}
    for constant in constants:
        values[constant.name] = _evaluate_expression(constant.value, values)
    return values


def _evaluate_expression(
    expression: ExpressionIR | None,
    values: dict[str, int | float | bool],
) -> int | float | bool:
    if expression is None:
        raise OrchestrationError("cannot evaluate an assumed extent")
    if expression.kind == "literal":
        assert isinstance(expression.value, (int, float, bool))
        return expression.value
    if expression.kind == "name":
        name = str(expression.value)
        if name not in values:
            raise OrchestrationError(f"unresolved orchestration constant: {name}")
        return values[name]
    if expression.kind == "unary":
        value = _evaluate_expression(expression.arguments[0], values)
        if expression.operator == "+":
            return +value
        if expression.operator == "-":
            return -value
        if expression.operator == "not":
            return not bool(value)
    if expression.kind == "binary":
        left = _evaluate_expression(expression.arguments[0], values)
        right = _evaluate_expression(expression.arguments[1], values)
        operator = expression.operator
        if operator == "+": return left + right
        if operator == "-": return left - right
        if operator == "*": return left * right
        if operator == "/": return left / right
        if operator == "**": return left ** right
    raise OrchestrationError(
        f"unsupported compile-time orchestration expression: {expression.kind}"
    )


def _state_class(group_name: str) -> str:
    parts = [item for item in re.split(r"[^a-zA-Z0-9]+|_+", group_name) if item]
    return "".join(item[:1].upper() + item[1:] for item in parts) + "State"


def _copy_source_set(source: str | Path, target: Path) -> None:
    source_path = Path(source).resolve()
    paths = _discover_source_paths(source_path)
    if source_path.is_file():
        shutil.copy2(source_path, target / source_path.name)
        return
    for path in paths:
        relative = path.relative_to(source_path)
        destination = target / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(path, destination)


def _validate_adapter_python(path: Path, callable_name: str, arguments: tuple[str, ...]) -> None:
    if not path.is_file():
        raise OrchestrationError(f"adapter source not found: {path}")
    try:
        tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
    except SyntaxError as exc:
        raise OrchestrationError(f"adapter source is not valid Python: {path}: {exc}") from exc
    function = next(
        (item for item in tree.body if isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef)) and item.name == callable_name),
        None,
    )
    if function is None:
        raise OrchestrationError(f"adapter callable {callable_name} not found in {path}")
    if isinstance(function, ast.AsyncFunctionDef):
        raise OrchestrationError(f"async adapters are not supported: {callable_name}")
    if function.args.vararg is not None or function.args.kwarg is not None:
        raise OrchestrationError(f"adapter {callable_name} must have an exact positional signature")
    positional = tuple(arg.arg.lower() for arg in (*function.args.posonlyargs, *function.args.args))
    required_count = len(positional) - len(function.args.defaults)
    if required_count != len(arguments) or len(positional) != len(arguments):
        raise OrchestrationError(
            f"adapter {callable_name}: Python signature {positional} does not match {arguments}"
        )
    if positional != arguments:
        raise OrchestrationError(
            f"adapter {callable_name}: Python argument names {positional} do not match {arguments}"
        )


def _name_arguments(expressions: tuple[ExpressionIR, ...], *, context: str) -> tuple[str, ...]:
    names: list[str] = []
    for expression in expressions:
        if expression.kind != "name":
            raise OrchestrationError(f"{context}: only scalar name arguments are supported")
        names.append(str(expression.value))
    return tuple(names)


def _fortran_declaration(symbol: SymbolIR, *, intent: str | None = None) -> str:
    attrs = f", intent({intent})" if intent else ""
    shape = ""
    if symbol.rank:
        if any(item is None for item in symbol.shape):
            raise OrchestrationError(f"assumed-shape main-program symbol is unsupported: {symbol.name}")
        shape = "(" + ", ".join(_fortran_expr(item) for item in symbol.shape if item is not None) + ")"
    return f"{_fortran_type(symbol.type)}{attrs} :: {symbol.name}{shape}"


def _fortran_type(type_ir: TypeIR) -> str:
    if type_ir.category == "integer":
        return "integer"
    if type_ir.category == "real":
        return "real(8)" if type_ir.kind in {"8", "double_precision"} else "real"
    if type_ir.category == "logical":
        return "logical"
    raise OrchestrationError(f"unsupported orchestration type: {type_ir.category}")


def _python_scalar_type(type_ir: TypeIR) -> str:
    return {"integer": "int", "real": "float", "logical": "bool"}[type_ir.category]


def _fortran_expr(expression: ExpressionIR | None) -> str:
    if expression is None:
        raise OrchestrationError("missing expression")
    if expression.kind == "name":
        return str(expression.value)
    if expression.kind == "literal":
        if isinstance(expression.value, bool):
            return ".true." if expression.value else ".false."
        if isinstance(expression.value, float):
            return f"{expression.value:.17e}".replace('e', 'd')
        return str(expression.value)
    if expression.kind == "binary":
        left, right = expression.arguments
        return f"({_fortran_expr(left)} {expression.operator} {_fortran_expr(right)})"
    if expression.kind == "unary":
        return f"({expression.operator}{_fortran_expr(expression.arguments[0])})"
    if expression.kind == "intrinsic":
        return f"{expression.value}({', '.join(_fortran_expr(v) for v in expression.arguments)})"
    if expression.kind == "array_ref":
        return f"{expression.value}({', '.join(_fortran_expr(v) for v in expression.indices)})"
    raise OrchestrationError(f"unsupported expression in wrapper: {expression.kind}")


def _safe_name(value: str) -> str:
    return re.sub(r"[^a-zA-Z0-9_]", "_", value).lower()


def _line(node: object, default: int) -> int:
    item = getattr(node, "item", None)
    span = getattr(item, "span", None)
    return int(span[0]) if span else default


def _expression_to_dict(expression: ExpressionIR) -> dict[str, object]:
    return {
        "kind": expression.kind,
        "value": expression.value,
        "operator": expression.operator,
        "arguments": [_expression_to_dict(item) for item in expression.arguments],
        "indices": [_expression_to_dict(item) for item in expression.indices],
    }


def _symbol_to_dict(symbol: SymbolIR) -> dict[str, object]:
    return {
        "name": symbol.name,
        "type": {
            "category": symbol.type.category,
            "kind": symbol.type.kind,
            "derived_name": symbol.type.derived_name,
        },
        "intent": symbol.intent,
        "rank": symbol.rank,
        "role": symbol.role,
    }
