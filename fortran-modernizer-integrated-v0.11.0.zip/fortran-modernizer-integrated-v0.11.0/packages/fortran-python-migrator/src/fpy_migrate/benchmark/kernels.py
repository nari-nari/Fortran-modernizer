from __future__ import annotations

from dataclasses import asdict, dataclass
import json
import math
import platform
from pathlib import Path
import shutil
import subprocess
import sys
import time
from typing import Any

import numpy as np

from fpy_migrate.backends import load_generated_backend
from fpy_migrate.ir import build_project_ir
from fpy_migrate.kernels import build_cython_extension
from fpy_migrate.translate import generate_cython, generate_python, write_cython, write_python


@dataclass(frozen=True)
class TimingResult:
    seconds_per_call: float
    elapsed_seconds: float
    repetitions: int


@dataclass(frozen=True)
class EquivalenceResult:
    residual: float
    pressure_sum: float
    pressure_max: float


@dataclass(frozen=True)
class BenchmarkCase:
    ntheta: int
    nz: int
    timings: dict[str, TimingResult]
    speedup_vs_python: dict[str, float]
    one_sweep: dict[str, EquivalenceResult]
    maximum_absolute_difference: dict[str, float]


@dataclass(frozen=True)
class BenchmarkReport:
    schema_version: str
    source: str
    procedure: str
    target_seconds: float
    environment: dict[str, str]
    cases: tuple[BenchmarkCase, ...]

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def write_benchmark_report(report: BenchmarkReport, output: str | Path) -> Path:
    path = Path(output)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(report.to_dict(), indent=2) + "\n", encoding="utf-8")
    return path


def benchmark_generated_kernel(
    source: str | Path,
    *,
    procedure: str,
    build_directory: str | Path,
    sizes: tuple[tuple[int, int], ...] = ((32, 17), (64, 33), (128, 65)),
    target_seconds: float = 0.05,
) -> BenchmarkReport:
    if target_seconds <= 0.0:
        raise ValueError("target_seconds must be positive")
    if shutil.which("gfortran") is None:
        raise RuntimeError("gfortran is required for the benchmark")
    if shutil.which("gcc") is None:
        raise RuntimeError("a C compiler is required for the Cython benchmark")

    source_path = Path(source).resolve()
    build_root = Path(build_directory).resolve()
    build_root.mkdir(parents=True, exist_ok=True)

    project = build_project_ir(source_path, procedure=procedure)
    python_source = write_python(
        generate_python(project, procedure=procedure),
        build_root / "generated_python.py",
    )
    safe_source = write_cython(
        generate_cython(project, procedure=procedure, safety_mode="safe"),
        build_root / "generated_cython_safe.py",
    )
    optimized_source = write_cython(
        generate_cython(project, procedure=procedure, safety_mode="optimized"),
        build_root / "generated_cython_optimized.py",
    )
    safe_built = build_cython_extension(
        safe_source,
        "generated_cython_safe",
        build_root / "cython_safe",
        safety_mode="safe",
    )
    optimized_built = build_cython_extension(
        optimized_source,
        "generated_cython_optimized",
        build_root / "cython_optimized",
        safety_mode="optimized",
    )

    python_backend = load_generated_backend("python", python_source)
    safe_backend = load_generated_backend(
        "cython", safe_built.extension, module_name=safe_built.module_name
    )
    optimized_backend = load_generated_backend(
        "cython", optimized_built.extension, module_name=optimized_built.module_name
    )
    fortran_executable = _build_fortran_benchmark(source_path, build_root)

    cases: list[BenchmarkCase] = []
    for ntheta, nz in sizes:
        if ntheta < 3 or nz < 3:
            raise ValueError("benchmark dimensions must both be at least 3")
        arguments = _initial_arguments(ntheta, nz, order="C")
        one_sweep_arrays: dict[str, np.ndarray] = {}
        one_sweep: dict[str, EquivalenceResult] = {}

        for name, backend in (
            ("python", python_backend),
            ("cython_safe", safe_backend),
            ("cython_optimized", optimized_backend),
        ):
            call_args = _copy_arguments(arguments, order="C")
            pressure, residual = backend.call(procedure, *call_args)
            pressure_array = np.asarray(pressure)
            one_sweep_arrays[name] = pressure_array.copy()
            one_sweep[name] = _equivalence_result(pressure_array, float(residual))

        fortran_one, fortran_timing = _run_fortran_benchmark(
            fortran_executable,
            ntheta=ntheta,
            nz=nz,
            target_seconds=target_seconds,
        )
        one_sweep["fortran_o3"] = fortran_one

        timings = {
            "python": _time_backend(
                python_backend,
                procedure,
                arguments,
                target_seconds=target_seconds,
            ),
            "cython_safe": _time_backend(
                safe_backend,
                procedure,
                arguments,
                target_seconds=target_seconds,
            ),
            "cython_optimized": _time_backend(
                optimized_backend,
                procedure,
                arguments,
                target_seconds=target_seconds,
            ),
            "fortran_o3": fortran_timing,
        }
        python_seconds = timings["python"].seconds_per_call
        speedups = {
            name: python_seconds / result.seconds_per_call
            for name, result in timings.items()
            if name != "python" and result.seconds_per_call > 0.0
        }
        maximum_absolute_difference = {
            "python_vs_cython_safe": float(
                np.max(np.abs(one_sweep_arrays["python"] - one_sweep_arrays["cython_safe"]))
            ),
            "python_vs_cython_optimized": float(
                np.max(
                    np.abs(
                        one_sweep_arrays["python"]
                        - one_sweep_arrays["cython_optimized"]
                    )
                )
            ),
            "cython_safe_vs_cython_optimized": float(
                np.max(
                    np.abs(
                        one_sweep_arrays["cython_safe"]
                        - one_sweep_arrays["cython_optimized"]
                    )
                )
            ),
            "python_vs_fortran_pressure_sum": abs(
                one_sweep["python"].pressure_sum
                - one_sweep["fortran_o3"].pressure_sum
            ),
            "python_vs_fortran_residual": abs(
                one_sweep["python"].residual - one_sweep["fortran_o3"].residual
            ),
        }
        cases.append(
            BenchmarkCase(
                ntheta=ntheta,
                nz=nz,
                timings=timings,
                speedup_vs_python=speedups,
                one_sweep=one_sweep,
                maximum_absolute_difference=maximum_absolute_difference,
            )
        )

    return BenchmarkReport(
        schema_version="1.0",
        source=str(source_path),
        procedure=procedure.lower(),
        target_seconds=target_seconds,
        environment={
            "python": sys.version.split()[0],
            "platform": platform.platform(),
            "machine": platform.machine(),
            "processor": platform.processor(),
            "numpy": np.__version__,
        },
        cases=tuple(cases),
    )


def _initial_arguments(
    ntheta: int,
    nz: int,
    *,
    order: str,
) -> tuple[Any, ...]:
    dtheta = 2.0 * math.pi / float(ntheta)
    dz = 1.0 / float(nz - 1)
    indices = np.arange(ntheta, dtype=np.float64)
    film = np.ascontiguousarray(1.0 + 0.60 * np.cos(indices * dtheta))
    i = np.arange(1, ntheta + 1, dtype=np.float64)[:, None]
    j = np.arange(1, nz + 1, dtype=np.float64)[None, :]
    pressure = np.array(0.002 * i * j, dtype=np.float64, order=order)
    return ntheta, nz, film, pressure, dtheta, dz, 0.20, 1.35


def _copy_arguments(arguments: tuple[Any, ...], *, order: str) -> tuple[Any, ...]:
    copied: list[Any] = []
    for value in arguments:
        if isinstance(value, np.ndarray):
            copied.append(np.array(value, copy=True, order=order))
        else:
            copied.append(value)
    return tuple(copied)


def _equivalence_result(pressure: np.ndarray, residual: float) -> EquivalenceResult:
    return EquivalenceResult(
        residual=residual,
        pressure_sum=float(np.sum(pressure, dtype=np.float64)),
        pressure_max=float(np.max(pressure)),
    )


def _time_backend(
    backend: Any,
    procedure: str,
    arguments: tuple[Any, ...],
    *,
    target_seconds: float,
    maximum_repetitions: int = 1_048_576,
) -> TimingResult:
    # Warm up import dispatch and Cython module initialisation outside timing.
    backend.call(procedure, *_copy_arguments(arguments, order="C"))
    repetitions = 1
    elapsed = 0.0
    while True:
        call_args = _copy_arguments(arguments, order="C")
        start = time.perf_counter()
        for _ in range(repetitions):
            backend.call(procedure, *call_args)
        elapsed = time.perf_counter() - start
        if elapsed >= target_seconds or repetitions >= maximum_repetitions:
            break
        repetitions *= 2
    return TimingResult(
        seconds_per_call=elapsed / float(repetitions),
        elapsed_seconds=elapsed,
        repetitions=repetitions,
    )


def _build_fortran_benchmark(source: Path, build_root: Path) -> Path:
    driver = build_root / "benchmark_sor_driver.f90"
    driver.write_text(_fortran_benchmark_source(), encoding="utf-8")
    executable = build_root / "benchmark_sor_driver"
    subprocess.run(
        [
            "gfortran",
            "-std=f2008",
            "-O3",
            str(source),
            str(driver),
            "-o",
            str(executable),
        ],
        check=True,
        capture_output=True,
        text=True,
        cwd=build_root,
    )
    return executable


def _run_fortran_benchmark(
    executable: Path,
    *,
    ntheta: int,
    nz: int,
    target_seconds: float,
) -> tuple[EquivalenceResult, TimingResult]:
    completed = subprocess.run(
        [str(executable), str(ntheta), str(nz), repr(target_seconds)],
        check=True,
        capture_output=True,
        text=True,
    )
    values: dict[str, float] = {}
    for line in completed.stdout.splitlines():
        if "=" not in line:
            continue
        key, value = line.split("=", maxsplit=1)
        values[key.strip()] = float(value.strip())
    required = {
        "one_residual",
        "one_pressure_sum",
        "one_pressure_max",
        "elapsed_seconds",
        "repetitions",
        "seconds_per_call",
    }
    missing = required - values.keys()
    if missing:
        raise RuntimeError(f"incomplete Fortran benchmark output: {sorted(missing)}")
    return (
        EquivalenceResult(
            residual=values["one_residual"],
            pressure_sum=values["one_pressure_sum"],
            pressure_max=values["one_pressure_max"],
        ),
        TimingResult(
            seconds_per_call=values["seconds_per_call"],
            elapsed_seconds=values["elapsed_seconds"],
            repetitions=int(values["repetitions"]),
        ),
    )


def _fortran_benchmark_source() -> str:
    return """program benchmark_sor_driver
  use iso_fortran_env, only: real64
  use sor_kernel_mod, only: sor_sweep
  implicit none
  integer :: ntheta, nz, repetitions, k, i, j
  integer, parameter :: max_repetitions = 1048576
  real(real64) :: target_seconds, dtheta, dz, residual
  real(real64) :: start_time, end_time, elapsed
  real(real64), allocatable :: film(:), pressure(:, :)
  character(len=128) :: argument

  call get_command_argument(1, argument)
  read(argument, *) ntheta
  call get_command_argument(2, argument)
  read(argument, *) nz
  call get_command_argument(3, argument)
  read(argument, *) target_seconds

  allocate(film(ntheta), pressure(ntheta, nz))
  dtheta = 2.0_real64 * acos(-1.0_real64) / real(ntheta, real64)
  dz = 1.0_real64 / real(nz - 1, real64)
  do i = 1, ntheta
    film(i) = 1.0_real64 + 0.60_real64 * cos(real(i - 1, real64) * dtheta)
    do j = 1, nz
      pressure(i, j) = 0.002_real64 * real(i * j, real64)
    end do
  end do
  call sor_sweep(ntheta, nz, film, pressure, dtheta, dz, 0.20_real64, &
    1.35_real64, residual)
  write(*, '(A,ES24.16)') 'one_residual=', residual
  write(*, '(A,ES24.16)') 'one_pressure_sum=', sum(pressure)
  write(*, '(A,ES24.16)') 'one_pressure_max=', maxval(pressure)

  repetitions = 1
  do
    do i = 1, ntheta
      do j = 1, nz
        pressure(i, j) = 0.002_real64 * real(i * j, real64)
      end do
    end do
    call cpu_time(start_time)
    do k = 1, repetitions
      call sor_sweep(ntheta, nz, film, pressure, dtheta, dz, 0.20_real64, &
        1.35_real64, residual)
    end do
    call cpu_time(end_time)
    elapsed = end_time - start_time
    if (elapsed >= target_seconds .or. repetitions >= max_repetitions) exit
    repetitions = repetitions * 2
  end do

  write(*, '(A,ES24.16)') 'elapsed_seconds=', elapsed
  write(*, '(A,I0)') 'repetitions=', repetitions
  write(*, '(A,ES24.16)') 'seconds_per_call=', elapsed / real(repetitions, real64)
end program benchmark_sor_driver
"""
