from __future__ import annotations

from dataclasses import asdict, dataclass
import json
from pathlib import Path
import subprocess
import tempfile
import time
from typing import Any

import numpy as np

from fpy_migrate.backends import load_generated_backend
from fpy_migrate.solver import PressureSolverCase, load_solver_manifest


@dataclass(frozen=True)
class SolverTiming:
    seconds_per_call: float
    elapsed_seconds: float
    repetitions: int


@dataclass(frozen=True)
class SolverBenchmarkCase:
    ntheta: int
    nz: int
    timings: dict[str, SolverTiming]
    speedup_vs_python: dict[str, float]
    summaries: dict[str, dict[str, int | float | bool]]
    maximum_absolute_pressure_difference: dict[str, float]


@dataclass(frozen=True)
class SolverBenchmarkReport:
    schema_version: str
    manifest: str
    target_seconds: float
    cases: tuple[SolverBenchmarkCase, ...]

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def benchmark_full_solver(
    manifest_path: str | Path,
    *,
    sizes: tuple[tuple[int, int], ...] = ((32, 9), (64, 17)),
    target_seconds: float = 0.05,
) -> SolverBenchmarkReport:
    if target_seconds <= 0.0:
        raise ValueError("target_seconds must be positive")
    manifest_file = Path(manifest_path).resolve()
    manifest = load_solver_manifest(manifest_file)
    required = {"python", "cython-safe", "cython-optimized", "fortran"}
    missing = required - manifest.artifacts.keys()
    if missing:
        raise ValueError(f"full solver benchmark requires all backends: {sorted(missing)}")

    def artifact_path(name: str) -> Path:
        value = Path(manifest.artifact(name)["path"])
        if not value.is_absolute():
            value = manifest_file.parent / value
        return value.resolve()

    backends = {
        "python": load_generated_backend("python", artifact_path("python")),
        "cython-safe": load_generated_backend(
            "cython",
            artifact_path("cython-safe"),
            module_name=manifest.artifact("cython-safe").get("module_name"),
        ),
        "cython-optimized": load_generated_backend(
            "cython",
            artifact_path("cython-optimized"),
            module_name=manifest.artifact("cython-optimized").get("module_name"),
        ),
    }
    fortran_executable = artifact_path("fortran")

    cases: list[SolverBenchmarkCase] = []
    for ntheta, nz in sizes:
        case = PressureSolverCase(ntheta=ntheta, nz=nz, tolerance=1.0e-10)
        arrays: dict[str, np.ndarray] = {}
        summaries: dict[str, dict[str, int | float | bool]] = {}
        timings: dict[str, SolverTiming] = {}
        for name, backend in backends.items():
            values = backend.call(manifest.procedure, *case.arguments())
            pressure = np.asarray(values[0], dtype=np.float64)
            arrays[name] = pressure.copy()
            summaries[name] = _summary(values)
            timings[name] = _time_generated(
                backend,
                manifest.procedure,
                case,
                target_seconds=target_seconds,
            )

        fortran_summary, fortran_pressure, fortran_timing = _run_fortran_benchmark(
            fortran_executable,
            case,
            target_seconds=target_seconds,
        )
        arrays["fortran"] = fortran_pressure
        summaries["fortran"] = fortran_summary
        timings["fortran"] = fortran_timing

        python_seconds = timings["python"].seconds_per_call
        speedups = {
            name: python_seconds / timing.seconds_per_call
            for name, timing in timings.items()
            if name != "python" and timing.seconds_per_call > 0.0
        }
        differences = {
            "python_vs_cython_safe": float(
                np.max(np.abs(arrays["python"] - arrays["cython-safe"]))
            ),
            "python_vs_cython_optimized": float(
                np.max(np.abs(arrays["python"] - arrays["cython-optimized"]))
            ),
            "python_vs_fortran": float(
                np.max(np.abs(arrays["python"] - arrays["fortran"]))
            ),
        }
        cases.append(
            SolverBenchmarkCase(
                ntheta=ntheta,
                nz=nz,
                timings=timings,
                speedup_vs_python=speedups,
                summaries=summaries,
                maximum_absolute_pressure_difference=differences,
            )
        )

    return SolverBenchmarkReport(
        schema_version="1.0",
        manifest=str(manifest_file),
        target_seconds=target_seconds,
        cases=tuple(cases),
    )


def write_solver_benchmark_report(
    report: SolverBenchmarkReport,
    output: str | Path,
) -> Path:
    path = Path(output)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(report.to_dict(), indent=2) + "\n", encoding="utf-8")
    return path


def _summary(values: tuple[Any, ...]) -> dict[str, int | float | bool]:
    pressure = np.asarray(values[0], dtype=np.float64)
    film = np.asarray(values[1], dtype=np.float64)
    return {
        "iterations": int(values[2]),
        "update_residual": float(values[3]),
        "converged": bool(values[4]),
        "maximum_pressure": float(np.max(pressure)),
        "minimum_film_thickness": float(np.min(film)),
        "pressure_sum": float(np.sum(pressure, dtype=np.float64)),
    }


def _time_generated(
    backend: Any,
    procedure: str,
    case: PressureSolverCase,
    *,
    target_seconds: float,
) -> SolverTiming:
    backend.call(procedure, *case.arguments())
    repetitions = 1
    while True:
        start = time.perf_counter()
        for _ in range(repetitions):
            backend.call(procedure, *case.arguments())
        elapsed = time.perf_counter() - start
        if elapsed >= target_seconds:
            return SolverTiming(elapsed / repetitions, elapsed, repetitions)
        repetitions *= 2


def _run_fortran_benchmark(
    executable: Path,
    case: PressureSolverCase,
    *,
    target_seconds: float,
) -> tuple[dict[str, int | float | bool], np.ndarray, SolverTiming]:
    repetitions = 1
    while True:
        with tempfile.TemporaryDirectory(prefix="fpy-full-benchmark-") as temporary:
            output = Path(temporary)
            subprocess.run(
                [
                    str(executable),
                    *(str(value) for value in case.arguments()),
                    str(output),
                    str(repetitions),
                ],
                check=True,
                capture_output=True,
                text=True,
            )
            raw = _read_key_values(output / "summary.txt")
            elapsed = float(raw["elapsed_seconds"])
            pressure = _read_pressure(output / "pressure.csv", case.ntheta, case.nz)
            film = _read_film(output / "film.csv", case.ntheta)
        if elapsed >= target_seconds:
            break
        repetitions *= 2
    summary: dict[str, int | float | bool] = {
        "iterations": int(raw["iterations"]),
        "update_residual": float(raw["update_residual"]),
        "converged": bool(int(raw["converged"])),
        "maximum_pressure": float(np.max(pressure)),
        "minimum_film_thickness": float(np.min(film)),
        "pressure_sum": float(np.sum(pressure, dtype=np.float64)),
    }
    return summary, pressure, SolverTiming(
        seconds_per_call=float(raw["seconds_per_call"]),
        elapsed_seconds=elapsed,
        repetitions=repetitions,
    )


def _read_key_values(path: Path) -> dict[str, str]:
    output: dict[str, str] = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        if "=" in line:
            key, value = line.split("=", maxsplit=1)
            output[key.strip()] = value.strip()
    return output


def _read_pressure(path: Path, ntheta: int, nz: int) -> np.ndarray:
    pressure = np.zeros((ntheta, nz), dtype=np.float64)
    for line in path.read_text(encoding="utf-8").splitlines():
        i, j, value = line.split(",")
        pressure[int(i) - 1, int(j) - 1] = float(value)
    return pressure


def _read_film(path: Path, ntheta: int) -> np.ndarray:
    film = np.zeros(ntheta, dtype=np.float64)
    for line in path.read_text(encoding="utf-8").splitlines():
        i, value = line.split(",")
        film[int(i) - 1] = float(value)
    return film
