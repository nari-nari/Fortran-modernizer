from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
from pathlib import Path

from .assessment import assess_tree, write_report
from .acceptance import (
    diagnose_project, validate_acceptance_report, write_acceptance_report,
    write_construct_csv, write_procedure_csv,
)
from .benchmark import (
    benchmark_full_solver,
    benchmark_generated_kernel,
    write_benchmark_report,
    write_solver_benchmark_report,
)
from .intake import validate_refactor_report
from .refactor_bridge import RefactorBridgeError, import_refactor_bundle, verify_refactor_connection
from .ir import UnsupportedFortranError, build_project_ir, validate_migration_ir, write_project_ir
from .translate import generate_cython, generate_python, write_cython, write_python
from .normalization import normalize_with_findent
from .orchestration import (
    OrchestrationError,
    analyze_orchestration,
    build_orchestration,
    write_orchestration_plan,
)
from .kernels import analyze_kernel_candidates, build_cython_extension, write_candidate_report
from .solver import (
    build_analysis_backends,
    build_solver_backends,
    load_solver_run_configuration,
    run_configured_analysis,
    run_configured_solver,
)
from .state import analyze_state_migration, write_state_migration_report
from .packaging import DistributionError, prepare_distribution, validate_distribution
from .extraction import (
    PartialLoopExtractionError,
    StateKernelExtractionError,
    analyze_hybrid_project,
    analyze_partial_loop,
    analyze_state_kernel,
    aggregate_hybrid_profiles,
    benchmark_hybrid_economics,
    build_hybrid_project,
    load_hybrid_profile,
    profile_hybrid_project,
    profile_hybrid_suite,
    write_hybrid_profile,
    write_hybrid_economics,
    build_partial_loop_bundle,
    build_state_kernel_bundle,
    write_hybrid_project_plan,
    write_partial_loop_report,
    write_state_kernel_report,
)
from .sample.journal_bearing.runner import (
    build_cython,
    build_fortran,
    compare_all,
    run_backend,
)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="fpy-migrate")
    subparsers = parser.add_subparsers(dest="command", required=True)

    assess = subparsers.add_parser("assess", help="assess Fortran migration readiness")
    assess.add_argument("source")
    assess.add_argument("--output", default="build/assessment.json")

    diagnose = subparsers.add_parser(
        "diagnose-project",
        help="inventory a real Fortran project and rank migration readiness by procedure",
    )
    diagnose.add_argument("source")
    diagnose.add_argument("--procedure")
    diagnose.add_argument("--output", required=True)
    diagnose.add_argument("--csv-output")
    diagnose.add_argument("--construct-csv-output")
    diagnose.add_argument("--refactor-report")

    normalize = subparsers.add_parser(
        "normalize",
        help="convert fixed-form Fortran to free form with findent",
    )
    normalize.add_argument("source")
    normalize.add_argument("--output", required=True)

    validate = subparsers.add_parser(
        "validate-refactor-report",
        help="validate JSON exported by the separate refactoring tool",
    )
    validate.add_argument("report")

    import_bundle = subparsers.add_parser(
        "import-refactor-bundle",
        help="normalise a directory of machine-readable refactoring-tool reports",
    )
    import_bundle.add_argument("bundle")
    import_bundle.add_argument("--output", required=True)
    import_bundle.add_argument("--producer", default="fortran-refactor-tool")
    import_bundle.add_argument("--producer-version")
    import_bundle.add_argument("--project-root")

    verify_connection = subparsers.add_parser(
        "verify-refactor-connection",
        help="cross-check a canonical refactoring hand-off against fparser Migration IR",
    )
    verify_connection.add_argument("source")
    verify_connection.add_argument("--procedure")
    verify_connection.add_argument("--report", required=True)
    verify_connection.add_argument("--output", required=True)

    verify_e2e = subparsers.add_parser(
        "verify-e2e",
        help="run the full legacy/normalized/handoff/backend acceptance gate",
    )
    verify_e2e.add_argument("legacy_source")
    verify_e2e.add_argument("normalized_source")
    verify_e2e.add_argument("--program", required=True)
    verify_e2e.add_argument("--adapter-config", required=True)
    verify_e2e.add_argument("--handoff", required=True)
    verify_e2e.add_argument("--handoff-procedure", required=True)
    verify_e2e.add_argument("--build-directory", required=True)
    verify_e2e.add_argument("--output", required=True)
    verify_e2e.add_argument("--rtol", type=float, default=1.0e-12)
    verify_e2e.add_argument("--atol", type=float, default=1.0e-13)
    verify_e2e.add_argument("--without-fortran-backend", action="store_true")

    build_ir = subparsers.add_parser(
        "build-ir",
        help="build the safe Migration IR for one or more Fortran subroutines",
    )
    build_ir.add_argument("source")
    build_ir.add_argument("--procedure")
    build_ir.add_argument("--output", required=True)
    build_ir.add_argument("--refactor-report")

    validate_ir = subparsers.add_parser(
        "validate-ir",
        help="validate a Migration IR JSON document",
    )
    validate_ir.add_argument("ir")

    translate = subparsers.add_parser(
        "translate",
        help="translate a supported Fortran subroutine to readable Python",
    )
    translate.add_argument("source")
    translate.add_argument("--procedure", required=True)
    translate.add_argument("--output", required=True)
    translate.add_argument("--ir-output")
    translate.add_argument("--refactor-report")

    analyze_orchestration_parser = subparsers.add_parser(
        "analyze-orchestration",
        help="analyze a Fortran main program and trailing Python adapters",
    )
    analyze_orchestration_parser.add_argument("source")
    analyze_orchestration_parser.add_argument("--program", required=True)
    analyze_orchestration_parser.add_argument("--adapter-config", required=True)
    analyze_orchestration_parser.add_argument("--output", required=True)
    analyze_orchestration_parser.add_argument("--refactor-report")

    build_orchestration_parser = subparsers.add_parser(
        "build-orchestration",
        help="generate a Python application from a Fortran main program",
    )
    build_orchestration_parser.add_argument("source")
    build_orchestration_parser.add_argument("--program", required=True)
    build_orchestration_parser.add_argument("--adapter-config", required=True)
    build_orchestration_parser.add_argument("--build-directory", required=True)
    build_orchestration_parser.add_argument("--refactor-report")
    build_orchestration_parser.add_argument(
        "--default-backend",
        choices=("python", "cython-safe", "cython-optimized", "fortran"),
        default="python",
    )
    build_orchestration_parser.add_argument("--include-fortran", action="store_true")

    analyze_state = subparsers.add_parser(
        "analyze-state",
        help="report COMMON/module state groups and their Python object mapping",
    )
    analyze_state.add_argument("source")
    analyze_state.add_argument("--procedure")
    analyze_state.add_argument("--output", required=True)
    analyze_state.add_argument("--refactor-report")

    analyze_kernels = subparsers.add_parser(
        "analyze-kernels",
        help="rank supported procedures as native-kernel candidates",
    )
    analyze_kernels.add_argument("source")
    analyze_kernels.add_argument("--procedure")
    analyze_kernels.add_argument("--output", required=True)
    analyze_kernels.add_argument("--refactor-report")

    analyze_state_kernel_parser = subparsers.add_parser(
        "analyze-state-kernel",
        help="analyze extraction of an explicit numerical kernel from shared state",
    )
    analyze_state_kernel_parser.add_argument("source")
    analyze_state_kernel_parser.add_argument("--procedure", required=True)
    analyze_state_kernel_parser.add_argument("--output", required=True)
    analyze_state_kernel_parser.add_argument("--ir-output")
    analyze_state_kernel_parser.add_argument("--refactor-report")

    build_state_kernel_parser = subparsers.add_parser(
        "build-state-kernel",
        help="generate Python/Cython and optional Fortran state-kernel backends plus a Python adapter",
    )
    build_state_kernel_parser.add_argument("source")
    build_state_kernel_parser.add_argument("--procedure", required=True)
    build_state_kernel_parser.add_argument("--build-directory", required=True)
    build_state_kernel_parser.add_argument("--refactor-report")
    build_state_kernel_parser.add_argument("--include-fortran", action="store_true")

    analyze_project_parser = subparsers.add_parser(
        "analyze-hybrid-project",
        help="classify all reachable procedures for project-level hybrid generation",
    )
    analyze_project_parser.add_argument("source")
    analyze_project_parser.add_argument("--procedure", required=True)
    analyze_project_parser.add_argument("--output", required=True)
    analyze_project_parser.add_argument("--refactor-report")
    analyze_project_parser.add_argument("--profile-report")
    analyze_project_parser.add_argument("--min-profile-share", type=float, default=0.0)
    analyze_project_parser.add_argument("--min-profile-mean-share", type=float, default=0.0)
    analyze_project_parser.add_argument("--min-profile-max-share", type=float, default=0.0)
    analyze_project_parser.add_argument("--min-profile-cases", type=int, default=1)
    analyze_project_parser.add_argument("--min-profile-time-ms", type=float, default=0.0)
    analyze_project_parser.add_argument("--max-native-kernels", type=int)
    analyze_project_parser.add_argument("--economics-report")
    analyze_project_parser.add_argument("--min-economics-speedup", type=float, default=1.0)
    analyze_project_parser.add_argument("--min-economics-saved-time-ms", type=float, default=0.0)
    analyze_project_parser.add_argument("--max-economics-build-seconds", type=float)
    analyze_project_parser.add_argument("--max-economics-artifact-mb", type=float)
    analyze_project_parser.add_argument("--max-economics-break-even-runs", type=float)
    analyze_project_parser.add_argument("--max-economics-break-even-calls", type=float)

    profile_project_parser = subparsers.add_parser(
        "profile-hybrid-project",
        help="profile generated Python reference procedures and internal loop candidates",
    )
    profile_project_parser.add_argument("source")
    profile_project_parser.add_argument("--procedure", required=True)
    profile_project_parser.add_argument("--workload", required=True)
    profile_project_parser.add_argument("--build-directory", required=True)
    profile_project_parser.add_argument("--output", required=True)
    profile_project_parser.add_argument("--warmup-runs", type=int, default=1)
    profile_project_parser.add_argument("--measured-runs", type=int, default=10)
    profile_project_parser.add_argument("--refactor-report")

    profile_suite_parser = subparsers.add_parser(
        "profile-hybrid-suite",
        help="profile multiple representative workloads and aggregate their importance",
    )
    profile_suite_parser.add_argument("source")
    profile_suite_parser.add_argument("--procedure", required=True)
    profile_suite_parser.add_argument(
        "--case", action="append", required=True,
        help="named workload in NAME=PATH form; repeat for multiple cases",
    )
    profile_suite_parser.add_argument(
        "--case-weight", action="append", default=[],
        help="optional case weight in NAME=WEIGHT form",
    )
    profile_suite_parser.add_argument("--build-directory", required=True)
    profile_suite_parser.add_argument("--output", required=True)
    profile_suite_parser.add_argument("--warmup-runs", type=int, default=1)
    profile_suite_parser.add_argument("--measured-runs", type=int, default=10)
    profile_suite_parser.add_argument("--refactor-report")

    aggregate_profiles_parser = subparsers.add_parser(
        "aggregate-hybrid-profiles",
        help="aggregate existing profile reports with optional case weights",
    )
    aggregate_profiles_parser.add_argument(
        "--profile", action="append", required=True,
        help="named profile in NAME=PATH form; repeat for multiple cases",
    )
    aggregate_profiles_parser.add_argument(
        "--profile-weight", action="append", default=[],
        help="optional profile weight in NAME=WEIGHT form",
    )
    aggregate_profiles_parser.add_argument("--output", required=True)

    economics_parser = subparsers.add_parser(
        "benchmark-hybrid-economics",
        help="measure kernel speedup against Cython build time and artifact size",
    )
    economics_parser.add_argument("source")
    economics_parser.add_argument("--procedure", required=True)
    economics_parser.add_argument("--profile-report", required=True)
    economics_parser.add_argument("--build-directory", required=True)
    economics_parser.add_argument("--output", required=True)
    economics_parser.add_argument("--warmup-runs", type=int, default=2)
    economics_parser.add_argument("--measured-runs", type=int, default=20)
    economics_parser.add_argument("--refactor-report")

    build_project_parser = subparsers.add_parser(
        "build-hybrid-project",
        help="build full state kernels and partial-loop kernels behind one registry",
    )
    build_project_parser.add_argument("source")
    build_project_parser.add_argument("--procedure", required=True)
    build_project_parser.add_argument("--build-directory", required=True)
    build_project_parser.add_argument("--refactor-report")
    build_project_parser.add_argument("--include-fortran", action="store_true")
    build_project_parser.add_argument("--profile-report")
    build_project_parser.add_argument("--min-profile-share", type=float, default=0.0)
    build_project_parser.add_argument("--min-profile-mean-share", type=float, default=0.0)
    build_project_parser.add_argument("--min-profile-max-share", type=float, default=0.0)
    build_project_parser.add_argument("--min-profile-cases", type=int, default=1)
    build_project_parser.add_argument("--min-profile-time-ms", type=float, default=0.0)
    build_project_parser.add_argument("--max-native-kernels", type=int)
    build_project_parser.add_argument("--economics-report")
    build_project_parser.add_argument("--min-economics-speedup", type=float, default=1.0)
    build_project_parser.add_argument("--min-economics-saved-time-ms", type=float, default=0.0)
    build_project_parser.add_argument("--max-economics-build-seconds", type=float)
    build_project_parser.add_argument("--max-economics-artifact-mb", type=float)
    build_project_parser.add_argument("--max-economics-break-even-runs", type=float)
    build_project_parser.add_argument("--max-economics-break-even-calls", type=float)
    build_project_parser.add_argument(
        "--default-backend",
        choices=["python", "cython-safe", "cython-optimized", "fortran"],
        default="cython-optimized",
    )

    analyze_partial_parser = subparsers.add_parser(
        "analyze-partial-loop",
        help="analyze extraction of one top-level DO loop while retaining surrounding Python",
    )
    analyze_partial_parser.add_argument("source")
    analyze_partial_parser.add_argument("--procedure", required=True)
    analyze_partial_parser.add_argument("--loop-index", type=int, default=1)
    analyze_partial_parser.add_argument("--output", required=True)
    analyze_partial_parser.add_argument("--ir-output")
    analyze_partial_parser.add_argument("--refactor-report")

    build_partial_parser = subparsers.add_parser(
        "build-partial-loop",
        help="build Python/Cython and optional Fortran backends for one internal loop plus a Python wrapper",
    )
    build_partial_parser.add_argument("source")
    build_partial_parser.add_argument("--procedure", required=True)
    build_partial_parser.add_argument("--loop-index", type=int, default=1)
    build_partial_parser.add_argument("--build-directory", required=True)
    build_partial_parser.add_argument("--refactor-report")
    build_partial_parser.add_argument("--include-fortran", action="store_true")
    build_partial_parser.add_argument(
        "--default-backend",
        choices=["python", "cython-safe", "cython-optimized", "fortran"],
        default="cython-optimized",
    )

    translate_cython = subparsers.add_parser(
        "translate-cython",
        help="generate a safe or optimised Cython Pure Python Mode kernel",
    )
    translate_cython.add_argument("source")
    translate_cython.add_argument("--procedure", required=True)
    translate_cython.add_argument("--output", required=True)
    translate_cython.add_argument("--ir-output")
    translate_cython.add_argument("--candidate-output")
    translate_cython.add_argument("--refactor-report")
    translate_cython.add_argument(
        "--mode", choices=["safe", "optimized"], default="safe"
    )

    compile_cython = subparsers.add_parser(
        "compile-cython",
        help="compile a generated Cython Pure Python Mode source",
    )
    compile_cython.add_argument("source")
    compile_cython.add_argument("--module-name", required=True)
    compile_cython.add_argument("--build-directory", required=True)
    compile_cython.add_argument(
        "--mode", choices=["safe", "optimized"], default="safe"
    )

    benchmark = subparsers.add_parser(
        "benchmark-kernel",
        help="benchmark generated Python, safe/optimized Cython, and Fortran",
    )
    benchmark.add_argument("source")
    benchmark.add_argument("--procedure", required=True)
    benchmark.add_argument("--build-directory", required=True)
    benchmark.add_argument("--output", required=True)
    benchmark.add_argument("--target-seconds", type=float, default=0.05)
    benchmark.add_argument(
        "--size",
        action="append",
        dest="sizes",
        metavar="NTHETAxNZ",
        help="benchmark size; may be specified more than once",
    )

    build_solver = subparsers.add_parser(
        "build-solver",
        help="generate Python/Cython full-solver backends and optionally build Fortran",
    )
    build_solver.add_argument("source")
    build_solver.add_argument("--procedure", default="solve_pressure")
    build_solver.add_argument("--build-directory", required=True)
    build_solver.add_argument("--fortran-driver")

    run_solver = subparsers.add_parser(
        "run-solver",
        help="run a generated full solver using a TOML backend configuration",
    )
    run_solver.add_argument("config")

    benchmark_solver = subparsers.add_parser(
        "benchmark-solver",
        help="benchmark full Python/Cython/Fortran solver backends",
    )
    benchmark_solver.add_argument("manifest")
    benchmark_solver.add_argument("--output", required=True)
    benchmark_solver.add_argument("--target-seconds", type=float, default=0.05)
    benchmark_solver.add_argument(
        "--size",
        action="append",
        dest="solver_sizes",
        metavar="NTHETAxNZ",
    )

    build_analysis = subparsers.add_parser(
        "build-analysis",
        help="generate Python/Cython lubrication-analysis backends and optionally build Fortran",
    )
    build_analysis.add_argument("source")
    build_analysis.add_argument("--procedure", default="solve_analysis")
    build_analysis.add_argument("--build-directory", required=True)
    build_analysis.add_argument("--fortran-driver")

    run_analysis = subparsers.add_parser(
        "run-analysis",
        help="run a generated lubrication analysis and write common result files",
    )
    run_analysis.add_argument("config")

    prepare_package = subparsers.add_parser(
        "prepare-distribution",
        help="prepare a source-only WSL or Windows/Nuitka distribution kit",
    )
    prepare_package.add_argument("hybrid_manifest")
    prepare_package.add_argument("--app-adapter", required=True)
    prepare_package.add_argument("--output-directory", required=True)
    prepare_package.add_argument("--app-name", required=True)
    prepare_package.add_argument(
        "--target",
        choices=["linux-wsl", "windows-nuitka"],
        default="windows-nuitka",
    )

    validate_package = subparsers.add_parser(
        "validate-distribution",
        help="validate a prepared source-only distribution kit",
    )
    validate_package.add_argument("directory")

    sample = subparsers.add_parser("sample", help="build/run/compare sample solver")
    sample_sub = sample.add_subparsers(dest="sample_command", required=True)
    sample_sub.add_parser("build")
    run = sample_sub.add_parser("run")
    run.add_argument(
        "--backend",
        choices=["python", "cython", "fortran-reference", "fortran-legacy", "all"],
        default="all",
    )
    run.add_argument("--case")
    compare = sample_sub.add_parser("compare")
    compare.add_argument("--json", action="store_true")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    if args.command == "assess":
        report = assess_tree(args.source)
        write_report(report, args.output)
        counts: dict[str, int] = {"READY": 0, "REVIEW_REQUIRED": 0, "BLOCKED": 0}
        for item in report.files:
            counts[item.status] += 1
        print(json.dumps({"output": args.output, "counts": counts}, indent=2))
        return 0 if counts["BLOCKED"] == 0 else 2

    if args.command == "diagnose-project":
        try:
            report = diagnose_project(
                args.source,
                procedure=args.procedure,
                refactor_report=args.refactor_report,
            )
        except (UnsupportedFortranError, ValueError, FileNotFoundError) as exc:
            print(f"BLOCKED: {exc}")
            return 2
        output = write_acceptance_report(report, args.output)
        errors = validate_acceptance_report(output)
        if errors:
            for error in errors:
                print(error)
            return 2
        csv_output = write_procedure_csv(report, args.csv_output) if args.csv_output else None
        construct_csv = write_construct_csv(report, args.construct_csv_output) if args.construct_csv_output else None
        print(json.dumps({
            "output": str(output),
            "csv_output": str(csv_output) if csv_output else None,
            "construct_csv_output": str(construct_csv) if construct_csv else None,
            "status": report.status,
            "summary": report.summary,
            "rates": report.rates,
            "migration_order": report.migration_order,
        }, indent=2))
        return 0 if report.status == "READY" else (1 if report.status == "REVIEW_REQUIRED" else 2)

    if args.command == "normalize":
        output = normalize_with_findent(args.source, args.output)
        print(str(output))
        return 0

    if args.command == "validate-refactor-report":
        errors = validate_refactor_report(args.report)
        if errors:
            for error in errors:
                print(error)
            return 2
        print("Refactoring report is valid.")
        return 0

    if args.command == "import-refactor-bundle":
        try:
            target = import_refactor_bundle(
                args.bundle,
                args.output,
                producer=args.producer,
                producer_version=args.producer_version,
                project_root=args.project_root,
            )
        except RefactorBridgeError as exc:
            print(f"BLOCKED: {exc}")
            return 2
        print(json.dumps({"output": str(target)}, indent=2))
        return 0

    if args.command == "verify-refactor-connection":
        try:
            target = verify_refactor_connection(
                args.source,
                args.report,
                args.output,
                procedure=args.procedure,
            )
        except (RefactorBridgeError, UnsupportedFortranError, ValueError) as exc:
            print(f"BLOCKED: {exc}")
            return 2
        payload = json.loads(Path(target).read_text(encoding="utf-8"))
        print(json.dumps({"output": str(target), "status": payload["status"], "coverage": payload["coverage"]}, indent=2))
        return 0 if payload["status"] == "PASS" else (1 if payload["status"] == "REVIEW_REQUIRED" else 2)

    if args.command == "verify-e2e":
        command = [
            sys.executable,
            str(Path(__file__).with_name("e2e_cli_worker.py")),
            str(args.legacy_source),
            str(args.normalized_source),
            "--program",
            args.program,
            "--adapter-config",
            str(args.adapter_config),
            "--handoff",
            str(args.handoff),
            "--handoff-procedure",
            args.handoff_procedure,
            "--build-directory",
            str(args.build_directory),
            "--output",
            str(args.output),
            "--rtol",
            str(args.rtol),
            "--atol",
            str(args.atol),
        ]
        if args.without_fortran_backend:
            command.append("--without-fortran-backend")
        os.execv(sys.executable, command)
        raise AssertionError("os.execv returned unexpectedly")

    if args.command == "build-ir":
        try:
            project = build_project_ir(
                args.source, procedure=args.procedure, refactor_report=args.refactor_report
            )
        except (UnsupportedFortranError, ValueError) as exc:
            print(f"BLOCKED: {exc}")
            return 2
        output = write_project_ir(project, args.output)
        errors = validate_migration_ir(output)
        if errors:
            for error in errors:
                print(error)
            return 2
        print(json.dumps({"output": str(output), "procedures": [item.name for item in project.procedures]}, indent=2))
        return 0

    if args.command == "validate-ir":
        errors = validate_migration_ir(args.ir)
        if errors:
            for error in errors:
                print(error)
            return 2
        print("Migration IR is valid.")
        return 0

    if args.command == "translate":
        try:
            project = build_project_ir(
                args.source, procedure=args.procedure, refactor_report=args.refactor_report
            )
        except (UnsupportedFortranError, ValueError) as exc:
            print(f"BLOCKED: {exc}")
            return 2
        if args.ir_output:
            write_project_ir(project, args.ir_output)
        generated = generate_python(project, procedure=args.procedure)
        output = write_python(generated, args.output)
        print(json.dumps({"output": str(output), "procedure": generated.procedure}, indent=2))
        return 0

    if args.command == "analyze-orchestration":
        try:
            plan, _, _ = analyze_orchestration(
                args.source,
                program=args.program,
                adapter_config=args.adapter_config,
                refactor_report=args.refactor_report,
            )
            output = write_orchestration_plan(plan, args.output)
        except (OrchestrationError, UnsupportedFortranError, ValueError) as exc:
            print(f"BLOCKED: {exc}")
            return 2
        print(
            json.dumps(
                {
                    "output": str(output),
                    "program": plan.program,
                    "synthetic_root": plan.synthetic_root,
                    "numeric_calls": [item.procedure for item in plan.numeric_calls],
                    "adapter_calls": [item.procedure for item in plan.adapter_calls],
                },
                indent=2,
            )
        )
        return 0

    if args.command == "build-orchestration":
        try:
            manifest, manifest_path = build_orchestration(
                args.source,
                program=args.program,
                adapter_config=args.adapter_config,
                build_directory=args.build_directory,
                refactor_report=args.refactor_report,
                default_backend=args.default_backend,
                include_fortran=args.include_fortran,
            )
        except (OrchestrationError, UnsupportedFortranError, ValueError) as exc:
            print(f"BLOCKED: {exc}")
            return 2
        print(
            json.dumps(
                {
                    "manifest": str(manifest_path),
                    "program": manifest.program,
                    "application": manifest.artifacts["application"],
                    "available_backends": list(manifest.available_backends),
                },
                indent=2,
            )
        )
        return 0

    if args.command == "analyze-state":
        try:
            project = build_project_ir(
                args.source, procedure=args.procedure, refactor_report=args.refactor_report
            )
        except (UnsupportedFortranError, ValueError) as exc:
            print(f"BLOCKED: {exc}")
            return 2
        report = analyze_state_migration(project)
        output = write_state_migration_report(report, args.output)
        print(
            json.dumps(
                {
                    "output": str(output),
                    "groups": [item.name for item in report.groups],
                },
                indent=2,
            )
        )
        return 0

    if args.command == "analyze-kernels":
        try:
            project = build_project_ir(
                args.source, procedure=args.procedure, refactor_report=args.refactor_report
            )
        except (UnsupportedFortranError, ValueError) as exc:
            print(f"BLOCKED: {exc}")
            return 2
        report = analyze_kernel_candidates(project)
        output = write_candidate_report(report, args.output)
        print(json.dumps({"output": str(output), "candidates": [item.to_dict() for item in report.candidates]}, indent=2))
        return 0 if all(item.status != "BLOCKED" for item in report.candidates) else 2

    if args.command == "analyze-state-kernel":
        try:
            project = build_project_ir(
                args.source, procedure=args.procedure, refactor_report=args.refactor_report
            )
            extraction = analyze_state_kernel(project, args.procedure)
        except (UnsupportedFortranError, StateKernelExtractionError, ValueError) as exc:
            print(f"BLOCKED: {exc}")
            return 2
        output = write_state_kernel_report(extraction, args.output)
        if args.ir_output:
            write_project_ir(extraction.kernel_project, args.ir_output)
        print(
            json.dumps(
                {
                    "output": str(output),
                    "source_procedure": extraction.source_procedure,
                    "kernel_procedure": extraction.kernel_procedure,
                    "bindings": [item.to_dict() for item in extraction.bindings],
                },
                indent=2,
            )
        )
        return 0

    if args.command == "build-state-kernel":
        try:
            bundle, manifest = build_state_kernel_bundle(
                args.source,
                procedure=args.procedure,
                build_directory=args.build_directory,
                refactor_report=args.refactor_report,
                include_fortran=args.include_fortran,
            )
        except (
            UnsupportedFortranError,
            StateKernelExtractionError,
            ValueError,
            RuntimeError,
            subprocess.CalledProcessError,
        ) as exc:
            print(f"STATE KERNEL BUILD FAILED: {exc}")
            return 2
        print(
            json.dumps(
                {
                    "manifest": str(manifest),
                    "source_procedure": bundle.source_procedure,
                    "kernel_procedure": bundle.kernel_procedure,
                    "backends": ["python", "cython-safe", "cython-optimized", *(("fortran",) if args.include_fortran else ())],
                },
                indent=2,
            )
        )
        return 0

    if args.command == "analyze-hybrid-project":
        try:
            project = build_project_ir(
                args.source,
                procedure=args.procedure,
                refactor_report=args.refactor_report,
            )
            plan = analyze_hybrid_project(
                project,
                args.procedure,
                profile_report=args.profile_report,
                min_profile_share=args.min_profile_share,
                min_profile_mean_share=args.min_profile_mean_share,
                min_profile_max_share=args.min_profile_max_share,
                min_profile_cases=args.min_profile_cases,
                min_profile_time_ms=args.min_profile_time_ms,
                max_native_kernels=args.max_native_kernels,
                economics_report=args.economics_report,
                min_economics_speedup=args.min_economics_speedup,
                min_economics_saved_time_ms=args.min_economics_saved_time_ms,
                max_economics_build_seconds=args.max_economics_build_seconds,
                max_economics_artifact_mb=args.max_economics_artifact_mb,
                max_economics_break_even_runs=args.max_economics_break_even_runs,
                max_economics_break_even_calls=args.max_economics_break_even_calls,
            )
            output = write_hybrid_project_plan(plan, args.output)
        except (UnsupportedFortranError, ValueError, OSError) as exc:
            print(f"HYBRID PROJECT ANALYSIS FAILED: {exc}")
            return 2
        print(
            json.dumps(
                {
                    "output": str(output),
                    "root_procedure": plan.root_procedure,
                    "eligible_procedures": list(plan.eligible_procedures),
                    "extracted_procedures": list(plan.extracted_procedures),
                    "full_extracted_procedures": list(plan.full_extracted_procedures),
                    "partial_extracted_procedures": list(plan.partial_extracted_procedures),
                },
                indent=2,
            )
        )
        return 0

    if args.command == "profile-hybrid-project":
        try:
            report, generated = profile_hybrid_project(
                args.source,
                root_procedure=args.procedure,
                workload=args.workload,
                build_directory=args.build_directory,
                warmup_runs=args.warmup_runs,
                measured_runs=args.measured_runs,
                refactor_report=args.refactor_report,
            )
            output = write_hybrid_profile(report, args.output)
        except (UnsupportedFortranError, ValueError, OSError, RuntimeError) as exc:
            print(f"HYBRID PROJECT PROFILE FAILED: {exc}")
            return 2
        print(
            json.dumps(
                {
                    "output": str(output),
                    "generated_reference": str(generated.parent / "profile_reference.py"),
                    "root_procedure": report.root_procedure,
                    "measured_runs": report.measured_runs,
                    "samples": [item.to_dict() for item in report.samples],
                },
                indent=2,
            )
        )
        return 0

    if args.command == "profile-hybrid-suite":
        try:
            named_cases = _parse_named_paths(args.case, label="case")
            weights = _parse_named_weights(args.case_weight, label="case weight")
            unknown = set(weights) - set(named_cases)
            if unknown:
                raise ValueError(f"weights provided for unknown cases: {sorted(unknown)}")
            cases = [
                (name, path, weights.get(name, 1.0))
                for name, path in named_cases.items()
            ]
            report, _ = profile_hybrid_suite(
                args.source,
                root_procedure=args.procedure,
                cases=cases,
                build_directory=args.build_directory,
                warmup_runs=args.warmup_runs,
                measured_runs=args.measured_runs,
                refactor_report=args.refactor_report,
            )
            output = write_hybrid_profile(report, args.output)
        except (UnsupportedFortranError, ValueError, OSError, RuntimeError) as exc:
            print(f"HYBRID PROFILE SUITE FAILED: {exc}")
            return 2
        print(json.dumps({
            "output": str(output),
            "root_procedure": report.root_procedure,
            "cases": [item.name for item in report.cases],
            "samples": [item.to_dict() for item in report.samples],
        }, indent=2))
        return 0

    if args.command == "aggregate-hybrid-profiles":
        try:
            named_profiles = _parse_named_paths(args.profile, label="profile")
            weights = _parse_named_weights(args.profile_weight, label="profile weight")
            unknown = set(weights) - set(named_profiles)
            if unknown:
                raise ValueError(f"weights provided for unknown profiles: {sorted(unknown)}")
            cases = []
            for name, path in named_profiles.items():
                report = load_hybrid_profile(path)
                if not hasattr(report, "workload_file"):
                    raise ValueError("aggregate-hybrid-profiles accepts single-case reports only")
                cases.append((name, report, weights.get(name, 1.0)))
            suite = aggregate_hybrid_profiles(cases)
            output = write_hybrid_profile(suite, args.output)
        except (ValueError, OSError) as exc:
            print(f"HYBRID PROFILE AGGREGATION FAILED: {exc}")
            return 2
        print(json.dumps({
            "output": str(output),
            "root_procedure": suite.root_procedure,
            "cases": [item.name for item in suite.cases],
            "samples": [item.to_dict() for item in suite.samples],
        }, indent=2))
        return 0

    if args.command == "benchmark-hybrid-economics":
        try:
            report, _ = benchmark_hybrid_economics(
                args.source,
                root_procedure=args.procedure,
                profile_report=args.profile_report,
                build_directory=args.build_directory,
                warmup_runs=args.warmup_runs,
                measured_runs=args.measured_runs,
                refactor_report=args.refactor_report,
            )
            output = write_hybrid_economics(report, args.output)
        except (
            UnsupportedFortranError,
            StateKernelExtractionError,
            ValueError,
            OSError,
            RuntimeError,
            subprocess.CalledProcessError,
        ) as exc:
            print(f"HYBRID ECONOMICS BENCHMARK FAILED: {exc}")
            return 2
        print(json.dumps({
            "output": str(output),
            "root_procedure": report.root_procedure,
            "samples": [item.to_dict() for item in report.samples],
        }, indent=2))
        return 0

    if args.command == "build-hybrid-project":
        try:
            manifest, output = build_hybrid_project(
                args.source,
                root_procedure=args.procedure,
                build_directory=args.build_directory,
                refactor_report=args.refactor_report,
                default_backend=args.default_backend,
                include_fortran=args.include_fortran,
                profile_report=args.profile_report,
                min_profile_share=args.min_profile_share,
                min_profile_mean_share=args.min_profile_mean_share,
                min_profile_max_share=args.min_profile_max_share,
                min_profile_cases=args.min_profile_cases,
                min_profile_time_ms=args.min_profile_time_ms,
                max_native_kernels=args.max_native_kernels,
                economics_report=args.economics_report,
                min_economics_speedup=args.min_economics_speedup,
                min_economics_saved_time_ms=args.min_economics_saved_time_ms,
                max_economics_build_seconds=args.max_economics_build_seconds,
                max_economics_artifact_mb=args.max_economics_artifact_mb,
                max_economics_break_even_runs=args.max_economics_break_even_runs,
                max_economics_break_even_calls=args.max_economics_break_even_calls,
            )
        except (
            UnsupportedFortranError,
            StateKernelExtractionError,
            ValueError,
            OSError,
            RuntimeError,
            subprocess.CalledProcessError,
        ) as exc:
            print(f"HYBRID PROJECT BUILD FAILED: {exc}")
            return 2
        print(
            json.dumps(
                {
                    "manifest": str(output),
                    "root_procedure": manifest.root_procedure,
                    "eligible_procedures": list(manifest.eligible_procedures),
                    "extracted_procedures": list(manifest.extracted_procedures),
                    "full_extracted_procedures": list(manifest.full_extracted_procedures),
                    "partial_extracted_procedures": list(manifest.partial_extracted_procedures),
                    "default_backend": manifest.default_backend,
                },
                indent=2,
            )
        )
        return 0

    if args.command == "analyze-partial-loop":
        try:
            project = build_project_ir(
                args.source,
                procedure=args.procedure,
                refactor_report=args.refactor_report,
            )
            extraction = analyze_partial_loop(
                project, args.procedure, loop_index=args.loop_index
            )
            output = write_partial_loop_report(extraction, args.output)
            if args.ir_output:
                write_project_ir(extraction.kernel_project, args.ir_output)
        except (UnsupportedFortranError, PartialLoopExtractionError, ValueError) as exc:
            print(f"BLOCKED: {exc}")
            return 2
        print(
            json.dumps(
                {
                    "output": str(output),
                    "source_procedure": extraction.source_procedure,
                    "loop_index": extraction.loop_index,
                    "kernel_procedure": extraction.kernel_procedure,
                    "bindings": [item.to_dict() for item in extraction.bindings],
                },
                indent=2,
            )
        )
        return 0

    if args.command == "build-partial-loop":
        try:
            bundle, manifest = build_partial_loop_bundle(
                args.source,
                procedure=args.procedure,
                loop_index=args.loop_index,
                build_directory=args.build_directory,
                refactor_report=args.refactor_report,
                default_backend=args.default_backend,
                include_fortran=args.include_fortran,
            )
        except (
            UnsupportedFortranError,
            PartialLoopExtractionError,
            ValueError,
            RuntimeError,
            subprocess.CalledProcessError,
        ) as exc:
            print(f"PARTIAL LOOP BUILD FAILED: {exc}")
            return 2
        print(
            json.dumps(
                {
                    "manifest": str(manifest),
                    "source_procedure": bundle.source_procedure,
                    "loop_index": bundle.loop_index,
                    "kernel_procedure": bundle.kernel_procedure,
                    "default_backend": bundle.default_backend,
                },
                indent=2,
            )
        )
        return 0

    if args.command == "translate-cython":
        try:
            project = build_project_ir(
                args.source, procedure=args.procedure, refactor_report=args.refactor_report
            )
            report = analyze_kernel_candidates(project)
            root = next(item for item in report.candidates if item.procedure == args.procedure.lower())
            if root.status == "BLOCKED":
                raise ValueError("selected procedure is blocked as a Cython kernel candidate")
            generated = generate_cython(
                project, procedure=args.procedure, safety_mode=args.mode
            )
        except (UnsupportedFortranError, ValueError, StopIteration) as exc:
            print(f"BLOCKED: {exc}")
            return 2
        if args.ir_output:
            write_project_ir(project, args.ir_output)
        if args.candidate_output:
            write_candidate_report(report, args.candidate_output)
        output = write_cython(generated, args.output)
        print(json.dumps({"output": str(output), "procedure": generated.procedure, "safety_mode": generated.safety_mode}, indent=2))
        return 0

    if args.command == "compile-cython":
        try:
            built = build_cython_extension(
                args.source,
                args.module_name,
                args.build_directory,
                safety_mode=args.mode,
            )
        except (ValueError, RuntimeError, subprocess.CalledProcessError) as exc:
            print(f"BUILD FAILED: {exc}")
            return 2
        print(json.dumps({"module_name": built.module_name, "source": str(built.source), "extension": str(built.extension)}, indent=2))
        return 0


    if args.command == "benchmark-kernel":
        try:
            sizes = (
                tuple(_parse_benchmark_size(item) for item in args.sizes)
                if args.sizes
                else ((32, 17), (64, 33), (128, 65))
            )
            report = benchmark_generated_kernel(
                args.source,
                procedure=args.procedure,
                build_directory=args.build_directory,
                sizes=sizes,
                target_seconds=args.target_seconds,
            )
            output = write_benchmark_report(report, args.output)
        except (ValueError, RuntimeError, subprocess.CalledProcessError) as exc:
            print(f"BENCHMARK FAILED: {exc}")
            return 2
        print(json.dumps({"output": str(output), "cases": len(report.cases)}, indent=2))
        return 0

    if args.command == "build-solver":
        try:
            manifest, output = build_solver_backends(
                args.source,
                procedure=args.procedure,
                build_directory=args.build_directory,
                fortran_driver=args.fortran_driver,
            )
        except (ValueError, RuntimeError, subprocess.CalledProcessError) as exc:
            print(f"SOLVER BUILD FAILED: {exc}")
            return 2
        print(
            json.dumps(
                {
                    "manifest": str(output),
                    "procedure": manifest.procedure,
                    "backends": sorted(manifest.artifacts),
                },
                indent=2,
            )
        )
        return 0

    if args.command == "run-solver":
        try:
            config = load_solver_run_configuration(args.config)
            result = run_configured_solver(config)
        except (ValueError, RuntimeError, OSError, subprocess.CalledProcessError) as exc:
            print(f"SOLVER RUN FAILED: {exc}")
            return 2
        print(
            json.dumps(
                {
                    "backend": config.backend,
                    "output": str(config.output_directory),
                    "summary": result.summary(),
                },
                indent=2,
            )
        )
        return 0 if result.converged else 1

    if args.command == "benchmark-solver":
        try:
            sizes = (
                tuple(_parse_benchmark_size(item) for item in args.solver_sizes)
                if args.solver_sizes
                else ((32, 9), (64, 17))
            )
            report = benchmark_full_solver(
                args.manifest,
                sizes=sizes,
                target_seconds=args.target_seconds,
            )
            output = write_solver_benchmark_report(report, args.output)
        except (ValueError, RuntimeError, OSError, subprocess.CalledProcessError) as exc:
            print(f"SOLVER BENCHMARK FAILED: {exc}")
            return 2
        print(json.dumps({"output": str(output), "cases": len(report.cases)}, indent=2))
        return 0

    if args.command == "build-analysis":
        try:
            manifest, output = build_analysis_backends(
                args.source,
                procedure=args.procedure,
                build_directory=args.build_directory,
                fortran_driver=args.fortran_driver,
            )
        except (ValueError, RuntimeError, subprocess.CalledProcessError) as exc:
            print(f"ANALYSIS BUILD FAILED: {exc}")
            return 2
        print(
            json.dumps(
                {
                    "manifest": str(output),
                    "procedure": manifest.procedure,
                    "backends": sorted(manifest.artifacts),
                },
                indent=2,
            )
        )
        return 0

    if args.command == "run-analysis":
        try:
            config = load_solver_run_configuration(args.config)
            result = run_configured_analysis(config)
        except (ValueError, RuntimeError, OSError, subprocess.CalledProcessError) as exc:
            print(f"ANALYSIS RUN FAILED: {exc}")
            return 2
        print(
            json.dumps(
                {
                    "backend": config.backend,
                    "output": str(config.output_directory),
                    "summary": result.summary(),
                },
                indent=2,
            )
        )
        return 0 if result.converged else 1

    if args.command == "prepare-distribution":
        try:
            manifest, output = prepare_distribution(
                args.hybrid_manifest,
                args.app_adapter,
                args.output_directory,
                app_name=args.app_name,
                target=args.target,
            )
        except (DistributionError, OSError, ValueError) as exc:
            print(f"DISTRIBUTION PREPARATION FAILED: {exc}")
            return 2
        print(
            json.dumps(
                {
                    "manifest": str(output),
                    "app_name": manifest.app_name,
                    "target": manifest.target,
                    "native_extensions": len(manifest.native_extensions),
                    "required_wheels": list(manifest.required_wheels),
                },
                indent=2,
            )
        )
        return 0

    if args.command == "validate-distribution":
        errors = validate_distribution(args.directory)
        if errors:
            for error in errors:
                print(error)
            return 2
        print("Distribution kit is valid.")
        return 0

    if args.command == "sample":
        if args.sample_command == "build":
            binaries = build_fortran()
            build_cython()
            print(json.dumps({key: str(value) for key, value in binaries.items()}, indent=2))
            return 0
        if args.sample_command == "run":
            backends = (
                ["fortran-reference", "fortran-legacy", "python", "cython"]
                if args.backend == "all"
                else [args.backend]
            )
            for backend in backends:
                result = run_backend(backend, case_file=args.case)
                print(backend, json.dumps(result.summary(), indent=2))
            return 0
        if args.sample_command == "compare":
            comparisons = compare_all()
            if args.json:
                print(json.dumps([item.as_dict() for item in comparisons], indent=2))
            else:
                for item in comparisons:
                    print(
                        f"{item.reference} vs {item.candidate}: "
                        f"{'PASS' if item.passed else 'FAIL'}, "
                        f"max_abs={item.max_abs_pressure:.3e}, "
                        f"max_rel={item.max_rel_pressure:.3e}"
                    )
                    for failure in item.scalar_failures:
                        print(f"  {failure}")
            return 0 if all(item.passed for item in comparisons) else 1

    raise AssertionError("unreachable")


def _parse_named_paths(values: list[str], *, label: str) -> dict[str, str]:
    result: dict[str, str] = {}
    for value in values:
        if "=" not in value:
            raise ValueError(f"invalid {label}: {value!r}; expected NAME=PATH")
        name, path = value.split("=", maxsplit=1)
        name = name.strip()
        path = path.strip()
        if not name or not path:
            raise ValueError(f"invalid {label}: {value!r}; expected NAME=PATH")
        if name in result:
            raise ValueError(f"duplicate {label} name: {name}")
        result[name] = path
    return result


def _parse_named_weights(values: list[str], *, label: str) -> dict[str, float]:
    result: dict[str, float] = {}
    for value in values:
        if "=" not in value:
            raise ValueError(f"invalid {label}: {value!r}; expected NAME=WEIGHT")
        name, weight_text = value.split("=", maxsplit=1)
        name = name.strip()
        try:
            weight = float(weight_text)
        except ValueError as exc:
            raise ValueError(f"invalid {label}: {value!r}") from exc
        if not name or weight <= 0.0:
            raise ValueError(f"invalid {label}: {value!r}; weight must be positive")
        if name in result:
            raise ValueError(f"duplicate {label} name: {name}")
        result[name] = weight
    return result


def _parse_benchmark_size(value: str) -> tuple[int, int]:
    normalised = value.lower().replace("×", "x")
    try:
        ntheta_text, nz_text = normalised.split("x", maxsplit=1)
        ntheta = int(ntheta_text)
        nz = int(nz_text)
    except (ValueError, TypeError) as exc:
        raise ValueError(f"invalid benchmark size: {value!r}; expected NTHETAxNZ") from exc
    if ntheta < 3 or nz < 3:
        raise ValueError("benchmark dimensions must both be at least 3")
    return ntheta, nz
