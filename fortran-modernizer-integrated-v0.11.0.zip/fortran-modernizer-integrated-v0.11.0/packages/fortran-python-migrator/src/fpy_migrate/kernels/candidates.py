from __future__ import annotations

from dataclasses import asdict, dataclass
from pathlib import Path
import json

from fpy_migrate.ir.model import (
    CallIR,
    DoLoopIR,
    IfIR,
    ProcedureIR,
    ProjectIR,
    StatementIR,
)


@dataclass(frozen=True)
class KernelCandidate:
    procedure: str
    status: str
    score: int
    loop_count: int
    maximum_loop_depth: int
    maximum_array_rank: int
    call_count: int
    numeric_only: bool
    reasons: tuple[str, ...]

    def to_dict(self) -> dict[str, object]:
        return asdict(self)


@dataclass(frozen=True)
class KernelCandidateReport:
    schema_version: str
    candidates: tuple[KernelCandidate, ...]

    def to_dict(self) -> dict[str, object]:
        return {
            "schema_version": self.schema_version,
            "candidates": [item.to_dict() for item in self.candidates],
        }


def analyze_kernel_candidates(project: ProjectIR) -> KernelCandidateReport:
    known = {procedure.name for procedure in project.procedures}
    candidates = tuple(_analyze_procedure(procedure, known) for procedure in project.procedures)
    return KernelCandidateReport(schema_version="1.0", candidates=candidates)


def write_candidate_report(
    report: KernelCandidateReport,
    output: str | Path,
) -> Path:
    path = Path(output)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(report.to_dict(), indent=2) + "\n", encoding="utf-8")
    return path


def _analyze_procedure(procedure: ProcedureIR, known: set[str]) -> KernelCandidate:
    loop_count, maximum_loop_depth, call_count = _statement_metrics(procedure.statements)
    maximum_array_rank = max((symbol.rank for symbol in procedure.symbols), default=0)
    numeric_only = all(symbol.type.category in {"integer", "real", "logical"} for symbol in procedure.symbols)

    reasons: list[str] = []
    score = 0
    status = "AUTO"

    if procedure.status == "BLOCKED":
        status = "BLOCKED"
        reasons.append("procedure is already blocked in Migration IR")

    if procedure.state_groups and status != "BLOCKED":
        status = "REVIEW_REQUIRED"
        reasons.append(
            "procedure uses explicit state objects; extract a stateless numeric kernel "
            "before Cython compilation"
        )

    if not numeric_only:
        status = "BLOCKED"
        reasons.append("character or derived-type data is not supported by the Cython kernel generator")

    unresolved = sorted(
        {
            statement.procedure
            for statement in _walk_statements(procedure.statements)
            if isinstance(statement, CallIR) and statement.procedure not in known
        }
    )
    if unresolved:
        status = "BLOCKED"
        reasons.append(f"unresolved calls: {', '.join(unresolved)}")

    if loop_count == 0 and status != "BLOCKED":
        status = "REVIEW_REQUIRED"
        reasons.append("no loop was found; native compilation may have little benefit")
    else:
        score += min(loop_count * 15, 45)
        reasons.append(f"contains {loop_count} loop(s)")

    if maximum_loop_depth >= 2:
        score += 30
        reasons.append(f"nested loop depth is {maximum_loop_depth}")
    elif maximum_loop_depth == 1:
        score += 10

    if maximum_array_rank:
        score += min(maximum_array_rank * 10, 20)
        reasons.append(f"maximum array rank is {maximum_array_rank}")

    if call_count:
        score += min(call_count * 5, 10)
        reasons.append(f"contains {call_count} resolved procedure call(s)")

    if numeric_only:
        score += 15
        reasons.append("all symbols use numeric or logical intrinsic types")

    if procedure.status == "REVIEW_REQUIRED" and status == "AUTO":
        status = "REVIEW_REQUIRED"
        reasons.append("Migration IR requests human review")

    return KernelCandidate(
        procedure=procedure.name,
        status=status,
        score=min(score, 100),
        loop_count=loop_count,
        maximum_loop_depth=maximum_loop_depth,
        maximum_array_rank=maximum_array_rank,
        call_count=call_count,
        numeric_only=numeric_only,
        reasons=tuple(reasons),
    )


def _statement_metrics(statements: tuple[StatementIR, ...]) -> tuple[int, int, int]:
    loop_count = 0
    maximum_depth = 0
    call_count = 0

    def visit(items: tuple[StatementIR, ...], depth: int) -> None:
        nonlocal loop_count, maximum_depth, call_count
        for statement in items:
            if isinstance(statement, DoLoopIR):
                loop_count += 1
                maximum_depth = max(maximum_depth, depth + 1)
                visit(statement.body, depth + 1)
            elif isinstance(statement, IfIR):
                visit(statement.body, depth)
                visit(statement.else_body, depth)
            elif isinstance(statement, CallIR):
                call_count += 1

    visit(statements, 0)
    return loop_count, maximum_depth, call_count


def _walk_statements(statements: tuple[StatementIR, ...]):
    for statement in statements:
        yield statement
        if isinstance(statement, DoLoopIR):
            yield from _walk_statements(statement.body)
        elif isinstance(statement, IfIR):
            yield from _walk_statements(statement.body)
            yield from _walk_statements(statement.else_body)
