from __future__ import annotations

from dataclasses import dataclass
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import sysconfig
import time
from typing import Literal


CythonBuildMode = Literal["safe", "optimized"]


class CythonBuildError(RuntimeError):
    """Raised when a generated Cython extension cannot be compiled.

    Build command, stdout, stderr, and a machine-readable report are retained in
    the build directory so callers can diagnose an offline compiler failure.
    """

    def __init__(self, message: str, *, report: Path):
        super().__init__(message)
        self.report = report


@dataclass(frozen=True)
class BuiltExtension:
    module_name: str
    source: Path
    extension: Path
    build_directory: Path
    safety_mode: CythonBuildMode = "safe"
    report: Path | None = None


def build_cython_extension(
    source: str | Path,
    module_name: str,
    build_directory: str | Path,
    *,
    safety_mode: CythonBuildMode = "safe",
) -> BuiltExtension:
    """Compile a generated Cython Pure-Python source into an extension module.

    The build is intentionally local and deterministic: the source is copied
    into ``build_directory`` and setuptools/Cython output is captured there.
    """

    if safety_mode not in {"safe", "optimized"}:
        raise ValueError(f"unsupported Cython build mode: {safety_mode}")
    source_path = Path(source).resolve()
    if source_path.suffix != ".py":
        raise ValueError("Cython Pure Python Mode source must use the .py suffix")
    if "." in module_name:
        raise ValueError("generated extension module_name must be a simple name")

    build_root = Path(build_directory).resolve()
    build_root.mkdir(parents=True, exist_ok=True)
    copied_source = build_root / f"{module_name}.py"
    if source_path != copied_source:
        shutil.copy2(source_path, copied_source)

    checks = safety_mode == "safe"
    if safety_mode == "optimized":
        compile_args = "['/O2'] if os.name == 'nt' else ['-O3']"
    else:
        compile_args = "[]"

    setup_path = build_root / "setup_generated_kernel.py"
    setup_path.write_text(
        "\n".join(
            [
                "import os",
                "from Cython.Build import cythonize",
                "from setuptools import Extension, setup",
                "",
                f"extra_compile_args = {compile_args}",
                f"extensions = [Extension({module_name!r}, [{str(copied_source)!r}], extra_compile_args=extra_compile_args)]",
                "setup(",
                "    name='generated-cython-kernel',",
                "    ext_modules=cythonize(",
                "        extensions,",
                "        compiler_directives={",
                "            'language_level': 3,",
                f"            'boundscheck': {checks!r},",
                f"            'wraparound': {checks!r},",
                f"            'initializedcheck': {checks!r},",
                "            'cdivision': True,",
                "        },",
                "        force=True,",
                "    ),",
                ")",
                "",
            ]
        ),
        encoding="utf-8",
    )

    build_lib = build_root / "lib"
    build_temp = build_root / "temp"
    command = [
        sys.executable,
        str(setup_path),
        "build_ext",
        "--build-lib",
        str(build_lib),
        "--build-temp",
        str(build_temp),
    ]
    started = time.perf_counter()
    completed = subprocess.run(
        command,
        cwd=build_root,
        check=False,
        capture_output=True,
        text=True,
        env={**os.environ},
    )
    elapsed = time.perf_counter() - started
    stdout_path = build_root / "build_stdout.txt"
    stderr_path = build_root / "build_stderr.txt"
    stdout_path.write_text(completed.stdout, encoding="utf-8")
    stderr_path.write_text(completed.stderr, encoding="utf-8")

    report_path = build_root / "cython_build_report.json"
    report: dict[str, object] = {
        "schema_version": "1.0",
        "status": "BLOCKED" if completed.returncode else "PASS",
        "module_name": module_name,
        "safety_mode": safety_mode,
        "source": str(copied_source),
        "source_sha256": hashlib.sha256(copied_source.read_bytes()).hexdigest(),
        "command": command,
        "cwd": str(build_root),
        "returncode": completed.returncode,
        "elapsed_seconds": elapsed,
        "stdout": stdout_path.name,
        "stderr": stderr_path.name,
        "python": sys.version,
        "platform": sys.platform,
    }
    report_path.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    if completed.returncode != 0:
        raise CythonBuildError(
            f"Cython build failed for {module_name}; see {report_path}",
            report=report_path,
        )

    extension_suffix = sysconfig.get_config_var("EXT_SUFFIX")
    if not extension_suffix:
        report["status"] = "BLOCKED"
        report["error"] = "Python extension suffix is unavailable"
        report_path.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
        raise CythonBuildError(
            "Python extension suffix is unavailable",
            report=report_path,
        )
    extension_path = build_lib / f"{module_name}{extension_suffix}"
    if not extension_path.exists():
        matches = [str(item) for item in build_lib.glob(f"{module_name}.*")]
        report["status"] = "BLOCKED"
        report["error"] = "compiled extension was not produced"
        report["matches"] = matches
        report_path.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
        raise CythonBuildError(
            f"compiled extension was not produced: {matches}",
            report=report_path,
        )

    report.update(
        {
            "extension": str(extension_path),
            "extension_sha256": hashlib.sha256(extension_path.read_bytes()).hexdigest(),
            "extension_size_bytes": extension_path.stat().st_size,
        }
    )
    report_path.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    return BuiltExtension(
        module_name=module_name,
        source=copied_source,
        extension=extension_path,
        build_directory=build_root,
        safety_mode=safety_mode,
        report=report_path,
    )
