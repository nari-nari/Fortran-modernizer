"""Standard representative case with balanced initialization, update, and summary."""

import numpy as np


def run(reference_module):
    state = reference_module.CommonFieldState(
        pressure=np.zeros((16,), dtype=np.float64),
        film=np.zeros((16,), dtype=np.float64),
        relaxation_factor=0.0,
    )
    return reference_module.run_partial_hybrid(state, 12, 0.4)
