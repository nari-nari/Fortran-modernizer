"""Reporting-heavy case with repeated post-processing of one solved state."""

import numpy as np


def run(reference_module):
    state = reference_module.CommonFieldState(
        pressure=np.zeros((16,), dtype=np.float64),
        film=np.zeros((16,), dtype=np.float64),
        relaxation_factor=0.0,
    )
    result = reference_module.run_partial_hybrid(state, 12, 0.4)
    for _ in range(80):
        result = reference_module.summarize_partial_state(state, 12)
    return result
