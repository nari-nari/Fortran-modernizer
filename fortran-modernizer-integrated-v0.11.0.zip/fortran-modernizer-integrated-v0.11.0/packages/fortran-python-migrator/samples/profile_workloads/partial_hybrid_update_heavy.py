"""High-iteration case dominated by the internal pressure-update loop."""

import numpy as np


def run(reference_module):
    state = reference_module.CommonFieldState(
        pressure=np.zeros((16,), dtype=np.float64),
        film=np.zeros((16,), dtype=np.float64),
        relaxation_factor=0.0,
    )
    result = reference_module.run_partial_hybrid(state, 12, 0.4)
    bias = 0.5 * state.relaxation_factor
    for _ in range(80):
        state.pressure = reference_module.run_partial_hybrid_loop_1_kernel(
            12, bias, state.pressure, state.film
        )
    return result
