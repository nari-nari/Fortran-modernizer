subroutine init_geometry
  implicit none
  integer, parameter :: ntheta = 36, nz = 17
  real(8) :: press(ntheta,nz), film(ntheta), angle(ntheta)
  real(8) :: pi, ecc
  integer :: i
  common /field/ press, film, angle

  pi = acos(-1.0d0)
  ecc = 0.60d0
  do i = 1, ntheta
    angle(i) = 2.0d0*pi*real(i-1,8)/real(ntheta,8)
    film(i) = 1.0d0 + ecc*cos(angle(i))
  end do
end subroutine init_geometry
