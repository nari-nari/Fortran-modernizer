program legacy_parameter_driver
  implicit none
  integer, parameter :: ntheta = 36, nz = 17
  real(8) :: p(ntheta,nz), h(ntheta), theta(ntheta)
  real(8) :: residual, load, pmax, hmin, friction
  integer :: iterations
  common /field/ p, h, theta

  call init_geometry
  call solve_reynolds(iterations, residual)
  call compute_metrics(load, pmax, hmin, friction)
  write(*,'(I0,1X,ES24.16,1X,ES24.16,1X,ES24.16,1X,ES24.16,1X,ES24.16)') &
    iterations, residual, load, pmax, hmin, friction
end program legacy_parameter_driver
