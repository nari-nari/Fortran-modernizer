subroutine compute_metrics(load, pmax, hmin, friction)
  implicit none
  integer, parameter :: ntheta = 36, nz = 17
  real(8) :: press(ntheta,nz), film(ntheta), angle(ntheta)
  real(8), intent(out) :: load, pmax, hmin, friction
  real(8) :: pi, dtheta, dz, loadx, loady
  integer :: i, j
  common /field/ press, film, angle

  pi = acos(-1.0d0)
  dtheta = 2.0d0*pi/real(ntheta,8)
  dz = 1.0d0/real(nz-1,8)
  loadx = 0.0d0
  loady = 0.0d0
  do j = 2, nz-1
    do i = 1, ntheta
      loadx = loadx + press(i,j)*cos(angle(i))*dtheta*dz
      loady = loady + press(i,j)*sin(angle(i))*dtheta*dz
    end do
  end do
  load = sqrt(loadx**2+loady**2)
  pmax = 0.0d0
  do j = 1, nz
    do i = 1, ntheta
      pmax = max(pmax,press(i,j))
    end do
  end do
  hmin = film(1)
  friction = 0.0d0
  do i = 1, ntheta
    hmin = min(hmin,film(i))
    friction = friction + dtheta/film(i)
  end do
end subroutine compute_metrics
