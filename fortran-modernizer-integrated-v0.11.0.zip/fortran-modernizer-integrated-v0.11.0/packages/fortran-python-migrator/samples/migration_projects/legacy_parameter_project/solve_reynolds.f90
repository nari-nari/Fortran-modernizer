subroutine solve_reynolds(iterations, residual)
  implicit none
  integer, parameter :: ntheta = 36, nz = 17, maxit = 25000
  real(8), parameter :: omega = 1.55d0, toler = 1.0d-10, aspect = 0.50d0
  real(8) :: p(ntheta,nz), h(ntheta), theta(ntheta)
  real(8), intent(out) :: residual
  integer, intent(out) :: iterations
  real(8) :: pi, dtheta, dz, hplus, hminus
  real(8) :: ae, aw, az, ap, rhs, pstar, updated, change
  integer :: i, j, ip, im
  common /field/ p, h, theta

  pi = acos(-1.0d0)
  dtheta = 2.0d0*pi/real(ntheta,8)
  dz = 1.0d0/real(nz-1,8)
  do j = 1, nz
    do i = 1, ntheta
      p(i,j) = 0.0d0
    end do
  end do
  residual = huge(1.0d0)
  do iterations = 1, maxit
    residual = 0.0d0
    do j = 2, nz-1
      do i = 1, ntheta
        ip = i + 1
        if (ip > ntheta) ip = 1
        im = i - 1
        if (im < 1) im = ntheta
        hplus = 0.5d0*(h(i)+h(ip))
        hminus = 0.5d0*(h(i)+h(im))
        ae = hplus**3/dtheta**2
        aw = hminus**3/dtheta**2
        az = aspect**2*h(i)**3/dz**2
        ap = ae + aw + 2.0d0*az
        rhs = -6.0d0*0.60d0*sin(theta(i))
        pstar = (ae*p(ip,j)+aw*p(im,j)+az*(p(i,j+1)+p(i,j-1))-rhs)/ap
        updated = max(0.0d0, p(i,j)+omega*(pstar-p(i,j)))
        change = abs(updated-p(i,j))
        residual = max(residual, change)
        p(i,j) = updated
      end do
    end do
    if (residual < toler) exit
  end do
end subroutine solve_reynolds
