subroutine run_common_state(n, eccentricity, total_pressure, minimum_film)
  implicit none
  integer, intent(in) :: n
  double precision, intent(in) :: eccentricity
  double precision, intent(out) :: total_pressure, minimum_film
  double precision :: pressure(16), film(16), relaxation_factor
  common /field/ pressure, film, relaxation_factor

  call initialize_common_state(n, eccentricity)
  call advance_common_state(n)
  call summarize_common_state(n, total_pressure, minimum_film)
end subroutine run_common_state
