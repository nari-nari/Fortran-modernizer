program common_state_project_driver
  implicit none
  integer :: n, i
  double precision :: eccentricity, total_pressure, minimum_film
  double precision :: pressure(16), film(16), relaxation_factor
  common /field/ pressure, film, relaxation_factor

  n = 12
  eccentricity = 0.4d0
  call run_common_state(n, eccentricity, total_pressure, minimum_film)
  write(*,'(ES24.16,1X,ES24.16,1X,ES24.16)') total_pressure, minimum_film, relaxation_factor
  do i = 1, n
    write(*,'(I4,1X,ES24.16,1X,ES24.16)') i, pressure(i), film(i)
  end do
end program common_state_project_driver
