subroutine summarize_common_state(n, total_pressure, minimum_film)
  implicit none
  integer, intent(in) :: n
  double precision, intent(out) :: total_pressure, minimum_film
  double precision :: pressure(16), film(16), relaxation_factor
  common /field/ pressure, film, relaxation_factor
  integer :: i

  total_pressure = 0.0d0
  minimum_film = film(1)
  do i = 1, n
    total_pressure = total_pressure + pressure(i)
    if (film(i) < minimum_film) minimum_film = film(i)
  end do
end subroutine summarize_common_state
