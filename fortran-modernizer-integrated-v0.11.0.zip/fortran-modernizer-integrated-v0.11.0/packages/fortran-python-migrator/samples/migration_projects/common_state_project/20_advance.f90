subroutine advance_common_state(n)
  implicit none
  integer, intent(in) :: n
  double precision :: p(16), h(16), omega
  common /field/ p, h, omega
  integer :: i

  do i = 2, n - 1
    p(i) = p(i) + omega * (0.5d0 * (p(i - 1) + p(i + 1)) - p(i)) / h(i)
  end do
end subroutine advance_common_state
