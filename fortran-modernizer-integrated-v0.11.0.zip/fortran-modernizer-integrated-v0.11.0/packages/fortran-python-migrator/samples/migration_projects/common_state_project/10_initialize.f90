subroutine initialize_common_state(n, eccentricity)
  implicit none
  integer, intent(in) :: n
  double precision, intent(in) :: eccentricity
  double precision :: pressure(16), film(16), relaxation_factor
  common /field/ pressure, film, relaxation_factor
  integer :: i
  double precision :: pi, theta

  pi = 4.0d0 * atan(1.0d0)
  relaxation_factor = 1.25d0
  pressure = 0.0d0
  do i = 1, n
    theta = 2.0d0 * pi * dble(i - 1) / dble(n)
    film(i) = 1.0d0 + eccentricity * cos(theta)
    pressure(i) = dble(i) * film(i)
  end do
end subroutine initialize_common_state
