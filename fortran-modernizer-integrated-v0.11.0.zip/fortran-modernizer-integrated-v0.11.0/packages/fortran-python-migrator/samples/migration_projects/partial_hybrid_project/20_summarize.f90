subroutine summarize_partial_state(n, total_pressure, peak_pressure)
  implicit none
  integer, intent(in) :: n
  double precision, intent(out) :: total_pressure, peak_pressure
  double precision :: pressure(16), film(16), relaxation_factor
  common /field/ pressure, film, relaxation_factor
  integer :: i

  total_pressure = 0.0d0
  peak_pressure = pressure(1)
  do i = 1, n
    total_pressure = total_pressure + pressure(i)
    if (pressure(i) > peak_pressure) peak_pressure = pressure(i)
  end do
end subroutine summarize_partial_state
