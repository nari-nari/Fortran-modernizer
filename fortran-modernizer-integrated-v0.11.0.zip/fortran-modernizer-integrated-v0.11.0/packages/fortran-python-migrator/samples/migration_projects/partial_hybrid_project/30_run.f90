subroutine run_partial_hybrid(n, eccentricity, total_pressure, peak_pressure)
  implicit none
  integer, intent(in) :: n
  double precision, intent(in) :: eccentricity
  double precision, intent(out) :: total_pressure, peak_pressure
  double precision :: pressure(16), film(16), relaxation_factor
  common /field/ pressure, film, relaxation_factor
  integer :: i
  double precision :: bias

  call initialize_partial_state(n, eccentricity)
  bias = 0.5d0 * relaxation_factor
  do i = 1, n
    pressure(i) = pressure(i) + bias * film(i)
  end do
  call summarize_partial_state(n, total_pressure, peak_pressure)
end subroutine run_partial_hybrid
