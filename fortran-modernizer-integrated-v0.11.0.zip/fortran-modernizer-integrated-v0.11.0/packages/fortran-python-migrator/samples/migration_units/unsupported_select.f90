subroutine unsupported_select(mode, value)
  implicit none
  integer, intent(in) :: mode
  real, intent(out) :: value
  select case (mode)
  case (1)
    value = 1.0
  case default
    value = 0.0
  end select
end subroutine unsupported_select
