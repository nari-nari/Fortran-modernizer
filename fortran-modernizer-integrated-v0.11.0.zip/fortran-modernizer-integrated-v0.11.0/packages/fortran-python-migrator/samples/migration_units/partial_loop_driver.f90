program partial_loop_driver
  implicit none
  integer, parameter :: n = 12
  integer :: i
  double precision :: scale, total_pressure, peak_pressure
  double precision :: pressure(16), film(16), relaxation_factor
  common /field/ pressure, film, relaxation_factor

  scale = 0.4d0
  relaxation_factor = 0.75d0
  pressure = 0.0d0
  film = 0.0d0
  do i = 1, n
    pressure(i) = 0.1d0 * dble(i)
    film(i) = 1.0d0 + 0.02d0 * dble(i)
  end do

  call run_partial_loop(n, scale, total_pressure, peak_pressure)

  write(*, '(3(ES25.16E3,1X))') total_pressure, peak_pressure, relaxation_factor
  do i = 1, n
    write(*, '(I6,2(1X,ES25.16E3))') i, pressure(i), film(i)
  end do
end program partial_loop_driver
