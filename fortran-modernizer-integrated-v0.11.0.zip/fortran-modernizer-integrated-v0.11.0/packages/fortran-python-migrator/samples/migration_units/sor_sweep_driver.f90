program sor_sweep_driver
  use iso_fortran_env, only : real64
  use sor_kernel_mod, only : sor_sweep
  implicit none
  integer, parameter :: ntheta = 12, nz = 7
  real(real64), parameter :: eccentricity = 0.60_real64
  real(real64), parameter :: relaxation_factor = 1.35_real64
  real(real64), parameter :: axial_scale = 0.20_real64
  real(real64) :: pressure(ntheta, nz), film(ntheta)
  real(real64) :: pi, dtheta, dz, theta, residual
  character(len=1024) :: output_path
  integer :: i, j, unit

  pi = 4.0_real64 * atan(1.0_real64)
  dtheta = 2.0_real64 * pi / real(ntheta, real64)
  dz = 1.0_real64 / real(nz - 1, real64)
  do i = 1, ntheta
    theta = real(i - 1, real64) * dtheta
    film(i) = 1.0_real64 + eccentricity * cos(theta)
    do j = 1, nz
      pressure(i, j) = 0.002_real64 * real(i * j, real64)
    end do
  end do

  call sor_sweep(ntheta, nz, film, pressure, dtheta, dz, axial_scale, &
    relaxation_factor, residual)

  call get_command_argument(1, output_path)
  if (len_trim(output_path) == 0) error stop 'output path required'
  open(newunit=unit, file=trim(output_path), status='replace', action='write')
  write(unit, '(a,es25.17e3)') 'residual=', residual
  do i = 1, ntheta
    do j = 1, nz
      write(unit, '(i0,a,i0,a,es25.17e3)') i, ',', j, ',', pressure(i, j)
    end do
  end do
  close(unit)
end program sor_sweep_driver
