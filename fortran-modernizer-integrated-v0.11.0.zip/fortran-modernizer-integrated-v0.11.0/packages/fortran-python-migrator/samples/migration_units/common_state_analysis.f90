subroutine initialize_common_state(n, eccentricity)
  implicit none
  integer, intent(in) :: n
  double precision, intent(in) :: eccentricity
  double precision :: pressure(16), film(16), relaxation_factor
  common /field/ pressure, film, relaxation_factor
  integer :: i
  double precision :: pi, theta

  pi = 4.0d0 * atan(1.0d0)
  relaxation_factor = 1.25d0
  pressure = 0.0d0
  do i = 1, n
    theta = 2.0d0 * pi * dble(i - 1) / dble(n)
    film(i) = 1.0d0 + eccentricity * cos(theta)
    pressure(i) = dble(i) * film(i)
  end do
end subroutine initialize_common_state

subroutine advance_common_state(n)
  implicit none
  integer, intent(in) :: n
  double precision :: p(16), h(16), omega
  common /field/ p, h, omega
  integer :: i

  do i = 2, n - 1
    p(i) = p(i) + omega * (0.5d0 * (p(i - 1) + p(i + 1)) - p(i)) / h(i)
  end do
end subroutine advance_common_state

subroutine summarize_common_state(n, total_pressure, minimum_film)
  implicit none
  integer, intent(in) :: n
  double precision, intent(out) :: total_pressure, minimum_film
  double precision :: pressure(16), film(16), relaxation_factor
  common /field/ pressure, film, relaxation_factor
  integer :: i

  total_pressure = 0.0d0
  minimum_film = film(1)
  do i = 1, n
    total_pressure = total_pressure + pressure(i)
    if (film(i) < minimum_film) minimum_film = film(i)
  end do
end subroutine summarize_common_state

subroutine run_common_state(n, eccentricity, total_pressure, minimum_film)
  implicit none
  integer, intent(in) :: n
  double precision, intent(in) :: eccentricity
  double precision, intent(out) :: total_pressure, minimum_film
  double precision :: pressure(16), film(16), relaxation_factor
  common /field/ pressure, film, relaxation_factor

  call initialize_common_state(n, eccentricity)
  call advance_common_state(n)
  call summarize_common_state(n, total_pressure, minimum_film)
end subroutine run_common_state
