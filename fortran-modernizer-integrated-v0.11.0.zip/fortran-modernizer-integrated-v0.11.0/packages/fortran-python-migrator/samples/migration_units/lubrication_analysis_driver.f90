program lubrication_analysis_driver
  use iso_fortran_env, only : real64
  use lubrication_analysis_mod, only : solve_analysis
  implicit none
  integer :: ntheta, nz, max_iterations, iterations, i, j, unit
  integer :: repetitions, repetition
  real(real64) :: eccentricity, relaxation_factor, tolerance, axial_scale
  real(real64) :: update_residual, equation_residual
  real(real64) :: load_x, load_y, load_magnitude, dimensionless_friction
  real(real64) :: maximum_pressure, minimum_film_thickness
  real(real64) :: start_time, end_time, elapsed_seconds
  real(real64), allocatable :: pressure(:, :), film(:)
  logical :: converged
  character(len=256) :: argument, output_dir

  call get_command_argument(1, argument)
  read(argument, *) ntheta
  call get_command_argument(2, argument)
  read(argument, *) nz
  call get_command_argument(3, argument)
  read(argument, *) eccentricity
  call get_command_argument(4, argument)
  read(argument, *) relaxation_factor
  call get_command_argument(5, argument)
  read(argument, *) tolerance
  call get_command_argument(6, argument)
  read(argument, *) max_iterations
  call get_command_argument(7, argument)
  read(argument, *) axial_scale
  call get_command_argument(8, output_dir)
  call get_command_argument(9, argument)
  if (len_trim(argument) == 0) then
    repetitions = 1
  else
    read(argument, *) repetitions
  end if

  allocate(pressure(ntheta, nz), film(ntheta))
  call cpu_time(start_time)
  do repetition = 1, repetitions
    call solve_analysis(ntheta, nz, eccentricity, relaxation_factor, tolerance, &
      max_iterations, axial_scale, pressure, film, iterations, update_residual, &
      converged, equation_residual, load_x, load_y, load_magnitude, &
      dimensionless_friction, maximum_pressure, minimum_film_thickness)
  end do
  call cpu_time(end_time)
  elapsed_seconds = end_time - start_time

  open(newunit=unit, file=trim(output_dir)//'/summary.txt', status='replace')
  write(unit, '(A,I0)') 'iterations=', iterations
  write(unit, '(A,ES25.17E3)') 'update_residual=', update_residual
  write(unit, '(A,I0)') 'converged=', merge(1, 0, converged)
  write(unit, '(A,ES25.17E3)') 'equation_residual=', equation_residual
  write(unit, '(A,ES25.17E3)') 'load_x=', load_x
  write(unit, '(A,ES25.17E3)') 'load_y=', load_y
  write(unit, '(A,ES25.17E3)') 'load_magnitude=', load_magnitude
  write(unit, '(A,ES25.17E3)') 'dimensionless_friction=', dimensionless_friction
  write(unit, '(A,ES25.17E3)') 'maximum_pressure=', maximum_pressure
  write(unit, '(A,ES25.17E3)') 'minimum_film_thickness=', minimum_film_thickness
  write(unit, '(A,I0)') 'repetitions=', repetitions
  write(unit, '(A,ES25.17E3)') 'elapsed_seconds=', elapsed_seconds
  write(unit, '(A,ES25.17E3)') 'seconds_per_call=', &
    elapsed_seconds / real(repetitions, real64)
  close(unit)

  open(newunit=unit, file=trim(output_dir)//'/pressure.csv', status='replace')
  do i = 1, ntheta
    do j = 1, nz
      write(unit, '(I0,A,I0,A,ES25.17E3)') i, ',', j, ',', pressure(i, j)
    end do
  end do
  close(unit)

  open(newunit=unit, file=trim(output_dir)//'/film.csv', status='replace')
  do i = 1, ntheta
    write(unit, '(I0,A,ES25.17E3)') i, ',', film(i)
  end do
  close(unit)
end program lubrication_analysis_driver
