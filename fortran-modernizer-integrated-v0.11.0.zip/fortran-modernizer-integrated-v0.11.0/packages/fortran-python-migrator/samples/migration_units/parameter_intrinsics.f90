subroutine parameter_intrinsics(values, real_limit, int_limit)
  implicit none
  integer, parameter :: nbase = 4
  integer, parameter :: nvalues = nbase + 1
  real(8), parameter :: pi = acos(-1.0d0)
  real(8), intent(out) :: values(nvalues)
  real(8), intent(out) :: real_limit
  integer, intent(out) :: int_limit
  integer :: i

  do i = 1, nvalues
    values(i) = cos(real(i - 1, 8) * pi / real(nvalues, 8))
  end do
  real_limit = huge(1.0d0)
  int_limit = huge(1)
end subroutine parameter_intrinsics
