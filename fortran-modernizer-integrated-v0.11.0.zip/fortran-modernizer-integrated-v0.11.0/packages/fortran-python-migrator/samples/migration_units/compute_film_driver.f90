program compute_film_driver
  use iso_fortran_env, only : real64
  use film_kernel_mod, only : compute_film
  implicit none
  integer, parameter :: ntheta = 32
  real(real64), parameter :: eccentricity = 0.60_real64
  real(real64) :: film(ntheta)
  character(len=1024) :: output_path
  integer :: i, unit

  call get_command_argument(1, output_path)
  if (len_trim(output_path) == 0) error stop 'output path required'
  call compute_film(ntheta, eccentricity, film)
  open(newunit=unit, file=trim(output_path), status='replace', action='write')
  do i = 1, ntheta
    write(unit, '(i0,a,es25.17e3)') i, ',', film(i)
  end do
  close(unit)
end program compute_film_driver
