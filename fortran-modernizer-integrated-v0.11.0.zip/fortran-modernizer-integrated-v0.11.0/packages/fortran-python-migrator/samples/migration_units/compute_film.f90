module film_kernel_mod
  use iso_fortran_env, only : real64
  implicit none
  private
  public :: compute_film
contains
  subroutine compute_film(ntheta, eccentricity, film)
    integer, intent(in) :: ntheta
    real(real64), intent(in) :: eccentricity
    real(real64), intent(out) :: film(ntheta)
    integer :: i
    real(real64) :: pi, dtheta, theta

    pi = 4.0_real64 * atan(1.0_real64)
    dtheta = 2.0_real64 * pi / real(ntheta, real64)
    do i = 1, ntheta
      theta = real(i - 1, real64) * dtheta
      film(i) = 1.0_real64 + eccentricity * cos(theta)
    end do
  end subroutine compute_film
end module film_kernel_mod
