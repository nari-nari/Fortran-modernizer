program module_state_driver
  use module_state_analysis_mod, only : run_module_state, pressure, film, &
    relaxation_factor, active_count
  implicit none
  integer :: i
  double precision :: total_pressure, minimum_film

  call run_module_state(12, 0.4d0, total_pressure, minimum_film)
  write(*,'(I4,1X,ES24.16,1X,ES24.16,1X,ES24.16)') active_count, &
    total_pressure, minimum_film, relaxation_factor
  do i = 1, active_count
    write(*,'(I4,1X,ES24.16,1X,ES24.16)') i, pressure(i), film(i)
  end do
end program module_state_driver
