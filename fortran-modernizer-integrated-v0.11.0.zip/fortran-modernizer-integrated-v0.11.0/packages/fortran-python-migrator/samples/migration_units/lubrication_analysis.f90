module lubrication_analysis_mod
  use iso_fortran_env, only : real64
  implicit none
  private
  public :: compute_film, periodic_neighbors, sor_sweep, solve_pressure
  public :: compute_postprocess, solve_analysis
contains
  subroutine compute_film(ntheta, eccentricity, film)
    integer, intent(in) :: ntheta
    real(real64), intent(in) :: eccentricity
    real(real64), intent(out) :: film(ntheta)
    integer :: i
    real(real64) :: pi, dtheta, theta

    pi = 4.0_real64 * atan(1.0_real64)
    dtheta = 2.0_real64 * pi / real(ntheta, real64)
    do i = 1, ntheta
      theta = real(i - 1, real64) * dtheta
      film(i) = 1.0_real64 + eccentricity * cos(theta)
    end do
  end subroutine compute_film

  subroutine periodic_neighbors(i, ntheta, iw, ie)
    integer, intent(in) :: i, ntheta
    integer, intent(out) :: iw, ie

    if (i > 1) then
      iw = i - 1
    else
      iw = ntheta
    end if
    if (i < ntheta) then
      ie = i + 1
    else
      ie = 1
    end if
  end subroutine periodic_neighbors

  subroutine sor_sweep(ntheta, nz, film, pressure, dtheta, dz, axial_scale, &
      relaxation_factor, update_residual)
    integer, intent(in) :: ntheta, nz
    real(real64), intent(in) :: film(:)
    real(real64), intent(inout) :: pressure(:, :)
    real(real64), intent(in) :: dtheta, dz, axial_scale, relaxation_factor
    real(real64), intent(out) :: update_residual
    integer :: i, j, iw, ie
    real(real64) :: ki, ae, aw, an, asouth, ap, rhs
    real(real64) :: old_value, candidate, updated, difference

    update_residual = 0.0_real64
    do i = 1, ntheta
      call periodic_neighbors(i, ntheta, iw, ie)
      ki = film(i)**3
      ae = 0.5_real64 * (ki + film(ie)**3) / (dtheta * dtheta)
      aw = 0.5_real64 * (ki + film(iw)**3) / (dtheta * dtheta)
      an = axial_scale * ki / (dz * dz)
      asouth = an
      ap = ae + aw + an + asouth
      rhs = 3.0_real64 * (film(ie) - film(iw)) / dtheta
      do j = 2, nz - 1
        old_value = pressure(i, j)
        candidate = (ae * pressure(ie, j) + aw * pressure(iw, j) + &
          an * pressure(i, j + 1) + asouth * pressure(i, j - 1) - rhs) / ap
        if (candidate < 0.0_real64 .and. ap > 0.0_real64) then
          candidate = 0.0_real64
        end if
        updated = old_value + relaxation_factor * (candidate - old_value)
        if (updated < 0.0_real64) updated = 0.0_real64
        pressure(i, j) = updated
        difference = abs(updated - old_value)
        if (difference > update_residual) update_residual = difference
      end do
    end do
  end subroutine sor_sweep

  subroutine solve_pressure(ntheta, nz, eccentricity, relaxation_factor, &
      tolerance, max_iterations, axial_scale, pressure, film, iterations, &
      update_residual, converged)
    integer, intent(in) :: ntheta, nz, max_iterations
    real(real64), intent(in) :: eccentricity, relaxation_factor, tolerance
    real(real64), intent(in) :: axial_scale
    real(real64), intent(out) :: pressure(ntheta, nz), film(ntheta)
    integer, intent(out) :: iterations
    real(real64), intent(out) :: update_residual
    logical, intent(out) :: converged
    integer :: iteration
    real(real64) :: pi, dtheta, dz

    pi = 4.0_real64 * atan(1.0_real64)
    dtheta = 2.0_real64 * pi / real(ntheta, real64)
    dz = 1.0_real64 / real(nz - 1, real64)
    pressure = 0.0_real64
    call compute_film(ntheta, eccentricity, film)
    iterations = 0
    update_residual = 0.0_real64
    converged = .false.
    do iteration = 1, max_iterations
      call sor_sweep(ntheta, nz, film, pressure, dtheta, dz, axial_scale, &
        relaxation_factor, update_residual)
      iterations = iteration
      if (update_residual <= tolerance) then
        converged = .true.
        exit
      end if
    end do
  end subroutine solve_pressure

  subroutine compute_postprocess(ntheta, nz, film, pressure, axial_scale, &
      equation_residual, load_x, load_y, load_magnitude, &
      dimensionless_friction, maximum_pressure, minimum_film_thickness)
    integer, intent(in) :: ntheta, nz
    real(real64), intent(in) :: film(:), pressure(:, :), axial_scale
    real(real64), intent(out) :: equation_residual, load_x, load_y
    real(real64), intent(out) :: load_magnitude, dimensionless_friction
    real(real64), intent(out) :: maximum_pressure, minimum_film_thickness
    integer :: i, j, iw, ie
    real(real64) :: pi, dtheta, dz, theta, ki
    real(real64) :: ae, aw, an, asouth, ap, rhs
    real(real64) :: equation_value, difference, pressure_gradient, local_shear

    pi = 4.0_real64 * atan(1.0_real64)
    dtheta = 2.0_real64 * pi / real(ntheta, real64)
    dz = 1.0_real64 / real(nz - 1, real64)
    equation_residual = 0.0_real64
    load_x = 0.0_real64
    load_y = 0.0_real64
    dimensionless_friction = 0.0_real64
    maximum_pressure = pressure(1, 1)
    minimum_film_thickness = film(1)

    do i = 1, ntheta
      call periodic_neighbors(i, ntheta, iw, ie)
      theta = real(i - 1, real64) * dtheta
      ki = film(i)**3
      ae = 0.5_real64 * (ki + film(ie)**3) / (dtheta * dtheta)
      aw = 0.5_real64 * (ki + film(iw)**3) / (dtheta * dtheta)
      an = axial_scale * ki / (dz * dz)
      asouth = an
      ap = ae + aw + an + asouth
      rhs = 3.0_real64 * (film(ie) - film(iw)) / dtheta
      if (film(i) < minimum_film_thickness) minimum_film_thickness = film(i)
      do j = 1, nz
        if (pressure(i, j) > maximum_pressure) maximum_pressure = pressure(i, j)
      end do
      do j = 2, nz - 1
        equation_value = ap * pressure(i, j) - ae * pressure(ie, j) - &
          aw * pressure(iw, j) - an * pressure(i, j + 1) - &
          asouth * pressure(i, j - 1) + rhs
        if (pressure(i, j) > 0.0_real64) then
          difference = abs(equation_value)
        else
          if (equation_value < 0.0_real64) then
            difference = abs(equation_value)
          else
            difference = 0.0_real64
          end if
        end if
        if (difference > equation_residual) equation_residual = difference
        load_x = load_x + pressure(i, j) * cos(theta) * dtheta * dz
        load_y = load_y + pressure(i, j) * sin(theta) * dtheta * dz
        pressure_gradient = (pressure(ie, j) - pressure(iw, j)) / &
          (2.0_real64 * dtheta)
        local_shear = 1.0_real64 / film(i) + &
          0.5_real64 * film(i) * pressure_gradient
        dimensionless_friction = dimensionless_friction + &
          abs(local_shear) * dtheta * dz
      end do
    end do
    load_magnitude = sqrt(load_x * load_x + load_y * load_y)
  end subroutine compute_postprocess

  subroutine solve_analysis(ntheta, nz, eccentricity, relaxation_factor, &
      tolerance, max_iterations, axial_scale, pressure, film, iterations, &
      update_residual, converged, equation_residual, load_x, load_y, &
      load_magnitude, dimensionless_friction, maximum_pressure, &
      minimum_film_thickness)
    integer, intent(in) :: ntheta, nz, max_iterations
    real(real64), intent(in) :: eccentricity, relaxation_factor, tolerance
    real(real64), intent(in) :: axial_scale
    real(real64), intent(out) :: pressure(ntheta, nz), film(ntheta)
    integer, intent(out) :: iterations
    real(real64), intent(out) :: update_residual
    logical, intent(out) :: converged
    real(real64), intent(out) :: equation_residual, load_x, load_y
    real(real64), intent(out) :: load_magnitude, dimensionless_friction
    real(real64), intent(out) :: maximum_pressure, minimum_film_thickness

    call solve_pressure(ntheta, nz, eccentricity, relaxation_factor, tolerance, &
      max_iterations, axial_scale, pressure, film, iterations, &
      update_residual, converged)
    call compute_postprocess(ntheta, nz, film, pressure, axial_scale, &
      equation_residual, load_x, load_y, load_magnitude, &
      dimensionless_friction, maximum_pressure, minimum_film_thickness)
  end subroutine solve_analysis
end module lubrication_analysis_mod
