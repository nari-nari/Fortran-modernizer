module module_parameter_analysis_mod
  implicit none
  integer, parameter :: nvalues = 5
  real(8), parameter :: scale = 2.5d0
contains
  subroutine fill_module_parameter(values)
    implicit none
    real(8), intent(out) :: values(nvalues)
    integer :: i

    do i = 1, nvalues
      values(i) = scale * real(i, 8)
    end do
  end subroutine fill_module_parameter
end module module_parameter_analysis_mod
