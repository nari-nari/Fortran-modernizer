module module_state_analysis_mod
  implicit none
  integer :: active_count
  double precision :: pressure(16), film(16), relaxation_factor
contains
  subroutine initialize_module_state(n, eccentricity)
    implicit none
    integer, intent(in) :: n
    double precision, intent(in) :: eccentricity
    integer :: i
    double precision :: pi, theta

    active_count = n
    pi = 4.0d0 * atan(1.0d0)
    relaxation_factor = 1.25d0
    pressure = 0.0d0
    do i = 1, n
      theta = 2.0d0 * pi * dble(i - 1) / dble(n)
      film(i) = 1.0d0 + eccentricity * cos(theta)
      pressure(i) = dble(i) * film(i)
    end do
  end subroutine initialize_module_state

  subroutine advance_module_state()
    implicit none
    integer :: i

    do i = 2, active_count - 1
      pressure(i) = pressure(i) + relaxation_factor * &
        (0.5d0 * (pressure(i - 1) + pressure(i + 1)) - pressure(i)) / film(i)
    end do
  end subroutine advance_module_state

  subroutine summarize_module_state(total_pressure, minimum_film)
    implicit none
    double precision, intent(out) :: total_pressure, minimum_film
    integer :: i

    total_pressure = 0.0d0
    minimum_film = film(1)
    do i = 1, active_count
      total_pressure = total_pressure + pressure(i)
      if (film(i) < minimum_film) minimum_film = film(i)
    end do
  end subroutine summarize_module_state

  subroutine run_module_state(n, eccentricity, total_pressure, minimum_film)
    implicit none
    integer, intent(in) :: n
    double precision, intent(in) :: eccentricity
    double precision, intent(out) :: total_pressure, minimum_film

    call initialize_module_state(n, eccentricity)
    call advance_module_state()
    call summarize_module_state(total_pressure, minimum_film)
  end subroutine run_module_state
end module module_state_analysis_mod
