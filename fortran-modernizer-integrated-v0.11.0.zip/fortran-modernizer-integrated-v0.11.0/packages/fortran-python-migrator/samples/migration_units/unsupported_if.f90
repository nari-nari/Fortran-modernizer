subroutine unsupported_if(x, y)
  use iso_fortran_env, only : real64
  implicit none
  real(real64), intent(in) :: x
  real(real64), intent(out) :: y
  if (x > 0.0_real64) then
    y = x
  else
    y = -x
  end if
end subroutine unsupported_if
