subroutine run_case(n, mode, pressure, film, scale)
  implicit none
  integer, intent(in) :: n, mode
  real(8), intent(out) :: pressure(n), film(n), scale
  call initialize_state(n, pressure, film)
  call choose_mode(mode, scale)
  call update_state(n, pressure, film)
end subroutine run_case
