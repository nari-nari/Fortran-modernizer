subroutine update_state(n, pressure, film)
  implicit none
  integer, intent(in) :: n
  integer :: i
  real(8), intent(inout) :: pressure(n)
  real(8), intent(in) :: film(n)
  real(8) :: relaxation
  common /control/ relaxation
  do i = 1, n
    pressure(i) = pressure(i) + relaxation * film(i)
  end do
end subroutine update_state
