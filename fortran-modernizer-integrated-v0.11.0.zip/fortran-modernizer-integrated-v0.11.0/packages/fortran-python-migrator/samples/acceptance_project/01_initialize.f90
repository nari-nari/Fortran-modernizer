subroutine initialize_state(n, pressure, film)
  implicit none
  integer, intent(in) :: n
  integer :: i
  real(8), intent(out) :: pressure(n), film(n)
  do i = 1, n
    pressure(i) = 0.25d0 * dble(i)
    film(i) = 1.0d0 + 0.01d0 * dble(i)
  end do
end subroutine initialize_state
