subroutine choose_mode(mode, scale)
  implicit none
  integer, intent(in) :: mode
  real(8), intent(out) :: scale
  select case (mode)
  case (1)
    scale = 1.0d0
  case default
    scale = 0.5d0
  end select
end subroutine choose_mode
