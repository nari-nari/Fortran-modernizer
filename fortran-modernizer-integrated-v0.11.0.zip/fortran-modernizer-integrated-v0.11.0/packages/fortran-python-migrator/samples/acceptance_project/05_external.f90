subroutine export_case(n, pressure)
  implicit none
  integer, intent(in) :: n
  real(8), intent(in) :: pressure(n)
  call vendor_write(n, pressure)
end subroutine export_case
