module journal_bearing_mod
  use iso_fortran_env, only : real64
  implicit none
  private
  public :: case_t, result_t, read_case, solve_case, write_result

  type :: case_t
    integer :: ntheta = 32
    integer :: nz = 9
    real(real64) :: eccentricity = 0.60_real64
    real(real64) :: relaxation_factor = 1.35_real64
    real(real64) :: tolerance = 1.0e-11_real64
    integer :: max_iterations = 20000
    real(real64) :: axial_scale = 0.20_real64
  end type case_t

  type :: result_t
    real(real64), allocatable :: pressure(:, :)
    real(real64), allocatable :: film(:)
    integer :: iterations = 0
    real(real64) :: update_residual = 0.0_real64
    real(real64) :: equation_residual = 0.0_real64
    real(real64) :: load_x = 0.0_real64
    real(real64) :: load_y = 0.0_real64
    real(real64) :: load_magnitude = 0.0_real64
    real(real64) :: maximum_pressure = 0.0_real64
    real(real64) :: minimum_film_thickness = 0.0_real64
    real(real64) :: friction_indicator = 0.0_real64
  end type result_t
contains
  subroutine read_case(path, case_data)
    character(len=*), intent(in) :: path
    type(case_t), intent(out) :: case_data
    integer :: unit
    integer :: ntheta, nz, max_iterations
    real(real64) :: eccentricity, relaxation_factor, tolerance, axial_scale
    namelist /case/ ntheta, nz, eccentricity, relaxation_factor, tolerance, &
      max_iterations, axial_scale

    ntheta = case_data%ntheta
    nz = case_data%nz
    eccentricity = case_data%eccentricity
    relaxation_factor = case_data%relaxation_factor
    tolerance = case_data%tolerance
    max_iterations = case_data%max_iterations
    axial_scale = case_data%axial_scale

    open(newunit=unit, file=path, status='old', action='read')
    read(unit, nml=case)
    close(unit)

    case_data%ntheta = ntheta
    case_data%nz = nz
    case_data%eccentricity = eccentricity
    case_data%relaxation_factor = relaxation_factor
    case_data%tolerance = tolerance
    case_data%max_iterations = max_iterations
    case_data%axial_scale = axial_scale
  end subroutine read_case

  subroutine solve_case(case, result)
    type(case_t), intent(in) :: case
    type(result_t), intent(out) :: result
    integer :: i, j, iw, ie, iteration
    real(real64) :: pi, dtheta, dz, theta
    real(real64) :: ki, ke, kw, ae, aw, an, asouth, ap, rhs
    real(real64) :: old_value, candidate, updated, difference, local

    pi = 4.0_real64 * atan(1.0_real64)
    dtheta = 2.0_real64 * pi / real(case%ntheta, real64)
    dz = 1.0_real64 / real(case%nz - 1, real64)
    allocate(result%pressure(case%ntheta, case%nz))
    allocate(result%film(case%ntheta))
    result%pressure = 0.0_real64

    do i = 1, case%ntheta
      theta = real(i - 1, real64) * dtheta
      result%film(i) = 1.0_real64 + case%eccentricity * cos(theta)
    end do

    do iteration = 1, case%max_iterations
      result%update_residual = 0.0_real64
      do i = 1, case%ntheta
        iw = merge(i - 1, case%ntheta, i > 1)
        ie = merge(i + 1, 1, i < case%ntheta)
        ki = result%film(i)**3
        ke = 0.5_real64 * (ki + result%film(ie)**3)
        kw = 0.5_real64 * (ki + result%film(iw)**3)
        ae = ke / (dtheta * dtheta)
        aw = kw / (dtheta * dtheta)
        an = case%axial_scale * ki / (dz * dz)
        asouth = an
        ap = ae + aw + an + asouth
        rhs = 3.0_real64 * (result%film(ie) - result%film(iw)) / dtheta
        do j = 2, case%nz - 1
          old_value = result%pressure(i, j)
          candidate = (ae * result%pressure(ie, j) + &
            aw * result%pressure(iw, j) + &
            an * result%pressure(i, j + 1) + &
            asouth * result%pressure(i, j - 1) - rhs) / ap
          candidate = max(0.0_real64, candidate)
          updated = old_value + case%relaxation_factor * (candidate - old_value)
          updated = max(0.0_real64, updated)
          result%pressure(i, j) = updated
          difference = abs(updated - old_value)
          result%update_residual = max(result%update_residual, difference)
        end do
      end do
      result%iterations = iteration
      if (result%update_residual <= case%tolerance) exit
    end do

    result%equation_residual = 0.0_real64
    result%load_x = 0.0_real64
    result%load_y = 0.0_real64
    result%maximum_pressure = maxval(result%pressure)
    result%minimum_film_thickness = minval(result%film)
    result%friction_indicator = 0.0_real64

    do i = 1, case%ntheta
      iw = merge(i - 1, case%ntheta, i > 1)
      ie = merge(i + 1, 1, i < case%ntheta)
      ki = result%film(i)**3
      ae = 0.5_real64 * (ki + result%film(ie)**3) / (dtheta * dtheta)
      aw = 0.5_real64 * (ki + result%film(iw)**3) / (dtheta * dtheta)
      an = case%axial_scale * ki / (dz * dz)
      asouth = an
      ap = ae + aw + an + asouth
      rhs = 3.0_real64 * (result%film(ie) - result%film(iw)) / dtheta
      theta = real(i - 1, real64) * dtheta
      result%friction_indicator = result%friction_indicator + 1.0_real64 / result%film(i)
      do j = 1, case%nz
        result%load_x = result%load_x + result%pressure(i, j) * cos(theta) * dtheta * dz
        result%load_y = result%load_y + result%pressure(i, j) * sin(theta) * dtheta * dz
        if (j > 1 .and. j < case%nz .and. result%pressure(i, j) > 0.0_real64) then
          local = abs(ae * result%pressure(ie, j) + &
            aw * result%pressure(iw, j) + &
            an * result%pressure(i, j + 1) + &
            asouth * result%pressure(i, j - 1) - &
            ap * result%pressure(i, j) - rhs)
          result%equation_residual = max(result%equation_residual, local)
        end if
      end do
    end do
    result%friction_indicator = result%friction_indicator * dtheta
    result%load_magnitude = sqrt(result%load_x**2 + result%load_y**2)
  end subroutine solve_case

  subroutine write_result(output_dir, result)
    character(len=*), intent(in) :: output_dir
    type(result_t), intent(in) :: result
    integer :: unit, i, j

    open(newunit=unit, file=trim(output_dir)//'/summary.txt', status='replace', action='write')
    write(unit, '(a,i0)') 'iterations=', result%iterations
    write(unit, '(a,es25.17e3)') 'update_residual=', result%update_residual
    write(unit, '(a,es25.17e3)') 'equation_residual=', result%equation_residual
    write(unit, '(a,es25.17e3)') 'load_x=', result%load_x
    write(unit, '(a,es25.17e3)') 'load_y=', result%load_y
    write(unit, '(a,es25.17e3)') 'load_magnitude=', result%load_magnitude
    write(unit, '(a,es25.17e3)') 'maximum_pressure=', result%maximum_pressure
    write(unit, '(a,es25.17e3)') 'minimum_film_thickness=', result%minimum_film_thickness
    write(unit, '(a,es25.17e3)') 'friction_indicator=', result%friction_indicator
    close(unit)

    open(newunit=unit, file=trim(output_dir)//'/pressure.csv', status='replace', action='write')
    write(unit, '(a)') 'i,j,pressure'
    do i = 1, size(result%pressure, 1)
      do j = 1, size(result%pressure, 2)
        write(unit, '(i0,a,i0,a,es25.17e3)') i, ',', j, ',', result%pressure(i, j)
      end do
    end do
    close(unit)
  end subroutine write_result
end module journal_bearing_mod

program journal_bearing
  use journal_bearing_mod, only : case_t, result_t, read_case, solve_case, write_result
  implicit none
  character(len=1024) :: case_path, output_dir
  type(case_t) :: case
  type(result_t) :: result

  call get_command_argument(1, case_path)
  call get_command_argument(2, output_dir)
  if (len_trim(case_path) == 0 .or. len_trim(output_dir) == 0) then
    error stop 'usage: journal_bearing CASE_FILE OUTPUT_DIR'
  end if
  call read_case(trim(case_path), case)
  call solve_case(case, result)
  call write_result(trim(output_dir), result)
end program journal_bearing
