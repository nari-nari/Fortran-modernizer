from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any


def _run_case(runtime, *, n: int, eccentricity: float, backend: str) -> dict[str, Any]:
    state = runtime.create_common_field()
    total, peak = runtime.run_partial_hybrid(
        state,
        n,
        eccentricity,
        backend=backend,
    )
    return {
        "backend": backend,
        "n": n,
        "eccentricity": eccentricity,
        "total_pressure": float(total),
        "peak_pressure": float(peak),
        "relaxation_factor": float(state.relaxation_factor),
        "pressure": [float(item) for item in state.pressure[:n]],
        "film": [float(item) for item in state.film[:n]],
    }


def self_check(runtime) -> dict[str, object]:
    expected_total = 83.1
    expected_peak = 16.998428289111413
    results = {}
    for backend in ("python", "cython-safe", "cython-optimized"):
        result = _run_case(runtime, n=12, eccentricity=0.4, backend=backend)
        results[backend] = {
            "total_pressure": result["total_pressure"],
            "peak_pressure": result["peak_pressure"],
        }
        if abs(result["total_pressure"] - expected_total) > 1.0e-12:
            return {"status": "FAIL", "reason": f"unexpected total for {backend}", "results": results}
        if abs(result["peak_pressure"] - expected_peak) > 1.0e-12:
            return {"status": "FAIL", "reason": f"unexpected peak for {backend}", "results": results}
    return {"status": "PASS", "results": results}


def run(runtime, argv: list[str]) -> int:
    parser = argparse.ArgumentParser(prog="lubrication-hybrid")
    parser.add_argument("--n", type=int, default=12)
    parser.add_argument("--eccentricity", type=float, default=0.4)
    parser.add_argument(
        "--backend",
        choices=["python", "cython-safe", "cython-optimized"],
        default="cython-optimized",
    )
    parser.add_argument("--output")
    args = parser.parse_args(argv)
    result = _run_case(
        runtime,
        n=args.n,
        eccentricity=args.eccentricity,
        backend=args.backend,
    )
    text = json.dumps(result, indent=2) + "\n"
    if args.output:
        Path(args.output).write_text(text, encoding="utf-8")
    else:
        print(text, end="")
    return 0
