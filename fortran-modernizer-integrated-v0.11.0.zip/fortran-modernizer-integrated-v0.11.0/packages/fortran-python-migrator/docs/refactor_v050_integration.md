# fortran-refactor-tool v0.50.0 connection

`fortran-python-migrator` accepts canonical refactoring handoffs with schema
`1.0` and `1.1`. Schema 1.1 adds qualified scopes and source SHA-256 evidence.

```bash
fpy-migrate validate-refactor-report build/refactor_handoff.json

fpy-migrate verify-refactor-connection refactored-src/ \
  --procedure root_subroutine \
  --report build/refactor_handoff.json \
  --output build/refactor_connection.json
```

Verification now blocks migration when:

- any source hash differs from the source used to generate the handoff;
- a handoff source file is absent;
- storage-overlay evidence says production source was not modified or remains
  blocked;
- program units, symbols, arguments, CALL edges, or COMMON layouts disagree.

The v0.50.0 exporter should be preferred to `import-refactor-bundle` for the
formal connection. The generic importer remains available for older and
third-party report formats.
