# Milestone 2: first verified AST-to-Python procedure migration

Implemented on 2026-08-02.

## Scope completed

- Replaced the Migration IR skeleton with versioned dataclasses and a detailed
  JSON Schema.
- Added fparser AST extraction for one safe initial subset:
  - explicit integer and real declarations;
  - `intent(in)`, `intent(out)`, and `intent(inout)` metadata;
  - scalar and explicit-shape one-dimensional arrays;
  - assignments and arithmetic expressions;
  - selected intrinsics (`REAL`, `ATAN`, `COS`, and related generator mappings);
  - non-labelled DO loops.
- Added source-file and source-line mappings to procedures and statements.
- Added a leaf lubrication procedure, `compute_film`, and a Fortran driver.
- Added Python generation from Migration IR, including:
  - NumPy `float64` output allocation;
  - one-based Fortran array index conversion;
  - inclusive Fortran DO-bound conversion;
  - type hints and source mapping comments.
- Enriched the separate refactoring-tool hand-off schema.
- Added optional hand-off/AST cross-checks for argument order, category,
  `intent`, and rank.
- Added CLI commands:
  - `build-ir`;
  - `validate-ir`;
  - `translate`.
- Added explicit `BLOCKED` handling for unsupported executable constructs.
- Added a Copilot skill for building and reviewing Migration IR.

## Verification result

- Full pytest suite: 15 tests passed.
- The generated Python implementation of `compute_film` matches the compiled
  Fortran subroutine exactly for the standard 32-point, eccentricity-0.60 case:
  - maximum absolute difference: `0.0`;
  - maximum relative difference: `0.0`.
- Migration IR JSON validates against `schemas/migration_ir.schema.json`.
- The deliberately unsupported IF fixture is rejected with `BLOCKED` and an
  `If_Construct` diagnostic rather than being partially translated.

Machine-readable outputs are under `reports/milestone2/`.

## Main generated artefacts

- `reports/milestone2/compute_film.ir.json`
- `generated/milestone2/compute_film.py`
- `reports/milestone2/generated_fortran_equivalence.json`
- `reports/milestone2/pytest.txt`

## Deliberate limitations

The current procedure generator is intentionally small. It does not yet handle:

- IF/ELSE;
- CALL and function calls other than selected intrinsics;
- derived-type component references such as `case%ntheta`;
- rank-2 or higher output allocation;
- assumed-shape arrays;
- reductions and array intrinsics;
- COMMON or module-state mapping;
- I/O statements;
- Cython code generation.

## Recommended milestone 3

1. Add IF/ELSE and relational/logical expressions.
2. Add CALL and a project-level procedure index.
3. Add rank-2 arrays and assumed-shape array arguments.
4. Extract a second leaf procedure from the journal-bearing solver, such as
   post-processing or a single SOR sweep.
5. Generate a Python reference and verify it against Fortran.
6. Add loop-cost/candidate metadata for later Cython generation.
