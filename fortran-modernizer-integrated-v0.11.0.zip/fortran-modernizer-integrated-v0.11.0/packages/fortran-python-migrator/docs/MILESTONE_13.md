# Milestone 13 — Profile-driven kernel selection

## Goal

Replace static “compile every eligible loop” behavior with a measured selection
step. Static analysis still determines what *can* be translated safely. A Python
reference workload then determines what is worth compiling.

## Implemented workflow

```text
Fortran project
  -> Migration IR and static hybrid candidates
  -> generated Python reference with partial loops exposed as functions
  -> representative workload profiling
  -> threshold/rank-based native selection
  -> Python/Cython hybrid build
  -> full-state comparison with compiled Fortran
```

The workload contract is deliberately small:

```python
def run(reference_module):
    ...
```

It receives the generated reference module, creates its state objects, and runs
representative analysis operations. No Cython extension is required during the
profiling stage.

## Profile report

`hybrid_profile.json` records, for every statically eligible candidate:

- source procedure and generated kernel procedure;
- full-procedure or partial-loop extraction kind;
- call count;
- inclusive and exclusive/self time;
- share of all measured candidate self time;
- share of workload wall time.

Nested candidate calls are accounted for with a call stack, so child time is not
double-counted in parent self time.

## Selection policy

The profiled plan supports:

- minimum candidate share;
- minimum self time in milliseconds;
- maximum number of native kernels.

Candidates are ranked by measured self time. A candidate that is statically
eligible but below the configured thresholds remains Python. If no measured
candidate passes, the hottest measured eligible candidate is retained as a
conservative fallback.

The plan schema is now `1.2`. It distinguishes:

- `eligible_procedures`: safe native candidates;
- `extracted_procedures`: candidates actually selected for this build;
- per-candidate `selected` and `selection_reason`;
- call count, self time, candidate share, and wall share.

The manifest schema is also `1.2` and preserves the normalized profile report as
a build artifact.

## Recorded sample

The supplied workload initializes the journal-bearing state once and executes
the internal pressure update loop another 50 times per workload invocation.
With 100 measured invocations, the recorded profile was:

| Candidate | Calls | Candidate self-time share |
|---|---:|---:|
| `run_partial_hybrid` internal loop | 5,100 | about 95.3% |
| `initialize_partial_state` | 100 | about 2.9% |
| `summarize_partial_state` | 100 | about 1.8% |

Using `--min-profile-share 0.5` selects only the internal update loop. The two
full-procedure candidates remain readable Python.

## Equivalence result

The profile-selected build was compared with `gfortran -O2` for:

- complete pressure array;
- complete film-thickness array;
- total pressure;
- peak pressure;
- shared relaxation factor.

Python, safe Cython, and optimized Cython all had an absolute difference of
`0.0` from the Fortran result for every compared value.

## Test status

The complete suite now contains:

- 41 non-integration tests;
- 20 compiler/integration tests;
- 61 passing tests in compiler-safe shards.

## Current limitations

- The workload must explicitly construct valid generated inputs and state.
- Selection is based on one supplied workload report; multi-case aggregation is
  not yet implemented.
- Memory allocation and workload setup time are not attributed to a candidate
  unless they occur inside an instrumented procedure.
- Line-level profiling inside a loop is not attempted; partial loops are already
  exposed as named synthetic procedures before timing.
- Profile portability is not assumed across machines, compilers, or problem
  sizes. Reports are evidence for one recorded workload and environment.
