# Milestone 10: project-level hybrid generation

## Goal

Generate one movable hybrid project from a reachable Fortran call graph. Python
retains orchestration and state ownership while every eligible state-dependent
leaf loop is available through three interchangeable backends:

- readable Python;
- safety-checked Cython;
- optimized Cython.

The milestone also introduces multi-file Fortran input so separate source files
can share one validated COMMON layout and call graph.

## Implemented workflow

```text
Fortran source file or source directory
    -> multi-file Migration IR
    -> dependency-ordered reachable procedures
    -> project-level kernel classification
       -> AUTO: build Python/safe-Cython/optimized-Cython bundle
       -> PYTHON_ONLY: retain in Python orchestration
    -> shared project backend registry
    -> generated root-procedure dispatcher
```

Two CLI commands were added:

```bash
fpy-migrate analyze-hybrid-project \
  samples/migration_projects/common_state_project \
  --procedure run_common_state \
  --output build/common_project_plan.json
```

```bash
fpy-migrate build-hybrid-project \
  samples/migration_projects/common_state_project \
  --procedure run_common_state \
  --build-directory build/common_hybrid_project \
  --default-backend cython-optimized
```

## Multi-file Migration IR

`build_project_ir` now accepts either one Fortran file or a directory. Directory
input recursively discovers supported Fortran suffixes, parses each file, and
then performs project-wide checks:

- duplicate subroutine names across files;
- cross-file call resolution;
- call argument-count validation;
- COMMON member count/type/kind/rank/shape validation;
- COMMON alias normalization by member position;
- dependency ordering that preserves call order.

The validation fixture splits initialization, update, summarization, and the
root orchestrator into separate source files while retaining one `/FIELD/`
COMMON block. Local aliases `p/h/omega` are normalized to
`pressure/film/relaxation_factor`.

## Project-level classification

For the COMMON fixture, the generated plan is:

| Procedure | Status | Role |
|---|---|---|
| `initialize_common_state` | `AUTO` | initializes shared arrays/scalar |
| `advance_common_state` | `AUTO` | performs the state update loop |
| `summarize_common_state` | `AUTO` | reduces state to scalar outputs |
| `run_common_state` | `PYTHON_ONLY` | calls the three leaf procedures |

The root procedure is deliberately not flattened or compiled. Its calls are
resolved dynamically through the generated registry.

## Generated runtime

The build directory contains:

```text
hybrid_project.ir.json
hybrid_project_plan.json
hybrid_project_manifest.json
project_reference.py
hybrid_project.py
kernels/
  initialize_common_state/
  advance_common_state/
  summarize_common_state/
```

`hybrid_project.py` loads the readable project reference module and each state
kernel wrapper. It then replaces only the eligible leaf procedure names inside
the reference module. Python's original call graph remains intact, but each
leaf call selects its backend from a context-local registry.

Uniform selection:

```python
state = runtime.create_common_field()
total, minimum = runtime.run_common_state(
    state,
    12,
    0.4,
    backend="cython-optimized",
)
```

Per-procedure override:

```python
total, minimum = runtime.run_common_state(
    state,
    12,
    0.4,
    backend="cython-optimized",
    backend_overrides={"summarize_common_state": "python"},
)
```

An override for a non-kernel procedure is rejected explicitly. Backend context
uses `ContextVar`, avoiding one process-global mutable backend setting during
nested or concurrent Python execution.

## State ownership

The central state dataclasses come from the project reference module. Individual
kernel wrappers accept these objects by Python duck typing, but extract only
explicit arrays/scalars before calling the compiled function. No dataclass is
passed into Cython.

For fixed literal state extents, the runtime also generates zero-initializing
factory functions such as:

```python
state = create_common_field()
```

Factories are omitted when dimensions cannot yet be allocated safely from
compile-time literals.

## Numerical verification

Both COMMON and module-state projects were built and compared with compiled
Fortran. The entire sequence—initialization, state update, summarization, arrays,
and scalar state—was checked.

### COMMON project

| Backend | Pressure max difference | Film max difference | Scalar differences |
|---|---:|---:|---:|
| Python | `0.0` | `0.0` | `0.0` |
| safe Cython | `0.0` | `0.0` | `0.0` |
| optimized Cython | `0.0` | `0.0` | `0.0` |
| optimized update + Python summary | n/a | n/a | `0.0` |

### Module-state project

| Backend | Pressure max difference | Film max difference | Scalar differences |
|---|---:|---:|---:|
| Python | `0.0` | `0.0` | `0.0` |
| safe Cython | `0.0` | `0.0` | `0.0` |
| optimized Cython | `0.0` | `0.0` | `0.0` |

## Test status

The suite now contains 51 tests:

- non-integration: `34 passed`;
- integration/equivalence/benchmark: `17 passed` in compiler-safe shards;
- total: `51 passed`.

Compiler-heavy groups are intentionally executed in fresh Python processes to
avoid retaining many dynamically loaded extensions and to stay within the
execution environment's process/time limits.

## Generated Copilot skill

`.github/skills/build-hybrid-project/SKILL.md` requires Copilot to review the
project plan, preserve Python orchestration, build all three backends, test a
mixed-backend run, and compare the complete state with Fortran.

## Current limitations

- directory discovery does not yet evaluate preprocessor include graphs or build
  system conditionals;
- duplicate module names and advanced module-use association across independent
  files remain outside the current subset;
- only complete stateful leaf procedure bodies are extracted;
- partial-loop extraction with scalar setup/teardown retained in Python is not
  yet implemented;
- a stateful procedure containing calls remains Python-only;
- backend choice is runtime-selectable, but automatic profile-guided choice is
  not implemented;
- Windows packaging of the project registry and compiled `.pyd` files remains a
  later milestone.

## Next recommended milestone

Add partial-loop extraction. A stateful procedure should be split into Python
setup, one explicit native loop kernel, and Python teardown without moving I/O,
allocation policy, or non-hot control logic into Cython. The split must preserve
source mapping and complete-state equivalence.
