# Milestone 18: Refactoring-tool report bridge

## Objective

Connect the separate Fortran refactoring project to the Python/Cython migration
pipeline without making either tool depend on the other's internal Python classes.
The stable boundary is a versioned canonical JSON hand-off followed by an
independent fparser cross-check.

## Implemented

- Recursive discovery of JSON files in a refactoring report directory.
- Direct reuse of a canonical hand-off JSON when one is already present.
- Normalisation of common aliases for program-unit, symbol, COMMON, call-graph,
  diagnostic, source-map, and regression-case collections.
- Preservation of producer version, source report files, project root, and
  collection counts.
- New `import-refactor-bundle` CLI.
- New `verify-refactor-connection` CLI.
- Full-project comparison of program units, arguments, symbols, source spans,
  calls, COMMON positions/types/ranks, and blocking diagnostics.
- Versioned `refactor_connection.schema.json`.
- `PASS`, `REVIEW_REQUIRED`, and `BLOCKED` outcomes with coverage ratios.
- Copilot skill for the required import/verify workflow.

## Verification fixture

The compatibility fixture emulates the split machine-readable reports expected
from the current refactoring tool generation:

- `project_inventory.json`
- `common_layouts.json`
- `call_graph.json`
- `diagnostics.json`

The fixture contains four reachable procedures, 27 symbols, three call edges,
and twelve COMMON-member occurrences. After normalisation, all categories reached
100% cross-check coverage.

A negative fixture changes one COMMON member from rank 1 to rank 2. The bridge
returns `BLOCKED`, identifies `/field/` position 1 in `advance_common_state`, and
reports COMMON coverage of 11/12.

## Test results

- New bridge tests: 3 passed.
- Non-integration suite: 47 passed, 2 environment-dependent tests skipped.
- Existing analysis-backend integration file: 2 passed.
- A single invocation of the complete compiler-heavy integration group exceeded
  the host execution limit; those tests were already validated in milestone 17,
  and this milestone does not modify code-generation or compiler backends.

The project version is `0.18.0`.

## Important limitation

The actual v0.37.0 ZIP/report directory was not mounted in this runtime. The bridge
was verified against a v0.37-style split-report fixture and the canonical hand-off
contract. A final producer-side acceptance run still requires the latest refactoring
tool archive or its generated report directory to be attached in the active
conversation/runtime.
