# Milestone 20: Named constants and intrinsic semantics

## Objective

Allow already-normalised numerical Fortran to retain scalar `PARAMETER`
declarations and the sample-required `ACOS`/`DACOS`/`HUGE` intrinsics through
Migration IR, generated Python, safe Cython, optimised Cython, and generated
`bind(C)` Fortran kernels.

This milestone does not restructure labelled loops, `GOTO`, or formatted
`WRITE`. Those remain upstream refactoring or later orchestration/I/O-boundary
work. The proprietary production code was not supplied; validation uses the
controlled journal-bearing sample that was evaluated in the preceding step.

## Implemented

### Migration IR 1.2

- Added immutable `ConstantIR` records separate from mutable `SymbolIR` values.
- Added ordered procedure-visible constants to `ProcedureIR`.
- Preserved source spans for constant declarations.
- Added module-parameter visibility for contained procedures without treating
  parameters as shared mutable state.
- Updated `migration_ir.schema.json` to schema version 1.2.

Initial supported subset:

- scalar INTEGER, REAL, and LOGICAL `PARAMETER` declarations;
- literal, unary, and binary constant expressions;
- references between named constants;
- supported intrinsic calls inside constant expressions;
- constants in array extents, loop bounds, and ordinary expressions.

Parameter arrays, character parameters, unresolved references, and cyclic
constant dependencies fail explicitly.

### Constant dependency handling

The builder topologically orders definitions such as:

```fortran
integer, parameter :: nbase = 4
integer, parameter :: nvalues = nbase + 1
```

A cycle produces an `UnsupportedFortranError` identifying the cyclic
`PARAMETER` dependency instead of generating unresolved code.

### Shared intrinsic lowering

Added a shared intrinsic helper used by all code-generation paths. Milestone 20
adds or normalises:

- `ACOS` and `DACOS`;
- `HUGE` with result selection from the inferred integer/real argument category;
- double-precision aliases such as `DBLE`, `DATAN`, `DCOS`, `DSIN`, `DSQRT`, and
  `DABS` to their existing generic forms.

Generated Python/Cython uses NumPy limits for `HUGE`; generated Fortran retains
Fortran `huge(...)` semantics under the existing double/C-int backend contract.

### Code generators and wrapper

- Python emits constants before executable statements and therefore never
  leaves names such as `ntheta`, `nz`, `maxit`, `omega`, `toler`, or `aspect`
  unresolved.
- Safe and optimised Cython emit typed Pure Python Mode constants.
- Generated `bind(C)` Fortran emits C-interoperable `parameter` declarations.
- The generated ctypes wrapper emits required constants before allocating
  explicit-shape `intent(out)` arrays.
- State-kernel and partial-loop extraction preserve source procedure constants.

### Regression repair retained

The complete regression run detected that the active hybrid-project source had
again lost part of the milestone-17 optional Fortran-backend integration. The
following were restored and revalidated:

- `--include-fortran` propagation;
- four-way `available_backends` manifest data;
- Fortran bundle/runtime registration for full and partial kernels;
- hybrid manifest schema 1.5 compatibility.

All project-level Fortran-backend and downstream profile/economics/distribution
integration tests passed after restoration.

## Four-backend constant fixture

`samples/migration_units/parameter_intrinsics.f90` exercises:

- a dependent integer parameter used as an explicit array extent;
- a real parameter defined with `ACOS`;
- `REAL`/`DBLE` conversion inside a loop;
- real and integer `HUGE`.

Python, safe Cython, and optimised Cython produced identical values. Generated
Fortran differed from the Python reference by at most
`1.1102230246251565e-16` in the cosine array; both `HUGE` results matched
exactly.

The fixture also verifies module parameters using
`samples/migration_units/module_parameter_analysis.f90`.

## Journal-bearing sample result

The controlled project under
`samples/migration_projects/legacy_parameter_project/` retains its original
scalar `PARAMETER`, `ACOS`, and `HUGE` statements. Generated Python now runs
without manual constant substitution.

Compiled Fortran versus generated Python:

| Quantity | Fortran | Generated Python | Absolute difference |
|---|---:|---:|---:|
| iterations | 173 | 173 | 0 |
| residual | 9.324352401307578e-11 | 9.324363503537825e-11 | 1.1102230246251565e-16 |
| load | 2.6071517885680344 | 2.607151788568037 | 2.6645352591003757e-15 |
| maximum pressure | 3.17977190404944 | 3.1797719040494443 | 4.440892098500626e-15 |
| minimum film | 0.4 | 0.4 | 0 |
| friction | 7.853981633974483 | 7.853981633974483 | 0 |

The exact iteration count is preserved and all floating-point quantities pass
`rtol=1e-12`, `atol=1e-13`.

## Test results

- Non-integration: 56 passed.
- Environment-dependent normalisation test: 1 skipped because the active PATH
  did not expose `findent`; the offline wheel remains in `vendor/wheels`.
- Compiler-heavy integration: 29 passed, each in a fresh Python process.
- Total collected: 86 tests; 85 passed and 1 skipped.
- `fpy-migrate sample compare`: modern Fortran, legacy Fortran, Python, and
  handwritten Cython passed the established comparison contract.

The project version is `0.20.0`.

## Deliberate limitations

- Scalar numeric/logical parameters only; no parameter arrays or character
  parameters.
- The generated integer `HUGE` contract currently follows the C-interoperable
  32-bit integer used by generated kernels.
- Generic external INCLUDE-directory discovery was not added here. INCLUDE
  resolution remains an upstream refactoring/handoff responsibility for this
  workflow; embedded or already-resolved declarations are supported.
- Labelled DO, `GOTO`, formatted `WRITE`, and whole-program orchestration remain
  outside this milestone.
- Unsupported sibling procedures can still block strict whole-project IR
  construction; procedure-scoped dependency-closure construction is milestone 21.

## Next step

Implement the two-pass project inventory and procedure-scoped IR builder so an
unsupported, unreachable reporting procedure in the same source file does not
block migration of the selected numerical procedure, while project-wide COMMON
layout checks remain strict.
