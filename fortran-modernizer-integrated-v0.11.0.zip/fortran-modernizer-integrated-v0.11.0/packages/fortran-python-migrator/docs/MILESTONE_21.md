# Milestone 21: procedure-scoped Migration IR construction

## Objective

Allow a supported numerical procedure and its reachable local dependencies to
be migrated even when the same Fortran file also contains unreachable,
unsupported procedures such as formatted reporting. Preserve strict failure for
unsupported reachable procedures and preserve project-wide COMMON layout
validation.

## Problem reproduced by the supplied journal-bearing sample

The normalized one-file sample contains four numerical/reporting subroutines:

- `init_geometry`
- `solve_reynolds`
- `compute_metrics`
- `print_results`

The first three are representable by the current safe Migration IR after the
Milestone-20 constant/intrinsic work. `print_results` contains formatted
`WRITE`, which remains outside the numerical migration subset. Before this
milestone, the builder translated every subroutine body before applying
`--procedure`, so `print_results` blocked even a request to migrate only
`solve_reynolds`.

## Two-pass architecture

### Pass 1: lightweight project inventory

The first pass parses all discovered source files but does not translate
executable bodies. It records:

- subroutine and main-program names;
- source spans and dummy argument order;
- local `CALL` edges, including calls inside unsupported executable constructs;
- module state contexts;
- type/rank/shape declarations needed for COMMON validation;
- COMMON member order and local aliases.

Unsupported executable statements such as `WRITE` do not fail this pass.
Duplicate program-unit names and invalid or incompatible COMMON declarations do
fail globally.

### Pass 2: dependency-closure IR construction

When `--procedure ROOT` is supplied, the lightweight call graph is traversed
first. Only `ROOT` and its reachable subroutines are translated into full
Migration IR, in dependency-first order.

- an unsupported unreachable sibling is excluded;
- an unsupported reachable procedure remains blocking;
- an unresolved reachable external call remains blocking;
- a recursive reachable call cycle remains blocking;
- requesting a main-program name is rejected explicitly until orchestration
  support is implemented;
- omitting `--procedure` retains strict whole-project subroutine translation.

## Project-wide COMMON validation

COMMON declarations are inventoried in all subroutines and main programs,
including units outside the selected dependency closure. The builder validates:

- member count;
- storage position;
- type and kind;
- rank;
- shape expression.

After validation, selected procedures receive canonical state-field aliases by
COMMON storage position. In the supplied one-file sample, the main program
establishes canonical `/field/` names `p`, `h`, and `theta`, while numerical
subroutines using aliases such as `press`, `film`, and `angle` map to those
canonical fields.

## Verified journal-bearing path

A controlled one-file fixture is stored at:

` samples/migration_units/legacy_scoped_analysis.f90 `

It intentionally retains formatted `WRITE` in `print_results`. The following
requests succeed independently:

```bash
fpy-migrate build-ir samples/migration_units/legacy_scoped_analysis.f90 \
  --procedure init_geometry --output build/init_geometry.ir.json

fpy-migrate build-ir samples/migration_units/legacy_scoped_analysis.f90 \
  --procedure solve_reynolds --output build/solve_reynolds.ir.json

fpy-migrate build-ir samples/migration_units/legacy_scoped_analysis.f90 \
  --procedure compute_metrics --output build/compute_metrics.ir.json
```

The fixture also contains a supported `run_numeric` root that calls the three
numerical procedures but not `print_results`. Its generated Python result is:

- iterations: `173`
- residual: `9.324363503537825e-11`
- load: `2.607151788568037`
- maximum pressure: `3.1797719040494443`
- minimum film: `0.4`
- friction: `7.853981633974483`

The largest scalar difference from the compiled Fortran reference is
`4.440892098500626e-15`.

The following remain deliberately blocked:

- whole-file strict construction, because `print_results` is selected;
- selecting `print_results` directly;
- selecting `run_analysis`, because its reachable closure includes
  `print_results`.

## Additional safety tests

The milestone adds tests proving that:

- an unreachable unresolved external call does not block an unrelated selected
  root;
- the same unresolved external call blocks strict whole-project construction;
- a COMMON rank/shape mismatch in an unreachable procedure still blocks the
  selected root;
- dependency-first ordering remains stable with an unsupported sibling;
- CLI `translate --procedure solve_reynolds` emits Python without including
  `print_results`.

## Test result

The complete repository now collects 96 tests:

- 66 non-integration tests passed;
- 29 compiler-heavy integration tests passed in isolated processes;
- 1 normalization test was skipped because `findent` was not on the active
  `PATH`.

The existing Python/Cython/Fortran solver, state migration, partial-loop,
profiling, economics, and distribution tests all remain green.

## Current limitation and next step

The lightweight pass inventories main programs but does not yet generate a
Python application entrypoint from them. Formatted `WRITE` also remains outside
the numerical code generator. Milestone 22 will introduce generated Python
orchestration and an explicit Python adapter boundary for unsupported I/O such
as `print_results`.
