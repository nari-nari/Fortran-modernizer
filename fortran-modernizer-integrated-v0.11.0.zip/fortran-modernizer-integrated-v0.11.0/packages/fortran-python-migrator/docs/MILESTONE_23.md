# Milestone 23: full end-to-end journal-bearing acceptance

Milestone 23 turns the supplied runnable journal-bearing program into a formal
end-to-end acceptance fixture. The gate compares source identity, refactoring
handoff evidence, the original fixed-form program, the normalized free-form
program, and every generated numerical backend before migration is accepted.

## Scope

The fixture is stored under `samples/e2e/journal_bearing/` and contains:

- the original fixed-form source and its two `INCLUDE` files;
- the normalized free-form source used by the migration tool;
- a read-only Python replacement for `PRINT_RESULTS`;
- a canonical handoff fixture containing procedures, symbols, calls, COMMON
  storage positions, and source fingerprints.

The handoff is deliberately labelled as a controlled fixture. It defines the
contract expected from the separate refactoring tool; it is not evidence that a
particular production version of that tool emitted this exact file.

## Command

```bash
fpy-migrate verify-e2e \
  samples/e2e/journal_bearing/legacy \
  samples/e2e/journal_bearing/normalized/journal_bearing_normalized.f90 \
  --program journal_bearing_legacy \
  --adapter-config samples/e2e/journal_bearing/adapters/config.json \
  --handoff samples/e2e/journal_bearing/refactor_handoff.json \
  --handoff-procedure run_numeric \
  --build-directory build/journal_bearing_e2e \
  --output reports/journal_bearing_e2e.json
```

The command returns success only after all gates below pass.

## Acceptance gates

1. Recompute aggregate SHA-256 fingerprints for the legacy source set and the
   normalized source and compare them with the handoff.
2. Cross-check the normalized source against the handoff for program units,
   symbols, argument order, calls, and COMMON storage positions.
3. Run the migration intake against the unnormalized fixed-form source and
   require it to remain `BLOCKED`.
4. Prove that intentional type, rank, COMMON-position, and source-fingerprint
   mismatches are rejected as `BLOCKED`.
5. Compile and run the original fixed-form source with a verification driver.
6. Compile and run the normalized free-form source with an equivalent driver.
7. Require original and normalized Fortran to match exactly for this fixture.
8. Build the generated orchestration application and execute Python, safe
   Cython, optimized Cython, and generated Fortran backends.
9. Compare integer results exactly, floating scalars and full arrays with the
   declared tolerance, and reject NaN or infinity.
10. Validate the final report against `schemas/e2e_acceptance.schema.json`.

## Full-state contract

The generated application now exposes `run_with_state()` in addition to the
existing `main()` API. The CLI can write an NPZ state snapshot with
`--state-output`. This is an acceptance-only observation interface; normal
application callers can continue using `main()`.

The fixture compares:

- `iterations` exactly;
- `residual`, `load`, `pmax`, `hmin`, and `friction`;
- pressure `P`, shape `(36, 17)`;
- film thickness `H`, shape `(36,)`;
- angular coordinates `THETA`, shape `(36,)`;
- finite-value status for every scalar and array.

Default tolerances are `rtol=1e-12` and `atol=1e-13`.

## Verified result

The original and normalized Fortran snapshots are identical, including every
array element. All generated backends converge in 173 iterations.

Maximum absolute pressure-array differences from the original Fortran baseline:

| Backend | Maximum absolute difference |
|---|---:|
| Python | `6.217248937900877e-15` |
| safe Cython | `6.217248937900877e-15` |
| optimized Cython | `6.217248937900877e-15` |
| generated Fortran | `1.3322676295501878e-15` |

All scalar and array comparisons pass. The four intentional negative controls
are observed as `BLOCKED`.

## Test execution note

The repository collects 105 pytest items. The normal hosted run has:

- 73 non-integration tests passed;
- 30 compiler-heavy integration tests executed in isolated interpreter shards;
- one `findent` test skipped when the executable is absent from `PATH`;
- one very slow E2E pytest wrapper kept opt-in because nested native builds can
  stall during hosted pytest process teardown.

The exact E2E implementation used by that wrapper was run independently and
produced a schema-valid `PASS` report. `scripts/test_all.sh` runs this independent
acceptance gate after the standard pytest shards.

## Remaining boundary

This milestone proves the controlled sample path. It does not prove that the
current separate refactoring tool emits the fixture handoff, nor that the
company's production lubrication code is supported. Those require the real
refactoring artifact and sanitized production inputs in Milestone 24.
