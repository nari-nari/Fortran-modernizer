# Milestone 16 — WSL development and Windows standalone packaging kit

## Objective

Add a reproducible packaging boundary after profile/economics-driven hybrid
code generation:

1. keep WSL/Linux as the normal migration and verification environment;
2. remove Linux-specific compiled extensions from a portable source kit;
3. rebuild Cython extensions on the target OS;
4. produce a Windows x64 Nuitka standalone-directory build script;
5. inventory third-party package licenses on the target build machine;
6. run a known-case self-check before and after packaging.

## New CLI

```bash
fpy-migrate prepare-distribution \
  build/hybrid/hybrid_project_manifest.json \
  --app-adapter samples/package_apps/partial_hybrid_cli.py \
  --output-directory build/windows-kit \
  --app-name lubrication_hybrid \
  --target windows-nuitka
```

```bash
fpy-migrate validate-distribution build/windows-kit
```

## Source-only kit

The preparation step copies the generated hybrid project while excluding:

- `.so`, `.pyd`, `.dll`, `.dylib`;
- object/static-library files;
- generated C files;
- `__pycache__` and compiler temporary directories.

Every selected safe and optimized Cython source is recorded in
`distribution_manifest.json` with its target module name and target-local build
directory. The target machine therefore recompiles `.pyd` files rather than
attempting to reuse Linux `.so` files.

## Generated files

- `launcher.py`: common CLI and `--self-check` entry point;
- `tools/build_native.py`: platform-native Cython compiler driver;
- `tools/generate_notices.py`: installed-package inventory and license-file copier;
- `build_wsl.sh`: Linux/WSL rebuild and self-check;
- `build_windows.ps1`: Windows native build and Nuitka standalone packaging;
- `run_windows.bat`: final executable launcher;
- `required_wheels.json`: offline wheel checklist;
- `requirements-build.txt` and `requirements-runtime.txt`;
- `README_DISTRIBUTION.md`.

## App adapter contract

The user-facing application is separated from generated solver internals. An
adapter supplies:

```python
def run(runtime, argv: list[str]) -> int: ...
```

and optionally:

```python
def self_check(runtime) -> dict[str, object]: ...
```

The sample adapter runs a known 12-point lubrication-state case through Python,
safe Cython, and optimized Cython.

## Cross-platform extension lookup

Generated hybrid runtimes, state wrappers, and partial-loop runtimes no longer
rely exclusively on a Python-version- and OS-specific extension filename. If
the recorded Linux `.so` path is absent, the loader searches for the module
using the active interpreter's extension suffixes. This permits a Windows
`.pyd` rebuilt from the same generated Cython source to be loaded without
rewriting the generated numerical code.

## Linux/WSL verification

A clean source kit was generated outside the repository, then:

1. safe and optimized Cython modules were rebuilt;
2. the package license inventory was generated;
3. `launcher.py --self-check` was run;
4. a normal optimized-Cython application run wrote JSON output.

Self-check result: `PASS`.

All three numerical backends produced:

- total pressure: `83.1`;
- peak pressure: `16.998428289111413`.

The generated target-native extensions in the recorded Linux check were:

- safe Cython: 859,240 bytes;
- optimized Cython: 1,102,960 bytes.

These Linux sizes are not predictions for Windows `.pyd` files.

## Windows build design

`build_windows.ps1`:

1. creates a Windows virtual environment;
2. installs from `wheelhouse/` when wheels are supplied, otherwise uses the
   configured package index;
3. builds the selected Cython sources with MSVC optimization;
4. runs the source-tree self-check;
5. compiles the launcher with Nuitka `--mode=standalone`;
6. copies the generated hybrid payload, Windows `.pyd` modules, notices, and
   license files next to the executable;
7. runs the packaged executable self-check.

The initial Windows target deliberately uses standalone-directory mode, not
one-file mode. Generated Python orchestration sources remain visible beside the
executable; only selected numerical kernels are native extensions. This is a
distribution mechanism, not yet an IP-protection boundary.

## License handling

The target build generates:

- `third_party_inventory.json`;
- `THIRD_PARTY_NOTICES.generated.md`;
- copied package license/notice files under `licenses/`.

The current standard Nuitka distribution uses AGPLv3 with a runtime exception
for created binaries. That exception is intended to prevent the user's code or
created binaries from becoming subject to AGPL solely because Nuitka compiled
them. Nevertheless, the exact downloaded version and organization-specific
commercial compliance must be reviewed before release.

## Offline Windows prerequisites

The kit requests compatible Windows x86-64 wheels for:

- NumPy;
- Cython;
- setuptools;
- wheel;
- Nuitka;
- ordered-set;
- zstandard.

The Windows build machine also needs an appropriate CPython installation and
Microsoft C/C++ Build Tools. The final target PC should not need Python or a C
compiler after the standalone directory has been built and validated.

## Validation boundary

The current environment cannot run Windows or MSVC. Therefore:

- source-kit generation: verified;
- schema/manual validation: verified;
- Linux rebuild from the source kit: verified;
- all-backend application self-check: verified;
- PowerShell script generation: verified by inspection/tests;
- actual Windows `.pyd` compilation: not run;
- actual Nuitka Windows standalone build: not run;
- clean Windows-without-Python launch: not run.

Those last three checks must be performed on Windows before claiming a finished
Windows binary distribution.

## Test status

- non-integration tests: 46 passed;
- compiler-heavy integration tests: 24 passed;
- total: 70 passed.
