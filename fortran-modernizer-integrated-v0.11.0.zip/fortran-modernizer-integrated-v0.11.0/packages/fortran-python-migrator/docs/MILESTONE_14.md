# Milestone 14: multi-case profile aggregation

## Objective

Milestone 13 selected Cython kernels from one measured Python-reference workload.
Milestone 14 extends that selection to a suite of representative cases so that a
kernel is not selected or rejected because of one operating condition alone.

The implementation keeps the existing safety order:

1. static extraction eligibility;
2. readable generated Python;
3. per-case Python-reference profiling;
4. profile aggregation and explicit thresholds;
5. selective Cython generation;
6. complete-state comparison with compiled Fortran.

## New profile-suite model

`HybridProfileSuiteReport` embeds the original single-case reports and adds one
aggregated sample per candidate. The following values are retained:

- number of configured cases;
- number and fraction of cases in which the candidate was observed;
- summed call count and self time;
- weighted mean self time;
- mean candidate share, with missing cases treated as zero;
- maximum candidate share across cases;
- case-weighted candidate share;
- corresponding wall-time shares;
- the complete per-case measurements and weights.

The suite is validated by `schemas/hybrid_profile_suite.schema.json`.

## Commands

Profile three cases directly:

```bash
fpy-migrate profile-hybrid-suite \
  samples/migration_projects/partial_hybrid_project \
  --procedure run_partial_hybrid \
  --case standard=samples/profile_workloads/partial_hybrid_standard.py \
  --case update-heavy=samples/profile_workloads/partial_hybrid_update_heavy.py \
  --case postprocess-heavy=samples/profile_workloads/partial_hybrid_postprocess_heavy.py \
  --case-weight standard=0.5 \
  --case-weight update-heavy=0.3 \
  --case-weight postprocess-heavy=0.2 \
  --build-directory build/profile_suite \
  --output build/hybrid_profile_suite.json
```

Existing single-case reports can instead be aggregated with
`aggregate-hybrid-profiles`.

Use the suite for selection:

```bash
fpy-migrate analyze-hybrid-project \
  samples/migration_projects/partial_hybrid_project \
  --procedure run_partial_hybrid \
  --profile-report build/hybrid_profile_suite.json \
  --min-profile-share 0.35 \
  --min-profile-mean-share 0.40 \
  --min-profile-max-share 0.80 \
  --min-profile-cases 3 \
  --output build/multi_case_plan.json
```

The same report and thresholds are passed to `build-hybrid-project`.

## Selection semantics

For a suite report:

- `--min-profile-share` applies to the case-weighted candidate share;
- `--min-profile-mean-share` applies to the arithmetic mean across all cases;
- `--min-profile-max-share` requires importance in at least one case;
- `--min-profile-cases` is a hard coverage requirement;
- `--min-profile-time-ms` applies to weighted mean self time;
- `--max-native-kernels` is applied after threshold filtering.

If no candidate meets the share/time thresholds, the hottest candidate may still
be retained as the conservative fallback, but only if it satisfies the minimum
case-count requirement.

## Recorded representative suite

The milestone fixture uses three cases:

| Case | Weight | Purpose |
|---|---:|---|
| standard | 0.5 | balanced initialization, one update, one summary |
| update-heavy | 0.3 | repeated pressure-update loop |
| postprocess-heavy | 0.2 | repeated summary/post-processing |

The measured aggregate was:

| Candidate | Weighted share | Mean share | Maximum share | Cases |
|---|---:|---:|---:|---:|
| internal update loop | 43.747% | 42.298% | 96.565% | 3/3 |
| summarization | 33.371% | 41.735% | 96.615% | 3/3 |
| initialization | 22.882% | 15.966% | 43.606% | 3/3 |

With thresholds 35% weighted, 40% mean, 80% maximum, and 3 observed cases, only
the internal update loop was selected. Initialization and summarization remained
readable Python.

## Numerical equivalence

The selected build was compared with `gfortran -O2`. For Python, safe Cython, and
optimized Cython:

- pressure maximum absolute difference: `0.0`;
- film-thickness maximum absolute difference: `0.0`;
- total-pressure difference: `0.0`;
- peak-pressure difference: `0.0`;
- shared relaxation-factor difference: `0.0`.

## Tests

The complete suite contains 65 tests:

- 44 non-integration tests;
- 21 compiler-heavy integration tests.

Compiler-heavy project builds are run in separate Python processes to avoid
retaining multiple generated extension graphs in one interpreter.

## Deliberate limitations

- Case weights are supplied by the user; the tool does not infer operating
  probabilities.
- Profiles must have the same root procedure and source-file set.
- Nested profile suites are rejected.
- Aggregation currently uses weighted means, means, maxima, and case coverage;
  percentile and risk-based policies are not yet implemented.
- Timing remains machine-specific and is used for selection, not as a portable
  performance guarantee.
