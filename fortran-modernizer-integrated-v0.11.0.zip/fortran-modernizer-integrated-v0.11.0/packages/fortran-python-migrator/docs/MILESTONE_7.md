# Milestone 7: complete analysis results and post-processing

## Scope

This milestone extends the generated iterative pressure solver with numerical
post-processing. Firedrake, FEM conversion, and Windows packaging remain outside
this milestone.

The selected root procedure is `solve_analysis`. Its transitive dependency set
contains:

- `compute_film`;
- `periodic_neighbors`;
- `sor_sweep`;
- `solve_pressure`;
- `compute_postprocess`;
- `solve_analysis`.

The same Fortran source is converted into readable Python, safe Cython, and
optimised Cython. A separately compiled `gfortran -O3` executable remains the
reference backend.

## Added analysis quantities

The post-processing routine computes:

- maximum pressure;
- minimum film thickness;
- dimensionless load components in the cosine and sine directions;
- dimensionless load magnitude;
- a dimensionless friction estimate from Couette shear plus the circumferential
  pressure-gradient contribution;
- a complementarity residual for the projected, non-negative-pressure Reynolds
  discretisation.

The load components use the same `theta-z` quadrature order in all backends:

```text
load_x = sum(p * cos(theta) * dtheta * dz)
load_y = sum(p * sin(theta) * dtheta * dz)
load_magnitude = sqrt(load_x**2 + load_y**2)
```

The friction quantity is deliberately named `dimensionless_friction`. It is a
verification quantity for this migration fixture, not a dimensional bearing
friction prediction.

## Complementarity residual

A simple absolute PDE residual is not appropriate in cells where the projected
SOR update enforces `pressure = 0`. Such cavitated cells may satisfy the
non-negative-pressure inequality while having a non-zero equality residual.

For a discrete residual `F` and pressure `p`, the implemented diagnostic is:

```text
p > 0 : abs(F)
p = 0 : max(0, -F)
```

The reported `equation_residual` is the maximum of this quantity. This makes the
residual consistent with the pressure projection used by the solver.

## Commands

```bash
fpy-migrate build-analysis \
  samples/migration_units/lubrication_analysis.f90 \
  --procedure solve_analysis \
  --fortran-driver samples/migration_units/lubrication_analysis_driver.f90 \
  --build-directory build/lubrication_analysis

fpy-migrate run-analysis \
  build/lubrication_analysis/run_analysis_python.toml

fpy-migrate run-analysis \
  build/lubrication_analysis/run_analysis_cython-optimized.toml

fpy-migrate run-analysis \
  build/lubrication_analysis/run_analysis_fortran.toml
```

Every backend writes the same contract:

```text
output_directory/
  summary.json
  pressure.csv
  film.csv
```

## Numerical verification

Standard case:

```text
ntheta = 32
nz = 9
eccentricity = 0.60
relaxation_factor = 1.35
tolerance = 1.0e-11
max_iterations = 20000
axial_scale = 0.20
```

All four backends converge in 163 iterations. The optimised Cython summary is:

```text
update_residual          = 9.33053634355474e-12
equation_residual        = 1.2130813511758072e-09
load_x                    = -1.7295996417911994
load_y                    = 2.298398527140976
load_magnitude            = 2.8764823501019525
dimensionless_friction    = 7.557331496304628
maximum_pressure          = 3.480597572352536
minimum_film_thickness    = 0.4
```

Compared with Fortran:

- maximum absolute pressure difference: `1.3322676295501878e-15`;
- maximum absolute film difference: `2.220446049250313e-16`;
- load, friction, residual, and extrema differences are at floating-point
  roundoff scale;
- generated Python, safe Cython, and optimised Cython produce identical arrays
  and summaries.

The detailed report is
`reports/milestone7/analysis_equivalence.json`.

## Cython candidate analysis

`compute_postprocess` is classified `AUTO` with score 100 because it contains
three loops, a maximum loop depth of two, rank-2 numerical arrays, and one
resolved local call. `solve_analysis` itself is `REVIEW_REQUIRED` as a standalone
kernel because it primarily orchestrates calls and contains no loop. It is still
compiled as part of the complete Cython backend.

## Tests

The repository now contains 35 tests. In this container, the compiler benchmark
is run separately from the other tests to avoid repeatedly compiling many
extension modules in one pytest process:

```text
34 passed, 1 deselected
1 passed
```

No functional test is skipped by this split.

## Remaining work

- map COMMON/module state into explicit Python state objects;
- support array sections and local automatic arrays;
- process external procedures distributed across multiple source files;
- add production-case input/output mapping;
- build Windows Cython extensions and package the application for Python-free
  Windows deployment.
