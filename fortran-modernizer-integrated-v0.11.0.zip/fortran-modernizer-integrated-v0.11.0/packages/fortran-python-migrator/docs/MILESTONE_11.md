# Milestone 11: partial top-level loop extraction

## Goal

Compile only one performance-critical loop while preserving scalar setup,
state ownership, reduction logic, and other teardown statements in readable
Python. This closes the gap between whole-procedure state-kernel extraction and
real procedures that mix orchestration with one hot loop.

## Implemented workflow

```text
Fortran procedure
    -> Migration IR with source spans
    -> choose one top-level DO loop by 1-based index
    -> conservative access and lifetime analysis
       -> explicit arguments/state bindings for the selected loop
       -> loop-local scalar temporaries retained inside the kernel
       -> unsafe local-array/call cases blocked
    -> stateless loop-kernel IR
       -> readable Python kernel
       -> safety-checked Cython kernel
       -> optimized Cython kernel
    -> transformed Python wrapper
       -> original pre-loop statements
       -> backend-dispatched loop call
       -> original post-loop statements
```

## CLI

Analyze a loop without compiling:

```bash
fpy-migrate analyze-partial-loop \
  samples/migration_units/partial_loop_analysis.f90 \
  --procedure run_partial_loop \
  --loop-index 1 \
  --output build/partial_loop_extraction.json \
  --ir-output build/partial_loop_kernel.ir.json
```

Build a movable bundle:

```bash
fpy-migrate build-partial-loop \
  samples/migration_units/partial_loop_analysis.f90 \
  --procedure run_partial_loop \
  --loop-index 1 \
  --build-directory build/partial_loop_bundle \
  --default-backend cython-optimized
```

The bundle contains:

```text
partial_loop_extraction.json
partial_loop_manifest.json
partial_wrapper.ir.json
partial_wrapper_reference.py
partial_loop_runtime.py
run_partial_loop_loop_1_kernel.ir.json
run_partial_loop_loop_1_kernel_python.py
run_partial_loop_loop_1_kernel_cython_safe.py
run_partial_loop_loop_1_kernel_cython_optimized.py
compiled safe/optimized Cython extensions
```

All manifest paths are relative to the bundle root.

## Validation fixture

The fixture `run_partial_loop` contains:

1. Python-side scalar setup:
   `bias = scale * relaxation_factor`;
2. selected pressure-update loop;
3. Python-side initialization of reduction outputs;
4. a second reduction loop that computes total and peak pressure;
5. final scalar adjustment.

Only step 2 is extracted. The selected kernel signature is:

```text
(n, bias, pressure, film)
```

with intents:

| Argument | Intent | Origin |
|---|---|---|
| `n` | `in` | explicit Fortran argument |
| `bias` | `in` | Python-side local setup value |
| `pressure` | `inout` | canonical `/FIELD/` state array |
| `film` | `in` | canonical `/FIELD/` state array |

The Python state dataclass remains outside Cython. The runtime extracts NumPy
arrays/scalars, invokes the selected loop backend, normalizes typed-memoryview
results to NumPy arrays, and resumes Python post-processing.

## Safety rules

The initial partial extractor deliberately supports one top-level loop selected
explicitly. It blocks:

- calls inside the selected loop;
- local arrays referenced by the loop;
- local scalars read before an unconditional pre-loop definition;
- an out-of-range loop index;
- implicit nested-region selection.

For assignment access analysis, the right-hand side is processed before the
target. Therefore `x = x + 1` becomes `inout`, while a bridge local first defined
entirely by the kernel may become `out` or remain a kernel-local temporary.

## Numerical verification

The complete state and outputs were compared against compiled `gfortran -O2`
Fortran for three generated backends.

| Backend | Pressure max difference | Film max difference | Total difference | Peak difference |
|---|---:|---:|---:|---:|
| Python | `0.0` | `0.0` | `0.0` | `0.0` |
| safe Cython | `0.0` | `0.0` | `0.0` | `0.0` |
| optimized Cython | `0.0` | `0.0` | `0.0` | `0.0` |

The scalar setup and second reduction loop are therefore verified indirectly as
part of the whole procedure, not just through a standalone loop comparison.

## Test status

The suite contains 56 tests:

- non-integration: `38 passed`;
- integration/equivalence/benchmark: `18 passed` in compiler-safe shards;
- total: `56 passed`.

The two project-level hybrid integration tests remain separate test nodes to
avoid retaining several complete generated-extension graphs in one interpreter.

## Generated Copilot skill

`.github/skills/extract-partial-loop/SKILL.md` requires Copilot to select the
loop explicitly, review the bridge variables and intents, preserve statement
order, build all three backends, and compare the complete state with Fortran.

## Current limitations

- only top-level `DO` loops can be selected;
- one loop is extracted per bundle;
- calls inside the selected loop are blocked;
- local arrays are blocked;
- conditional pre-loop definitions are not considered definite assignments;
- automatic profile-guided loop selection is not implemented;
- project-level hybrid generation does not yet use partial-loop bundles for
  procedures currently classified Python-only.

## Next recommended milestone

Integrate partial-loop extraction into project-level hybrid planning. Procedures
that are not whole-body kernel candidates should be inspected for eligible
internal loops and built as partial-loop bundles, while pure orchestration
procedures remain Python-only.
