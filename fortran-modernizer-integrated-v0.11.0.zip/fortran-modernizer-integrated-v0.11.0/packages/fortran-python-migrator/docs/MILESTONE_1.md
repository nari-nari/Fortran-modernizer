# Milestone 1: verified migration foundation

Implemented on 2026-08-02.

## Scope completed

- Project/package skeleton and WSL-oriented scripts.
- Offline installation of the supplied `fparser 0.2.4` and `findent 4.3.6` wheels.
- Versioned JSON Schema for hand-off from the separate Fortran refactoring tool.
- fparser-based source-tree assessment with `READY`, `REVIEW_REQUIRED`, and `BLOCKED` states.
- A finite-difference journal-bearing lubrication sample with matching:
  - modern Fortran;
  - fixed-form legacy-style Fortran using COMMON and implicit typing;
  - readable Python reference implementation;
  - compiled Cython implementation of the sequential SOR loop.
- Common result files for scalar values and pressure fields.
- Automated Fortran/Python/Cython numerical comparison.
- Initial GitHub Copilot instructions, custom agents, prompts, and skills.

## Verification result

- pytest: 7 tests passed.
- Modern Fortran vs legacy Fortran pressure field: exact match.
- Modern Fortran vs Cython pressure field: exact match.
- Modern Fortran vs Python maximum absolute pressure difference:
  `3.552713678800501e-15`.

See `reports/verification/` for machine-readable reports.

## Deliberate limitations of this milestone

- No general-purpose Fortran-to-Python code generator yet.
- The Migration IR schema is only a skeleton.
- COMMON/symbol/call-graph data are not yet consumed beyond schema validation.
- Windows Cython/Nuitka packaging is not yet implemented.
- F2PY procedure-level comparison is deferred; current Fortran comparison uses executable output.

## Next implementation milestone

1. Enrich the hand-off schema with program-unit, symbol, COMMON, call, and source-map fields.
2. Build Migration IR for declarations, assignments, expressions, IF, DO, and CALL.
3. Generate Python for one leaf procedure from the sample.
4. Compare generated Python against both the hand-written Python reference and Fortran.
5. Add automatic identification of Cython candidate loops.
