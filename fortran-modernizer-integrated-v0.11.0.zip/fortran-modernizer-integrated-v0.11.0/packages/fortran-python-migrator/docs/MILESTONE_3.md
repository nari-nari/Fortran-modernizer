# Milestone 3: verified low-dependency SOR sweep migration

Implemented on 2026-08-02.

## Scope completed

- Extended Migration IR with:
  - `IfIR` for block and single-line conditionals;
  - `CallIR` for project-local subroutine calls;
  - unary expressions;
  - logical and relational operators;
  - assumed-shape dimensions represented explicitly as unknown extents.
- Added parsing and Python generation for:
  - `IF/ELSE`;
  - nested/else-if representation;
  - single-line `IF`;
  - comparison operators;
  - `.AND.`, `.OR.`, and `.NOT.`;
  - logical literals;
  - rank-2 array references;
  - rank-1/rank-2 assumed-shape arguments;
  - `CALL` statements with positional arguments.
- Added local call-graph dependency resolution. Selecting `sor_sweep`
  automatically includes `periodic_neighbors` before the caller in generated
  Python.
- Added call-signature validation:
  - called procedure must be available in the parsed source;
  - actual/dummy argument counts must match;
  - output actual arguments must be assignable.
- Converted Fortran output arguments into Python return assignments.
- Added the migration fixture `sor_kernel_mod` containing:
  - an `IF/ELSE` periodic-neighbour helper;
  - a two-dimensional, in-place, sequential SOR sweep;
  - a helper `CALL`;
  - clipping and residual-update conditionals;
  - logical conditions;
  - assumed-shape arrays.
- Added a deliberately unsupported `SELECT CASE` fixture to preserve explicit
  `BLOCKED` behaviour.
- Updated JSON Schema, README, tests, and Copilot migration guidance.

## Verification result

- Full pytest suite: 20 tests passed.
- Generated Python and compiled Fortran were compared for a 12 x 7 pressure
  field after one sequential SOR sweep:
  - Fortran update residual: `2.0868043280752855`;
  - generated-Python update residual: `2.0868043280752855`;
  - residual absolute difference: `0.0`;
  - maximum absolute pressure difference: `4.440892098500626e-16`;
  - maximum relative pressure difference: `2.732450981211243e-15`;
  - result: PASS.
- Migration IR validates against `schemas/migration_ir.schema.json`.
- `SELECT CASE` is rejected with `BLOCKED` and a `Case_Construct` diagnostic.

## Main generated artefacts

- `reports/milestone3/sor_sweep.ir.json`
- `generated/milestone3/sor_sweep.py`
- `reports/milestone3/generated_sor_fortran_equivalence.json`
- `reports/milestone3/blocked_example.txt`
- `reports/milestone3/pytest.txt`

## Deliberate limitations

The milestone translates a single sweep rather than the entire iterative
solver. It does not yet support:

- `EXIT` and full convergence-loop translation;
- `GOTO` or labelled DO loops;
- derived-type component access;
- module/global-state mapping;
- external calls located in another source file;
- array slices;
- Cython code generation from Migration IR.

## Recommended milestone 4

1. Add a kernel-candidate analysis report based on loop depth, numeric-only
   operations, I/O absence, and side-effect boundaries.
2. Generate Cython Pure Python Mode code for the verified `sor_sweep` IR.
3. Keep bounds/wraparound checks enabled in the first Cython build.
4. Compare Fortran, generated Python, and generated Cython for the same sweep.
5. Add a backend adapter interface so the generated Python and Cython kernels
   can be selected with the same call contract.
