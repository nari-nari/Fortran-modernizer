# Milestone 4: generated safe Cython kernel

## Goal

Extend the verified Fortran-to-Python path with a generated Cython implementation
for a sequential finite-difference kernel. The milestone keeps all Cython safety
checks enabled and requires numerical agreement among Fortran, generated Python,
and generated Cython before any performance optimisation is attempted.

## Implemented components

### Kernel candidate analysis

`fpy-migrate analyze-kernels` now evaluates each procedure in a selected
Migration IR using:

- loop count;
- maximum nested-loop depth;
- maximum array rank;
- resolved local calls;
- numeric/logical-only symbol types;
- existing Migration IR safety status.

Each procedure is classified as `AUTO`, `REVIEW_REQUIRED`, or `BLOCKED` and is
assigned an explanatory score. In the SOR fixture:

- `sor_sweep` is `AUTO`, score 100, with two nested loops and rank-2 arrays;
- `periodic_neighbors` is `REVIEW_REQUIRED` as a standalone target because it
  has no loop, although it is included and compiled as a dependency.

### Cython Pure Python Mode generation

Migration IR can now generate a `.py` Cython source containing:

- `cython.int`, `cython.double`, and `cython.bint` scalar types;
- typed rank-1 and rank-2 memoryviews;
- typed local loop indices and scalar temporaries;
- the same one-based-to-zero-based index conversion as the Python generator;
- local procedure-call conversion and output-return mapping;
- source-file and source-line comments.

The generated version intentionally uses:

```text
boundscheck=True
wraparound=True
initializedcheck=True
cdivision=True
```

This is the safety baseline, not the final optimised kernel.

### Isolated generated-extension build

`fpy-migrate compile-cython` creates a temporary build script and compiles a
generated Pure Python Mode source into a platform-specific extension module.
The main project `setup.py` remains independent from generated kernels.

### Common runtime backend

`load_generated_backend` loads either a generated `.py` module or a compiled
Cython extension and calls the same named procedure. Cython memoryview returns
are converted to zero-copy NumPy views, while tuples and scalars retain the same
shape as the Python backend result.

## SOR verification case

The verified kernel performs one in-place SOR pressure sweep on a `12 x 7`
field, including:

- periodic circumferential neighbours;
- nested sequential updates;
- non-negative pressure clipping;
- an `intent(inout)` rank-2 array;
- maximum update-residual evaluation;
- a local subroutine call.

### Numerical results

| Comparison | Residual difference | Maximum pressure difference |
|---|---:|---:|
| Generated Python vs Fortran | `0.0` | `4.440892098500626e-16` |
| Generated safe Cython vs Fortran | `0.0` | `4.440892098500626e-16` |
| Generated Python vs generated safe Cython | `0.0` | `0.0` |

The resulting pressure difference against Fortran is at double-precision
rounding level. The generated Python and generated safe Cython outputs are
identical for the verification case.

## Test status

```text
25 passed
```

The full journal-bearing sample continues to pass for modern Fortran, legacy
Fortran, handwritten Python, and handwritten Cython.

## New CLI workflow

```bash
fpy-migrate analyze-kernels \
  samples/migration_units/sor_sweep.f90 \
  --procedure sor_sweep \
  --output build/sor_sweep.candidates.json

fpy-migrate translate-cython \
  samples/migration_units/sor_sweep.f90 \
  --procedure sor_sweep \
  --ir-output build/sor_sweep.cython.ir.json \
  --candidate-output build/sor_sweep.candidates.json \
  --output generated/sor_sweep_cython.py

fpy-migrate compile-cython \
  generated/sor_sweep_cython.py \
  --module-name generated_sor_cython \
  --build-directory build/generated_sor_cython
```

## Safety limitations retained

This milestone does not yet:

- disable array bounds or wraparound checks;
- release the GIL;
- infer memory contiguity requirements;
- combine helper procedures into C-only call paths;
- generate local automatic arrays;
- benchmark or tune the generated kernel;
- map COMMON/module global state;
- translate the complete iterative solver control flow.

## Recommended next milestone

The next stage should measure the generated safe Cython kernel against generated
Python and optimised Fortran over representative grid sizes. After profiling,
one optimisation should be introduced at a time:

1. specialise array memory-layout contracts;
2. remove Python-level helper-call overhead where justified;
3. disable bounds checking only after explicit index-range validation;
4. consider `nogil` only for a fully Python-object-free kernel;
5. preserve a safety build and run both safety and optimised equivalence tests.
