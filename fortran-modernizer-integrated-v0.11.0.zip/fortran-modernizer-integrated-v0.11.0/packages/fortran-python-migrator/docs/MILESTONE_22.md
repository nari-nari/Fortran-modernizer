# Milestone 22: generated main-program orchestration and Python adapters

## Objective

Generate a runnable Python application from a safe Fortran main-program call
sequence while keeping unsupported formatted reporting outside the numerical
Migration IR. Numerical procedures continue to use the existing Python, safe
Cython, optimized Cython, and optional generated Fortran backend registry.

## Supported main-program subset

Milestone 22 deliberately supports a narrow orchestration subset:

- one explicitly selected Fortran main program;
- top-level `CALL` statements only;
- migration-ready numerical calls first;
- one or more configured Python adapter calls as a trailing suffix;
- scalar adapter arguments that were assigned by preceding numerical calls;
- read-only adapters with an exact positional Python signature.

The tool stops rather than guessing when it finds assignments, control flow,
I/O interleaved with later numerical work, direct adapter access to shared
state, array adapter arguments, unresolved calls, or adapter writes.

## Commands

Analyze the main-program boundary without compiling native code:

```bash
fpy-migrate analyze-orchestration \
  samples/migration_units/legacy_scoped_analysis.f90 \
  --program journal_bearing_legacy \
  --adapter-config samples/python_adapters/journal_bearing_adapter_config.json \
  --output build/orchestration_plan.json
```

Build the generated application and all four numerical backends:

```bash
fpy-migrate build-orchestration \
  samples/migration_units/legacy_scoped_analysis.f90 \
  --program journal_bearing_legacy \
  --adapter-config samples/python_adapters/journal_bearing_adapter_config.json \
  --build-directory build/journal_bearing_app \
  --default-backend python \
  --include-fortran
```

The generated application can then be run as:

```bash
python build/journal_bearing_app/application.py --backend python
python build/journal_bearing_app/application.py --backend cython-safe
python build/journal_bearing_app/application.py --backend cython-optimized
python build/journal_bearing_app/application.py --backend fortran
```

`--no-adapters --json` is available for machine-readable numerical regression
without formatted console output.

## Adapter contract

The adapter configuration is JSON Schema validated. The controlled sample uses:

```json
{
  "schema_version": "1.0",
  "adapters": {
    "print_results": {
      "source": "journal_bearing_adapters.py",
      "callable": "print_results",
      "arguments": [
        "iterations",
        "residual",
        "load",
        "pmax",
        "hmin",
        "friction"
      ],
      "mode": "read_only"
    }
  }
}
```

The adapter source is parsed with Python `ast` before generation. The callable
must exist, must not be asynchronous or variadic, and must have exactly the
configured positional argument names and order. The adapter source is copied
into the generated application bundle.

## Synthetic numerical root

The original main program is not put directly into the numerical Migration IR.
The tool generates a normalized Fortran subroutine containing only the numeric
call prefix. For the journal-bearing fixture this is equivalent to:

```fortran
subroutine program_journal_bearing_legacy_numeric( &
    iterations, residual, load, pmax, hmin, friction)
  implicit none
  ! PARAMETER, declarations, and COMMON layout retained
  call init_geometry
  call solve_reynolds(iterations, residual)
  call compute_metrics(load, pmax, hmin, friction)
end subroutine program_journal_bearing_legacy_numeric
```

The generated wrapper is added to a staged copy of the source project. The
Milestone-21 procedure-scoped builder then translates only this synthetic root
and its reachable numerical procedures. `print_results` remains in the source
for global COMMON inventory but is not lowered as numerical code.

The synthetic root is Python-only orchestration. Its numerical dependencies are
eligible for the existing native-kernel selection and backend registry.

## Generated application

The bundle contains:

- `application.py`: generated `main()` and command-line entrypoint;
- `orchestration_plan.json`;
- `orchestration_manifest.json`;
- the synthetic normalized Fortran wrapper;
- copied Python adapter modules;
- the complete hybrid numerical build under `hybrid/`.

`application.main()` creates the canonical shared-state dataclass, calls the
synthetic numerical root through the hybrid runtime, converts returned values to
an immutable `AnalysisResult`, invokes configured adapters when enabled, and
returns the result.

Backend selection does not alter adapter or orchestration code:

```python
result = main(backend="cython-optimized")
```

Per-procedure backend overrides are also forwarded to the hybrid registry.

## Refactoring-tool boundary

If a canonical refactoring handoff is supplied, it is checked against the
original numerical procedures during analysis. The generated synthetic wrapper
is not expected to exist in that upstream report, so the staged build does not
attempt to cross-check the synthetic unit itself. It is generated from the
already validated main-program declarations and call sequence.

## Numerical result

The controlled journal-bearing application was run through all four backends.
The compiled legacy Fortran reference is:

- iterations: `173`
- residual: `9.3243524013075785e-11`
- load: `2.6071517885680344`
- maximum pressure: `3.1797719040494399`
- minimum film: `0.4`
- friction: `7.8539816339744828`

Maximum scalar absolute differences were:

| Backend | Maximum difference |
|---|---:|
| Python | `4.440892098500626e-15` |
| safe Cython | `4.440892098500626e-15` |
| optimized Cython | `4.440892098500626e-15` |
| generated Fortran | `4.440892098500626e-16` |

All backends produced exactly 173 iterations. The Python adapter emitted the six
expected result lines without changing the numerical state.

## Schemas

Milestone 22 adds:

- `schemas/python_adapter_config.schema.json`;
- `schemas/orchestration_plan.schema.json`;
- `schemas/orchestration_manifest.schema.json`.

Generated plan and manifest files are validated before the build is reported as
successful.

## Tests

The repository now collects 102 tests:

- 71 non-integration tests pass;
- 1 normalization test is skipped when `findent` is absent from `PATH`;
- 30 compiler-heavy integration tests cover the existing backend suite plus the
  generated four-backend orchestration application.

The orchestration integration is run in a separate Python process so compiler
and dynamically loaded extension lifetimes cannot contaminate the main pytest
interpreter.

## Current limitations

Milestone 22 does not yet support:

- arbitrary executable statements in a main program;
- structured main-program IF/DO lowering;
- numerical calls after an adapter call;
- I/O adapters interleaved with solver iterations;
- adapters that write COMMON/module state;
- array-valued adapter arguments;
- automatic translation of general `FORMAT` statements;
- automatic reconstruction of arbitrary main-program local data flow.

These cases remain `BLOCKED` until an explicit lowering rule and regression test
are added.

## Next milestone

Milestone 23 will turn the journal-bearing sample into a complete acceptance
fixture with original and normalized Fortran baselines, full shared-state array
comparison, handoff gates, source fingerprints, intentional mismatch tests, and
one end-to-end verification command.
