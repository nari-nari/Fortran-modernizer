# Milestone 17: project-level optional Fortran kernel backend

## Goal

Complete the original hybrid-backend requirement by allowing each extracted
full state kernel or partial hot loop to run as compiled Fortran behind the same
Python state-object API used by generated Python and Cython backends.

The implementation must not reintroduce COMMON/module storage across the Python
boundary. Instead, it generates a C-interoperable Fortran procedure from the
canonical explicit-argument Migration IR.

## Implemented architecture

```text
Python orchestration and dataclass state
        |
        +-- generated Python kernel
        +-- safe Cython kernel
        +-- optimized Cython kernel
        +-- generated bind(C) Fortran kernel
                 |
                 +-- shared library
                 +-- generated ctypes adapter
```

The Fortran backend is opt-in. Existing builds do not invoke gfortran unless
`--include-fortran` is specified.

## CLI

```bash
fpy-migrate build-hybrid-project \
  samples/migration_projects/common_state_project \
  --procedure run_common_state \
  --include-fortran \
  --build-directory build/common_hybrid_fortran
```

A Fortran-default runtime is generated with:

```bash
fpy-migrate build-hybrid-project \
  samples/migration_projects/partial_hybrid_project \
  --procedure run_partial_hybrid \
  --include-fortran \
  --default-backend fortran \
  --build-directory build/partial_hybrid_fortran
```

The same option is available for standalone state-kernel and partial-loop
bundles:

```bash
fpy-migrate build-state-kernel ... --include-fortran
fpy-migrate build-partial-loop ... --include-fortran --default-backend fortran
```

## C ABI design

For each supported kernel, the generator creates a `bind(C)` subroutine.

- input scalars are passed with `value`;
- output and in/out scalars are passed by reference;
- arrays are passed as `c_ptr` plus explicit dimensions;
- `c_f_pointer` creates a Fortran pointer view;
- the Python wrapper uses `ctypes` and C-contiguous NumPy arrays;
- in/out arrays are copied back to the original NumPy object only when a
  contiguous staging array was required.

For rank-two and higher C-contiguous arrays, the generated Fortran pointer shape
and logical indices are reversed. This preserves the same logical element
access as generated Python/Cython without transposing the state representation.
A dedicated rank-two fixture verifies this contract.

## Safety restrictions

Generated Fortran kernels currently block:

- procedure calls inside the extracted body;
- local automatic arrays;
- unsupported scalar or array element types;
- assumed-shape `intent(out)` arrays whose allocation shape cannot be inferred;
- implicit conversion of incompatible hot-kernel array layouts.

Legacy COMMON/module state is never passed directly to ctypes. The existing
state extraction first canonicalizes aliases and produces explicit kernel
arguments.

## Manifest changes

Hybrid project manifest schema `1.5` includes:

- `default_backend`, now including `fortran`;
- `available_backends`, explicitly listing the generated runtime choices;
- child full-kernel and partial-loop manifests containing the generated Fortran
  source, shared library, wrapper, and module name.

All paths remain relative to the generated build root.

## Numerical verification

### Cross-file COMMON project

Three full state kernels were generated with all four backends. Compared with
the original `gfortran -O2` program:

- Python and both Cython modes matched all arrays and scalar values exactly;
- the all-Fortran generated-kernel run differed by at most
  `3.552713678800501e-15` in pressure and
  `2.220446049250313e-16` in film thickness;
- Python orchestration with only `advance_common_state` overridden to Fortran
  matched the original program exactly.

### Partial-loop project

Two full kernels and the internal update loop were generated. Compared with the
original Fortran program:

- all four uniform backends matched within double-precision roundoff;
- a Python-default runtime with only the partial update loop overridden to
  Fortran matched all arrays and scalars exactly;
- `default_backend=fortran` works when `--include-fortran` is present.

### Rank-two array contract

A generated two-dimensional in/out kernel was called with a C-contiguous NumPy
array. The Fortran and generated Python arrays and scalar reduction were exactly
identical.

See:

- `reports/milestone17/fortran_backend_equivalence.json`
- `reports/milestone17/common_fortran_backend_equivalence.json`
- `reports/milestone17/partial_fortran_backend_equivalence.json`

## Test status

The repository now contains 73 tests: 46 non-integration tests and 27
compiler-heavy integration tests.

During this milestone:

- all 46 non-integration tests passed;
- all 3 new Fortran-backend integration tests passed;
- all affected state-kernel, partial-loop, project-hybrid, profile-selection,
  economics-selection, and distribution-packaging integration tests passed in
  fresh-process shards;
- the single all-in-one compiler-heavy command exceeded the hosted environment
  wall-time while entering an unchanged complete-analysis test, so the relevant
  compiler tests were retained as separate shards in `scripts/test_all.sh`.

## Platform status

Verified:

- Linux x86-64;
- gfortran shared libraries (`.so`);
- Python 3.13 `ctypes` loading;
- C-contiguous NumPy rank-one and rank-two arrays.

Not yet verified:

- Windows `.dll` generation;
- inclusion of optional Fortran DLLs in the Nuitka distribution kit;
- Python-free Windows target execution with the Fortran backend.

These remain target-side acceptance items rather than claims of completed
Windows support.

## Next recommended stage

Connect this project to the actual JSON output produced by the separate Fortran
refactoring tool. The next milestone should use a real exported report to check
program units, types, COMMON positions, calls, diagnostics, and source mappings
against this migrator's fparser analysis before any new syntax support is added.
