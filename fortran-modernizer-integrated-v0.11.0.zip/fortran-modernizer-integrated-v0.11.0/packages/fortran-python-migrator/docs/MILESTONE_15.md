# Milestone 15: build-cost and runtime-benefit kernel selection

## Objective

Milestones 13 and 14 selected native kernels from measured Python-reference
importance. Milestone 15 adds the cost side of the decision. A kernel is no
longer selected merely because it is hot or faster in Cython: the plan can also
consider native build time, distribution size, saved time, and the estimated
number of executions required to recover the build cost.

The safety order remains:

1. static extraction eligibility;
2. readable generated Python;
3. representative single- or multi-case profiling;
4. build every eligible bundle in an isolated economics workspace;
5. compare an all-Python baseline with one optimized-Cython candidate at a time;
6. apply explicit economics thresholds;
7. build only the selected kernels;
8. compare the complete Python/Cython state with compiled Fortran.

## Economics benchmark

```bash
fpy-migrate benchmark-hybrid-economics \
  samples/migration_projects/partial_hybrid_project \
  --procedure run_partial_hybrid \
  --profile-report reports/milestone14/hybrid_profile_suite.json \
  --build-directory build/milestone15/economics \
  --output reports/milestone15/hybrid_economics.json \
  --warmup-runs 5 \
  --measured-runs 200
```

The generated all-kernel runtime uses Python for the baseline. Each candidate is
then switched individually to `cython-optimized`, with every other candidate
remaining Python. This avoids attributing another kernel's speedup to the
candidate under test.

For each candidate, the report records:

- Cython bundle build seconds;
- total bundle bytes;
- optimized extension bytes;
- case-by-case baseline and optimized time;
- weighted baseline and optimized time;
- weighted saved seconds and speedup;
- profile-derived calls per representative run;
- saved seconds per call;
- estimated build break-even runs and calls;
- saved seconds per MiB;
- saved runtime per build second (`cost_benefit_score`).

A non-positive saving has no finite break-even and is represented as `null`.
The report is validated by `schemas/hybrid_economics.schema.json`.

## Selection gates

The economics report can be supplied to `analyze-hybrid-project` and
`build-hybrid-project` with:

- `--min-economics-speedup`;
- `--min-economics-saved-time-ms`;
- `--max-economics-build-seconds`;
- `--max-economics-artifact-mb`;
- `--max-economics-break-even-runs`;
- `--max-economics-break-even-calls`.

If a profile report is also supplied, profile selection is applied first and the
economics gates filter the remaining candidates. Unlike the profile fallback,
economics rejection is final: an unprofitable kernel is not compiled merely to
ensure that one native kernel exists.

The plan and manifest schemas are version 1.4. Candidate plan entries retain all
measured economics fields and a human-readable acceptance/rejection reason. The
manifest records measured build seconds, bundle bytes, and optimized extension
bytes for the final selected bundles.

## Recorded representative result

The same three-case suite as milestone 14 was used:

| Candidate | Weighted speedup | Saved time/run | Build time | Optimized extension | Break-even runs |
|---|---:|---:|---:|---:|---:|
| internal update loop | 1.623x | 0.0484 ms | 10.345 s | 1.052 MiB | 213,746 |
| summarization | 1.441x | 0.0386 ms | 9.990 s | 1.043 MiB | 258,716 |
| initialization | 0.968x | -0.0042 ms | 10.272 s | 1.085 MiB | none |

The applied gates were:

```text
minimum speedup             1.50x
minimum saved time          0.04 ms per weighted suite run
maximum build time          11 s
maximum optimized artifact  2 MiB
maximum break-even          230,000 weighted suite runs
```

Only the internal update loop passed. Summarization was faster but did not meet
the speedup, saved-time, or break-even thresholds. Initialization was slower in
the representative weighted suite and therefore had no finite break-even.

These break-even values reflect a deliberately small sample kernel and include
Cython dispatch/build overhead. They are planning signals for this machine,
compiler, workload suite, and source revision—not universal performance claims.
For larger production kernels, the same report structure remains applicable.

## Numerical equivalence

The economics-selected build retained initialization and summarization in Python
and compiled only the internal update loop. Compared with `gfortran -O2`, all
three runtime modes had exact agreement for the fixture:

- pressure maximum absolute difference: `0.0`;
- film-thickness maximum absolute difference: `0.0`;
- total-pressure difference: `0.0`;
- peak-pressure difference: `0.0`;
- shared relaxation-factor difference: `0.0`.

## Tests

The complete suite now contains 68 tests:

- 45 non-integration tests;
- 23 compiler-heavy integration tests.

Compiler-heavy project builds remain isolated in fresh Python processes to avoid
retaining many generated extension graphs in one interpreter.

## Deliberate limitations

- Build time is measured for the current Cython safe+optimized bundle and is
  machine/compiler specific.
- Runtime savings are measured by changing one candidate at a time; interactions
  between several simultaneously compiled kernels are not yet modelled.
- Disk artifact size is not a measurement of runtime memory.
- The current break-even converts build seconds into runtime seconds only; it does
  not assign monetary cost to developer time, CI occupancy, code signing, or
  release validation.
- Source-change frequency and expected deployment count must still be chosen by
  the user when setting thresholds.
- Windows build economics must be remeasured on the Windows toolchain before a
  production Windows release.
