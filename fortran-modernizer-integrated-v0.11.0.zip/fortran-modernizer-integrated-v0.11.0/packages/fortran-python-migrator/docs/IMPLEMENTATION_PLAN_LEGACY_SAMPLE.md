# Legacy journal-bearing sample compatibility implementation plan

## Goal

After the separate Fortran refactoring tool has safely normalized the legacy source, the migration tool shall convert the numerical path of the supplied journal-bearing sample to generated Python, safe Cython, optimized Cython, and optional Fortran kernels, while keeping formatted reporting behind a Python adapter boundary.

The raw legacy source must continue to be diagnosed as blocked until labeled DO loops, GO TO control flow, implicit typing, COMMON inconsistencies, and typo candidates have been resolved by the refactoring tool.

## Responsibility boundary

### Refactoring tool

- fixed-form to free-form normalization
- labeled DO to block DO conversion
- GO TO to structured EXIT/control-flow conversion
- IMPLICIT NONE introduction and explicit declarations
- COMMON layout reconciliation
- INCLUDE resolution or a resolved include manifest
- typo-candidate handling, including `RESIDUALL`
- numerical regression between original and normalized Fortran

### Migration tool

- PARAMETER/constants in Migration IR and all code generators
- intrinsic support required by the sample (`ACOS`/`DACOS`, `HUGE`)
- procedure-scoped dependency-closure building
- main-program/orchestration generation
- Python adapter boundary for unsupported formatted I/O
- Python/Cython/Fortran backend equivalence testing
- handoff verification and end-to-end acceptance reporting

## Milestone 20: constants and intrinsic semantics

### IR changes

Add `ConstantIR` with:

- `name`
- `type`
- `value: ExpressionIR`
- `source_span`
- scope metadata where needed

Add procedure-visible constants to `ProcedureIR`. Module parameters are injected into contained procedures as visible constants, without treating them as mutable state.

Initial supported subset:

- scalar INTEGER, REAL, LOGICAL parameters
- literal constant expressions
- unary/binary arithmetic
- references to previously declared parameters
- supported intrinsic constant expressions

Reject parameter arrays, character parameters, forward cycles, and unresolved references explicitly.

### Builder changes

- preserve `PARAMETER` declarations and entity initializers
- topologically order dependent constants
- include constants in symbol-reference validation
- allow array shape expressions to reference constants
- retain source locations and declaration order

### Code generation

Python:

- emit constants at function/module scope according to Fortran visibility
- use immutable naming convention and never return constants as outputs

Cython:

- emit typed local/module constants compatible with Pure Python Mode
- ensure shape expressions and loops compile without unresolved names

Fortran bind(C):

- emit equivalent `parameter` declarations or safely substitute constant expressions

### Intrinsic registry

Replace duplicated intrinsic maps with a shared intrinsic specification registry.

Add:

- `acos`, `dacos` -> `math.acos` / Fortran `acos`
- `huge` with type-sensitive behavior
  - real -> IEEE double maximum used by the generated backend contract
  - integer -> integer maximum for the selected integer contract

The registry records Python, Cython, and Fortran lowering plus argument-count/type rules.

### CLI/include handling

Add repeatable `--include-dir` support and record resolved include files in Project IR/source manifests. Missing or ambiguous includes remain blocking.

### Acceptance criteria

- generated Python has no unresolved `ntheta`, `nz`, `maxit`, `omega`, `toler`, or `aspect`
- `ACOS`/`DACOS` and `HUGE` generate and execute on all backends
- constant-dependent array shapes allocate correctly
- cyclic and unsupported parameter expressions fail with precise source diagnostics
- existing non-parameter projects remain unchanged

## Milestone 21: procedure-scoped IR construction

### Two-pass architecture

Pass 1 performs lightweight project inventory without translating executable bodies:

- procedure/main-program names and spans
- argument lists
- call edges
- declarations needed for COMMON layout validation
- module/INCLUDE dependencies

Pass 2 builds full Migration IR only for the selected root and its reachable dependency closure.

### Safety requirements

- unsupported, unreachable sibling procedures do not block a selected numerical procedure
- unsupported reachable procedures still block the root
- COMMON layout checking remains project-wide through the lightweight declaration inventory
- duplicate procedure names and conflicting declarations remain blocking
- `procedure=None` retains strict whole-project behavior

### Acceptance criteria

- selecting `INIT_GEOMETRY`, `SOLVE_REYNOLDS`, or `COMPUTE_METRICS` succeeds even when `PRINT_RESULTS` remains in the same file
- selecting a root that directly calls unadapted `PRINT_RESULTS` remains blocked
- an unreachable COMMON mismatch is still reported by the global declaration check
- dependency order and source spans are stable in generated IR

## Milestone 22: orchestration and Python adapter boundary

### Main program support

Represent the safe orchestration subset of a Fortran main program:

- scalar assignments
- supported CALL statements
- structured IF/DO if already normalized
- state-group access

Generate a Python `main()`/application entrypoint that invokes migrated procedures through the existing backend registry.

### Adapter configuration

Add a TOML/JSON adapter contract such as:

```toml
[python_adapters.print_results]
callable = "journal_bearing_app.adapters:print_results"
mode = "python"
```

The generator validates:

- adapter name and importability
- argument count/order
- state groups read by the original procedure
- no hidden writes unless declared

Formatted `WRITE`/`FORMAT` is not automatically translated in this milestone. It is isolated as a Python adapter or retained Fortran boundary.

### Generated application structure

- generated numerical module
- generated state dataclasses
- backend registry: Python, safe Cython, optimized Cython, Fortran
- generated orchestration module
- user-editable adapter module
- self-check command

### Acceptance criteria

- the sample call sequence runs from generated Python orchestration
- `PRINT_RESULTS` is invoked through a Python adapter
- changing the numerical backend does not change orchestration or adapter code
- missing/mismatched adapters fail before execution

## Milestone 23: end-to-end sample acceptance

### Fixed baselines

Maintain:

1. original legacy Fortran baseline
2. refactoring-tool normalized Fortran baseline
3. generated Python
4. generated safe Cython
5. generated optimized Cython
6. generated/retained Fortran kernel configuration

### Comparison contract

Compare:

- iteration count exactly
- convergence status exactly
- residual with explicit tolerance
- full pressure array
- full film-thickness array
- load
- maximum pressure
- minimum film thickness
- friction metric
- NaN/Inf absence

Recommended initial tolerance:

- arrays/scalars: `rtol=1e-12`, `atol=1e-13`
- integer iteration counts: exact

A verification driver should expose arrays from COMMON/module state instead of comparing only formatted output.

### Handoff gates

Before migration:

- refactoring handoff schema validation
- AST/handoff type, rank, argument, COMMON-position cross-check
- no unresolved blocking diagnostics
- original vs normalized Fortran numerical regression pass

### Deliverables

- reusable journal-bearing acceptance fixture
- normalized handoff fixture
- end-to-end CLI test
- backend equivalence JSON
- unsupported-boundary report
- migration manifest with source/include fingerprints

### Acceptance criteria

- normalized Fortran matches original baseline
- all four numerical backends match normalized/original Fortran within tolerance
- generated application self-check passes
- raw unnormalized source remains correctly BLOCKED
- intentional type/rank/COMMON/constant mismatches are caught before code generation

## Milestone 24: real refactoring-tool artifact and Windows acceptance

This milestone starts only after the actual latest refactoring-tool report/ZIP is available.

- import the real report layout, not only a fixture
- adjust field-name adapters without weakening canonical validation
- run the supplied sample through the real refactoring output
- create Windows `.pyd` and optional Fortran `.dll`
- build Nuitka standalone distribution
- run self-check on a Python-free Windows machine

## Test strategy

Each milestone adds three layers:

1. unit tests for IR and lowering rules
2. generated-source tests, including `py_compile` and Cython/Fortran compilation
3. numerical integration tests against compiled Fortran

Compiler-heavy tests remain isolated in fresh Python processes to avoid extension-module retention and environment timeouts.

## Explicitly deferred

The following are not required to complete this sample path:

- general automatic conversion of arbitrary `FORMAT`
- unrestricted GOTO translation in the migration tool
- arbitrary parameter arrays or character constants
- preprocessor macro evaluation
- automatic OpenMP/SIMD insertion
- universal translation of all Fortran main programs

They should be prioritized only after real-code frequency data shows they are needed.

## Implementation status through Milestone 23

- Milestone 20 is complete: scalar numeric/logical `PARAMETER`, dependent
  constants, `ACOS`/`DACOS`, and type-directed `HUGE` are verified across
  Python, safe Cython, optimized Cython, and generated `bind(C)` Fortran.
- Milestone 21 is complete: lightweight whole-project inventory precedes
  dependency-closure translation, unreachable unsupported siblings no longer
  block a selected numerical root, reachable unsupported procedures still
  block, and COMMON layout validation remains project-wide including main
  programs.
- The supplied normalized one-file journal-bearing path now generates and runs
  as Python when rooted at `run_numeric`; its output matches the compiled
  Fortran reference at double-precision roundoff scale.
- Milestone 22 is complete: a top-level main-program CALL sequence is split
  into a generated synthetic numerical root and a trailing read-only Python
  adapter suffix. The generated application uses one backend-neutral `main()`
  for Python, safe Cython, optimized Cython, and optional generated Fortran.
- Adapter JSON, orchestration plans, and manifests are schema validated;
  signature mismatches, interleaved I/O, and unassigned adapter arguments are
  blocked before native compilation.
- Milestone 23 is complete: the controlled sample is now a complete E2E
  acceptance fixture. The gate fingerprints legacy and normalized sources,
  verifies the canonical handoff, proves type/rank/COMMON-position/fingerprint
  mismatches are blocked, compares original and normalized compiled Fortran,
  and compares full pressure, film-thickness, and angle arrays plus all scalar
  results across Python, safe Cython, optimized Cython, and generated Fortran.
- Milestone 24 is next: repeat the same gate with an actual output artifact from
  the separately developed refactoring tool and then perform Windows target
  builds and clean-machine acceptance.
