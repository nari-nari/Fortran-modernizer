# Milestone 5: generated-kernel optimisation and benchmark harness

## Scope

This milestone adds a controlled optimisation stage after the safe generated
Cython kernel has already matched Fortran and generated Python. It does not
change the finite-difference equations, loop order, clipping logic, precision,
or in-place Gauss-Seidel/SOR update order.

## Added capabilities

- safe and optimised Cython generation modes;
- independent compilation of both modes;
- C-contiguous memory-layout contracts for optimised rank-1/rank-2 inputs;
- disabled bounds, negative-index wraparound, and initialisation checks only in
  the optimised build;
- `-O3` compilation for the optimised extension on GCC-compatible platforms;
- inlining of supported scalar leaf subroutines inside hot loops;
- an adaptive benchmark harness for generated Python, safe Cython, optimised
  Cython, and `gfortran -O3`;
- one-sweep numerical summaries and Python/Cython full-array comparisons in the
  benchmark report;
- a Copilot skill that requires equivalence testing before optimisation.

## CLI

```bash
fpy-migrate translate-cython \
  samples/migration_units/sor_sweep.f90 \
  --procedure sor_sweep \
  --mode optimized \
  --output generated/sor_sweep_cython_optimized.py

fpy-migrate compile-cython \
  generated/sor_sweep_cython_optimized.py \
  --module-name sor_sweep_cython_optimized \
  --build-directory build/sor_sweep_cython_optimized \
  --mode optimized

fpy-migrate benchmark-kernel \
  samples/migration_units/sor_sweep.f90 \
  --procedure sor_sweep \
  --build-directory build/sor_sweep_benchmark \
  --output reports/sor_sweep_benchmark.json \
  --size 32x17 --size 64x33 --size 128x65 --size 256x129
```

## Safety and memory-layout policy

The safe generated source accepts general strided numerical memoryviews and
keeps Cython's bounds, wraparound, and initialisation checks enabled.

The optimised source requires contiguous one-dimensional arrays and
C-contiguous rank-2 arrays (`double[:, ::1]`). This matches the generated Python
loop order, where the second index is the inner loop. The requirement is
explicit: callers must prepare compatible arrays instead of allowing a hidden
copy inside the numerical kernel.

A supported scalar leaf call such as `periodic_neighbors` is expanded inside
the outer SOR loop. The separately generated helper remains available for
traceability, but the hot loop does not construct and unpack a Python tuple on
each circumferential index.

## Verification

The full test suite reports:

```text
28 passed
```

For every benchmark size, generated Python, safe Cython, and optimised Cython
produce identical pressure arrays. The residual also matches the optimised
Fortran result. The pressure-sum difference against Fortran is caused by
floating-point reduction order and remains small relative to the total sum.

## Benchmark results in the current WSL environment

The timings below are from one container/WSL-like Linux environment with Python
3.13.5, NumPy 2.3.5, GCC/Cython, and `gfortran -O3`. They are evidence for this
implementation, not portable performance guarantees.

| Grid | Python | Safe Cython | Optimised Cython | Fortran `-O3` | Optimised Cython / Fortran |
|---|---:|---:|---:|---:|---:|
| 32 x 17 | 519.17 us | 10.32 us | 8.39 us | 5.57 us | 1.51x slower |
| 64 x 33 | 2.066 ms | 31.43 us | 27.30 us | 27.08 us | approximately equal |
| 128 x 65 | 8.218 ms | 112.41 us | 94.00 us | 104.65 us | 1.11x faster |
| 256 x 129 | 33.431 ms | 881.35 us | 362.64 us | 451.23 us | 1.24x faster |

Compared with generated Python, the optimised Cython kernel is approximately
62x to 92x faster over these sizes. The large safe/optimised difference at the
largest size also demonstrates why memory layout and safety checks must be
measured rather than assumed.

## Interpretation

The result supports the planned architecture:

- retain generated Python as the readable numerical reference;
- retain safe Cython as the diagnostic compiled implementation;
- use optimised Cython as the default candidate for production FDM kernels;
- keep the Fortran backend as a compatibility and performance reference until
  the migrated kernel has passed broader cases.

The benchmark does not yet cover full solver startup, I/O, repeated convergence
to a solution, Windows compilation, parallel execution, or production-sized
models. Those remain later milestones.
