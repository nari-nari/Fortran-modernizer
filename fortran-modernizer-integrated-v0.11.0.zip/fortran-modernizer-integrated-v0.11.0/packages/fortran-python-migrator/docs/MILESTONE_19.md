# Milestone 19: Production-project acceptance diagnostic

## Objective

Provide a safe entry point for an actual lubrication-analysis repository before
translation begins. The diagnostic must distinguish parser coverage from the
smaller safe subset represented by the Migration IR, identify dependency-chain
blockers, and rank the work by procedure rather than by file alone.

The actual proprietary lubrication-analysis source was not supplied in this
runtime. This milestone therefore implements and verifies the acceptance
mechanism against a controlled multi-file project and against the connected
COMMON project from milestone 18. It does not claim a readiness result for the
user's production code.

## Implemented

- New `diagnose-project` CLI.
- Recursive Fortran source discovery for fixed- and free-form suffixes.
- File-level fparser parse status and parse error retention.
- Independent per-subroutine Migration IR construction, so one unsupported
  procedure does not hide the readiness of its neighbours.
- Procedure-level `READY`, `REVIEW_REQUIRED`, and `BLOCKED` classification.
- Source-location-aware detection of current unsupported/review constructs.
- Direct unresolved-external-call detection.
- Fixed-point propagation of blocked dependencies to all affected callers.
- Dependency-first migration ordering from a selected root procedure.
- Recommended vertical slice with an explicit blocked-procedure list.
- Fortran-retention candidate list.
- Unsupported-construct frequency summary with example locations.
- Optional canonical refactoring-report metadata and full-project cross-check.
- Versioned `project_acceptance.schema.json`.
- Procedure readiness CSV for review and prioritisation.
- Copilot skill enforcing acceptance-before-translation.

## Metrics

The report intentionally publishes separate ratios:

- `file_parse_rate`: files accepted by fparser;
- `procedure_ir_build_rate`: procedures individually represented by the current IR;
- `procedure_migratable_rate`: procedures that are READY or REVIEW_REQUIRED after
  dependency propagation;
- `procedure_ready_rate`: procedures requiring no current review item.

These numbers answer different questions. In particular, a project can have a
100% parse rate and still be blocked for migration.

## Controlled blocked fixture

The five-file acceptance fixture contains:

- one explicit numerical initialization loop (`READY`);
- one explicitly declared COMMON-based update (`REVIEW_REQUIRED`);
- one `SELECT CASE` procedure (`BLOCKED`);
- one root procedure that depends on the blocked procedure (`BLOCKED` by
  dependency propagation);
- one procedure calling unavailable vendor code (`BLOCKED` as an unresolved
  external call).

Result:

- files parsed: 5/5 (100%);
- procedures with individual IR: 4/5 (80%);
- READY: 1;
- REVIEW_REQUIRED: 1;
- BLOCKED: 3;
- whole requested project IR: BLOCKED.

This demonstrates why parse success is not a migration-readiness metric by itself.

## Connected refactoring-tool sample

The milestone-18 canonical hand-off was supplied to the COMMON project diagnostic.
The result was:

- files parsed: 5/5;
- procedures with individual IR: 4/4;
- procedure migratable rate: 100%;
- whole project IR plus hand-off cross-check: PASS;
- overall status: REVIEW_REQUIRED because COMMON normalisation remains an explicit
  review item;
- dependency-first order: initialization, update, summary, orchestration.

The report records producer `fortran-refactor-tool` version `0.37.0` and confirms
that no blocking producer diagnostic was present.

## Safety behaviour

The diagnostic does not:

- infer interfaces for unavailable external calls;
- mark a caller READY when a required callee is blocked;
- treat fparser acceptance as proof of translatability;
- guess through unsupported construct patterns;
- claim that the controlled fixture represents the production source.

## Test results

- New milestone-19 tests: 4 passed.
- Non-integration suite after building the sample Cython extension: 52 passed,
  1 environment-dependent test skipped (`findent` was not on the active PATH).
- Compiler-heavy integration suite: 27 passed in fresh Python processes.
- Total collected suite: 80 tests; 79 passed and 1 skipped.

The complete regression run also found that the active milestone-18 source had
lost the milestone-17 `include_fortran` integration in the project-level hybrid
builder. The milestone-17 source was diffed against the active file, the missing
manifest/runtime/build integration was restored, and all three project-level
Fortran backend tests plus the downstream hybrid/profile/economics/distribution
tests passed. This repair is included in the milestone-19 archive.

The project version is `0.19.0`.

## Next acceptance step

Attach or mount a sanitised copy of the actual lubrication-analysis source tree,
its build/source inventory, and preferably the real refactoring-tool hand-off.
Run `diagnose-project` without modifying the source. Use the frequency report to
choose only the high-impact missing constructs, then migrate the first vertical
slice after a Fortran regression case is fixed.
