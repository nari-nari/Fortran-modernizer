# Milestone 12: project-level partial-loop promotion

## Goal

Extend project-level hybrid generation so that a procedure no longer has to be
entirely native-compatible to benefit from Cython. Whole-procedure state-kernel
extraction remains the first choice. When it is blocked, the planner searches
that procedure's top-level `DO` loops in source order and promotes the first safe
loop while retaining all surrounding orchestration in generated Python.

## Implemented planning policy

```text
reachable Fortran procedure
    -> try complete state-kernel extraction
       -> success: AUTO / full-procedure kernel
       -> blocked:
          -> inspect top-level DO loops in source order
             -> first safe loop: PARTIAL_AUTO / partial-loop kernel
             -> none safe: PYTHON_ONLY
```

The plan schema is now version `1.1` and records:

- `extraction_kind`: `full-procedure`, `partial-loop`, or null;
- `loop_index` for partial extraction;
- full, partial, and combined extracted-procedure lists;
- the synthetic kernel procedure generated for each accelerated item.

## Combined transformed project

For every `PARTIAL_AUTO` procedure, the selected loop is replaced in a copy of
the Migration IR by a call to a synthetic explicit-argument kernel. The original
IR is retained separately.

```text
hybrid_project.ir.json       original validated project IR
hybrid_transformed.ir.json   selected loops replaced by kernel calls
project_reference.py         generated from transformed IR
hybrid_project.py            common full/partial backend registry
```

This transformed-project approach is important because calls before and after
the selected loop still resolve through the same project-level registry. Full
state kernels and partial-loop kernels can therefore be mixed in one execution
without creating isolated wrapper subprojects.

## Validation project

The fixture `samples/migration_projects/partial_hybrid_project` contains:

1. `initialize_partial_state`: complete stateful loop, classified `AUTO`;
2. `summarize_partial_state`: complete reduction loop, classified `AUTO`;
3. `run_partial_hybrid`: calls initialization, computes a scalar `bias`, runs one
   pressure-update loop, then calls summarization.

The calls prevent complete extraction of `run_partial_hybrid`. Its update loop is
safe, so the planner classifies it as:

```text
status: PARTIAL_AUTO
extraction_kind: partial-loop
loop_index: 1
kernel_procedure: run_partial_hybrid_loop_1_kernel
```

The initialization call, scalar setup, and summarization call remain in Python in
their original order.

## Runtime registry

The generated runtime exposes one backend context for both kernel kinds:

```python
state = runtime.create_common_field()
total, peak = runtime.run_partial_hybrid(
    state,
    12,
    0.4,
    backend="cython-optimized",
)
```

Per-procedure overrides also cover partial procedures:

```python
total, peak = runtime.run_partial_hybrid(
    state,
    12,
    0.4,
    backend="cython-optimized",
    backend_overrides={
        "initialize_partial_state": "python",
        "run_partial_hybrid": "cython-safe",
        "summarize_partial_state": "python",
    },
)
```

The source-procedure name, rather than the synthetic kernel name, is used in the
override contract.

## Numerical verification

Compiled `gfortran -O2` output was compared with three uniform hybrid backends
and one mixed configuration.

| Configuration | Pressure max difference | Film max difference | Total difference | Peak difference |
|---|---:|---:|---:|---:|
| Python | `0.0` | `0.0` | `0.0` | `0.0` |
| safe Cython | `0.0` | `0.0` | `0.0` | `0.0` |
| optimized Cython | `0.0` | `0.0` | `0.0` | `0.0` |
| mixed full/partial backends | `0.0` | `0.0` | `0.0` | `0.0` |

The reference values are:

- total pressure: `83.1`;
- peak pressure: `16.998428289111413`;
- relaxation factor: `1.25`.

## Schemas and manifests

The hybrid plan and manifest schemas were updated to `1.1`.

The manifest now separates:

- `kernel_bundles`: full-procedure state-kernel bundles;
- `partial_loop_bundles`: partial-loop bundles;
- `full_extracted_procedures`;
- `partial_extracted_procedures`;
- `extracted_procedures`: their union;
- `python_only_procedures`.

All paths remain relative to the build root.

## Safety policy

- complete state-kernel extraction is always preferred;
- automatic partial selection considers top-level loops only;
- the first safe loop in source order is selected;
- calls inside the selected loop remain blocked;
- pre-loop and post-loop statements remain Python and preserve source order;
- local-array lifetime and conditionally initialized bridge locals remain blocked;
- backend overrides may target only source procedures listed in
  `EXTRACTED_PROCEDURES`.

## Tests

The complete suite now contains 58 tests:

- non-integration: `39 passed`;
- integration/equivalence/benchmark: `19 passed` in compiler-safe shards;
- total: `58 passed`.

The three project-level hybrid builds are executed as separate test nodes to
avoid retaining several compiled extension graphs in one interpreter.

## Copilot support

The existing `build-hybrid-project` skill now understands `PARTIAL_AUTO`.
A focused skill was added at:

```text
.github/skills/promote-project-partial-loop/SKILL.md
```

It requires review of the full-extraction blocker, loop index, source span,
bridge intents, transformed IR, and complete-state equivalence.

## Current limitations

- one partial loop is selected per procedure;
- selection is source-order based rather than profile guided;
- nested regions are not sliced;
- procedure calls inside the selected loop are blocked;
- local arrays inside the bridge are blocked;
- no automatic cost model yet decides whether compilation is worthwhile.

## Next recommended milestone

Add profile-guided project planning. Candidate loops should be timed in the
Python reference execution, ranked by measured cost, and promoted only when the
expected native speedup justifies compilation and boundary-conversion overhead.
