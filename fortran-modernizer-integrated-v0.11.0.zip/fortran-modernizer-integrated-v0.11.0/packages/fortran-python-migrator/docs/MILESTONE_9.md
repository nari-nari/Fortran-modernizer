# Milestone 9: extract native kernels from Python state objects

## Goal

Keep migrated COMMON/module state in ordinary Python dataclasses while moving a
performance-critical state-dependent loop into an explicit numerical kernel.
The same generated Python wrapper must be able to select:

- readable Python;
- safety-checked Cython;
- optimized Cython.

The native interface must contain only numerical scalars and NumPy-compatible
arrays. Python dataclass objects are never passed into Cython.

## Implemented workflow

```text
Fortran COMMON/module procedure
    -> state-aware Migration IR
    -> read/write analysis of state fields
    -> stateless explicit-argument kernel IR
       -> Python reference kernel
       -> safe Cython kernel
       -> optimized Cython kernel
    -> generated Python state adapter
```

Two CLI commands were added:

```bash
fpy-migrate analyze-state-kernel \
  samples/migration_units/common_state_analysis.f90 \
  --procedure advance_common_state \
  --output build/advance_common_state.extraction.json \
  --ir-output build/advance_common_state.kernel.ir.json
```

```bash
fpy-migrate build-state-kernel \
  samples/migration_units/common_state_analysis.f90 \
  --procedure advance_common_state \
  --build-directory build/advance_common_state_bundle
```

The build command creates a movable directory containing:

- extraction report;
- stateless Migration IR;
- explicit-argument Python kernel;
- safe and optimized Cython Pure Python Mode sources;
- compiled Cython extension modules;
- generated Python state dataclass and adapter;
- relative-path manifest.

## State access inference

Every state field used by the selected procedure is classified from the IR:

- read only -> `intent(in)`;
- written only -> `intent(out)`;
- read and written -> `intent(inout)`.

For the COMMON fixture, local aliases are normalized by storage position:

```text
p     -> pressure           -> inout
h     -> film               -> in
omega -> relaxation_factor  -> in
```

The extracted kernel signature becomes:

```python
def advance_common_state_kernel(
    n: int,
    pressure: FloatArray,
    film: FloatArray,
    relaxation_factor: float,
) -> FloatArray:
    ...
```

The Python wrapper retains the state object:

```python
def advance_common_state(
    state_common_field: CommonFieldState,
    n: int,
    *,
    backend: BackendName = "python",
) -> None:
    ...
```

An `inout` array is passed without copying, returned by the generated kernel,
and assigned back to the dataclass field. Scalar `out`/`inout` state fields are
cast back to their Python scalar type.

## COMMON and module coverage

The milestone verifies two independent paths:

1. named COMMON with different local aliases in different procedures;
2. module variables including a scalar loop bound and shared arrays.

The module fixture extracts:

```text
active_count       -> in
pressure           -> inout
film               -> in
relaxation_factor  -> in
```

## Safety constraints

The initial extraction subset deliberately requires:

- at least one loop;
- supported numeric/logical symbols only;
- no procedure calls inside the selected state-dependent body;
- already validated COMMON/module state mapping;
- no change to loop order, index mapping, precision, or update timing.

A stateful orchestrator such as `run_common_state`, which calls initialization,
update, and summarization procedures, is not silently flattened. It remains
blocked until interprocedural state side effects are represented explicitly.

The optimized Cython backend retains the existing explicit memory-layout
contract. The adapter does not silently copy incompatible arrays.

## Numerical verification

The complete sequence was compared, not only the extracted loop:

```text
initialize state
-> run selected Python/safe-Cython/optimized-Cython update
-> summarize state
-> compare complete arrays and scalars with compiled Fortran
```

### COMMON fixture

| Comparison | Maximum pressure difference | Maximum film difference | Scalar differences |
|---|---:|---:|---:|
| Python vs Fortran | `0.0` | `0.0` | `0.0` |
| safe Cython vs Fortran | `0.0` | `0.0` | `0.0` |
| optimized Cython vs Fortran | `0.0` | `0.0` | `0.0` |
| generated backends among themselves | `0.0` | `0.0` | `0.0` |

### Module fixture

| Comparison | Maximum pressure difference | Maximum film difference | Scalar differences |
|---|---:|---:|---:|
| Python vs Fortran | `0.0` | `0.0` | `0.0` |
| safe Cython vs Fortran | `0.0` | `0.0` | `0.0` |
| optimized Cython vs Fortran | `0.0` | `0.0` | `0.0` |
| generated backends among themselves | `0.0` | `0.0` | `0.0` |

The generated bundle was also copied to another directory and remained
loadable because all artifact paths are relative to the wrapper directory.

## Test status

Compiler-heavy tests were run in separate shards to avoid the execution
environment timeout caused by repeatedly launching Cython, C, and Fortran
compilers in one process.

- non-integration: `31 passed`;
- existing integration/equivalence/benchmark: `11 passed`;
- state migration integration: `2 passed`;
- new state-kernel integration: `2 passed`;
- total: `46 passed`.

No test was omitted.

## Generated Copilot skill

`.github/skills/extract-state-kernel/SKILL.md` requires Copilot to:

1. verify the state-object Python implementation against Fortran;
2. review every state binding and inferred intent;
3. build Python, safe Cython, and optimized Cython together;
4. compare the complete state transition;
5. preserve the Python wrapper and safe Cython diagnostic backend.

## Current limitations

- the complete selected procedure body is extracted; partial-loop slicing with
  Python setup/teardown is not implemented;
- calls inside the selected stateful procedure are blocked;
- recursive and interprocedural state side effects are not inferred;
- local `SAVE` state is not yet promoted and extracted;
- incompatible array layouts are not copied automatically;
- OpenMP, SIMD, `nogil`, and parallel reductions remain outside the current
  safe subset.

## Next recommended milestone

Add project-level hybrid generation. The tool should identify multiple stateful
hot procedures, extract each eligible kernel, retain orchestration in Python,
and generate one application-level backend registry. The first extension should
also support a stateful procedure with scalar setup/teardown around one loop,
while proving that only the loop body moves into the native kernel.
