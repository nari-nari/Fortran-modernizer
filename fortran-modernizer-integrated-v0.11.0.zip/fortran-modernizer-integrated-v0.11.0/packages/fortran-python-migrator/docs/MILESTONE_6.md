# Milestone 6: full iterative solver and configurable backends

## Scope

This milestone moves beyond a single SOR sweep and translates a complete
pressure solver. The generated solver computes the film field, initialises the
pressure array, repeatedly calls the SOR sweep, records the iteration count,
checks the convergence tolerance, and exits the loop without changing the
Fortran numerical update order.

Firedrake and Windows packaging remain outside this milestone.

## Added Migration IR support

- unnamed Fortran `EXIT` statements represented as a dedicated `ExitIR` node;
- `EXIT` emitted as Python/Cython `break`;
- whole-array scalar assignment emitted as `array[...] = value` instead of
  rebinding a NumPy variable;
- complete dependency inclusion for `compute_film`, `periodic_neighbors`,
  `sor_sweep`, and `solve_pressure`;
- logical convergence output, iteration count, and final update residual.

Named `EXIT` statements remain blocked because the current IR does not yet
represent loop labels.

## Full solver build

```bash
fpy-migrate build-solver \
  samples/migration_units/pressure_solver.f90 \
  --procedure solve_pressure \
  --fortran-driver samples/migration_units/pressure_solver_driver.f90 \
  --build-directory build/pressure_solver
```

The build produces:

- readable generated Python;
- safety-checked generated Cython;
- optimised generated Cython;
- a `gfortran -O3` reference executable when a driver is supplied;
- a relative-path JSON manifest;
- one TOML run configuration per available backend.

## Backend selection

```bash
fpy-migrate run-solver build/pressure_solver/run_python.toml
fpy-migrate run-solver build/pressure_solver/run_cython-safe.toml
fpy-migrate run-solver build/pressure_solver/run_cython-optimized.toml
fpy-migrate run-solver build/pressure_solver/run_fortran.toml
```

The configuration contains the backend, common case parameters, manifest path,
and output directory. All backends write the same `summary.json`, `pressure.csv`,
and `film.csv` output contract. A run that reaches `max_iterations` without
meeting the tolerance keeps `converged=false` and returns a non-zero CLI status.

## Numerical verification

For the standard 32 x 9 case with tolerance `1e-11`:

| Backend | Iterations | Final update residual | Converged |
|---|---:|---:|---|
| Generated Python | 163 | 9.33053634355474e-12 | yes |
| Safe Cython | 163 | 9.33053634355474e-12 | yes |
| Optimised Cython | 163 | 9.33053634355474e-12 | yes |
| Fortran `-O3` | 163 | 9.33098043276459e-12 | yes |

Generated Python, safe Cython, and optimised Cython produce exactly identical
pressure arrays. The maximum absolute pressure difference between generated
Python and Fortran is approximately `1.3e-15`.

The full test suite reports:

```text
33 passed
```

It includes a deliberately under-iterated case that confirms
`converged=false` after one iteration.

## Complete-solve benchmark

Timings below are from the current Linux environment and include allocation,
film generation, the complete convergence loop, and return-value construction.
They do not include file I/O or process startup for the generated Python/Cython
backends. Fortran timing is measured inside its executable.

| Grid | Generated Python | Safe Cython | Optimised Cython | Fortran `-O3` |
|---|---:|---:|---:|---:|
| 32 x 9 | 41.17 ms | 0.835 ms | 0.608 ms | 0.320 ms |
| 64 x 17 | 602.0 ms | 9.84 ms | 7.64 ms | 6.37 ms |

Optimised Cython is approximately 68x and 79x faster than generated Python for
the two recorded cases. It is about 1.9x slower than Fortran for 32 x 9 and
about 1.2x slower for 64 x 17. The result supports retaining Fortran as a
reference/optional backend while using optimised Cython as the primary
Fortran-free production candidate.

## Portability policy

Artifact paths in `solver_manifest.json` are relative to the manifest. Moving
the complete build directory therefore preserves the relationship between the
manifest, generated source, extension modules, executable, and TOML files.
Compiled Cython and Fortran artifacts are still platform- and Python-ABI-
specific and must be rebuilt for the final Windows target.

## Remaining work

- translate post-processing routines and combine them with the pressure solver;
- model module state and COMMON-derived state explicitly;
- support more array syntax and local automatic arrays;
- add Windows Cython compilation and application packaging;
- add production-case intake and wider regression suites.
