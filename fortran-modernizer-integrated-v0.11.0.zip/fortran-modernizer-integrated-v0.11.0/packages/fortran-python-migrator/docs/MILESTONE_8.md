# Milestone 8: COMMON/module state to explicit Python objects

## Goal

Convert Fortran shared state into explicit Python dataclasses without changing the numerical result. This milestone covers both named `COMMON` blocks and variables declared in a Fortran module.

The generated state wrapper is deliberately kept in normal Python. Performance-sensitive loops must continue to use explicit NumPy-array/scalar arguments when extracted into Cython. This avoids passing Python object graphs into native kernels and keeps the compiled interface stable.

## Implemented IR changes

Migration IR was advanced from schema version `1.0` to `1.1`.

New elements:

- `ProjectIR.state_groups`;
- `StateGroupIR` with `source_kind = module | common`;
- `ProcedureIR.state_groups`;
- state-aware `SymbolIR` fields:
  - `role = state`;
  - `state_group`;
  - `state_field`.

A symbol retains its local Fortran name but can map to a different canonical state field. This is used for compatible COMMON aliases.

Example:

```text
initialize_common_state:
  pressure -> pressure
  film -> film
  relaxation_factor -> relaxation_factor

advance_common_state:
  p -> pressure
  h -> film
  omega -> relaxation_factor
```

COMMON declarations are consolidated by storage position. Member count, type, kind, rank, and shape must be compatible; otherwise translation is blocked.

## Generated Python form

A named COMMON block such as `/field/` becomes:

```python
@dataclass
class CommonFieldState:
    pressure: FloatArray
    film: FloatArray
    relaxation_factor: float
```

State-dependent procedures receive the object explicitly:

```python
def advance_common_state(state_common_field: CommonFieldState, n: int) -> None:
    ...
```

Fortran module variables are handled similarly:

```python
@dataclass
class ModuleModuleStateAnalysisModState:
    active_count: int
    pressure: FloatArray
    film: FloatArray
    relaxation_factor: float
```

Calls between state-dependent procedures automatically forward the required state object.

## CLI

```bash
fpy-migrate analyze-state \
  samples/migration_units/common_state_analysis.f90 \
  --procedure run_common_state \
  --output reports/common_state_migration.json

fpy-migrate translate \
  samples/migration_units/common_state_analysis.f90 \
  --procedure run_common_state \
  --output generated/common_state.py
```

The state report lists:

- source kind and source name;
- canonical fields;
- type, kind, rank, and shape;
- procedures using the state group;
- generated Python class name;
- required Cython strategy.

## Cython boundary

Stateful procedures are classified `REVIEW_REQUIRED` as direct Cython candidates. Direct Cython generation is intentionally blocked for projects containing state groups.

Required architecture:

```text
Python state dataclass
    -> extract arrays/scalars
    -> stateless Cython numerical kernel
    -> update the same state arrays
```

This keeps shared-state migration separate from numerical-kernel compilation.

## Verification fixtures

Two independent fixtures were added:

1. named COMMON with compatible aliases across procedures;
2. Fortran module variables shared by module procedures.

Both execute an initialise/update/summarise sequence and compare the complete state against compiled Fortran.

## Numerical results

| Case | Maximum pressure difference | Maximum film difference | Scalar differences |
|---|---:|---:|---:|
| COMMON state | `0.0` | `0.0` | `0.0` |
| Module state | `0.0` | `0.0` | `0.0` |

The generated Python state-object implementations exactly matched the `gfortran -O2` reference results for the recorded fixtures.

## Test status

- non-integration tests: `27 passed`;
- integration tests excluding benchmarks: `11 passed`;
- integration benchmark tests: `2 passed`;
- total: `40 passed`.

## Current limitations

- blank and named COMMON parsing is supported, but incompatible layouts block translation;
- COMMON objects must currently be explicitly declared and must be simple names;
- EQUIVALENCE/type-punning remains blocked;
- module parameters are blocked until a separate constant IR is implemented;
- local `SAVE` variables are not yet promoted into a state group;
- allocatable module arrays are represented as required dataclass fields; allocation policy remains the caller's responsibility;
- direct state-object Cython compilation is intentionally unsupported.

## Next recommended milestone

Extract a stateless numerical kernel from a state-dependent procedure automatically. The tool should generate:

1. a Python state wrapper;
2. an explicit-array Python kernel;
3. safe and optimised Cython versions of that kernel;
4. state-to-kernel adapter code;
5. Fortran/Python/Cython equivalence tests for the full state transition.
