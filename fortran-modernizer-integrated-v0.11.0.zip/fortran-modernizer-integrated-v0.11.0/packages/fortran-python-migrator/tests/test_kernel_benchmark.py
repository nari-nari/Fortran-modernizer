from __future__ import annotations

import shutil
from pathlib import Path

import pytest

from fpy_migrate.benchmark import benchmark_generated_kernel


pytestmark = pytest.mark.integration


def test_kernel_benchmark_builds_all_four_backends(tmp_path: Path) -> None:
    if shutil.which("gfortran") is None or shutil.which("gcc") is None:
        pytest.skip("Fortran and C compilers are required")

    report = benchmark_generated_kernel(
        "samples/migration_units/sor_sweep.f90",
        procedure="sor_sweep",
        build_directory=tmp_path / "benchmark",
        sizes=((12, 7),),
        target_seconds=0.005,
    )

    case = report.cases[0]
    assert set(case.timings) == {
        "python",
        "cython_safe",
        "cython_optimized",
        "fortran_o3",
    }
    assert all(item.seconds_per_call > 0.0 for item in case.timings.values())
    assert case.maximum_absolute_difference["python_vs_cython_safe"] == 0.0
    assert case.maximum_absolute_difference["python_vs_cython_optimized"] == 0.0
    assert case.maximum_absolute_difference["python_vs_fortran_residual"] <= 1.0e-14
