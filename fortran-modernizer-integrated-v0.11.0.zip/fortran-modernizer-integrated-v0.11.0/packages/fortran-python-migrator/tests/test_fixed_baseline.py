from pathlib import Path

import numpy as np

from fpy_migrate.sample.journal_bearing.case_io import read_case
from fpy_migrate.sample.journal_bearing.output_io import read_result
from fpy_migrate.sample.journal_bearing.python_solver import solve_python


def test_python_matches_fixed_fortran_baseline() -> None:
    case = read_case(Path("samples/journal_bearing/cases/standard.nml"))
    expected = read_result(Path("samples/journal_bearing/expected"))
    actual = solve_python(case)
    np.testing.assert_allclose(actual.pressure, expected.pressure, rtol=1e-10, atol=1e-12)
    assert actual.iterations == expected.iterations
