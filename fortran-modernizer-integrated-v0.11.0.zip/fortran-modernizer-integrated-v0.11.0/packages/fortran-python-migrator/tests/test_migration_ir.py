from pathlib import Path

import pytest

from fpy_migrate.ir import (
    UnsupportedFortranError,
    build_project_ir,
    validate_migration_ir,
    write_project_ir,
)


SOURCE = Path("samples/migration_units/compute_film.f90")


def test_build_compute_film_ir(tmp_path: Path) -> None:
    project = build_project_ir(SOURCE, procedure="compute_film")
    assert len(project.procedures) == 1
    procedure = project.procedures[0]
    assert procedure.name == "compute_film"
    assert procedure.arguments == ("ntheta", "eccentricity", "film")
    assert procedure.symbol("film").intent == "out"
    assert procedure.symbol("film").rank == 1
    assert [statement.kind for statement in procedure.statements] == [
        "assignment",
        "assignment",
        "do",
    ]

    target = write_project_ir(project, tmp_path / "compute_film.ir.json")
    assert validate_migration_ir(target) == []


def test_if_else_and_unary_expression_are_supported() -> None:
    project = build_project_ir("samples/migration_units/unsupported_if.f90")
    procedure = project.procedures[0]
    assert [statement.kind for statement in procedure.statements] == ["if"]
    conditional = procedure.statements[0]
    assert conditional.condition.operator == ">"
    assert conditional.else_body[0].value.kind == "unary"
    assert conditional.else_body[0].value.operator == "-"


def test_sor_ir_includes_call_dependencies_and_assumed_shape_arrays(tmp_path: Path) -> None:
    project = build_project_ir(
        "samples/migration_units/sor_sweep.f90",
        procedure="sor_sweep",
    )
    assert [item.name for item in project.procedures] == [
        "periodic_neighbors",
        "sor_sweep",
    ]
    procedure = project.procedure("sor_sweep")
    assert procedure.symbol("film").shape == (None,)
    assert procedure.symbol("pressure").shape == (None, None)
    assert procedure.symbol("pressure").intent == "inout"
    outer_loop = procedure.statements[1]
    assert outer_loop.kind == "do"
    assert outer_loop.body[0].kind == "call"
    assert outer_loop.body[0].procedure == "periodic_neighbors"

    target = write_project_ir(project, tmp_path / "sor_sweep.ir.json")
    assert validate_migration_ir(target) == []


def test_unsupported_select_case_fails_loudly() -> None:
    with pytest.raises(UnsupportedFortranError, match="Case_Construct"):
        build_project_ir("samples/migration_units/unsupported_select.f90")


def test_refactor_handoff_is_cross_checked() -> None:
    project = build_project_ir(
        SOURCE,
        procedure="compute_film",
        refactor_report="examples/refactor_report_compute_film.json",
    )
    assert project.procedures[0].status == "AUTO"
    assert project.procedures[0].diagnostics == ()


def test_full_solver_ir_preserves_exit_and_validates(tmp_path: Path) -> None:
    project = build_project_ir(
        "samples/migration_units/pressure_solver.f90",
        procedure="solve_pressure",
    )
    assert [item.name for item in project.procedures] == [
        "compute_film",
        "periodic_neighbors",
        "sor_sweep",
        "solve_pressure",
    ]
    solver = project.procedure("solve_pressure")
    outer_loop = next(item for item in solver.statements if item.kind == "do")
    convergence_if = next(item for item in outer_loop.body if item.kind == "if")
    assert convergence_if.body[-1].kind == "exit"

    target = write_project_ir(project, tmp_path / "pressure_solver.ir.json")
    assert validate_migration_ir(target) == []
