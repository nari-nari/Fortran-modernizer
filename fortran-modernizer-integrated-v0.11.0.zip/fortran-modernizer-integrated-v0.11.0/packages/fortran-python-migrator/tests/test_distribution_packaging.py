from __future__ import annotations

import json
import os
from pathlib import Path
import subprocess
import sys

import pytest
from jsonschema import validate

from fpy_migrate.extraction import build_hybrid_project
from fpy_migrate.packaging import prepare_distribution, validate_distribution


ROOT = Path(__file__).resolve().parents[1]


def _fake_hybrid_build(root: Path) -> Path:
    root.mkdir(parents=True)
    (root / "hybrid_project.py").write_text("def available_kernels(): return ('update',)\ndef eligible_kernels(): return ('update',)\n", encoding="utf-8")
    (root / "project_reference.py").write_text("", encoding="utf-8")
    bundle = root / "partial_loops" / "update"
    bundle.mkdir(parents=True)
    (bundle / "update_python.py").write_text("def update(x): return x\n", encoding="utf-8")
    (bundle / "update_safe.py").write_text("import cython\ndef update(x: cython.double) -> cython.double: return x\n", encoding="utf-8")
    (bundle / "update_optimized.py").write_text("import cython\ndef update(x: cython.double) -> cython.double: return x\n", encoding="utf-8")
    (bundle / "stale.so").write_bytes(b"linux")
    bundle_manifest = {
        "schema_version": "1.0",
        "source_procedure": "update",
        "loop_index": 1,
        "kernel_procedure": "update",
        "default_backend": "cython-optimized",
        "available_backends": ["python", "cython-safe", "cython-optimized"],
        "artifacts": {
            "kernel_python": "update_python.py",
            "cython_safe_source": "update_safe.py",
            "cython_optimized_source": "update_optimized.py",
            "cython_safe_extension": "cython_safe_build/lib/update_safe.so",
            "cython_optimized_extension": "cython_optimized_build/lib/update_optimized.so",
        },
        "module_names": {
            "python": "update_python",
            "cython-safe": "update_safe",
            "cython-optimized": "update_optimized",
        },
        "bindings": [],
    }
    (bundle / "partial_loop_manifest.json").write_text(json.dumps(bundle_manifest), encoding="utf-8")
    manifest = {
        "schema_version": "1.5",
        "root_procedure": "run",
        "source_files": [],
        "default_backend": "cython-optimized",
        "available_backends": ["python", "cython-safe", "cython-optimized"],
        "artifacts": {
            "project_ir": "project.json",
            "transformed_ir": "transformed.json",
            "plan": "plan.json",
            "reference_python": "project_reference.py",
            "hybrid_runtime": "hybrid_project.py",
        },
        "kernel_bundles": {},
        "partial_loop_bundles": {"update": "partial_loops/update/partial_loop_manifest.json"},
        "eligible_procedures": ["update"],
        "extracted_procedures": ["update"],
        "full_extracted_procedures": [],
        "partial_extracted_procedures": ["update"],
        "python_only_procedures": [],
        "build_metrics": {},
    }
    path = root / "hybrid_project_manifest.json"
    path.write_text(json.dumps(manifest), encoding="utf-8")
    return path


def test_prepare_distribution_creates_source_only_windows_kit(tmp_path: Path) -> None:
    hybrid_manifest = _fake_hybrid_build(tmp_path / "hybrid")
    adapter = tmp_path / "adapter.py"
    adapter.write_text("def run(runtime, argv): return 0\n", encoding="utf-8")
    manifest, output = prepare_distribution(
        hybrid_manifest,
        adapter,
        tmp_path / "kit",
        app_name="demo_app",
        target="windows-nuitka",
    )
    assert output.is_file()
    assert len(manifest.native_extensions) == 2
    assert not list((tmp_path / "kit").rglob("*.so"))
    assert (tmp_path / "kit" / "build_windows.ps1").is_file()
    assert (tmp_path / "kit" / "build_wsl.sh").is_file()
    schema = json.loads((ROOT / "schemas" / "distribution_manifest.schema.json").read_text(encoding="utf-8"))
    validate(json.loads(output.read_text(encoding="utf-8")), schema)
    assert validate_distribution(tmp_path / "kit") == []


@pytest.mark.integration
def test_prepared_distribution_rebuilds_native_and_passes_self_check(tmp_path: Path) -> None:
    hybrid_root = tmp_path / "hybrid_build"
    _, hybrid_manifest = build_hybrid_project(
        ROOT / "samples" / "migration_projects" / "partial_hybrid_project",
        root_procedure="run_partial_hybrid",
        build_directory=hybrid_root,
        profile_report=ROOT / "reports" / "milestone14" / "hybrid_profile_suite.json",
        min_profile_share=0.35,
        min_profile_mean_share=0.40,
        min_profile_max_share=0.80,
        min_profile_cases=3,
        default_backend="cython-optimized",
    )
    kit = tmp_path / "distribution"
    prepare_distribution(
        hybrid_manifest,
        ROOT / "samples" / "package_apps" / "partial_hybrid_cli.py",
        kit,
        app_name="lubrication_hybrid",
        target="linux-wsl",
    )
    env = {**os.environ, "PYTHONPATH": ""}
    subprocess.run(
        [sys.executable, str(kit / "tools" / "build_native.py")],
        cwd=kit,
        env=env,
        check=True,
        capture_output=True,
        text=True,
    )
    subprocess.run(
        [sys.executable, str(kit / "tools" / "generate_notices.py")],
        cwd=kit,
        env=env,
        check=True,
        capture_output=True,
        text=True,
    )
    completed = subprocess.run(
        [sys.executable, str(kit / "launcher.py"), "--self-check"],
        cwd=kit,
        env=env,
        check=True,
        capture_output=True,
        text=True,
    )
    payload = json.loads(completed.stdout)
    assert payload["status"] == "PASS"
    assert payload["application"]["status"] == "PASS"
    assert (kit / "native_build_report.json").is_file()
    assert (kit / "third_party_inventory.json").is_file()
    assert (kit / "THIRD_PARTY_NOTICES.generated.md").is_file()
    assert (kit / "licenses").is_dir()
