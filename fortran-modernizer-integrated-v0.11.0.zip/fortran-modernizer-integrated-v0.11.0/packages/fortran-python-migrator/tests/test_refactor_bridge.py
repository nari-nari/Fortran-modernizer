from __future__ import annotations

import json
from pathlib import Path

from fpy_migrate.intake import validate_refactor_report
from fpy_migrate.ir import build_project_ir
from fpy_migrate.refactor_bridge import import_refactor_bundle, verify_refactor_connection


SOURCE = Path("samples/migration_projects/common_state_project")
ROOT = "run_common_state"


def _write_external_bundle(directory: Path, *, break_rank: bool = False) -> None:
    project = build_project_ir(SOURCE, procedure=ROOT)
    group = project.state_group("common_field")
    positions = {field.name: index for index, field in enumerate(group.fields, start=1)}

    procedures = []
    variables = []
    common_occurrences = []
    for procedure in project.procedures:
        procedures.append({
            "unit_name": procedure.name,
            "unit_kind": "SUBROUTINE",
            "location": {
                "path": procedure.source_span.file,
                "line_start": procedure.source_span.start_line,
                "line_end": procedure.source_span.end_line,
            },
            "dummy_arguments": list(procedure.arguments),
        })
        members = []
        for symbol in procedure.symbols:
            shape = []
            for extent in symbol.shape:
                shape.append(extent.value if extent is not None else ":")
            record = {
                "scope": procedure.name,
                "variable": symbol.name,
                "declared_type": symbol.type.category,
                "kind_name": symbol.type.kind,
                "argument_intent": symbol.intent,
                "array_rank": symbol.rank,
                "dimensions": shape,
                "storage_class": "dummy argument" if symbol.role == "argument" else "local",
                "location": {"path": procedure.source_span.file, "line": procedure.source_span.start_line},
            }
            if symbol.role == "state":
                record["storage_class"] = "COMMON"
                record["common_block"] = "FIELD"
                record["common_position"] = positions[symbol.state_field]
                members.append({
                    "variable": symbol.name,
                    "declared_type": symbol.type.category,
                    "kind_name": symbol.type.kind,
                    "array_rank": symbol.rank + (1 if break_rank and procedure.name == "advance_common_state" and symbol.name == "p" else 0),
                    "dimensions": shape,
                    "ordinal": positions[symbol.state_field],
                })
            variables.append(record)
        common_occurrences.append({
            "block_name": "/FIELD/",
            "owner": procedure.name,
            "location": {"path": procedure.source_span.file, "line": procedure.source_span.start_line},
            "layout": members,
        })

    calls = []
    root = project.procedure(ROOT)
    for statement in root.statements:
        if statement.kind == "call":
            calls.append({
                "from": ROOT,
                "to": statement.procedure,
                "location": {
                    "path": statement.source_span.file,
                    "line": statement.source_span.start_line,
                },
            })

    directory.mkdir(parents=True)
    (directory / "project_inventory.json").write_text(json.dumps({
        "metadata": {"tool_version": "0.37.0", "project_root": str(SOURCE)},
        "procedure_inventory": procedures,
        "variable_inventory": variables,
    }, indent=2), encoding="utf-8")
    (directory / "common_layouts.json").write_text(json.dumps({
        "common_layouts": common_occurrences,
    }, indent=2), encoding="utf-8")
    (directory / "call_graph.json").write_text(json.dumps({
        "call_edges": calls,
    }, indent=2), encoding="utf-8")
    (directory / "diagnostics.json").write_text(json.dumps({
        "findings": [{"level": "info", "description": "migration hand-off generated"}],
    }, indent=2), encoding="utf-8")


def test_imports_separate_tool_report_bundle_and_cross_checks_full_project(tmp_path: Path) -> None:
    bundle = tmp_path / "v037_reports"
    _write_external_bundle(bundle)
    canonical = import_refactor_bundle(bundle, tmp_path / "handoff.json")
    assert validate_refactor_report(canonical) == []

    report = verify_refactor_connection(
        SOURCE,
        canonical,
        tmp_path / "connection.json",
        procedure=ROOT,
    )
    payload = json.loads(report.read_text(encoding="utf-8"))
    assert payload["status"] == "PASS"
    assert payload["producer_version"] == "0.37.0"
    assert payload["coverage"] == {
        "calls": 1.0,
        "common_members": 1.0,
        "program_units": 1.0,
        "symbols": 1.0,
    }
    assert payload["summary"]["matched_program_units"] == 4
    assert payload["summary"]["matched_common_members"] == 12

    connected = build_project_ir(SOURCE, procedure=ROOT, refactor_report=canonical)
    assert all(item.status == "AUTO" for item in connected.procedures)


def test_rank_disagreement_blocks_connection(tmp_path: Path) -> None:
    bundle = tmp_path / "v037_bad_reports"
    _write_external_bundle(bundle, break_rank=True)
    canonical = import_refactor_bundle(bundle, tmp_path / "handoff.json")
    report = verify_refactor_connection(
        SOURCE,
        canonical,
        tmp_path / "connection.json",
        procedure=ROOT,
    )
    payload = json.loads(report.read_text(encoding="utf-8"))
    assert payload["status"] == "BLOCKED"
    assert any(item["category"] == "common-member-mismatch" for item in payload["issues"])


def test_existing_canonical_report_can_be_imported_from_bundle(tmp_path: Path) -> None:
    bundle = tmp_path / "canonical_bundle"
    bundle.mkdir()
    original = json.loads(Path("examples/refactor_report_compute_film.json").read_text(encoding="utf-8"))
    (bundle / "handoff.json").write_text(json.dumps(original), encoding="utf-8")
    output = import_refactor_bundle(bundle, tmp_path / "normalised.json")
    payload = json.loads(output.read_text(encoding="utf-8"))
    assert payload["program_units"][0]["name"] == "compute_film"
    assert payload["handoff_metadata"]["canonical_source"].endswith("handoff.json")


def _sha256(path: Path) -> str:
    import hashlib

    return hashlib.sha256(path.read_bytes()).hexdigest()


def test_schema_11_source_hashes_are_verified(tmp_path: Path) -> None:
    import shutil

    bundle = tmp_path / "v050_reports"
    _write_external_bundle(bundle)
    canonical = import_refactor_bundle(bundle, tmp_path / "handoff.json")
    payload = json.loads(canonical.read_text(encoding="utf-8"))
    payload["schema_version"] = "1.1"
    payload["source_map"] = [
        {
            "source_file": path.relative_to(SOURCE).as_posix(),
            "absolute_path": str(path.resolve()),
            "sha256": _sha256(path),
        }
        for path in sorted(SOURCE.glob("*.f90"))
    ]
    canonical.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    assert validate_refactor_report(canonical) == []

    copied = tmp_path / "source_copy"
    shutil.copytree(SOURCE, copied)
    changed = copied / "20_advance.f90"
    changed.write_text(changed.read_text(encoding="utf-8") + "\n! changed after handoff\n", encoding="utf-8")

    report = verify_refactor_connection(
        copied,
        canonical,
        tmp_path / "connection.json",
        procedure=ROOT,
    )
    result = json.loads(report.read_text(encoding="utf-8"))
    assert result["status"] == "BLOCKED"
    assert any(item["category"] == "source-hash-mismatch" for item in result["issues"])


def test_unresolved_storage_overlay_blocks_migration(tmp_path: Path) -> None:
    bundle = tmp_path / "v050_overlay_reports"
    _write_external_bundle(bundle)
    canonical = import_refactor_bundle(bundle, tmp_path / "handoff.json")
    payload = json.loads(canonical.read_text(encoding="utf-8"))
    payload["schema_version"] = "1.1"
    payload["storage_overlays"] = [
        {
            "program_unit": "advance_common_state",
            "production_source_modified": False,
            "synthetic_fixture_status": "ready",
        }
    ]
    canonical.write_text(json.dumps(payload, indent=2), encoding="utf-8")

    report = verify_refactor_connection(
        SOURCE,
        canonical,
        tmp_path / "connection.json",
        procedure=ROOT,
    )
    result = json.loads(report.read_text(encoding="utf-8"))
    assert result["status"] == "BLOCKED"
    assert any(item["category"] == "storage-overlay-blocked" for item in result["issues"])
