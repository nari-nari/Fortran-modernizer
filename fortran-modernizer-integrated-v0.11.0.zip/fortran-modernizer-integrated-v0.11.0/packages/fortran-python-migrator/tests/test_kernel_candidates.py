from fpy_migrate.ir import build_project_ir
from fpy_migrate.kernels import analyze_kernel_candidates


def test_sor_sweep_is_high_priority_cython_candidate() -> None:
    project = build_project_ir(
        "samples/migration_units/sor_sweep.f90",
        procedure="sor_sweep",
    )
    report = analyze_kernel_candidates(project)
    by_name = {item.procedure: item for item in report.candidates}

    assert by_name["sor_sweep"].status == "AUTO"
    assert by_name["sor_sweep"].maximum_loop_depth == 2
    assert by_name["sor_sweep"].maximum_array_rank == 2
    assert by_name["sor_sweep"].score >= 90

    assert by_name["periodic_neighbors"].status == "REVIEW_REQUIRED"
    assert by_name["periodic_neighbors"].loop_count == 0
