from __future__ import annotations

import json
import os
from pathlib import Path
import subprocess
import sys

import numpy as np
import pytest

from fpy_migrate.e2e_acceptance import (
    Snapshot,
    compare_snapshots,
    fingerprint_source,
    validate_e2e_report,
)


ROOT = Path(__file__).resolve().parents[1]


def test_source_fingerprint_is_path_stable_and_content_sensitive(tmp_path: Path) -> None:
    first = tmp_path / "first"
    second = tmp_path / "second"
    first.mkdir()
    second.mkdir()
    (first / "a.f90").write_text("subroutine a\nend\n", encoding="utf-8")
    (second / "a.f90").write_text("subroutine a\nend\n", encoding="utf-8")

    assert fingerprint_source(first).aggregate_sha256 == fingerprint_source(second).aggregate_sha256
    (second / "a.f90").write_text("subroutine b\nend\n", encoding="utf-8")
    assert fingerprint_source(first).aggregate_sha256 != fingerprint_source(second).aggregate_sha256


def test_snapshot_comparison_requires_exact_integers_and_tolerant_arrays() -> None:
    expected = Snapshot(
        {"iterations": 10, "residual": 1.0},
        {"common_field__p": np.asarray([[1.0, 2.0]])},
    )
    close = Snapshot(
        {"iterations": 10, "residual": 1.0 + 1.0e-14},
        {"common_field__p": np.asarray([[1.0, 2.0 + 1.0e-14]])},
    )
    wrong_iteration = Snapshot(
        {"iterations": 11, "residual": 1.0},
        {"common_field__p": np.asarray([[1.0, 2.0]])},
    )

    assert compare_snapshots(expected, close, rtol=1.0e-12, atol=1.0e-13).passed
    assert not compare_snapshots(expected, wrong_iteration, rtol=1.0e-12, atol=1.0e-13).passed


@pytest.mark.integration
@pytest.mark.skipif(
    os.environ.get("FPY_RUN_SLOW_E2E") != "1",
    reason="Run independently with FPY_RUN_SLOW_E2E=1; nested native builds can stall under CI pytest.",
)
def test_journal_bearing_full_e2e_acceptance(tmp_path: Path) -> None:
    helper = ROOT / "tests/helpers/run_e2e_acceptance.py"
    report = tmp_path / "e2e_acceptance.json"
    subprocess.run(
        [sys.executable, str(helper), str(tmp_path / "build"), str(report)],
        check=True,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        timeout=1200,
        env={
            **{
                key: value
                for key, value in __import__("os").environ.items()
                if not key.startswith("PYTEST_")
            },
            "PYTHONPATH": str(ROOT / "src"),
        },
    )
    payload = json.loads(report.read_text(encoding="utf-8"))
    assert payload["status"] == "PASS"
    assert payload["generated_application"]["available_backends"] == [
        "python",
        "cython-safe",
        "cython-optimized",
        "fortran",
    ]
    assert payload["state_fields"]["common_field__p"]["shape"] == [36, 17]
    assert not validate_e2e_report(report)
