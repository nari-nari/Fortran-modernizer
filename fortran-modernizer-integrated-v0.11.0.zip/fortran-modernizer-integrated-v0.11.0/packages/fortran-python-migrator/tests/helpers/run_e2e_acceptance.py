from __future__ import annotations

import os
from pathlib import Path
import sys

from fpy_migrate.e2e_acceptance import verify_e2e_acceptance


def main() -> int:
    build_root = Path(sys.argv[1]).resolve()
    report = Path(sys.argv[2]).resolve()
    repository = Path(__file__).resolve().parents[2]
    fixture = repository / "samples/e2e/journal_bearing"
    verify_e2e_acceptance(
        fixture / "legacy",
        fixture / "normalized/journal_bearing_normalized.f90",
        program="journal_bearing_legacy",
        adapter_config=fixture / "adapters/config.json",
        handoff=fixture / "refactor_handoff.json",
        handoff_procedure="run_numeric",
        build_directory=build_root,
        output=report,
        include_fortran=True,
    )
    return 0


if __name__ == "__main__":
    code = main()
    sys.stdout.flush()
    sys.stderr.flush()
    os._exit(code)
