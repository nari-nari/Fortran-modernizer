from __future__ import annotations

import json
import os
from pathlib import Path
import subprocess
import sys

import numpy as np

from fpy_migrate.orchestration import build_orchestration, validate_orchestration_document


def main() -> int:
    root = Path(sys.argv[1]).resolve()
    report_path = Path(sys.argv[2]).resolve()
    repository = Path(__file__).resolve().parents[2]
    source = repository / "samples/migration_units/legacy_scoped_analysis.f90"
    config = repository / "samples/python_adapters/journal_bearing_adapter_config.json"
    expected = np.asarray(
        [
            9.3243524013075785e-11,
            2.6071517885680344,
            3.1797719040494399,
            0.4,
            7.8539816339744828,
        ],
        dtype=np.float64,
    )
    manifest, manifest_path = build_orchestration(
        source,
        program="journal_bearing_legacy",
        adapter_config=config,
        build_directory=root,
        default_backend="python",
        include_fortran=True,
    )
    errors = validate_orchestration_document(manifest_path, kind="manifest")
    if errors:
        raise RuntimeError(errors)
    application = root / "application.py"
    results: dict[str, dict[str, float | int]] = {}
    for backend in manifest.available_backends:
        completed = subprocess.run(
            [
                sys.executable,
                str(application),
                "--backend",
                backend,
                "--no-adapters",
                "--json",
            ],
            check=True,
            capture_output=True,
            text=True,
            timeout=30,
        )
        payload = json.loads(completed.stdout)
        if payload["iterations"] != 173:
            raise AssertionError(payload)
        np.testing.assert_allclose(
            np.asarray(
                [
                    payload["residual"],
                    payload["load"],
                    payload["pmax"],
                    payload["hmin"],
                    payload["friction"],
                ],
                dtype=np.float64,
            ),
            expected,
            rtol=1.0e-12,
            atol=1.0e-13,
        )
        results[backend] = payload
    completed = subprocess.run(
        [sys.executable, str(application), "--backend", "python"],
        check=True,
        capture_output=True,
        text=True,
        timeout=30,
    )
    if "iterations=173" not in completed.stdout:
        raise AssertionError(completed.stdout)
    if "max_pressure=3.1797719040494443E+00" not in completed.stdout:
        raise AssertionError(completed.stdout)
    if results["python"] != results["cython-safe"]:
        raise AssertionError("safe Cython differs from Python")
    if results["python"] != results["cython-optimized"]:
        raise AssertionError("optimized Cython differs from Python")
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text(
        json.dumps(
            {
                "manifest": str(manifest_path),
                "available_backends": list(manifest.available_backends),
                "results": results,
                "adapter_output": completed.stdout.splitlines(),
            },
            indent=2,
        ) + "\n",
        encoding="utf-8",
    )
    return 0


if __name__ == "__main__":
    code = main()
    os._exit(code)
