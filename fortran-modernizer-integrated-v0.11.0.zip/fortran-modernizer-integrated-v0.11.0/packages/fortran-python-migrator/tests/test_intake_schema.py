from fpy_migrate.intake import validate_refactor_report


def test_minimal_refactor_report_is_valid() -> None:
    assert validate_refactor_report("examples/refactor_report_minimal.json") == []
