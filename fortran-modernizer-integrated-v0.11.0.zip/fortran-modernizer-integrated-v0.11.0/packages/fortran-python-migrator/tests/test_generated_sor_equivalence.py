from __future__ import annotations

import importlib.util
import math
import shutil
import subprocess
from pathlib import Path

import numpy as np
import pytest

from fpy_migrate.ir import build_project_ir
from fpy_migrate.translate import generate_python, write_python


pytestmark = pytest.mark.integration


def _load_module(path: Path):
    spec = importlib.util.spec_from_file_location("generated_sor_sweep", path)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _read_fortran_output(path: Path, ntheta: int, nz: int) -> tuple[float, np.ndarray]:
    lines = path.read_text(encoding="utf-8").splitlines()
    residual = float(lines[0].split("=", maxsplit=1)[1])
    pressure = np.empty((ntheta, nz), dtype=np.float64, order="F")
    for line in lines[1:]:
        i_text, j_text, value_text = line.split(",")
        pressure[int(i_text) - 1, int(j_text) - 1] = float(value_text)
    return residual, pressure


def test_generated_sor_sweep_matches_fortran(tmp_path: Path) -> None:
    if shutil.which("gfortran") is None:
        pytest.skip("gfortran is not available")

    executable = tmp_path / "sor_sweep_driver"
    subprocess.run(
        [
            "gfortran",
            "-std=f2008",
            "-O0",
            "-fcheck=all",
            "samples/migration_units/sor_sweep.f90",
            "samples/migration_units/sor_sweep_driver.f90",
            "-o",
            str(executable),
        ],
        check=True,
    )
    output = tmp_path / "sor_sweep.txt"
    subprocess.run([str(executable), str(output)], check=True)

    ntheta = 12
    nz = 7
    expected_residual, expected_pressure = _read_fortran_output(output, ntheta, nz)

    project = build_project_ir(
        "samples/migration_units/sor_sweep.f90",
        procedure="sor_sweep",
    )
    generated_path = write_python(
        generate_python(project, procedure="sor_sweep"),
        tmp_path / "sor_sweep.py",
    )
    module = _load_module(generated_path)

    dtheta = 2.0 * math.pi / float(ntheta)
    dz = 1.0 / float(nz - 1)
    film = np.empty(ntheta, dtype=np.float64)
    pressure = np.empty((ntheta, nz), dtype=np.float64, order="F")
    for i in range(ntheta):
        film[i] = 1.0 + 0.60 * math.cos(float(i) * dtheta)
        for j in range(nz):
            pressure[i, j] = 0.002 * float((i + 1) * (j + 1))

    actual_pressure, actual_residual = module.sor_sweep(
        ntheta,
        nz,
        film,
        pressure,
        dtheta,
        dz,
        0.20,
        1.35,
    )
    np.testing.assert_allclose(actual_pressure, expected_pressure, rtol=0.0, atol=7.0e-16)
    assert actual_residual == pytest.approx(expected_residual, rel=0.0, abs=5.0e-16)
