from __future__ import annotations

from pathlib import Path
import subprocess

import json

import numpy as np
import pytest
from jsonschema import Draft202012Validator

from fpy_migrate.extraction import (
    PartialLoopExtractionError,
    analyze_partial_loop,
    build_partial_loop_bundle,
    load_partial_loop_runtime,
)
from fpy_migrate.ir import build_project_ir
from fpy_migrate.ir.model import CallIR, DoLoopIR


ROOT = Path(__file__).resolve().parents[1]
SAMPLES = ROOT / "samples" / "migration_units"


def _compile_and_run(tmp_path: Path):
    executable = tmp_path / "partial_loop_driver"
    subprocess.run(
        [
            "gfortran",
            "-O2",
            str(SAMPLES / "partial_loop_analysis.f90"),
            str(SAMPLES / "partial_loop_driver.f90"),
            "-o",
            str(executable),
        ],
        check=True,
        capture_output=True,
        text=True,
    )
    completed = subprocess.run(
        [str(executable)], check=True, capture_output=True, text=True
    )
    lines = completed.stdout.splitlines()
    total, peak, relaxation = map(float, lines[0].split())
    pressure = np.zeros(16, dtype=np.float64)
    film = np.zeros(16, dtype=np.float64)
    for line in lines[1:]:
        index, p_value, h_value = line.split()
        pressure[int(index) - 1] = float(p_value)
        film[int(index) - 1] = float(h_value)
    return total, peak, relaxation, pressure, film


def _initial_state(runtime):
    state = runtime.CommonFieldState(
        pressure=np.zeros(16, dtype=np.float64),
        film=np.zeros(16, dtype=np.float64),
        relaxation_factor=0.75,
    )
    for index in range(12):
        state.pressure[index] = 0.1 * (index + 1)
        state.film[index] = 1.0 + 0.02 * (index + 1)
    return state


def test_first_top_level_loop_is_extracted_and_post_loop_remains_python() -> None:
    project = build_project_ir(
        SAMPLES / "partial_loop_analysis.f90", procedure="run_partial_loop"
    )
    extraction = analyze_partial_loop(project, "run_partial_loop", loop_index=1)

    assert extraction.status == "AUTO"
    assert extraction.pre_statement_count == 1
    assert extraction.post_statement_count == 4
    assert extraction.kernel_procedure == "run_partial_loop_loop_1_kernel"
    kernel = extraction.kernel_project.procedure(extraction.kernel_procedure)
    assert kernel.arguments == ("n", "bias", "pressure", "film")
    assert {name: kernel.symbol(name).intent for name in kernel.arguments} == {
        "n": "in",
        "bias": "in",
        "pressure": "inout",
        "film": "in",
    }
    assert len(kernel.statements) == 1
    assert isinstance(kernel.statements[0], DoLoopIR)

    wrapper = extraction.wrapper_project.procedure("run_partial_loop")
    assert isinstance(wrapper.statements[1], CallIR)
    assert wrapper.statements[1].procedure == extraction.kernel_procedure
    assert sum(isinstance(item, DoLoopIR) for item in wrapper.statements) == 1
    assert wrapper.statements[-1].kind == "assignment"


def test_second_top_level_loop_can_be_selected_independently() -> None:
    project = build_project_ir(
        SAMPLES / "partial_loop_analysis.f90", procedure="run_partial_loop"
    )
    extraction = analyze_partial_loop(project, "run_partial_loop", loop_index=2)
    kernel = extraction.kernel_project.procedure(extraction.kernel_procedure)

    assert extraction.pre_statement_count == 4
    assert extraction.post_statement_count == 1
    assert kernel.arguments == ("n", "total_pressure", "peak_pressure", "pressure")
    assert kernel.symbol("total_pressure").intent == "inout"
    assert kernel.symbol("peak_pressure").intent == "inout"
    assert kernel.symbol("pressure").intent == "in"


def test_invalid_loop_index_is_blocked() -> None:
    project = build_project_ir(
        SAMPLES / "partial_loop_analysis.f90", procedure="run_partial_loop"
    )
    with pytest.raises(PartialLoopExtractionError, match="only 2 loop"):
        analyze_partial_loop(project, "run_partial_loop", loop_index=3)


@pytest.mark.integration
def test_partial_loop_backends_match_fortran_and_keep_postprocessing_in_python(
    tmp_path: Path,
) -> None:
    build_root = tmp_path / "partial_loop_bundle"
    bundle, manifest_path = build_partial_loop_bundle(
        SAMPLES / "partial_loop_analysis.f90",
        procedure="run_partial_loop",
        loop_index=1,
        build_directory=build_root,
    )
    assert manifest_path.exists()
    report_data = json.loads((build_root / "partial_loop_extraction.json").read_text())
    report_schema = json.loads((ROOT / "schemas" / "partial_loop_extraction.schema.json").read_text())
    manifest_data = json.loads(manifest_path.read_text())
    manifest_schema = json.loads((ROOT / "schemas" / "partial_loop_manifest.schema.json").read_text())
    assert list(Draft202012Validator(report_schema).iter_errors(report_data)) == []
    assert list(Draft202012Validator(manifest_schema).iter_errors(manifest_data)) == []
    runtime = load_partial_loop_runtime(
        build_root / bundle.artifacts["runtime"], "milestone11_partial_runtime"
    )
    f_total, f_peak, f_relaxation, f_pressure, f_film = _compile_and_run(tmp_path)

    reference_pressure = None
    for backend in ("python", "cython-safe", "cython-optimized"):
        state = _initial_state(runtime)
        total, peak = runtime.run_partial_loop(state, 12, 0.4, backend=backend)

        np.testing.assert_allclose(state.pressure, f_pressure, rtol=1e-14, atol=1e-14)
        np.testing.assert_allclose(state.film, f_film, rtol=1e-14, atol=1e-14)
        assert total == pytest.approx(f_total, rel=1e-14, abs=1e-14)
        assert peak == pytest.approx(f_peak, rel=1e-14, abs=1e-14)
        assert state.relaxation_factor == pytest.approx(
            f_relaxation, rel=1e-14, abs=1e-14
        )
        if reference_pressure is None:
            reference_pressure = state.pressure.copy()
        else:
            np.testing.assert_array_equal(state.pressure, reference_pressure)
