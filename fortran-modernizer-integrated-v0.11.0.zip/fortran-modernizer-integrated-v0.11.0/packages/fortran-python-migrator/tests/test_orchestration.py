from __future__ import annotations

from pathlib import Path
import json
import subprocess
import sys

import numpy as np
import pytest

from fpy_migrate.orchestration import (
    OrchestrationError,
    analyze_orchestration,
    build_orchestration,
    validate_orchestration_document,
)


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "samples/migration_units/legacy_scoped_analysis.f90"
CONFIG = ROOT / "samples/python_adapters/journal_bearing_adapter_config.json"
EXPECTED = np.asarray(
    [
        9.3243524013075785e-11,
        2.6071517885680344,
        3.1797719040494399,
        0.4,
        7.8539816339744828,
    ],
    dtype=np.float64,
)


def test_main_program_is_partitioned_into_numeric_and_adapter_calls() -> None:
    plan, _, project = analyze_orchestration(
        SOURCE,
        program="journal_bearing_legacy",
        adapter_config=CONFIG,
    )

    assert [item.procedure for item in plan.numeric_calls] == [
        "init_geometry",
        "solve_reynolds",
        "compute_metrics",
    ]
    assert [item.procedure for item in plan.adapter_calls] == ["print_results"]
    assert [item.name for item in plan.result_fields] == [
        "iterations",
        "residual",
        "load",
        "pmax",
        "hmin",
        "friction",
    ]
    assert [item.name for item in project.procedures] == [
        "init_geometry",
        "solve_reynolds",
        "compute_metrics",
    ]
    assert plan.state_groups == ("common_field",)


def test_adapter_signature_mismatch_is_blocked(tmp_path: Path) -> None:
    adapter = tmp_path / "bad_adapter.py"
    adapter.write_text(
        "def print_results(iterations, residual):\n    return None\n",
        encoding="utf-8",
    )
    config = tmp_path / "config.json"
    config.write_text(
        """{
  "schema_version": "1.0",
  "adapters": {
    "print_results": {
      "source": "bad_adapter.py",
      "callable": "print_results",
      "arguments": ["iterations", "residual", "load", "pmax", "hmin", "friction"],
      "mode": "read_only"
    }
  }
}
""",
        encoding="utf-8",
    )

    with pytest.raises(OrchestrationError, match="signature"):
        analyze_orchestration(
            SOURCE,
            program="journal_bearing_legacy",
            adapter_config=config,
        )


def test_unconfigured_formatted_output_remains_blocked(tmp_path: Path) -> None:
    adapter = tmp_path / "unused.py"
    adapter.write_text("def unused():\n    return None\n", encoding="utf-8")
    config = tmp_path / "config.json"
    config.write_text(
        """{
  "schema_version": "1.0",
  "adapters": {
    "unused": {
      "source": "unused.py",
      "callable": "unused",
      "arguments": [],
      "mode": "read_only"
    }
  }
}
""",
        encoding="utf-8",
    )

    with pytest.raises(OrchestrationError, match="print_results.*not migration-ready"):
        analyze_orchestration(
            SOURCE,
            program="journal_bearing_legacy",
            adapter_config=config,
        )


def test_numeric_call_after_adapter_is_blocked(tmp_path: Path) -> None:
    source = tmp_path / "interleaved.f90"
    source.write_text(
        """program interleaved
  implicit none
  real(8) :: value
  call compute(value)
  call emit(value)
  call compute(value)
end program interleaved

subroutine compute(value)
  implicit none
  real(8), intent(out) :: value
  value = 1.0d0
end subroutine compute

subroutine emit(value)
  implicit none
  real(8), intent(in) :: value
  write(*,*) value
end subroutine emit
""",
        encoding="utf-8",
    )
    adapter = tmp_path / "adapter.py"
    adapter.write_text("def emit(value):\n    print(value)\n", encoding="utf-8")
    config = tmp_path / "config.json"
    config.write_text(
        """{
  "schema_version": "1.0",
  "adapters": {
    "emit": {
      "source": "adapter.py",
      "callable": "emit",
      "arguments": ["value"],
      "mode": "read_only"
    }
  }
}
""",
        encoding="utf-8",
    )

    with pytest.raises(OrchestrationError, match="appears after an adapter"):
        analyze_orchestration(
            source,
            program="interleaved",
            adapter_config=config,
        )


@pytest.mark.integration
def test_generated_application_runs_all_four_backends(tmp_path: Path) -> None:
    helper = ROOT / "tests/helpers/run_orchestration_integration.py"
    report = tmp_path / "orchestration_integration.json"
    subprocess.run(
        [sys.executable, str(helper), str(tmp_path / "app"), str(report)],
        check=True,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        timeout=150,
        env={**__import__("os").environ, "PYTHONPATH": str(ROOT / "src")},
    )
    payload = json.loads(report.read_text(encoding="utf-8"))
    assert payload["available_backends"] == [
        "python",
        "cython-safe",
        "cython-optimized",
        "fortran",
    ]
    assert payload["results"]["python"]["iterations"] == 173
    assert "iterations=173" in payload["adapter_output"]

