from __future__ import annotations

import json
import subprocess
from pathlib import Path

import pytest

from fpy_migrate.kernels import CythonBuildError, build_cython_extension


def test_failed_cython_build_retains_report_and_logs(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    source = tmp_path / "broken_kernel.py"
    source.write_text("def broken(:\n    pass\n", encoding="utf-8")

    def fake_run(*args: object, **kwargs: object) -> subprocess.CompletedProcess[str]:
        return subprocess.CompletedProcess(
            args=["python", "setup_generated_kernel.py"],
            returncode=1,
            stdout="build started\n",
            stderr="synthetic compiler failure\n",
        )

    monkeypatch.setattr(subprocess, "run", fake_run)

    with pytest.raises(CythonBuildError) as caught:
        build_cython_extension(
            source,
            "broken_kernel_native",
            tmp_path / "build",
        )

    report_path = caught.value.report
    report = json.loads(report_path.read_text(encoding="utf-8"))
    assert report["status"] == "BLOCKED"
    assert report["returncode"] == 1
    assert report["module_name"] == "broken_kernel_native"
    assert (report_path.parent / report["stdout"]).read_text(encoding="utf-8") == "build started\n"
    assert "synthetic compiler failure" in (
        report_path.parent / report["stderr"]
    ).read_text(encoding="utf-8")
