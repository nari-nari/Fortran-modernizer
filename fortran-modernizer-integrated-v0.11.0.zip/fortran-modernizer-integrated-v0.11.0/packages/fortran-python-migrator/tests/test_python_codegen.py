from __future__ import annotations

import importlib.util
import math
from pathlib import Path

import numpy as np

from fpy_migrate.ir import build_project_ir
from fpy_migrate.translate import generate_python, write_python


def _load_module(path: Path, name: str = "generated_module"):
    spec = importlib.util.spec_from_file_location(name, path)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def test_generated_compute_film_matches_formula(tmp_path: Path) -> None:
    project = build_project_ir(
        "samples/migration_units/compute_film.f90",
        procedure="compute_film",
    )
    generated = generate_python(project, procedure="compute_film")
    target = write_python(generated, tmp_path / "compute_film.py")
    module = _load_module(target)

    actual = module.compute_film(32, 0.60)
    theta = np.arange(32, dtype=np.float64) * (2.0 * math.pi / 32.0)
    expected = 1.0 + 0.60 * np.cos(theta)
    np.testing.assert_allclose(actual, expected, rtol=0.0, atol=5.0e-16)
    assert "film[(i) - 1]" in generated.source
    assert "range(1, (ntheta) + 1)" in generated.source


def test_generated_if_else_executes_both_branches(tmp_path: Path) -> None:
    project = build_project_ir(
        "samples/migration_units/unsupported_if.f90",
        procedure="unsupported_if",
    )
    target = write_python(
        generate_python(project, procedure="unsupported_if"),
        tmp_path / "generated_abs.py",
    )
    module = _load_module(target, "generated_abs")
    assert module.unsupported_if(2.5) == 2.5
    assert module.unsupported_if(-2.5) == 2.5


def test_generated_sor_contains_helper_call_and_two_dimensional_indices() -> None:
    project = build_project_ir(
        "samples/migration_units/sor_sweep.f90",
        procedure="sor_sweep",
    )
    source = generate_python(project, procedure="sor_sweep").source
    assert "def periodic_neighbors" in source
    assert "iw, ie = periodic_neighbors(i, ntheta)" in source
    assert "pressure[(i) - 1, (j) - 1]" in source
    assert " and " in source
