from __future__ import annotations

import importlib.util
import shutil
import subprocess
from pathlib import Path

import numpy as np
import pytest

from fpy_migrate.ir import build_project_ir
from fpy_migrate.translate import generate_python, write_python


pytestmark = pytest.mark.integration


def _load_module(path: Path):
    spec = importlib.util.spec_from_file_location("generated_compute_film", path)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def test_generated_python_matches_fortran_subroutine(tmp_path: Path) -> None:
    if shutil.which("gfortran") is None:
        pytest.skip("gfortran is not available")

    executable = tmp_path / "compute_film_driver"
    subprocess.run(
        [
            "gfortran",
            "-std=f2008",
            "-O0",
            "-fcheck=all",
            "samples/migration_units/compute_film.f90",
            "samples/migration_units/compute_film_driver.f90",
            "-o",
            str(executable),
        ],
        check=True,
    )
    fortran_output = tmp_path / "film.csv"
    subprocess.run([str(executable), str(fortran_output)], check=True)
    fortran_values = np.loadtxt(fortran_output, delimiter=",", usecols=1)

    project = build_project_ir(
        "samples/migration_units/compute_film.f90",
        procedure="compute_film",
    )
    generated_path = write_python(
        generate_python(project, procedure="compute_film"),
        tmp_path / "compute_film.py",
    )
    module = _load_module(generated_path)
    python_values = module.compute_film(32, 0.60)
    np.testing.assert_allclose(python_values, fortran_values, rtol=0.0, atol=5.0e-16)
