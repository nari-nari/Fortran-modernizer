from __future__ import annotations

from pathlib import Path
import subprocess

import json

import jsonschema
import numpy as np
import pytest

from fpy_migrate.extraction import (
    analyze_hybrid_project,
    build_hybrid_project,
    load_hybrid_runtime,
)
from fpy_migrate.ir import build_project_ir


ROOT = Path(__file__).resolve().parents[1]
PROJECT = ROOT / "samples" / "migration_projects" / "common_state_project"


def _compile_and_run_project(tmp_path: Path):
    executable = tmp_path / "common_state_project"
    sources = [
        PROJECT / "10_initialize.f90",
        PROJECT / "20_advance.f90",
        PROJECT / "30_summarize.f90",
        PROJECT / "40_run.f90",
        PROJECT / "driver.f90",
    ]
    subprocess.run(
        ["gfortran", "-O2", *(str(item) for item in sources), "-o", str(executable)],
        check=True,
        capture_output=True,
        text=True,
    )
    completed = subprocess.run(
        [str(executable)], check=True, capture_output=True, text=True
    )
    lines = completed.stdout.splitlines()
    total, minimum, relaxation = map(float, lines[0].split())
    pressure = np.zeros(12, dtype=np.float64)
    film = np.zeros(12, dtype=np.float64)
    for line in lines[1:]:
        index, p_value, h_value = line.split()
        pressure[int(index) - 1] = float(p_value)
        film[int(index) - 1] = float(h_value)
    return total, minimum, relaxation, pressure, film


def test_directory_project_ir_preserves_cross_file_calls_and_common_aliases() -> None:
    project = build_project_ir(PROJECT, procedure="run_common_state")

    assert len(project.source_files) == 5
    assert [item.name for item in project.procedures] == [
        "initialize_common_state",
        "advance_common_state",
        "summarize_common_state",
        "run_common_state",
    ]
    group = project.state_group("common_field")
    assert [item.state_field for item in group.fields] == [
        "pressure",
        "film",
        "relaxation_factor",
    ]
    advance = project.procedure("advance_common_state")
    aliases = {
        item.name: item.state_field for item in advance.symbols if item.role == "state"
    }
    assert aliases == {"p": "pressure", "h": "film", "omega": "relaxation_factor"}


def test_hybrid_plan_extracts_leaf_state_loops_and_keeps_orchestrator_in_python() -> None:
    project = build_project_ir(PROJECT, procedure="run_common_state")
    plan = analyze_hybrid_project(project, "run_common_state")

    assert plan.extracted_procedures == (
        "initialize_common_state",
        "advance_common_state",
        "summarize_common_state",
    )
    statuses = {item.procedure: item.status for item in plan.candidates}
    assert statuses["run_common_state"] == "PYTHON_ONLY"
    assert all(statuses[name] == "AUTO" for name in plan.extracted_procedures)
    schema = json.loads((ROOT / "schemas" / "hybrid_project_plan.schema.json").read_text())
    jsonschema.validate(plan.to_dict(), schema)


@pytest.mark.integration
def test_hybrid_project_backends_and_per_procedure_override_match_fortran(
    tmp_path: Path,
) -> None:
    manifest, manifest_path = build_hybrid_project(
        PROJECT,
        root_procedure="run_common_state",
        build_directory=tmp_path / "hybrid",
    )
    assert manifest_path.exists()
    schema = json.loads((ROOT / "schemas" / "hybrid_project_manifest.schema.json").read_text())
    jsonschema.validate(manifest.to_dict(), schema)
    assert manifest.extracted_procedures == (
        "initialize_common_state",
        "advance_common_state",
        "summarize_common_state",
    )

    runtime = load_hybrid_runtime(
        tmp_path / "hybrid" / manifest.artifacts["hybrid_runtime"],
        "test_hybrid_project_runtime",
    )
    f_total, f_minimum, f_relaxation, f_pressure, f_film = _compile_and_run_project(
        tmp_path
    )

    reference_pressure = None
    for backend in ("python", "cython-safe", "cython-optimized"):
        state = runtime.create_common_field()
        total, minimum = runtime.run_common_state(
            state, 12, 0.4, backend=backend
        )
        np.testing.assert_allclose(state.pressure[:12], f_pressure, rtol=1e-14, atol=1e-14)
        np.testing.assert_allclose(state.film[:12], f_film, rtol=1e-14, atol=1e-14)
        assert total == pytest.approx(f_total, rel=1e-14, abs=1e-14)
        assert minimum == pytest.approx(f_minimum, rel=1e-14, abs=1e-14)
        assert state.relaxation_factor == pytest.approx(
            f_relaxation, rel=1e-14, abs=1e-14
        )
        if reference_pressure is None:
            reference_pressure = state.pressure.copy()
        else:
            np.testing.assert_array_equal(state.pressure, reference_pressure)

    state = runtime.create_common_field()
    total, minimum = runtime.run_common_state(
        state,
        12,
        0.4,
        backend="cython-optimized",
        backend_overrides={"summarize_common_state": "python"},
    )
    assert total == pytest.approx(f_total, rel=1e-14, abs=1e-14)
    assert minimum == pytest.approx(f_minimum, rel=1e-14, abs=1e-14)

    with pytest.raises(ValueError, match="non-kernel"):
        runtime.run_common_state(
            runtime.create_common_field(),
            12,
            0.4,
            backend_overrides={"run_common_state": "python"},
        )


@pytest.mark.integration
def test_module_state_hybrid_project_matches_fortran(tmp_path: Path) -> None:
    source = ROOT / "samples" / "migration_units" / "module_state_analysis.f90"
    driver = ROOT / "samples" / "migration_units" / "module_state_driver.f90"
    manifest, _ = build_hybrid_project(
        source,
        root_procedure="run_module_state",
        build_directory=tmp_path / "module_hybrid",
    )
    runtime = load_hybrid_runtime(
        tmp_path / "module_hybrid" / manifest.artifacts["hybrid_runtime"],
        "test_module_hybrid_project_runtime",
    )

    executable = tmp_path / "module_state_project"
    subprocess.run(
        ["gfortran", "-O2", str(source), str(driver), "-o", str(executable)],
        check=True,
        capture_output=True,
        text=True,
    )
    completed = subprocess.run(
        [str(executable)], check=True, capture_output=True, text=True
    )
    lines = completed.stdout.splitlines()
    header = lines[0].split()
    active = int(header[0])
    f_total, f_minimum, f_relaxation = map(float, header[1:])
    f_pressure = np.zeros(active, dtype=np.float64)
    f_film = np.zeros(active, dtype=np.float64)
    for line in lines[1:]:
        index, p_value, h_value = line.split()
        f_pressure[int(index) - 1] = float(p_value)
        f_film[int(index) - 1] = float(h_value)

    for backend in ("python", "cython-safe", "cython-optimized"):
        state = runtime.create_module_module_state_analysis_mod()
        total, minimum = runtime.run_module_state(state, 12, 0.4, backend=backend)
        assert state.active_count == active
        np.testing.assert_allclose(state.pressure[:active], f_pressure, rtol=1e-14, atol=1e-14)
        np.testing.assert_allclose(state.film[:active], f_film, rtol=1e-14, atol=1e-14)
        assert total == pytest.approx(f_total, rel=1e-14, abs=1e-14)
        assert minimum == pytest.approx(f_minimum, rel=1e-14, abs=1e-14)
        assert state.relaxation_factor == pytest.approx(
            f_relaxation, rel=1e-14, abs=1e-14
        )

PARTIAL_PROJECT = ROOT / "samples" / "migration_projects" / "partial_hybrid_project"


def _compile_and_run_partial_project(tmp_path: Path):
    executable = tmp_path / "partial_hybrid_project"
    sources = [
        PARTIAL_PROJECT / "10_initialize.f90",
        PARTIAL_PROJECT / "20_summarize.f90",
        PARTIAL_PROJECT / "30_run.f90",
        PARTIAL_PROJECT / "driver.f90",
    ]
    subprocess.run(
        ["gfortran", "-O2", *(str(item) for item in sources), "-o", str(executable)],
        check=True,
        capture_output=True,
        text=True,
    )
    completed = subprocess.run(
        [str(executable)], check=True, capture_output=True, text=True
    )
    lines = completed.stdout.splitlines()
    total, peak, relaxation = map(float, lines[0].split())
    pressure = np.zeros(12, dtype=np.float64)
    film = np.zeros(12, dtype=np.float64)
    for line in lines[1:]:
        index, p_value, h_value = line.split()
        pressure[int(index) - 1] = float(p_value)
        film[int(index) - 1] = float(h_value)
    return total, peak, relaxation, pressure, film


def test_hybrid_plan_promotes_python_only_orchestrator_loop_to_partial_auto() -> None:
    project = build_project_ir(PARTIAL_PROJECT, procedure="run_partial_hybrid")
    plan = analyze_hybrid_project(project, "run_partial_hybrid")

    assert plan.full_extracted_procedures == (
        "initialize_partial_state",
        "summarize_partial_state",
    )
    assert plan.partial_extracted_procedures == ("run_partial_hybrid",)
    candidate = plan.candidate("run_partial_hybrid")
    assert candidate.status == "PARTIAL_AUTO"
    assert candidate.extraction_kind == "partial-loop"
    assert candidate.loop_index == 1
    assert candidate.kernel_procedure == "run_partial_hybrid_loop_1_kernel"
    schema = json.loads((ROOT / "schemas" / "hybrid_project_plan.schema.json").read_text())
    jsonschema.validate(plan.to_dict(), schema)


@pytest.mark.integration
def test_project_hybrid_combines_full_and_partial_kernels_and_matches_fortran(
    tmp_path: Path,
) -> None:
    build_root = tmp_path / "partial_hybrid"
    manifest, manifest_path = build_hybrid_project(
        PARTIAL_PROJECT,
        root_procedure="run_partial_hybrid",
        build_directory=build_root,
    )
    schema = json.loads((ROOT / "schemas" / "hybrid_project_manifest.schema.json").read_text())
    jsonschema.validate(manifest.to_dict(), schema)
    assert manifest_path.exists()
    assert manifest.full_extracted_procedures == (
        "initialize_partial_state",
        "summarize_partial_state",
    )
    assert manifest.partial_extracted_procedures == ("run_partial_hybrid",)
    assert "run_partial_hybrid" in manifest.partial_loop_bundles
    assert (build_root / manifest.artifacts["transformed_ir"]).exists()

    runtime = load_hybrid_runtime(
        build_root / manifest.artifacts["hybrid_runtime"],
        "test_partial_hybrid_project_runtime",
    )
    f_total, f_peak, f_relaxation, f_pressure, f_film = (
        _compile_and_run_partial_project(tmp_path)
    )

    reference_pressure = None
    for backend in ("python", "cython-safe", "cython-optimized"):
        state = runtime.create_common_field()
        total, peak = runtime.run_partial_hybrid(state, 12, 0.4, backend=backend)
        np.testing.assert_allclose(state.pressure[:12], f_pressure, rtol=1e-14, atol=1e-14)
        np.testing.assert_allclose(state.film[:12], f_film, rtol=1e-14, atol=1e-14)
        assert total == pytest.approx(f_total, rel=1e-14, abs=1e-14)
        assert peak == pytest.approx(f_peak, rel=1e-14, abs=1e-14)
        assert state.relaxation_factor == pytest.approx(
            f_relaxation, rel=1e-14, abs=1e-14
        )
        if reference_pressure is None:
            reference_pressure = state.pressure.copy()
        else:
            np.testing.assert_array_equal(state.pressure, reference_pressure)

    state = runtime.create_common_field()
    total, peak = runtime.run_partial_hybrid(
        state,
        12,
        0.4,
        backend="cython-optimized",
        backend_overrides={
            "initialize_partial_state": "python",
            "run_partial_hybrid": "cython-safe",
            "summarize_partial_state": "python",
        },
    )
    assert total == pytest.approx(f_total, rel=1e-14, abs=1e-14)
    assert peak == pytest.approx(f_peak, rel=1e-14, abs=1e-14)
    np.testing.assert_allclose(state.pressure[:12], f_pressure, rtol=1e-14, atol=1e-14)
