import shutil
from pathlib import Path

import pytest

from fpy_migrate.assessment import assess_tree
from fpy_migrate.normalization import normalize_with_findent


def test_findent_converts_legacy_sample_to_parseable_free_form(tmp_path: Path) -> None:
    if shutil.which("findent") is None:
        pytest.skip("findent not available")
    output = tmp_path / "journal_bearing_legacy.f90"
    normalize_with_findent(
        "samples/journal_bearing/fortran_legacy/journal_bearing_legacy.f",
        output,
    )
    report = assess_tree(tmp_path)
    assert report.files[0].source_form == "free"
    assert report.files[0].parse_succeeded
