from __future__ import annotations

import json
from pathlib import Path
import subprocess

import jsonschema
import numpy as np
import pytest

from fpy_migrate.extraction import (
    EconomicsCaseSample,
    HybridEconomicsReport,
    KernelEconomicsSample,
    analyze_hybrid_project,
    benchmark_hybrid_economics,
    build_hybrid_project,
    load_hybrid_runtime,
)
from fpy_migrate.ir import build_project_ir


ROOT = Path(__file__).resolve().parents[1]
PROJECT = ROOT / "samples" / "migration_projects" / "partial_hybrid_project"
PROFILE = ROOT / "reports" / "milestone14" / "hybrid_profile_suite.json"
SOURCE_FILES = tuple(str(item) for item in sorted(PROJECT.glob("*.f90")))


def _sample(
    procedure: str,
    kernel: str,
    kind: str,
    *,
    speedup: float,
    saved: float,
    build: float,
    extension_bytes: int,
    break_even_runs: float | None,
) -> KernelEconomicsSample:
    return KernelEconomicsSample(
        procedure=procedure,
        kernel_procedure=kernel,
        extraction_kind=kind,
        build_seconds=build,
        bundle_bytes=extension_bytes * 4,
        optimized_extension_bytes=extension_bytes,
        weighted_baseline_seconds=0.1,
        weighted_optimized_seconds=0.1 - saved,
        weighted_saved_seconds=saved,
        speedup=speedup,
        weighted_calls_per_run=10.0,
        saved_seconds_per_call=saved / 10.0 if saved > 0 else None,
        break_even_runs=break_even_runs,
        break_even_calls=(break_even_runs * 10.0 if break_even_runs is not None else None),
        savings_per_megabyte=saved / max(extension_bytes / (1024.0**2), 1e-12),
        cost_benefit_score=saved / build,
        cases=(
            EconomicsCaseSample(
                case_name="standard",
                weight=1.0,
                call_count_per_run=10.0,
                baseline_seconds=0.1,
                optimized_seconds=0.1 - saved,
                speedup=speedup,
                saved_seconds=saved,
            ),
        ),
    )


def _economics_report() -> HybridEconomicsReport:
    return HybridEconomicsReport(
        schema_version="1.0",
        root_procedure="run_partial_hybrid",
        source_files=SOURCE_FILES,
        profile_kind="suite",
        profile_report="fake_profile.json",
        build_manifest="fake_manifest.json",
        warmup_runs=1,
        measured_runs=20,
        samples=(
            _sample(
                "run_partial_hybrid",
                "run_partial_hybrid_loop_1_kernel",
                "partial-loop",
                speedup=3.0,
                saved=0.06,
                build=1.0,
                extension_bytes=200_000,
                break_even_runs=16.7,
            ),
            _sample(
                "initialize_partial_state",
                "initialize_partial_state_kernel",
                "full-procedure",
                speedup=1.02,
                saved=0.001,
                build=2.0,
                extension_bytes=300_000,
                break_even_runs=2000.0,
            ),
            _sample(
                "summarize_partial_state",
                "summarize_partial_state_kernel",
                "full-procedure",
                speedup=0.95,
                saved=-0.002,
                build=1.5,
                extension_bytes=250_000,
                break_even_runs=None,
            ),
        ),
    )


def test_economics_thresholds_retain_only_profitable_kernel() -> None:
    project = build_project_ir(PROJECT, procedure="run_partial_hybrid")
    plan = analyze_hybrid_project(
        project,
        "run_partial_hybrid",
        economics_report=_economics_report(),
        min_economics_speedup=1.2,
        min_economics_saved_time_ms=10.0,
        max_economics_build_seconds=1.2,
        max_economics_artifact_mb=0.5,
        max_economics_break_even_runs=100.0,
    )
    assert plan.extracted_procedures == ("run_partial_hybrid",)
    selected = plan.candidate("run_partial_hybrid")
    assert selected.economics_speedup == pytest.approx(3.0)
    assert selected.economics_break_even_runs == pytest.approx(16.7)
    assert not plan.candidate("initialize_partial_state").selected
    assert not plan.candidate("summarize_partial_state").selected
    schema = json.loads((ROOT / "schemas" / "hybrid_project_plan.schema.json").read_text())
    jsonschema.validate(plan.to_dict(), schema)


def _fortran_result(tmp_path: Path):
    executable = tmp_path / "economics_partial_fortran"
    sources = [
        PROJECT / "10_initialize.f90",
        PROJECT / "20_summarize.f90",
        PROJECT / "30_run.f90",
        PROJECT / "driver.f90",
    ]
    subprocess.run(
        ["gfortran", "-O2", *(str(item) for item in sources), "-o", str(executable)],
        check=True,
        capture_output=True,
        text=True,
    )
    completed = subprocess.run([str(executable)], check=True, capture_output=True, text=True)
    lines = completed.stdout.splitlines()
    total, peak, relaxation = map(float, lines[0].split())
    pressure = np.zeros(12, dtype=np.float64)
    film = np.zeros(12, dtype=np.float64)
    for line in lines[1:]:
        index, p_value, h_value = line.split()
        pressure[int(index) - 1] = float(p_value)
        film[int(index) - 1] = float(h_value)
    return total, peak, relaxation, pressure, film


@pytest.mark.integration
def test_economics_selected_build_matches_fortran(tmp_path: Path) -> None:
    build_root = tmp_path / "economics_selected"
    manifest, _ = build_hybrid_project(
        PROJECT,
        root_procedure="run_partial_hybrid",
        build_directory=build_root,
        economics_report=_economics_report(),
        min_economics_speedup=1.2,
        min_economics_saved_time_ms=10.0,
        max_economics_break_even_runs=100.0,
    )
    assert manifest.extracted_procedures == ("run_partial_hybrid",)
    assert set(manifest.build_metrics) == {"run_partial_hybrid"}
    manifest_schema = json.loads(
        (ROOT / "schemas" / "hybrid_project_manifest.schema.json").read_text()
    )
    jsonschema.validate(manifest.to_dict(), manifest_schema)

    runtime = load_hybrid_runtime(
        build_root / manifest.artifacts["hybrid_runtime"],
        "test_economics_selected_runtime",
    )
    expected = _fortran_result(tmp_path)
    state = runtime.create_common_field()
    total, peak = runtime.run_partial_hybrid(state, 12, 0.4, backend="cython-optimized")
    np.testing.assert_allclose(state.pressure[:12], expected[3], rtol=1e-14, atol=1e-14)
    np.testing.assert_allclose(state.film[:12], expected[4], rtol=1e-14, atol=1e-14)
    assert total == pytest.approx(expected[0], rel=1e-14, abs=1e-14)
    assert peak == pytest.approx(expected[1], rel=1e-14, abs=1e-14)
    assert state.relaxation_factor == pytest.approx(expected[2], rel=1e-14, abs=1e-14)


@pytest.mark.integration
def test_economics_benchmark_records_build_size_and_speedup(tmp_path: Path) -> None:
    report, output = benchmark_hybrid_economics(
        PROJECT,
        root_procedure="run_partial_hybrid",
        profile_report=PROFILE,
        build_directory=tmp_path / "economics",
        warmup_runs=0,
        measured_runs=2,
    )
    assert output.exists()
    assert {sample.procedure for sample in report.samples} == {
        "initialize_partial_state",
        "summarize_partial_state",
        "run_partial_hybrid",
    }
    for sample in report.samples:
        assert sample.build_seconds > 0.0
        assert sample.bundle_bytes > sample.optimized_extension_bytes > 0
        assert len(sample.cases) == 3
    schema = json.loads((ROOT / "schemas" / "hybrid_economics.schema.json").read_text())
    jsonschema.validate(report.to_dict(), schema)
