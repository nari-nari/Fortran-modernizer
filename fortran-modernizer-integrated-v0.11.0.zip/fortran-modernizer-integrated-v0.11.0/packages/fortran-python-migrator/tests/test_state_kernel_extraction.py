from __future__ import annotations

import importlib.util
from pathlib import Path
import subprocess
import sys

import numpy as np
import pytest

from fpy_migrate.extraction import (
    StateKernelExtractionError,
    analyze_state_kernel,
    build_state_kernel_bundle,
    load_generated_wrapper,
)
from fpy_migrate.ir import build_project_ir, validate_migration_ir, write_project_ir
from fpy_migrate.kernels import analyze_kernel_candidates
from fpy_migrate.translate import generate_python, write_python


ROOT = Path(__file__).resolve().parents[1]
SAMPLES = ROOT / "samples" / "migration_units"


def _load_module(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def _compile_and_run(source: Path, driver: Path, output: Path) -> list[str]:
    executable = output / f"{driver.stem}_state_kernel"
    subprocess.run(
        ["gfortran", "-O2", str(source), str(driver), "-o", str(executable)],
        check=True,
        capture_output=True,
        text=True,
    )
    completed = subprocess.run(
        [str(executable)], check=True, capture_output=True, text=True
    )
    return completed.stdout.splitlines()


def _parse_fortran_output(lines: list[str], *, module: bool = False):
    header = lines[0].split()
    if module:
        active_count = int(header[0])
        total, minimum, relaxation = map(float, header[1:])
    else:
        active_count = 12
        total, minimum, relaxation = map(float, header)
    pressure = np.zeros(active_count, dtype=np.float64)
    film = np.zeros(active_count, dtype=np.float64)
    for line in lines[1:]:
        index, p_value, h_value = line.split()
        pressure[int(index) - 1] = float(p_value)
        film[int(index) - 1] = float(h_value)
    return active_count, total, minimum, relaxation, pressure, film


def test_common_state_hot_loop_becomes_explicit_kernel(tmp_path: Path) -> None:
    project = build_project_ir(
        SAMPLES / "common_state_analysis.f90", procedure="advance_common_state"
    )
    extraction = analyze_state_kernel(project, "advance_common_state")

    assert extraction.status == "AUTO"
    assert extraction.loop_count == 1
    kernel = extraction.kernel_project.procedure("advance_common_state_kernel")
    assert kernel.state_groups == ()
    assert kernel.arguments == ("n", "pressure", "film", "relaxation_factor")
    intents = {name: kernel.symbol(name).intent for name in kernel.arguments}
    assert intents == {
        "n": "in",
        "pressure": "inout",
        "film": "in",
        "relaxation_factor": "in",
    }
    assert [(item.local_name, item.state_field, item.intent) for item in extraction.bindings] == [
        ("p", "pressure", "inout"),
        ("h", "film", "in"),
        ("omega", "relaxation_factor", "in"),
    ]

    ir_path = write_project_ir(
        extraction.kernel_project, tmp_path / "advance_common_state_kernel.ir.json"
    )
    assert validate_migration_ir(ir_path) == []
    candidates = analyze_kernel_candidates(extraction.kernel_project)
    assert candidates.candidates[0].status == "AUTO"


def test_module_state_scalar_and_arrays_become_kernel_arguments() -> None:
    project = build_project_ir(
        SAMPLES / "module_state_analysis.f90", procedure="advance_module_state"
    )
    extraction = analyze_state_kernel(project, "advance_module_state")
    kernel = extraction.kernel_project.procedure("advance_module_state_kernel")

    assert kernel.arguments == (
        "active_count",
        "pressure",
        "film",
        "relaxation_factor",
    )
    assert kernel.symbol("active_count").intent == "in"
    assert kernel.symbol("pressure").intent == "inout"
    assert kernel.symbol("film").intent == "in"
    assert kernel.symbol("relaxation_factor").intent == "in"


def test_stateful_call_graph_is_not_silently_extracted() -> None:
    project = build_project_ir(
        SAMPLES / "common_state_analysis.f90", procedure="run_common_state"
    )
    with pytest.raises(StateKernelExtractionError, match="procedure calls"):
        analyze_state_kernel(project, "run_common_state")


@pytest.mark.integration
def test_common_state_wrapper_backends_match_fortran(tmp_path: Path) -> None:
    source = SAMPLES / "common_state_analysis.f90"
    build_root = tmp_path / "common_bundle"
    bundle, manifest = build_state_kernel_bundle(
        source,
        procedure="advance_common_state",
        build_directory=build_root,
    )
    assert manifest.exists()
    assert set(bundle.module_names) == {"python", "cython-safe", "cython-optimized"}

    full_project = build_project_ir(source, procedure="run_common_state")
    full_path = write_python(
        generate_python(full_project, procedure="run_common_state"),
        build_root / "full_common_state.py",
    )
    full = _load_module(full_path, "milestone9_full_common")
    wrapper = load_generated_wrapper(
        build_root / bundle.artifacts["wrapper"], "milestone9_common_wrapper"
    )

    _, f_total, f_minimum, f_relaxation, f_pressure, f_film = _parse_fortran_output(
        _compile_and_run(source, SAMPLES / "common_state_driver.f90", tmp_path)
    )
    reference_pressure = None
    for backend in ("python", "cython-safe", "cython-optimized"):
        state = wrapper.CommonFieldState(
            pressure=np.zeros(16, dtype=np.float64),
            film=np.zeros(16, dtype=np.float64),
            relaxation_factor=0.0,
        )
        full.initialize_common_state(state, 12, 0.4)
        wrapper.advance_common_state(state, 12, backend=backend)
        total, minimum = full.summarize_common_state(state, 12)

        np.testing.assert_allclose(state.pressure[:12], f_pressure, rtol=1e-14, atol=1e-14)
        np.testing.assert_allclose(state.film[:12], f_film, rtol=1e-14, atol=1e-14)
        assert total == pytest.approx(f_total, rel=1e-14, abs=1e-14)
        assert minimum == pytest.approx(f_minimum, rel=1e-14, abs=1e-14)
        assert state.relaxation_factor == pytest.approx(
            f_relaxation, rel=1e-14, abs=1e-14
        )
        if reference_pressure is None:
            reference_pressure = state.pressure.copy()
        else:
            np.testing.assert_array_equal(state.pressure, reference_pressure)


@pytest.mark.integration
def test_module_state_wrapper_backends_match_fortran(tmp_path: Path) -> None:
    source = SAMPLES / "module_state_analysis.f90"
    build_root = tmp_path / "module_bundle"
    bundle, _ = build_state_kernel_bundle(
        source,
        procedure="advance_module_state",
        build_directory=build_root,
    )
    full_project = build_project_ir(source, procedure="run_module_state")
    full_path = write_python(
        generate_python(full_project, procedure="run_module_state"),
        build_root / "full_module_state.py",
    )
    full = _load_module(full_path, "milestone9_full_module")
    wrapper = load_generated_wrapper(
        build_root / bundle.artifacts["wrapper"], "milestone9_module_wrapper"
    )

    active, f_total, f_minimum, f_relaxation, f_pressure, f_film = _parse_fortran_output(
        _compile_and_run(
            source, SAMPLES / "module_state_driver.f90", tmp_path
        ),
        module=True,
    )
    for backend in ("python", "cython-safe", "cython-optimized"):
        state = wrapper.ModuleModuleStateAnalysisModState(
            active_count=0,
            pressure=np.zeros(16, dtype=np.float64),
            film=np.zeros(16, dtype=np.float64),
            relaxation_factor=0.0,
        )
        full.initialize_module_state(state, 12, 0.4)
        wrapper.advance_module_state(state, backend=backend)
        total, minimum = full.summarize_module_state(state)

        assert state.active_count == active
        np.testing.assert_allclose(state.pressure[:active], f_pressure, rtol=1e-14, atol=1e-14)
        np.testing.assert_allclose(state.film[:active], f_film, rtol=1e-14, atol=1e-14)
        assert total == pytest.approx(f_total, rel=1e-14, abs=1e-14)
        assert minimum == pytest.approx(f_minimum, rel=1e-14, abs=1e-14)
        assert state.relaxation_factor == pytest.approx(
            f_relaxation, rel=1e-14, abs=1e-14
        )
