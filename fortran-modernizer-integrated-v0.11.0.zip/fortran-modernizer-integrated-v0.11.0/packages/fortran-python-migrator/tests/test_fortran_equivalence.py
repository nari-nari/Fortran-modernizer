import shutil

import numpy as np
import pytest

from fpy_migrate.sample.journal_bearing.runner import run_backend


pytestmark = pytest.mark.integration


def test_modern_legacy_and_python_match() -> None:
    if shutil.which("gfortran") is None:
        pytest.skip("gfortran not available")
    modern = run_backend("fortran-reference")
    legacy = run_backend("fortran-legacy")
    python = run_backend("python")
    np.testing.assert_allclose(legacy.pressure, modern.pressure, rtol=1e-12, atol=1e-13)
    np.testing.assert_allclose(python.pressure, modern.pressure, rtol=1e-10, atol=1e-12)
    assert legacy.iterations == modern.iterations == python.iterations
