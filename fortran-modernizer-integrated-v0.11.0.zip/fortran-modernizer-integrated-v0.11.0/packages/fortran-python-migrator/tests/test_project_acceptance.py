import json
from pathlib import Path

from jsonschema import Draft202012Validator

from fpy_migrate.acceptance import (
    diagnose_project, write_acceptance_report, write_construct_csv, write_procedure_csv,
)
from fpy_migrate.cli import main


def _by_name(report):
    return {item.name: item for item in report.procedures}


def test_project_acceptance_classifies_units_and_dependencies() -> None:
    report = diagnose_project("samples/acceptance_project", procedure="run_case")
    procedures = _by_name(report)

    assert procedures["initialize_state"].status == "READY"
    assert procedures["update_state"].status == "REVIEW_REQUIRED"
    assert "common" in procedures["update_state"].review_items
    assert procedures["choose_mode"].status == "BLOCKED"
    assert "select_case" in procedures["choose_mode"].blockers
    assert procedures["run_case"].status == "BLOCKED"
    assert procedures["run_case"].blocked_dependencies == ("choose_mode",)
    assert procedures["export_case"].external_calls == ("vendor_write",)
    assert report.migration_order.index("initialize_state") < report.migration_order.index("run_case")
    assert report.recommended_vertical_slice["root"] == "run_case"
    assert report.recommended_vertical_slice["status"] == "BLOCKED"
    assert report.rates["file_parse_rate"] == 1.0
    assert report.project_ir_build["status"] == "BLOCKED"


def test_acceptance_report_schema_and_csv(tmp_path: Path) -> None:
    report = diagnose_project("samples/acceptance_project", procedure="run_case")
    output = write_acceptance_report(report, tmp_path / "acceptance.json")
    csv_output = write_procedure_csv(report, tmp_path / "procedures.csv")
    construct_csv = write_construct_csv(report, tmp_path / "constructs.csv")
    payload = json.loads(output.read_text(encoding="utf-8"))
    schema = json.loads(Path("schemas/project_acceptance.schema.json").read_text(encoding="utf-8"))
    errors = list(Draft202012Validator(schema).iter_errors(payload))
    assert not errors
    assert "migration_rank,name,status" in csv_output.read_text(encoding="utf-8").splitlines()[0]
    assert "category,severity,occurrences" in construct_csv.read_text(encoding="utf-8").splitlines()[0]


def test_diagnose_project_cli_writes_outputs(tmp_path: Path) -> None:
    output = tmp_path / "acceptance.json"
    csv_output = tmp_path / "procedures.csv"
    construct_csv = tmp_path / "constructs.csv"
    status = main([
        "diagnose-project",
        "samples/acceptance_project",
        "--procedure", "run_case",
        "--output", str(output),
        "--csv-output", str(csv_output),
        "--construct-csv-output", str(construct_csv),
    ])
    assert status == 2
    assert output.exists()
    assert csv_output.exists()
    assert construct_csv.exists()


def test_acceptance_uses_connected_refactor_handoff() -> None:
    report = diagnose_project(
        "samples/migration_projects/common_state_project",
        procedure="run_common_state",
        refactor_report="reports/milestone18/refactor_handoff.json",
    )
    assert report.status == "REVIEW_REQUIRED"
    assert report.project_ir_build["status"] == "PASS"
    assert report.rates["procedure_migratable_rate"] == 1.0
    assert report.migration_order == (
        "initialize_common_state",
        "advance_common_state",
        "summarize_common_state",
        "run_common_state",
    )
    assert report.refactor_report is not None
    assert report.refactor_report["producer_version"] == "0.37.0"
