from pathlib import Path

import numpy as np
import pytest

from fpy_migrate.sample.journal_bearing.case_io import read_case
from fpy_migrate.sample.journal_bearing.cython_solver import solve_cython
from fpy_migrate.sample.journal_bearing.python_solver import solve_python


def test_cython_matches_python() -> None:
    case = read_case(Path("samples/journal_bearing/cases/standard.nml"))
    reference = solve_python(case)
    try:
        candidate = solve_cython(case)
    except RuntimeError as exc:
        pytest.skip(str(exc))
    np.testing.assert_allclose(candidate.pressure, reference.pressure, rtol=1e-12, atol=1e-13)
    assert candidate.iterations == reference.iterations
    assert candidate.load_magnitude == pytest.approx(reference.load_magnitude, rel=1e-12)
