from __future__ import annotations

import importlib.util
from pathlib import Path
import subprocess
import sys

import numpy as np
import pytest

from fpy_migrate.ir import build_project_ir, validate_migration_ir, write_project_ir
from fpy_migrate.kernels import analyze_kernel_candidates
from fpy_migrate.state import analyze_state_migration
from fpy_migrate.translate import generate_cython, generate_python, write_python


ROOT = Path(__file__).resolve().parents[1]
SAMPLES = ROOT / "samples" / "migration_units"


def _load_generated(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def _compile_and_run(source: Path, driver: Path, output: Path) -> list[str]:
    executable = output / driver.stem
    subprocess.run(
        ["gfortran", "-O2", str(source), str(driver), "-o", str(executable)],
        check=True,
        capture_output=True,
        text=True,
    )
    completed = subprocess.run(
        [str(executable)], check=True, capture_output=True, text=True
    )
    return completed.stdout.splitlines()


def _parse_fortran_output(lines: list[str], *, module: bool = False):
    header = lines[0].split()
    if module:
        active_count = int(header[0])
        total, minimum, relaxation = map(float, header[1:])
    else:
        active_count = 12
        total, minimum, relaxation = map(float, header)
    pressure = np.zeros(active_count, dtype=np.float64)
    film = np.zeros(active_count, dtype=np.float64)
    for line in lines[1:]:
        index, p_value, h_value = line.split()
        pressure[int(index) - 1] = float(p_value)
        film[int(index) - 1] = float(h_value)
    return active_count, total, minimum, relaxation, pressure, film


def test_common_state_is_normalized_with_aliases(tmp_path: Path) -> None:
    source = SAMPLES / "common_state_analysis.f90"
    project = build_project_ir(source, procedure="run_common_state")

    assert project.schema_version == "1.2"
    assert len(project.state_groups) == 1
    group = project.state_groups[0]
    assert group.source_kind == "common"
    assert [item.state_field for item in group.fields] == [
        "pressure",
        "film",
        "relaxation_factor",
    ]
    advance = project.procedure("advance_common_state")
    aliases = {
        item.name: item.state_field
        for item in advance.symbols
        if item.role == "state"
    }
    assert aliases == {
        "p": "pressure",
        "h": "film",
        "omega": "relaxation_factor",
    }

    ir_path = write_project_ir(project, tmp_path / "common_state.ir.json")
    assert validate_migration_ir(ir_path) == []


@pytest.mark.integration
def test_common_state_generated_python_matches_fortran(tmp_path: Path) -> None:
    source = SAMPLES / "common_state_analysis.f90"
    project = build_project_ir(source, procedure="run_common_state")
    generated_path = write_python(
        generate_python(project, procedure="run_common_state"),
        tmp_path / "generated_common_state.py",
    )
    module = _load_generated(generated_path, "generated_common_state_test")
    state = module.CommonFieldState(
        pressure=np.zeros(16, dtype=np.float64),
        film=np.zeros(16, dtype=np.float64),
        relaxation_factor=0.0,
    )
    total, minimum = module.run_common_state(state, 12, 0.4)

    values = _parse_fortran_output(
        _compile_and_run(source, SAMPLES / "common_state_driver.f90", tmp_path)
    )
    _, f_total, f_minimum, f_relaxation, f_pressure, f_film = values
    np.testing.assert_allclose(state.pressure[:12], f_pressure, rtol=1e-14, atol=1e-14)
    np.testing.assert_allclose(state.film[:12], f_film, rtol=1e-14, atol=1e-14)
    assert total == pytest.approx(f_total, rel=1e-14, abs=1e-14)
    assert minimum == pytest.approx(f_minimum, rel=1e-14, abs=1e-14)
    assert state.relaxation_factor == pytest.approx(f_relaxation, rel=1e-14, abs=1e-14)


@pytest.mark.integration
def test_module_state_generated_python_matches_fortran(tmp_path: Path) -> None:
    source = SAMPLES / "module_state_analysis.f90"
    project = build_project_ir(source, procedure="run_module_state")
    assert project.state_groups[0].source_kind == "module"
    generated_path = write_python(
        generate_python(project, procedure="run_module_state"),
        tmp_path / "generated_module_state.py",
    )
    module = _load_generated(generated_path, "generated_module_state_test")
    state = module.ModuleModuleStateAnalysisModState(
        active_count=0,
        pressure=np.zeros(16, dtype=np.float64),
        film=np.zeros(16, dtype=np.float64),
        relaxation_factor=0.0,
    )
    total, minimum = module.run_module_state(state, 12, 0.4)

    values = _parse_fortran_output(
        _compile_and_run(source, SAMPLES / "module_state_driver.f90", tmp_path),
        module=True,
    )
    active, f_total, f_minimum, f_relaxation, f_pressure, f_film = values
    assert state.active_count == active
    np.testing.assert_allclose(state.pressure[:active], f_pressure, rtol=1e-14, atol=1e-14)
    np.testing.assert_allclose(state.film[:active], f_film, rtol=1e-14, atol=1e-14)
    assert total == pytest.approx(f_total, rel=1e-14, abs=1e-14)
    assert minimum == pytest.approx(f_minimum, rel=1e-14, abs=1e-14)
    assert state.relaxation_factor == pytest.approx(f_relaxation, rel=1e-14, abs=1e-14)


def test_stateful_procedure_is_not_direct_cython_candidate() -> None:
    project = build_project_ir(
        SAMPLES / "module_state_analysis.f90", procedure="run_module_state"
    )
    report = analyze_kernel_candidates(project)
    root = next(item for item in report.candidates if item.procedure == "run_module_state")
    assert root.status == "REVIEW_REQUIRED"
    assert any("state objects" in reason for reason in root.reasons)

    try:
        generate_cython(project, procedure="run_module_state")
    except ValueError as exc:
        assert "state-object procedures" in str(exc)
    else:
        raise AssertionError("stateful project should not be compiled directly with Cython")


def test_state_report_describes_wrapper_kernel_split() -> None:
    project = build_project_ir(
        SAMPLES / "common_state_analysis.f90", procedure="run_common_state"
    )
    report = analyze_state_migration(project)
    assert report.groups[0].python_class == "CommonFieldState"
    assert "extracted Cython kernels" in report.groups[0].cython_strategy

