from fpy_migrate.ir import build_project_ir
from fpy_migrate.translate import generate_cython


def test_safe_cython_codegen_adds_static_numeric_types() -> None:
    project = build_project_ir(
        "samples/migration_units/sor_sweep.f90",
        procedure="sor_sweep",
    )
    source = generate_cython(project, procedure="sor_sweep").source

    assert "boundscheck=True" in source
    assert "@cython.boundscheck(True)" in source
    assert "pressure: cython.double[:, :]" in source
    assert "film: cython.double[:]" in source
    assert "i: cython.int" in source
    assert "old_value: cython.double" in source
    assert "def periodic_neighbors" in source
    assert "def sor_sweep" in source


def test_optimized_cython_codegen_disables_checks_and_inlines_leaf_calls() -> None:
    project = build_project_ir(
        "samples/migration_units/sor_sweep.f90",
        procedure="sor_sweep",
    )
    source = generate_cython(
        project,
        procedure="sor_sweep",
        safety_mode="optimized",
    ).source

    assert "boundscheck=False" in source
    assert "@cython.boundscheck(False)" in source
    assert "pressure: cython.double[:, ::1]" in source
    assert "film: cython.double[::1]" in source
    assert "# Inlined leaf call: periodic_neighbors" in source
