from __future__ import annotations

import json
from pathlib import Path
import shutil

import numpy as np
import pytest

from fpy_migrate.solver import (
    PressureSolverCase,
    SolverRunConfiguration,
    build_analysis_backends,
    load_solver_run_configuration,
    run_configured_analysis,
)


pytestmark = pytest.mark.integration


@pytest.fixture(scope="module")
def analysis_build(tmp_path_factory: pytest.TempPathFactory) -> tuple[Path, Path]:
    if shutil.which("gfortran") is None:
        pytest.skip("gfortran is not available")
    if shutil.which("gcc") is None:
        pytest.skip("C compiler is not available")
    build_directory = tmp_path_factory.mktemp("lubrication_analysis")
    _, manifest = build_analysis_backends(
        "samples/migration_units/lubrication_analysis.f90",
        procedure="solve_analysis",
        build_directory=build_directory,
        fortran_driver="samples/migration_units/lubrication_analysis_driver.f90",
    )
    return build_directory, manifest


def test_all_analysis_backends_match(analysis_build: tuple[Path, Path]) -> None:
    build_directory, manifest = analysis_build
    results = {}
    for backend in ("python", "cython-safe", "cython-optimized", "fortran"):
        results[backend] = run_configured_analysis(
            SolverRunConfiguration(
                backend=backend,  # type: ignore[arg-type]
                manifest=manifest,
                case=PressureSolverCase(),
                output_directory=build_directory / f"analysis_result_{backend}",
            )
        )

    reference = results["fortran"]
    scalar_names = (
        "update_residual",
        "equation_residual",
        "load_x",
        "load_y",
        "load_magnitude",
        "dimensionless_friction",
        "maximum_pressure",
        "minimum_film_thickness",
    )
    for backend, result in results.items():
        assert result.converged
        assert result.iterations == reference.iterations
        np.testing.assert_allclose(result.pressure, reference.pressure, rtol=0.0, atol=3e-15)
        np.testing.assert_allclose(result.film, reference.film, rtol=0.0, atol=5e-16)
        for name in scalar_names:
            assert getattr(result, name) == pytest.approx(
                getattr(reference, name), rel=2e-14, abs=3e-14
            ), (backend, name)

    np.testing.assert_array_equal(results["python"].pressure, results["cython-optimized"].pressure)
    assert results["python"].summary() == results["cython-optimized"].summary()
    assert reference.equation_residual < 1.0e-8
    assert reference.load_magnitude > 0.0
    assert reference.dimensionless_friction > 0.0


def test_analysis_toml_and_common_outputs(analysis_build: tuple[Path, Path]) -> None:
    build_directory, _ = analysis_build
    config = load_solver_run_configuration(
        build_directory / "run_analysis_cython-optimized.toml"
    )
    result = run_configured_analysis(config)
    assert result.converged
    summary_path = config.output_directory / "summary.json"
    summary = json.loads(summary_path.read_text(encoding="utf-8"))
    for key in (
        "equation_residual",
        "load_magnitude",
        "dimensionless_friction",
        "maximum_pressure",
        "minimum_film_thickness",
    ):
        assert key in summary
    assert (config.output_directory / "pressure.csv").exists()
    assert (config.output_directory / "film.csv").exists()
