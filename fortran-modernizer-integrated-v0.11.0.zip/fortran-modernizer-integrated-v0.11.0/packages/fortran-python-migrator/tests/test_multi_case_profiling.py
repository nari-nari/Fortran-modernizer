from __future__ import annotations

import json
from pathlib import Path
import subprocess

import jsonschema
import numpy as np
import pytest

from fpy_migrate.extraction import (
    HybridProfileReport,
    ProfileSample,
    aggregate_hybrid_profiles,
    analyze_hybrid_project,
    build_hybrid_project,
    load_hybrid_profile,
    load_hybrid_runtime,
    profile_hybrid_suite,
)
from fpy_migrate.ir import build_project_ir


ROOT = Path(__file__).resolve().parents[1]
PROJECT = ROOT / "samples" / "migration_projects" / "partial_hybrid_project"
WORKLOADS = ROOT / "samples" / "profile_workloads"
SOURCE_FILES = tuple(str(item) for item in sorted(PROJECT.glob("*.f90")))


def _profile(name: str, shares: tuple[float, float, float]) -> HybridProfileReport:
    procedures = (
        ("run_partial_hybrid", "run_partial_hybrid_loop_1_kernel", "partial-loop"),
        ("initialize_partial_state", "initialize_partial_state_kernel", "full-procedure"),
        ("summarize_partial_state", "summarize_partial_state_kernel", "full-procedure"),
    )
    samples = tuple(
        ProfileSample(
            procedure=procedure,
            kernel_procedure=kernel,
            extraction_kind=kind,
            call_count=100,
            inclusive_seconds=share,
            self_seconds=share,
            candidate_share=share,
            wall_share=share * 0.9,
        )
        for (procedure, kernel, kind), share in zip(procedures, shares, strict=True)
    )
    return HybridProfileReport(
        schema_version="1.0",
        root_procedure="run_partial_hybrid",
        source_files=SOURCE_FILES,
        workload_file=f"{name}.py",
        warmup_runs=1,
        measured_runs=100,
        wall_seconds=1.1,
        candidate_seconds=1.0,
        samples=samples,
    )


def _suite():
    return aggregate_hybrid_profiles(
        [
            ("standard", _profile("standard", (0.8, 0.15, 0.05)), 0.5),
            ("startup", _profile("startup", (0.3, 0.6, 0.1)), 0.3),
            ("reporting", _profile("reporting", (0.6, 0.2, 0.2)), 0.2),
        ]
    )


def test_aggregate_profile_suite_computes_weighted_mean_max_and_coverage(tmp_path: Path) -> None:
    suite = _suite()
    update = suite.sample("run_partial_hybrid")
    assert update is not None
    assert update.case_count == 3
    assert update.observed_case_count == 3
    assert update.case_coverage == pytest.approx(1.0)
    assert update.weighted_candidate_share == pytest.approx(0.61)
    assert update.mean_candidate_share == pytest.approx((0.8 + 0.3 + 0.6) / 3.0)
    assert update.max_candidate_share == pytest.approx(0.8)
    assert update.weighted_self_seconds == pytest.approx(0.61)
    assert update.call_count == 300

    output = tmp_path / "suite.json"
    output.write_text(json.dumps(suite.to_dict(), indent=2) + "\n", encoding="utf-8")
    loaded = load_hybrid_profile(output)
    loaded_update = loaded.sample("run_partial_hybrid")
    assert loaded_update is not None
    assert loaded_update.weighted_candidate_share == pytest.approx(0.61)

    schema = json.loads((ROOT / "schemas" / "hybrid_profile_suite.schema.json").read_text())
    jsonschema.validate(suite.to_dict(), schema)


def test_multi_case_thresholds_select_kernel_important_across_suite() -> None:
    project = build_project_ir(PROJECT, procedure="run_partial_hybrid")
    plan = analyze_hybrid_project(
        project,
        "run_partial_hybrid",
        profile_report=_suite(),
        min_profile_share=0.5,
        min_profile_mean_share=0.5,
        min_profile_max_share=0.7,
        min_profile_cases=3,
    )
    assert plan.extracted_procedures == ("run_partial_hybrid",)
    selected = plan.candidate("run_partial_hybrid")
    assert selected.profile_case_count == 3
    assert selected.profile_observed_case_count == 3
    assert selected.profile_weighted_candidate_share == pytest.approx(0.61)
    assert selected.profile_mean_candidate_share == pytest.approx((0.8 + 0.3 + 0.6) / 3.0)
    assert selected.profile_max_candidate_share == pytest.approx(0.8)
    assert not plan.candidate("initialize_partial_state").selected
    assert not plan.candidate("summarize_partial_state").selected

    schema = json.loads((ROOT / "schemas" / "hybrid_project_plan.schema.json").read_text())
    jsonschema.validate(plan.to_dict(), schema)


def test_profile_hybrid_suite_runs_multiple_workloads(tmp_path: Path) -> None:
    suite, output = profile_hybrid_suite(
        PROJECT,
        root_procedure="run_partial_hybrid",
        cases=(
            ("standard", WORKLOADS / "partial_hybrid_standard.py", 0.5),
            ("update-heavy", WORKLOADS / "partial_hybrid_update_heavy.py", 0.3),
            ("postprocess-heavy", WORKLOADS / "partial_hybrid_postprocess_heavy.py", 0.2),
        ),
        build_directory=tmp_path / "suite",
        warmup_runs=0,
        measured_runs=3,
    )
    assert output.exists()
    assert tuple(case.name for case in suite.cases) == (
        "standard",
        "update-heavy",
        "postprocess-heavy",
    )
    assert suite.sample("run_partial_hybrid") is not None
    assert suite.sample("initialize_partial_state") is not None
    assert suite.sample("summarize_partial_state") is not None
    assert (tmp_path / "suite" / "cases" / "standard" / "hybrid_profile.json").exists()


def _fortran_result(tmp_path: Path):
    executable = tmp_path / "suite_partial_fortran"
    sources = [
        PROJECT / "10_initialize.f90",
        PROJECT / "20_summarize.f90",
        PROJECT / "30_run.f90",
        PROJECT / "driver.f90",
    ]
    subprocess.run(
        ["gfortran", "-O2", *(str(item) for item in sources), "-o", str(executable)],
        check=True,
        capture_output=True,
        text=True,
    )
    completed = subprocess.run([str(executable)], check=True, capture_output=True, text=True)
    lines = completed.stdout.splitlines()
    total, peak, relaxation = map(float, lines[0].split())
    pressure = np.zeros(12, dtype=np.float64)
    film = np.zeros(12, dtype=np.float64)
    for line in lines[1:]:
        index, p_value, h_value = line.split()
        pressure[int(index) - 1] = float(p_value)
        film[int(index) - 1] = float(h_value)
    return total, peak, relaxation, pressure, film


@pytest.mark.integration
def test_multi_case_selected_build_matches_fortran(tmp_path: Path) -> None:
    build_root = tmp_path / "multi_case_hybrid"
    manifest, manifest_path = build_hybrid_project(
        PROJECT,
        root_procedure="run_partial_hybrid",
        build_directory=build_root,
        profile_report=_suite(),
        min_profile_share=0.5,
        min_profile_mean_share=0.5,
        min_profile_max_share=0.7,
        min_profile_cases=3,
    )
    assert manifest_path.exists()
    assert manifest.extracted_procedures == ("run_partial_hybrid",)
    assert manifest.partial_extracted_procedures == ("run_partial_hybrid",)

    runtime = load_hybrid_runtime(
        build_root / manifest.artifacts["hybrid_runtime"],
        "test_multi_case_hybrid_runtime",
    )
    f_total, f_peak, f_relaxation, f_pressure, f_film = _fortran_result(tmp_path)
    state = runtime.create_common_field()
    total, peak = runtime.run_partial_hybrid(
        state, 12, 0.4, backend="cython-optimized"
    )
    np.testing.assert_allclose(state.pressure[:12], f_pressure, rtol=1e-14, atol=1e-14)
    np.testing.assert_allclose(state.film[:12], f_film, rtol=1e-14, atol=1e-14)
    assert total == pytest.approx(f_total, rel=1e-14, abs=1e-14)
    assert peak == pytest.approx(f_peak, rel=1e-14, abs=1e-14)
    assert state.relaxation_factor == pytest.approx(f_relaxation, rel=1e-14, abs=1e-14)
