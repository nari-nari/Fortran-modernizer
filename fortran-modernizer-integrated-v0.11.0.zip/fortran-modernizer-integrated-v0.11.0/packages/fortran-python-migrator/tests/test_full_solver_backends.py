from __future__ import annotations

from pathlib import Path
import shutil

import numpy as np
import pytest

from fpy_migrate.benchmark import benchmark_full_solver
from fpy_migrate.solver import (
    PressureSolverCase,
    SolverRunConfiguration,
    build_solver_backends,
    load_solver_run_configuration,
    run_configured_solver,
)


pytestmark = pytest.mark.integration


@pytest.fixture(scope="module")
def solver_build(tmp_path_factory: pytest.TempPathFactory) -> tuple[Path, Path]:
    if shutil.which("gfortran") is None:
        pytest.skip("gfortran is not available")
    if shutil.which("gcc") is None:
        pytest.skip("C compiler is not available")
    build_directory = tmp_path_factory.mktemp("full_solver")
    _, manifest = build_solver_backends(
        "samples/migration_units/pressure_solver.f90",
        procedure="solve_pressure",
        build_directory=build_directory,
        fortran_driver="samples/migration_units/pressure_solver_driver.f90",
    )
    return build_directory, manifest


def test_all_full_solver_backends_match(solver_build: tuple[Path, Path]) -> None:
    build_directory, manifest = solver_build
    results = {}
    for backend in ("python", "cython-safe", "cython-optimized", "fortran"):
        results[backend] = run_configured_solver(
            SolverRunConfiguration(
                backend=backend,  # type: ignore[arg-type]
                manifest=manifest,
                case=PressureSolverCase(),
                output_directory=build_directory / f"result_{backend}",
            )
        )

    reference = results["fortran"]
    for backend, result in results.items():
        assert result.converged
        assert result.iterations == reference.iterations
        assert result.update_residual == pytest.approx(
            reference.update_residual,
            rel=0.0,
            abs=5.0e-16,
        )
        np.testing.assert_allclose(result.film, reference.film, rtol=0.0, atol=5.0e-16)
        np.testing.assert_allclose(
            result.pressure,
            reference.pressure,
            rtol=0.0,
            atol=3.0e-15,
        )

    np.testing.assert_array_equal(
        results["python"].pressure,
        results["cython-optimized"].pressure,
    )


def test_backend_can_be_selected_from_toml(solver_build: tuple[Path, Path]) -> None:
    build_directory, _ = solver_build
    config = load_solver_run_configuration(build_directory / "run_cython-optimized.toml")
    assert config.backend == "cython-optimized"
    result = run_configured_solver(config)
    assert result.converged
    assert (config.output_directory / "summary.json").exists()


def test_convergence_status_is_false_when_iteration_limit_is_too_small(
    solver_build: tuple[Path, Path],
) -> None:
    build_directory, manifest = solver_build
    result = run_configured_solver(
        SolverRunConfiguration(
            backend="cython-optimized",
            manifest=manifest,
            case=PressureSolverCase(max_iterations=1),
            output_directory=build_directory / "not_converged",
        )
    )
    assert not result.converged
    assert result.iterations == 1


def test_full_solver_benchmark_reports_equivalent_results(
    solver_build: tuple[Path, Path],
) -> None:
    _, manifest = solver_build
    report = benchmark_full_solver(
        manifest,
        sizes=((16, 5),),
        target_seconds=0.001,
    )
    case = report.cases[0]
    assert case.maximum_absolute_pressure_difference["python_vs_cython_optimized"] == 0.0
    assert case.maximum_absolute_pressure_difference["python_vs_fortran"] < 3.0e-15
    assert case.speedup_vs_python["cython-optimized"] > 1.0
