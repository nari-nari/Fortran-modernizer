from __future__ import annotations

from pathlib import Path
import importlib.util
import sys

import numpy as np
import pytest

from fpy_migrate.ir import UnsupportedFortranError, build_project_ir
from fpy_migrate.translate import generate_python, write_python


ROOT = Path(__file__).resolve().parents[1]
SCOPED_SOURCE = ROOT / "samples/migration_units/legacy_scoped_analysis.f90"


@pytest.mark.parametrize(
    "procedure",
    ["init_geometry", "solve_reynolds", "compute_metrics"],
)
def test_unreachable_formatted_output_does_not_block_numeric_procedure(
    procedure: str,
) -> None:
    project = build_project_ir(SCOPED_SOURCE, procedure=procedure)

    assert [item.name for item in project.procedures] == [procedure]
    assert project.procedure(procedure).source_span.file.endswith(
        "legacy_scoped_analysis.f90"
    )
    assert project.state_group("common_field").fields[0].name == "p"


def test_whole_file_remains_strict_when_formatted_output_is_unsupported() -> None:
    with pytest.raises(UnsupportedFortranError, match="Write_Stmt"):
        build_project_ir(SCOPED_SOURCE)


def test_reachable_unsupported_procedure_still_blocks_root() -> None:
    with pytest.raises(UnsupportedFortranError, match="Write_Stmt"):
        build_project_ir(SCOPED_SOURCE, procedure="run_analysis")


def test_unreachable_external_call_does_not_block_selected_procedure(
    tmp_path: Path,
) -> None:
    source = tmp_path / "external_sibling.f90"
    source.write_text(
        """subroutine supported(value)
  implicit none
  real(8), intent(inout) :: value
  value = value + 1.0d0
end subroutine supported

subroutine unsupported_external(value)
  implicit none
  real(8), intent(in) :: value
  call vendor_write(value)
end subroutine unsupported_external
""",
        encoding="utf-8",
    )

    project = build_project_ir(source, procedure="supported")
    assert [item.name for item in project.procedures] == ["supported"]

    with pytest.raises(
        UnsupportedFortranError,
        match="unsupported_external: unresolved called subroutine vendor_write",
    ):
        build_project_ir(source)


def test_global_common_mismatch_blocks_even_when_bad_procedure_is_unreachable(
    tmp_path: Path,
) -> None:
    source = tmp_path / "common_mismatch.f90"
    source.write_text(
        """subroutine supported_common
  implicit none
  real(8) :: field(2)
  common /shared/ field
  field(1) = 1.0d0
end subroutine supported_common

subroutine unreachable_bad_common
  implicit none
  real(8) :: alias(3)
  common /shared/ alias
  write(*,*) alias(1)
end subroutine unreachable_bad_common
""",
        encoding="utf-8",
    )

    with pytest.raises(
        UnsupportedFortranError,
        match="common_shared: incompatible COMMON member at position 1",
    ):
        build_project_ir(source, procedure="supported_common")


def test_inventory_dependency_order_is_stable_with_unsupported_sibling(
    tmp_path: Path,
) -> None:
    source = tmp_path / "dependency_order.f90"
    source.write_text(
        """subroutine helper(value)
  implicit none
  real(8), intent(inout) :: value
  value = value + 1.0d0
end subroutine helper

subroutine root(value)
  implicit none
  real(8), intent(inout) :: value
  call helper(value)
end subroutine root

subroutine ignored_output(value)
  implicit none
  real(8), intent(in) :: value
  write(*,*) value
end subroutine ignored_output
""",
        encoding="utf-8",
    )

    project = build_project_ir(source, procedure="root")
    assert [item.name for item in project.procedures] == ["helper", "root"]


def test_scoped_numeric_root_generates_and_runs_without_print_results(
    tmp_path: Path,
) -> None:
    project = build_project_ir(SCOPED_SOURCE, procedure="run_numeric")
    assert [item.name for item in project.procedures] == [
        "init_geometry",
        "solve_reynolds",
        "compute_metrics",
        "run_numeric",
    ]

    target = write_python(
        generate_python(project, procedure="run_numeric"),
        tmp_path / "scoped_numeric.py",
    )
    spec = importlib.util.spec_from_file_location("scoped_numeric_m21", target)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)

    state = module.CommonFieldState(
        p=np.zeros((36, 17), dtype=np.float64),
        h=np.zeros(36, dtype=np.float64),
        theta=np.zeros(36, dtype=np.float64),
    )
    actual = module.run_numeric(state)

    assert actual[0] == 173
    np.testing.assert_allclose(
        np.asarray(actual[1:], dtype=np.float64),
        np.asarray(
            [
                9.3243524013075785e-11,
                2.6071517885680344,
                3.1797719040494399,
                0.4,
                7.8539816339744828,
            ],
            dtype=np.float64,
        ),
        rtol=1.0e-12,
        atol=1.0e-13,
    )
