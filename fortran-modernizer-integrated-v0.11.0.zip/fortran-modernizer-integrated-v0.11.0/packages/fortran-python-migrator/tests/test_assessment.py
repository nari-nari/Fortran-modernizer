from fpy_migrate.assessment import assess_tree


def test_legacy_sample_requires_review_but_parses() -> None:
    report = assess_tree("samples/journal_bearing/fortran_legacy")
    assert len(report.files) == 1
    item = report.files[0]
    assert item.parse_succeeded
    assert item.status == "REVIEW_REQUIRED"
    assert "common" in item.review_items
    assert "implicit_typing" in item.review_items


def test_equivalence_fixture_is_blocked() -> None:
    report = assess_tree("samples/assessment_fixtures")
    assert report.files[0].status == "BLOCKED"
    assert "equivalence" in report.files[0].blockers
