from __future__ import annotations

import math
import shutil
import subprocess
from pathlib import Path

import numpy as np
import pytest

from fpy_migrate.backends import load_generated_backend
from fpy_migrate.ir import build_project_ir
from fpy_migrate.kernels import build_cython_extension
from fpy_migrate.translate import (
    generate_cython,
    generate_python,
    write_cython,
    write_python,
)


pytestmark = pytest.mark.integration


def _read_fortran_output(path: Path, ntheta: int, nz: int) -> tuple[float, np.ndarray]:
    lines = path.read_text(encoding="utf-8").splitlines()
    residual = float(lines[0].split("=", maxsplit=1)[1])
    pressure = np.empty((ntheta, nz), dtype=np.float64, order="F")
    for line in lines[1:]:
        i_text, j_text, value_text = line.split(",")
        pressure[int(i_text) - 1, int(j_text) - 1] = float(value_text)
    return residual, pressure


def _initial_state(ntheta: int, nz: int) -> tuple[np.ndarray, np.ndarray, float, float]:
    dtheta = 2.0 * math.pi / float(ntheta)
    dz = 1.0 / float(nz - 1)
    film = np.empty(ntheta, dtype=np.float64)
    pressure = np.empty((ntheta, nz), dtype=np.float64, order="F")
    for i in range(ntheta):
        film[i] = 1.0 + 0.60 * math.cos(float(i) * dtheta)
        for j in range(nz):
            pressure[i, j] = 0.002 * float((i + 1) * (j + 1))
    return film, pressure, dtheta, dz


def test_generated_python_and_cython_match_fortran(tmp_path: Path) -> None:
    if shutil.which("gfortran") is None:
        pytest.skip("gfortran is not available")
    if shutil.which("gcc") is None:
        pytest.skip("C compiler is not available")

    executable = tmp_path / "sor_sweep_driver"
    subprocess.run(
        [
            "gfortran",
            "-std=f2008",
            "-O0",
            "-fcheck=all",
            "samples/migration_units/sor_sweep.f90",
            "samples/migration_units/sor_sweep_driver.f90",
            "-o",
            str(executable),
        ],
        check=True,
    )
    output = tmp_path / "sor_sweep.txt"
    subprocess.run([str(executable), str(output)], check=True)

    ntheta = 12
    nz = 7
    expected_residual, expected_pressure = _read_fortran_output(output, ntheta, nz)

    project = build_project_ir(
        "samples/migration_units/sor_sweep.f90",
        procedure="sor_sweep",
    )
    python_source = write_python(
        generate_python(project, procedure="sor_sweep"),
        tmp_path / "generated_sor_python.py",
    )
    cython_source = write_cython(
        generate_cython(project, procedure="sor_sweep"),
        tmp_path / "generated_sor_cython_source.py",
    )
    built = build_cython_extension(
        cython_source,
        "generated_sor_cython",
        tmp_path / "cython_build",
    )

    python_backend = load_generated_backend("python", python_source)
    cython_backend = load_generated_backend(
        "cython",
        built.extension,
        module_name=built.module_name,
    )

    film, pressure, dtheta, dz = _initial_state(ntheta, nz)
    python_pressure, python_residual = python_backend.call(
        "sor_sweep",
        ntheta,
        nz,
        film.copy(),
        pressure.copy(order="F"),
        dtheta,
        dz,
        0.20,
        1.35,
    )
    cython_pressure, cython_residual = cython_backend.call(
        "sor_sweep",
        ntheta,
        nz,
        film.copy(),
        pressure.copy(order="F"),
        dtheta,
        dz,
        0.20,
        1.35,
    )

    assert isinstance(python_pressure, np.ndarray)
    assert isinstance(cython_pressure, np.ndarray)
    python_pressure_array = np.asarray(python_pressure)
    cython_pressure_array = np.asarray(cython_pressure)
    np.testing.assert_allclose(python_pressure_array, expected_pressure, rtol=0.0, atol=7.0e-16)
    np.testing.assert_allclose(cython_pressure_array, expected_pressure, rtol=0.0, atol=7.0e-16)
    np.testing.assert_allclose(cython_pressure_array, python_pressure_array, rtol=0.0, atol=0.0)
    assert python_residual == pytest.approx(expected_residual, rel=0.0, abs=5.0e-16)
    assert cython_residual == pytest.approx(expected_residual, rel=0.0, abs=5.0e-16)
