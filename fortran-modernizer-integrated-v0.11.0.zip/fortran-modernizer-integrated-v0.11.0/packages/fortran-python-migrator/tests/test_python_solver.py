from pathlib import Path

import numpy as np

from fpy_migrate.sample.journal_bearing.case_io import read_case
from fpy_migrate.sample.journal_bearing.python_solver import solve_python


def test_python_solver_converges_and_obeys_boundaries() -> None:
    case = read_case(Path("samples/journal_bearing/cases/standard.nml"))
    result = solve_python(case)
    assert result.iterations < case.max_iterations
    assert result.update_residual <= case.tolerance
    assert np.all(result.pressure >= 0.0)
    assert np.all(result.pressure[:, 0] == 0.0)
    assert np.all(result.pressure[:, -1] == 0.0)
    assert result.maximum_pressure > 0.0
    assert result.load_magnitude > 0.0
