from __future__ import annotations

import importlib.util
from pathlib import Path

import numpy as np
import pytest

from fpy_migrate.backends import build_fortran_kernel_backend
from fpy_migrate.extraction import (
    HybridProfileReport,
    ProfileSample,
    build_hybrid_project,
    load_hybrid_runtime,
)
from fpy_migrate.ir import build_project_ir
from fpy_migrate.ir.model import (
    AssignmentIR,
    DoLoopIR,
    ExpressionIR,
    ProcedureIR,
    ProjectIR,
    SourceSpan,
    SymbolIR,
    TypeIR,
)
from fpy_migrate.translate import generate_python, write_python


ROOT = Path(__file__).resolve().parents[1]
COMMON_PROJECT = ROOT / "samples" / "migration_projects" / "common_state_project"
PARTIAL_PROJECT = ROOT / "samples" / "migration_projects" / "partial_hybrid_project"


def _load(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _two_dimensional_project() -> ProjectIR:
    real = TypeIR("real", kind="8")
    integer = TypeIR("integer")
    span = SourceSpan("generated_test.f90", 1, 20)
    ref = lambda name, *indices: ExpressionIR("array_ref", value=name, indices=tuple(indices))
    name = lambda value: ExpressionIR("name", value=value)
    literal = lambda value: ExpressionIR("literal", value=value)
    add = lambda left, right: ExpressionIR("binary", operator="+", arguments=(left, right))
    mul = lambda left, right: ExpressionIR("binary", operator="*", arguments=(left, right))
    body = (
        AssignmentIR(target=name("total"), value=literal(0.0)),
        DoLoopIR(
            variable="i",
            start=literal(1),
            stop=name("n"),
            step=literal(1),
            body=(
                DoLoopIR(
                    variable="j",
                    start=literal(1),
                    stop=name("m"),
                    step=literal(1),
                    body=(
                        AssignmentIR(
                            target=ref("field", name("i"), name("j")),
                            value=add(
                                ref("field", name("i"), name("j")),
                                mul(name("scale"), add(name("i"), name("j"))),
                            ),
                        ),
                        AssignmentIR(
                            target=name("total"),
                            value=add(name("total"), ref("field", name("i"), name("j"))),
                        ),
                    ),
                ),
            ),
        ),
    )
    procedure = ProcedureIR(
        name="update_field",
        source_span=span,
        arguments=("n", "m", "field", "scale", "total"),
        symbols=(
            SymbolIR("n", integer, intent="in", role="argument"),
            SymbolIR("m", integer, intent="in", role="argument"),
            SymbolIR("field", real, intent="inout", rank=2, shape=(None, None), role="argument"),
            SymbolIR("scale", real, intent="in", role="argument"),
            SymbolIR("total", real, intent="out", role="argument"),
            SymbolIR("i", integer, role="local"),
            SymbolIR("j", integer, role="local"),
        ),
        statements=body,
    )
    return ProjectIR("1.1", (span.file,), (procedure,))


@pytest.mark.integration
def test_ctypes_fortran_kernel_preserves_c_order_two_dimensional_indexing(tmp_path: Path) -> None:
    project = _two_dimensional_project()
    built = build_fortran_kernel_backend(
        project, procedure="update_field", build_directory=tmp_path / "fortran"
    )
    python_path = write_python(
        generate_python(project, procedure="update_field"), tmp_path / "reference.py"
    )
    fortran = _load(built.module_name, built.wrapper)
    python = _load("fortran_backend_reference", python_path)

    original = np.arange(20, dtype=np.float64).reshape(4, 5)
    expected_field, expected_total = python.update_field(4, 5, original.copy(), 0.25)
    actual_input = original.copy(order="C")
    actual_field, actual_total = fortran.update_field(4, 5, actual_input, 0.25)

    np.testing.assert_array_equal(actual_field, expected_field)
    np.testing.assert_array_equal(actual_input, expected_field)
    assert actual_total == pytest.approx(expected_total, rel=0.0, abs=0.0)


def _single_candidate_profile(project: ProjectIR, root: str, procedure: str, kernel: str, kind: str):
    return HybridProfileReport(
        schema_version="1.0",
        root_procedure=root,
        source_files=project.source_files,
        workload_file="synthetic-profile",
        warmup_runs=0,
        measured_runs=1,
        wall_seconds=1.0,
        candidate_seconds=1.0,
        samples=(
            ProfileSample(
                procedure=procedure,
                kernel_procedure=kernel,
                extraction_kind=kind,
                call_count=1,
                inclusive_seconds=1.0,
                self_seconds=1.0,
                candidate_share=1.0,
                wall_share=1.0,
            ),
        ),
    )


@pytest.mark.integration
def test_project_level_full_kernel_can_use_fortran_backend(tmp_path: Path) -> None:
    project = build_project_ir(COMMON_PROJECT, procedure="run_common_state")
    profile = _single_candidate_profile(
        project,
        "run_common_state",
        "advance_common_state",
        "advance_common_state_kernel",
        "full-procedure",
    )
    manifest, _ = build_hybrid_project(
        COMMON_PROJECT,
        root_procedure="run_common_state",
        build_directory=tmp_path / "hybrid",
        profile_report=profile,
        min_profile_share=0.5,
        include_fortran=True,
    )
    assert manifest.extracted_procedures == ("advance_common_state",)
    assert manifest.available_backends == ("python", "cython-safe", "cython-optimized", "fortran")
    runtime = load_hybrid_runtime(
        tmp_path / "hybrid" / manifest.artifacts["hybrid_runtime"],
        "test_full_fortran_hybrid_runtime",
    )

    python_state = runtime.create_common_field()
    fortran_state = runtime.create_common_field()
    python_result = runtime.run_common_state(python_state, 12, 0.4, backend="python")
    fortran_result = runtime.run_common_state(fortran_state, 12, 0.4, backend="fortran")
    np.testing.assert_array_equal(fortran_state.pressure, python_state.pressure)
    np.testing.assert_array_equal(fortran_state.film, python_state.film)
    assert fortran_state.relaxation_factor == python_state.relaxation_factor
    assert fortran_result == python_result


@pytest.mark.integration
def test_project_level_partial_loop_can_use_fortran_backend(tmp_path: Path) -> None:
    project = build_project_ir(PARTIAL_PROJECT, procedure="run_partial_hybrid")
    profile = _single_candidate_profile(
        project,
        "run_partial_hybrid",
        "run_partial_hybrid",
        "run_partial_hybrid_loop_1_kernel",
        "partial-loop",
    )
    manifest, _ = build_hybrid_project(
        PARTIAL_PROJECT,
        root_procedure="run_partial_hybrid",
        build_directory=tmp_path / "hybrid",
        profile_report=profile,
        min_profile_share=0.5,
        include_fortran=True,
        default_backend="fortran",
    )
    assert manifest.partial_extracted_procedures == ("run_partial_hybrid",)
    assert manifest.default_backend == "fortran"
    assert "fortran" in manifest.available_backends
    runtime = load_hybrid_runtime(
        tmp_path / "hybrid" / manifest.artifacts["hybrid_runtime"],
        "test_partial_fortran_hybrid_runtime",
    )
    state = runtime.create_common_field()
    total, peak = runtime.run_partial_hybrid(state, 12, 0.4)
    reference_state = runtime.create_common_field()
    reference_total, reference_peak = runtime.run_partial_hybrid(
        reference_state, 12, 0.4, backend="python"
    )
    np.testing.assert_array_equal(state.pressure, reference_state.pressure)
    np.testing.assert_array_equal(state.film, reference_state.film)
    assert total == reference_total
    assert peak == reference_peak
