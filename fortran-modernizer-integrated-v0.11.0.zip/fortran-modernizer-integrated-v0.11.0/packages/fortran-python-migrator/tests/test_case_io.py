from pathlib import Path

from fpy_migrate.sample.journal_bearing.case_io import read_case


def test_read_standard_case() -> None:
    path = Path("samples/journal_bearing/cases/standard.nml")
    case = read_case(path)
    assert case.ntheta == 32
    assert case.nz == 9
    assert case.eccentricity == 0.60
