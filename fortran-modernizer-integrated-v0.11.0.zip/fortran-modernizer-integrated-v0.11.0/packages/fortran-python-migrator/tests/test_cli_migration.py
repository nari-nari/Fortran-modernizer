from fpy_migrate.cli import main


def test_cli_reports_blocked_without_traceback(capsys) -> None:
    exit_code = main(
        [
            "build-ir",
            "samples/migration_units/unsupported_select.f90",
            "--output",
            "build/unsupported.ir.json",
        ]
    )
    captured = capsys.readouterr()
    assert exit_code == 2
    assert captured.out.startswith("BLOCKED:")
    assert "Case_Construct" in captured.out


def test_cli_generates_kernel_candidate_report(tmp_path) -> None:
    output = tmp_path / "candidates.json"
    exit_code = main(
        [
            "analyze-kernels",
            "samples/migration_units/sor_sweep.f90",
            "--procedure",
            "sor_sweep",
            "--output",
            str(output),
        ]
    )
    assert exit_code == 0
    assert output.exists()


def test_cli_generates_safe_cython_source(tmp_path) -> None:
    output = tmp_path / "sor_sweep_cython.py"
    exit_code = main(
        [
            "translate-cython",
            "samples/migration_units/sor_sweep.f90",
            "--procedure",
            "sor_sweep",
            "--output",
            str(output),
        ]
    )
    assert exit_code == 0
    assert output.exists()
    assert "pressure: cython.double[:, :]" in output.read_text(encoding="utf-8")


def test_cli_generates_optimized_cython_source(tmp_path) -> None:
    output = tmp_path / "sor_sweep_cython_optimized.py"
    exit_code = main(
        [
            "translate-cython",
            "samples/migration_units/sor_sweep.f90",
            "--procedure",
            "sor_sweep",
            "--mode",
            "optimized",
            "--output",
            str(output),
        ]
    )
    assert exit_code == 0
    source = output.read_text(encoding="utf-8")
    assert "boundscheck=False" in source
    assert "pressure: cython.double[:, ::1]" in source


def test_cli_analyzes_state_kernel_extraction(tmp_path) -> None:
    report = tmp_path / "state_kernel.json"
    ir = tmp_path / "state_kernel.ir.json"
    exit_code = main(
        [
            "analyze-state-kernel",
            "samples/migration_units/common_state_analysis.f90",
            "--procedure",
            "advance_common_state",
            "--output",
            str(report),
            "--ir-output",
            str(ir),
        ]
    )
    assert exit_code == 0
    assert report.exists()
    assert ir.exists()
    assert '"kernel_procedure": "advance_common_state_kernel"' in report.read_text(
        encoding="utf-8"
    )


def test_cli_analyzes_multi_file_hybrid_project(tmp_path) -> None:
    output = tmp_path / "hybrid_plan.json"
    exit_code = main(
        [
            "analyze-hybrid-project",
            "samples/migration_projects/common_state_project",
            "--procedure",
            "run_common_state",
            "--output",
            str(output),
        ]
    )
    assert exit_code == 0
    source = output.read_text(encoding="utf-8")
    assert '"initialize_common_state"' in source
    assert '"advance_common_state"' in source
    assert '"summarize_common_state"' in source
    assert '"run_common_state"' in source


def test_cli_analyzes_partial_loop_extraction(tmp_path) -> None:
    report = tmp_path / "partial_loop.json"
    ir = tmp_path / "partial_loop.ir.json"
    exit_code = main(
        [
            "analyze-partial-loop",
            "samples/migration_units/partial_loop_analysis.f90",
            "--procedure",
            "run_partial_loop",
            "--loop-index",
            "1",
            "--output",
            str(report),
            "--ir-output",
            str(ir),
        ]
    )
    assert exit_code == 0
    assert report.exists()
    assert ir.exists()
    source = report.read_text(encoding="utf-8")
    assert '"kernel_procedure": "run_partial_loop_loop_1_kernel"' in source
    assert '"pre_statement_count": 1' in source
    assert '"post_statement_count": 4' in source


def test_cli_translates_selected_numeric_procedure_with_unsupported_sibling(
    tmp_path,
) -> None:
    output = tmp_path / "solve_reynolds.py"
    ir = tmp_path / "solve_reynolds.ir.json"
    exit_code = main(
        [
            "translate",
            "samples/migration_units/legacy_scoped_analysis.f90",
            "--procedure",
            "solve_reynolds",
            "--output",
            str(output),
            "--ir-output",
            str(ir),
        ]
    )
    assert exit_code == 0
    assert output.exists()
    assert ir.exists()
    source = output.read_text(encoding="utf-8")
    assert "def solve_reynolds" in source
    assert "print_results" not in source


def test_cli_analyzes_main_program_orchestration(tmp_path) -> None:
    output = tmp_path / "orchestration_plan.json"
    exit_code = main(
        [
            "analyze-orchestration",
            "samples/migration_units/legacy_scoped_analysis.f90",
            "--program",
            "journal_bearing_legacy",
            "--adapter-config",
            "samples/python_adapters/journal_bearing_adapter_config.json",
            "--output",
            str(output),
        ]
    )
    assert exit_code == 0
    assert output.exists()
    source = output.read_text(encoding="utf-8")
    assert '"synthetic_root": "program_journal_bearing_legacy_numeric"' in source
    assert '"procedure": "print_results"' in source
