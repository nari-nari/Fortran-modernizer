from __future__ import annotations

import json
from pathlib import Path
import subprocess

import jsonschema
import numpy as np
import pytest

from fpy_migrate.extraction import (
    HybridProfileReport,
    ProfileSample,
    analyze_hybrid_project,
    build_hybrid_project,
    load_hybrid_runtime,
    profile_hybrid_project,
)
from fpy_migrate.ir import build_project_ir


ROOT = Path(__file__).resolve().parents[1]
PROJECT = ROOT / "samples" / "migration_projects" / "partial_hybrid_project"
WORKLOAD = ROOT / "samples" / "profile_workloads" / "partial_hybrid_workload.py"


def _fake_profile() -> HybridProfileReport:
    samples = (
        ProfileSample(
            procedure="run_partial_hybrid",
            kernel_procedure="run_partial_hybrid_loop_1_kernel",
            extraction_kind="partial-loop",
            call_count=100,
            inclusive_seconds=0.8,
            self_seconds=0.8,
            candidate_share=0.8,
            wall_share=0.72,
        ),
        ProfileSample(
            procedure="initialize_partial_state",
            kernel_procedure="initialize_partial_state_kernel",
            extraction_kind="full-procedure",
            call_count=100,
            inclusive_seconds=0.1,
            self_seconds=0.1,
            candidate_share=0.1,
            wall_share=0.09,
        ),
        ProfileSample(
            procedure="summarize_partial_state",
            kernel_procedure="summarize_partial_state_kernel",
            extraction_kind="full-procedure",
            call_count=100,
            inclusive_seconds=0.1,
            self_seconds=0.1,
            candidate_share=0.1,
            wall_share=0.09,
        ),
    )
    return HybridProfileReport(
        schema_version="1.0",
        root_procedure="run_partial_hybrid",
        source_files=tuple(str(item) for item in sorted(PROJECT.glob("*.f90"))),
        workload_file=str(WORKLOAD),
        warmup_runs=1,
        measured_runs=100,
        wall_seconds=1.1,
        candidate_seconds=1.0,
        samples=samples,
    )


def test_python_reference_profiler_records_full_and_partial_candidates(tmp_path: Path) -> None:
    report, output = profile_hybrid_project(
        PROJECT,
        root_procedure="run_partial_hybrid",
        workload=WORKLOAD,
        build_directory=tmp_path / "profile",
        warmup_runs=1,
        measured_runs=20,
    )
    assert output.exists()
    assert {item.procedure for item in report.samples} == {
        "initialize_partial_state",
        "summarize_partial_state",
        "run_partial_hybrid",
    }
    calls = {item.procedure: item.call_count for item in report.samples}
    assert calls["initialize_partial_state"] == 20
    assert calls["summarize_partial_state"] == 20
    assert calls["run_partial_hybrid"] == 1020
    assert sum(item.candidate_share for item in report.samples) == pytest.approx(1.0)
    schema = json.loads((ROOT / "schemas" / "hybrid_profile.schema.json").read_text())
    jsonschema.validate(report.to_dict(), schema)


def test_profile_threshold_selects_only_measured_hot_loop() -> None:
    project = build_project_ir(PROJECT, procedure="run_partial_hybrid")
    plan = analyze_hybrid_project(
        project,
        "run_partial_hybrid",
        profile_report=_fake_profile(),
        min_profile_share=0.5,
    )
    assert plan.eligible_procedures == (
        "initialize_partial_state",
        "summarize_partial_state",
        "run_partial_hybrid",
    )
    assert plan.full_extracted_procedures == ()
    assert plan.partial_extracted_procedures == ("run_partial_hybrid",)
    assert plan.candidate("run_partial_hybrid").selected
    assert not plan.candidate("initialize_partial_state").selected
    schema = json.loads((ROOT / "schemas" / "hybrid_project_plan.schema.json").read_text())
    jsonschema.validate(plan.to_dict(), schema)


def _fortran_result(tmp_path: Path):
    executable = tmp_path / "profiled_partial_fortran"
    sources = [
        PROJECT / "10_initialize.f90",
        PROJECT / "20_summarize.f90",
        PROJECT / "30_run.f90",
        PROJECT / "driver.f90",
    ]
    subprocess.run(
        ["gfortran", "-O2", *(str(item) for item in sources), "-o", str(executable)],
        check=True,
        capture_output=True,
        text=True,
    )
    completed = subprocess.run([str(executable)], check=True, capture_output=True, text=True)
    lines = completed.stdout.splitlines()
    total, peak, relaxation = map(float, lines[0].split())
    pressure = np.zeros(12, dtype=np.float64)
    film = np.zeros(12, dtype=np.float64)
    for line in lines[1:]:
        index, p_value, h_value = line.split()
        pressure[int(index) - 1] = float(p_value)
        film[int(index) - 1] = float(h_value)
    return total, peak, relaxation, pressure, film


@pytest.mark.integration
def test_profiled_build_compiles_only_hot_partial_loop_and_matches_fortran(
    tmp_path: Path,
) -> None:
    build_root = tmp_path / "profiled_hybrid"
    manifest, manifest_path = build_hybrid_project(
        PROJECT,
        root_procedure="run_partial_hybrid",
        build_directory=build_root,
        profile_report=_fake_profile(),
        min_profile_share=0.5,
    )
    assert manifest_path.exists()
    assert manifest.eligible_procedures == (
        "initialize_partial_state",
        "summarize_partial_state",
        "run_partial_hybrid",
    )
    assert manifest.full_extracted_procedures == ()
    assert manifest.partial_extracted_procedures == ("run_partial_hybrid",)
    assert manifest.python_only_procedures == (
        "initialize_partial_state",
        "summarize_partial_state",
    )
    assert "profile_report" in manifest.artifacts
    schema = json.loads((ROOT / "schemas" / "hybrid_project_manifest.schema.json").read_text())
    jsonschema.validate(manifest.to_dict(), schema)

    runtime = load_hybrid_runtime(
        build_root / manifest.artifacts["hybrid_runtime"],
        "test_profiled_hybrid_runtime",
    )
    f_total, f_peak, f_relaxation, f_pressure, f_film = _fortran_result(tmp_path)
    state = runtime.create_common_field()
    total, peak = runtime.run_partial_hybrid(
        state, 12, 0.4, backend="cython-optimized"
    )
    np.testing.assert_allclose(state.pressure[:12], f_pressure, rtol=1e-14, atol=1e-14)
    np.testing.assert_allclose(state.film[:12], f_film, rtol=1e-14, atol=1e-14)
    assert total == pytest.approx(f_total, rel=1e-14, abs=1e-14)
    assert peak == pytest.approx(f_peak, rel=1e-14, abs=1e-14)
    assert state.relaxation_factor == pytest.approx(f_relaxation, rel=1e-14, abs=1e-14)
