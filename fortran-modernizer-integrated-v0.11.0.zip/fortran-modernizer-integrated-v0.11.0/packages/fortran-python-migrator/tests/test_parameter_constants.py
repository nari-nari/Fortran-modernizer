from __future__ import annotations

import importlib.util
from pathlib import Path
import subprocess
import sys

import numpy as np
import pytest

from fpy_migrate.backends.fortran_ctypes import build_fortran_kernel_backend
from fpy_migrate.ir import (
    UnsupportedFortranError,
    build_project_ir,
    validate_migration_ir,
    write_project_ir,
)
from fpy_migrate.kernels.build import build_cython_extension
from fpy_migrate.translate import (
    generate_cython,
    generate_fortran_kernel,
    generate_python,
    write_cython,
    write_python,
)


ROOT = Path(__file__).resolve().parents[1]
PARAMETER_SOURCE = ROOT / "samples/migration_units/parameter_intrinsics.f90"
LEGACY_PROJECT = ROOT / "samples/migration_projects/legacy_parameter_project"


def _load_module(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def test_parameter_constants_are_ordered_and_validate(tmp_path: Path) -> None:
    project = build_project_ir(PARAMETER_SOURCE, procedure="parameter_intrinsics")
    procedure = project.procedure("parameter_intrinsics")

    assert project.schema_version == "1.2"
    assert [item.name for item in procedure.constants] == ["nbase", "nvalues", "pi"]
    assert procedure.constant("nvalues").value.arguments[0].value == "nbase"
    assert procedure.symbol("values").shape[0].value == "nvalues"

    target = write_project_ir(project, tmp_path / "parameter_intrinsics.ir.json")
    assert validate_migration_ir(target) == []


def test_cyclic_parameter_dependencies_fail_loudly(tmp_path: Path) -> None:
    source = tmp_path / "cyclic_parameters.f90"
    source.write_text(
        """subroutine cyclic_parameters(value)
  implicit none
  integer, parameter :: a = b + 1
  integer, parameter :: b = a + 1
  integer, intent(out) :: value
  value = a
end subroutine cyclic_parameters
""",
        encoding="utf-8",
    )
    with pytest.raises(UnsupportedFortranError, match="cyclic PARAMETER dependency"):
        build_project_ir(source, procedure="cyclic_parameters")


def test_all_code_generators_emit_parameters_and_intrinsics() -> None:
    project = build_project_ir(PARAMETER_SOURCE, procedure="parameter_intrinsics")
    python_source = generate_python(project, procedure="parameter_intrinsics").source
    cython_source = generate_cython(
        project, procedure="parameter_intrinsics", safety_mode="optimized"
    ).source
    fortran_source = generate_fortran_kernel(
        project, procedure="parameter_intrinsics"
    ).source

    assert "nvalues = (nbase + 1)" in python_source
    assert "pi = math.acos((-1.0))" in python_source
    assert "np.finfo(np.float64).max" in python_source
    assert "np.iinfo(np.int32).max" in python_source

    assert "nvalues: cython.int = (nbase + 1)" in cython_source
    assert "pi: cython.double = math.acos((-1.0))" in cython_source

    assert "integer(c_int), parameter :: nvalues = (nbase + 1)" in fortran_source
    assert "real(c_double), parameter :: pi = acos" in fortran_source
    assert "real_limit = huge(1.0_c_double)" in fortran_source
    assert "int_limit = huge(1)" in fortran_source


def test_module_parameters_are_attached_to_contained_procedure(tmp_path: Path) -> None:
    source = ROOT / "samples/migration_units/module_parameter_analysis.f90"
    project = build_project_ir(source, procedure="fill_module_parameter")
    procedure = project.procedure("fill_module_parameter")

    assert [item.name for item in procedure.constants] == ["nvalues", "scale"]
    assert project.state_groups == ()
    target = write_python(
        generate_python(project, procedure="fill_module_parameter"),
        tmp_path / "module_parameter.py",
    )
    module = _load_module(target, "module_parameter_m20")
    np.testing.assert_allclose(
        module.fill_module_parameter(),
        np.asarray([2.5, 5.0, 7.5, 10.0, 12.5]),
        rtol=0.0,
        atol=0.0,
    )


@pytest.mark.integration
def test_parameter_intrinsics_match_all_generated_backends(tmp_path: Path) -> None:
    project = build_project_ir(PARAMETER_SOURCE, procedure="parameter_intrinsics")
    python_path = write_python(
        generate_python(project, procedure="parameter_intrinsics"),
        tmp_path / "parameter_reference.py",
    )
    python_module = _load_module(python_path, "parameter_reference_m20")
    expected = python_module.parameter_intrinsics()

    generated_results = []
    for mode in ("safe", "optimized"):
        module_name = f"parameter_{mode}_m20"
        source = write_cython(
            generate_cython(
                project,
                procedure="parameter_intrinsics",
                safety_mode=mode,
            ),
            tmp_path / f"{module_name}.py",
        )
        built = build_cython_extension(
            source,
            module_name,
            tmp_path / f"build_{mode}",
            safety_mode=mode,
        )
        module = _load_module(built.extension, module_name)
        generated_results.append(module.parameter_intrinsics())

    fortran_build = build_fortran_kernel_backend(
        project,
        procedure="parameter_intrinsics",
        build_directory=tmp_path / "fortran",
    )
    fortran_module = _load_module(
        fortran_build.wrapper, fortran_build.module_name
    )
    generated_results.append(fortran_module.parameter_intrinsics())

    expected_values, expected_real_limit, expected_int_limit = expected
    for actual_values, actual_real_limit, actual_int_limit in generated_results:
        np.testing.assert_allclose(
            np.asarray(actual_values), expected_values, rtol=0.0, atol=5.0e-16
        )
        assert actual_real_limit == expected_real_limit
        assert actual_int_limit == expected_int_limit


@pytest.mark.integration
def test_legacy_parameter_project_generated_python_matches_fortran(tmp_path: Path) -> None:
    sources = [
        LEGACY_PROJECT / "init_geometry.f90",
        LEGACY_PROJECT / "solve_reynolds.f90",
        LEGACY_PROJECT / "compute_metrics.f90",
        LEGACY_PROJECT / "driver.f90",
    ]
    executable = tmp_path / "legacy_parameter_driver"
    subprocess.run(
        ["gfortran", "-O2", *map(str, sources), "-o", str(executable)],
        check=True,
        capture_output=True,
        text=True,
    )
    completed = subprocess.run(
        [str(executable)], check=True, capture_output=True, text=True
    )
    fields = completed.stdout.split()
    expected_iteration = int(fields[0])
    expected_scalars = np.asarray([float(item) for item in fields[1:]], dtype=np.float64)

    project = build_project_ir(LEGACY_PROJECT)
    generated_path = write_python(
        generate_python(project, procedure="compute_metrics"),
        tmp_path / "legacy_parameter_generated.py",
    )
    module = _load_module(generated_path, "legacy_parameter_generated_m20")
    state = module.CommonFieldState(
        press=np.zeros((36, 17), dtype=np.float64),
        film=np.zeros(36, dtype=np.float64),
        angle=np.zeros(36, dtype=np.float64),
    )
    module.init_geometry(state)
    iteration, residual = module.solve_reynolds(state)
    load, pmax, hmin, friction = module.compute_metrics(state)
    actual_scalars = np.asarray(
        [residual, load, pmax, hmin, friction], dtype=np.float64
    )

    assert iteration == expected_iteration == 173
    np.testing.assert_allclose(
        actual_scalars, expected_scalars, rtol=1.0e-12, atol=1.0e-13
    )
