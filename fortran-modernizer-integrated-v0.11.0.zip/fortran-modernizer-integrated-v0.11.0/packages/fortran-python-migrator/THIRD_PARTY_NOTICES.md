# Third-party notices

The offline bootstrap bundle contains user-supplied wheels for:

- **fparser 0.2.4** — BSD-3-Clause
- **findent 4.3.6** — BSD-3-Clause

Their licences remain applicable to those components. The wheel files are kept
under `vendor/wheels/` to support offline WSL installation.
