# fortran-python-migrator

Verification-driven migration support for legacy Fortran numerical programs.
The project separates migration into controlled stages:

1. assess and minimally normalise the Fortran input;
2. build a versioned Migration IR for one approved procedure and its local dependencies;
3. generate and verify a readable Python reference implementation;
4. identify sequential numerical loops suitable for native compilation;
5. generate and compile safety-checked and optimised Cython implementations;
6. integrate verified kernels into a complete iterative solver with preserved convergence control;
7. translate post-processing and produce one common analysis-result contract;
8. convert COMMON/module shared state into explicit Python dataclasses;
9. extract state-dependent hot loops into explicit Python/Cython kernels and generate adapters;
10. generate project-level hybrid runtimes for multiple stateful procedures;
11. extract one internal hot loop while retaining scalar setup and post-processing in Python;
12. promote eligible loops inside project-level Python-only procedures to partial Cython kernels;
13. select hot kernels from measured Python-reference profiles;
14. aggregate multiple representative cases before native-kernel selection;
15. include Cython build time, artifact size, measured speedup, and break-even estimates in the final selection;
16. prepare a source-only WSL/Linux-to-Windows distribution kit with target-side Cython/Nuitka build scripts;
17. generate optional project-level `bind(C)` Fortran kernels behind the same backend registry as Python and Cython;
18. import and independently verify machine-readable reports from the separate Fortran refactoring tool;
19. diagnose production-project acceptance by procedure, unsupported-construct frequency, dependency chain, and recommended migration order;
20. preserve scalar `PARAMETER` constants and translate `ACOS`/`DACOS`/`HUGE` across generated Python, Cython, and `bind(C)` Fortran kernels.
21. inventory the whole project first, then build full Migration IR only for a selected subroutine and its reachable dependency closure while retaining global COMMON validation.

Original Fortran sources are never overwritten. Unsupported constructs are
reported as `BLOCKED` rather than omitted or guessed.

## Current implementation

The repository contains:

- a journal-bearing finite-difference lubrication sample in modern Fortran,
  deliberately legacy-style Fortran, handwritten Python, and handwritten Cython;
- numerical comparison of all four full-solver sample backends;
- fparser-based migration-readiness assessment;
- findent-based fixed-to-free-form normalisation;
- a versioned JSON hand-off format for the separate Fortran refactoring tool;
- a project-acceptance diagnostic that separates file parse success from procedure IR readiness, propagates blocked dependencies, ranks unsupported constructs, and emits JSON/CSV migration inventories;
- a serialisable Migration IR with source mappings and ordered named constants;
- two-pass procedure-scoped construction that inventories calls and COMMON declarations before translating only the selected reachable subroutines;
- AST-to-IR and IR-to-Python translation for leaf and low-dependency numerical
  procedures;
- project-local `CALL` dependency resolution;
- strict blocking for unsupported reachable calls while unreachable formatted-output siblings can remain outside a selected numerical migration slice;
- support for `IF/ELSE`, single-line `IF`, relational/logical expressions,
  rank-2 arrays, and assumed-shape array arguments;
- automatic Cython-candidate ranking based on loops, array ranks, calls, and
  symbol types;
- Migration-IR-to-Cython generation using Cython 3 Pure Python Mode;
- an isolated compiler for safe and optimised generated Cython extensions;
- explicit C-contiguous array contracts and supported scalar leaf-call inlining for optimised kernels;
- an adaptive Python/safe-Cython/optimised-Cython/Fortran kernel benchmark harness;
- full iterative-solver generation with `EXIT`, convergence status, iteration count,
  and whole-array initialisation preserved;
- a portable relative-path solver manifest and TOML backend configurations;
- complete-solve benchmarking for generated Python, safe Cython, optimised Cython,
  and `gfortran -O3`;
- generated post-processing for complementarity residual, dimensionless load,
  dimensionless friction, maximum pressure, and minimum film thickness;
- one JSON/CSV analysis-result contract shared by Python, Cython, and Fortran;
- one backend loader that presents generated Python, Cython, and optional Fortran output through
  the same NumPy-based API;
- Migration IR 1.2 state groups for named/blank COMMON and module variables, plus scalar `PARAMETER` constants;
- canonical COMMON alias mapping by storage position;
- generated Python dataclasses and explicit state-object procedure arguments;
- state-migration reports and a Python-wrapper/stateless-Cython-kernel boundary;
- automatic state-field read/write analysis and explicit kernel-argument extraction;
- movable state-kernel bundles containing Python, safe Cython, optimized Cython,
  a dataclass adapter, compiled extensions, and a relative-path manifest;
- project-wide hybrid generation with per-procedure backend overrides;
- optional project-level Fortran kernel generation from explicit-argument Migration IR, using `bind(C)` shared libraries and generated `ctypes` adapters;
- one four-way backend registry (`python`, `cython-safe`, `cython-optimized`, `fortran`) for full state kernels and extracted partial loops;
- automatic project-level promotion of eligible loops in otherwise Python-only procedures;
- multi-case profile aggregation with explicit case weights and coverage gates;
- kernel economics reports covering Cython build time, bundle/extension size, speedup, saved time, and break-even runs/calls;
- economics-aware native selection with transparent rejection reasons in the project plan;
- combined full-procedure and partial-loop manifests behind one context-local registry;
- top-level partial-loop extraction that keeps setup and teardown in readable Python;
- movable partial-loop bundles with Python, safe Cython, optimized Cython, a
  backend-selecting runtime, source spans, and a relative-path manifest;
- Fortran/generated-Python/generated-Cython equivalence tests for one in-place
  SOR pressure sweep;
- GitHub Copilot instructions, agents, prompts, and skills.

## WSL/Linux quick start

```bash
./scripts/bootstrap_wsl.sh
source .venv/bin/activate
./scripts/test_all.sh
```

The bootstrap script installs the uploaded offline wheels for `fparser 0.2.4`
and `findent 4.3.6`, then builds the sample Cython extension.

## Full sample solver commands

```bash
# Build Fortran executables and the handwritten Cython extension
fpy-migrate sample build

# Run all available full-solver sample backends
fpy-migrate sample run --backend all

# Compare modern Fortran, legacy Fortran, Python and Cython
fpy-migrate sample compare
```

## Generated full solver and backend selection

The milestone-6 sample contains a complete pressure solver with film generation,
repeated SOR sweeps, convergence testing, iteration count, and `EXIT`. Build all
backends from the same Fortran source as follows:

```bash
fpy-migrate build-solver \
  samples/migration_units/pressure_solver.f90 \
  --procedure solve_pressure \
  --fortran-driver samples/migration_units/pressure_solver_driver.f90 \
  --build-directory build/pressure_solver
```

The command generates readable Python, safe Cython, optimised Cython, and an
optional Fortran executable. It also writes `solver_manifest.json` and one TOML
configuration per backend. Backend selection therefore changes configuration,
not application code:

```bash
fpy-migrate run-solver build/pressure_solver/run_python.toml
fpy-migrate run-solver build/pressure_solver/run_cython-optimized.toml
fpy-migrate run-solver build/pressure_solver/run_fortran.toml
```

The generated manifest stores artifact paths relative to the manifest, allowing
the complete build directory to be moved as one unit. Each run writes a JSON
summary plus pressure and film CSV files. A non-converged solve is reported
explicitly and returns a non-zero CLI status.

```bash
fpy-migrate benchmark-solver \
  build/pressure_solver/solver_manifest.json \
  --output reports/full_solver_benchmark.json \
  --size 32x9 --size 64x17
```

## Complete lubrication analysis and post-processing

Milestone 7 adds post-processing to the generated pressure solver. It computes
a non-negative-pressure Reynolds complementarity residual, dimensionless load
components and magnitude, a dimensionless shear-friction estimate, maximum
pressure, and minimum film thickness.

```bash
fpy-migrate build-analysis \
  samples/migration_units/lubrication_analysis.f90 \
  --procedure solve_analysis \
  --fortran-driver samples/migration_units/lubrication_analysis_driver.f90 \
  --build-directory build/lubrication_analysis

fpy-migrate run-analysis \
  build/lubrication_analysis/run_analysis_cython-optimized.toml
```

All backends write the same files:

- `summary.json` with convergence and post-processing scalars;
- `pressure.csv`;
- `film.csv`.

The equation residual uses the complementarity condition associated with the
projected non-negative-pressure update. In positive-pressure cells it is the
absolute discrete Reynolds residual. In zero-pressure cells only a violation of
the admissible inequality contributes. This avoids reporting cavitated cells as
large false residuals.

## Assessment and normalisation

```bash
fpy-migrate assess samples/journal_bearing/fortran_legacy \
  --output build/assessment.json

fpy-migrate normalize source.f \
  --output build/normalized/source.f90

fpy-migrate validate-refactor-report path/to/report.json
```

## Procedure-level Python migration

The safe translation subset currently supports:

- explicitly declared integer, real, and logical scalars;
- explicit-shape and assumed-shape numerical arrays;
- rank-1 and rank-2 array references;
- `intent(in)`, `intent(out)`, and `intent(inout)`;
- assignments and basic arithmetic, including exponentiation;
- selected intrinsic functions;
- non-labelled `DO` loops and unnamed `EXIT` statements;
- block `IF/ELSE`, nested/else-if representation, and single-line `IF`;
- relational and logical expressions, including `.AND.`, `.OR.`, and `.NOT.`;
- calls to subroutines defined in the same parsed source, with output arguments
  converted into Python return-value assignment;
- transitive dependency inclusion for a selected root procedure.

Array references are converted from Fortran one-based indices to Python
zero-based indices. Inclusive Fortran `DO` bounds are preserved.

```bash
fpy-migrate build-ir \
  samples/migration_units/sor_sweep.f90 \
  --procedure sor_sweep \
  --output build/sor_sweep.ir.json

fpy-migrate validate-ir build/sor_sweep.ir.json

fpy-migrate translate \
  samples/migration_units/sor_sweep.f90 \
  --procedure sor_sweep \
  --ir-output build/sor_sweep.ir.json \
  --output generated/sor_sweep.py
```

The external refactoring report is optional, but when supplied its program-unit,
argument, type, `intent`, and rank information is cross-checked against the
fparser AST. A disagreement blocks translation.

## Shared-state migration

Milestone 8 converts supported Fortran `COMMON` blocks and module variables into
explicit Python dataclasses. Compatible COMMON aliases are mapped by storage
position rather than by local variable name. Incompatible member count, type,
kind, rank, or shape blocks translation.

```bash
fpy-migrate analyze-state \
  samples/migration_units/common_state_analysis.f90 \
  --procedure run_common_state \
  --output reports/common_state_migration.json

fpy-migrate translate \
  samples/migration_units/common_state_analysis.f90 \
  --procedure run_common_state \
  --output generated/common_state.py
```

Generated procedures receive the state object explicitly instead of using
Python module globals. The state wrapper remains in Python. A performance-critical
stateful procedure must be split into a Python adapter and a stateless kernel
that receives only NumPy arrays and scalar values before Cython generation.
Direct Cython generation for state-object projects is intentionally blocked.

Current state limitations include EQUIVALENCE/type-punning, module parameters,
local `SAVE` promotion, and automatic allocation policy for allocatable module
arrays.

## State-object to native-kernel extraction

Milestone 9 automatically separates a supported hot loop from COMMON/module
state. The generated wrapper owns the Python dataclass, while the extracted
kernel receives only explicit numerical arrays and scalar values.

```bash
fpy-migrate analyze-state-kernel \
  samples/migration_units/common_state_analysis.f90 \
  --procedure advance_common_state \
  --output build/advance_common_state.extraction.json \
  --ir-output build/advance_common_state.kernel.ir.json

fpy-migrate build-state-kernel \
  samples/migration_units/common_state_analysis.f90 \
  --procedure advance_common_state \
  --build-directory build/advance_common_state_bundle
```

The build creates:

- an explicit-argument Python reference kernel;
- safety-checked and optimized Cython Pure Python Mode kernels;
- compiled Cython extensions;
- a generated Python dataclass/state adapter;
- a relative-path manifest and extraction report.

The wrapper selects `python`, `cython-safe`, or `cython-optimized` without
changing the calling code:

```python
wrapper.advance_common_state(state, 12, backend="cython-optimized")
```

State access is inferred conservatively from the procedure body. A field read
and written by the loop becomes `inout`; a read-only field becomes `in`. Calls
inside the extracted stateful body remain blocked until interprocedural state
and alias analysis is implemented. The generated bundle uses only relative
paths and can be moved as one directory.

## Project-level hybrid generation

Milestones 10 and 12 accept either a Fortran file or a directory of Fortran
sources and build one reachable call graph. Whole stateful numerical procedures
are extracted first. If whole-procedure extraction is blocked, the planner now
searches top-level `DO` loops in source order and promotes the first safe loop to
`PARTIAL_AUTO`; the surrounding orchestration remains in readable Python.

```bash
fpy-migrate analyze-hybrid-project \
  samples/migration_projects/common_state_project \
  --procedure run_common_state \
  --output build/common_project_plan.json

fpy-migrate build-hybrid-project \
  samples/migration_projects/common_state_project \
  --procedure run_common_state \
  --build-directory build/common_hybrid_project \
  --default-backend cython-optimized
```

The generated runtime exposes the project state classes and routes calls through
one context-local backend registry:

```python
state = runtime.create_common_field()
total, minimum = runtime.run_common_state(
    state, 12, 0.4, backend="cython-optimized"
)
```

A project may also mix backends without changing the Fortran-derived call graph:

```python
total, minimum = runtime.run_common_state(
    state,
    12,
    0.4,
    backend="cython-optimized",
    backend_overrides={"summarize_common_state": "python"},
)
```

The original project fixture splits COMMON initialization, update, summarization,
and orchestration across separate files. Project-wide validation resolves
cross-file calls and normalizes compatible COMMON aliases by storage position.
A second fixture contains an orchestrator with calls before and after one update
loop. Its initialization and summarization procedures become full kernels, while
the orchestrator is classified `PARTIAL_AUTO`: only its update loop is compiled.
Both kernel kinds use the same backend registry and per-procedure overrides. All
manifest paths are relative so the complete build directory remains movable.



## Optional project-level Fortran kernel backend (Milestone 17)

A project build can retain selected numerical kernels as compiled Fortran while
keeping shared-state management, orchestration, and backend selection in Python.
The Fortran backend is generated from the same explicit-argument kernel IR used
for Python and Cython. Legacy COMMON/module storage is therefore not exposed
directly through the ABI.

```bash
fpy-migrate build-hybrid-project \
  samples/migration_projects/common_state_project \
  --procedure run_common_state \
  --include-fortran \
  --build-directory build/common_hybrid_fortran
```

The generated runtime accepts all four backends:

```python
state = runtime.create_common_field()
result = runtime.run_common_state(state, 12, 0.4, backend="fortran")

# Keep orchestration and inexpensive procedures in Python, but use Fortran for
# one selected numerical kernel.
result = runtime.run_common_state(
    state,
    12,
    0.4,
    backend="python",
    backend_overrides={"advance_common_state": "fortran"},
)
```

To make Fortran the default for a generated project, both options are required:

```bash
fpy-migrate build-hybrid-project \
  samples/migration_projects/partial_hybrid_project \
  --procedure run_partial_hybrid \
  --include-fortran \
  --default-backend fortran \
  --build-directory build/partial_hybrid_fortran
```

For each selected full kernel or partial loop, the build stores:

- generated C-interoperable Fortran source;
- a platform shared library (`.so` on the verified Linux environment);
- a generated Python `ctypes` adapter;
- the existing Python, safe Cython, and optimized Cython implementations;
- relative-path bundle and project manifests.

Numerical arrays follow an explicit C-contiguous NumPy contract. For rank-two
and higher arrays, the generated Fortran pointer shape and logical indices are
reversed so that element-wise results remain consistent with the generated
Python/Cython code. Unsupported kernels containing procedure calls or local
automatic arrays remain blocked rather than partially translated.

Linux shared-library generation and four-way numerical equivalence are verified.
Windows `.dll` generation and inclusion in the final Nuitka distribution still
require target-side Windows/MSVC testing.

## Profile-driven native-kernel selection

Milestone 13 profiles the generated Python reference implementation before any
native build is selected. A workload module defines `run(reference_module)` and
uses ordinary generated state classes and procedures. The profiler records
call count, inclusive time, self time, candidate-relative share, and wall-time
share for both full-procedure and partial-loop candidates.

```bash
fpy-migrate profile-hybrid-project \
  samples/migration_projects/partial_hybrid_project \
  --procedure run_partial_hybrid \
  --workload samples/profile_workloads/partial_hybrid_workload.py \
  --build-directory build/profile_run \
  --output build/hybrid_profile.json \
  --warmup-runs 2 \
  --measured-runs 100
```

The measured report can then restrict native generation to hot candidates:

```bash
fpy-migrate analyze-hybrid-project \
  samples/migration_projects/partial_hybrid_project \
  --procedure run_partial_hybrid \
  --profile-report build/hybrid_profile.json \
  --min-profile-share 0.50 \
  --output build/profiled_plan.json

fpy-migrate build-hybrid-project \
  samples/migration_projects/partial_hybrid_project \
  --procedure run_partial_hybrid \
  --profile-report build/hybrid_profile.json \
  --min-profile-share 0.50 \
  --build-directory build/profiled_hybrid
```

`--min-profile-time-ms` can suppress short-lived candidates and
`--max-native-kernels` caps the number of compiled kernels. If every eligible
candidate falls below the thresholds, the hottest measured candidate is kept as
a conservative fallback. Procedures not selected by the profile remain in the
generated Python reference path; they are not compiled merely because static
analysis says that they are eligible.

The supplied iterative workload calls the internal update loop repeatedly. In
the recorded run that loop accounts for about 95% of measured candidate self
time, so only `run_partial_hybrid` is selected for partial-loop Cython generation;
initialization and summarization remain Python. All three runtime backends still
match the compiled Fortran arrays and scalar outputs exactly.

## Multi-case profile aggregation

Milestone 14 combines independently measured representative cases instead of
letting one workload define the native build. Each case retains its own report
and receives an explicit positive weight.

```bash
fpy-migrate profile-hybrid-suite \
  samples/migration_projects/partial_hybrid_project \
  --procedure run_partial_hybrid \
  --case standard=samples/profile_workloads/partial_hybrid_standard.py \
  --case update-heavy=samples/profile_workloads/partial_hybrid_update_heavy.py \
  --case postprocess-heavy=samples/profile_workloads/partial_hybrid_postprocess_heavy.py \
  --case-weight standard=0.5 \
  --case-weight update-heavy=0.3 \
  --case-weight postprocess-heavy=0.2 \
  --build-directory build/profile_suite \
  --output build/hybrid_profile_suite.json
```

Existing single-case reports may also be combined with
`aggregate-hybrid-profiles`. The aggregated report records, per candidate:

- per-case call count, self time, candidate share, and wall share;
- observed case count and coverage;
- arithmetic mean and maximum share;
- case-weighted share and weighted mean self time.

The suite can drive the same analysis and build commands:

```bash
fpy-migrate build-hybrid-project \
  samples/migration_projects/partial_hybrid_project \
  --procedure run_partial_hybrid \
  --profile-report build/hybrid_profile_suite.json \
  --min-profile-share 0.35 \
  --min-profile-mean-share 0.40 \
  --min-profile-max-share 0.80 \
  --min-profile-cases 3 \
  --build-directory build/multi_case_hybrid
```

`--min-profile-share` is the weighted share. The mean and maximum thresholds
prevent a weighted average from hiding respectively broad or extreme-case
importance. `--min-profile-cases` is a hard coverage gate and is not bypassed by
the hottest-candidate fallback.

In the recorded standard/update-heavy/postprocess-heavy suite, only the internal
update loop passes all four thresholds. Initialization and summarization remain
Python, while Python, safe Cython, and optimized Cython results all match compiled
Fortran exactly.

## Build-cost and runtime-benefit selection

Milestone 15 measures whether compiling an eligible kernel is worthwhile rather
than assuming every speedup justifies a native artifact. It first builds all
statically eligible bundles, records per-kernel Cython build time and generated
size, and then runs each representative workload with all candidates in Python
and with one candidate at a time switched to optimized Cython.

```bash
fpy-migrate benchmark-hybrid-economics \
  samples/migration_projects/partial_hybrid_project \
  --procedure run_partial_hybrid \
  --profile-report build/hybrid_profile_suite.json \
  --build-directory build/hybrid_economics \
  --output build/hybrid_economics.json \
  --warmup-runs 5 \
  --measured-runs 200
```

The report records:

- build seconds for the safe and optimized bundle;
- complete bundle bytes and optimized-extension bytes;
- case-by-case Python baseline and one-kernel-Cython time;
- weighted speedup and saved time per representative suite run;
- estimated saved time per kernel call;
- estimated runs and calls required to recover the build time;
- saved seconds per MiB and a transparent cost-benefit score.

The economics report can be applied by itself or after profile selection:

```bash
fpy-migrate build-hybrid-project \
  samples/migration_projects/partial_hybrid_project \
  --procedure run_partial_hybrid \
  --economics-report build/hybrid_economics.json \
  --min-economics-speedup 1.50 \
  --min-economics-saved-time-ms 0.04 \
  --max-economics-build-seconds 11 \
  --max-economics-artifact-mb 2 \
  --max-economics-break-even-runs 230000 \
  --build-directory build/economics_selected
```

Additional gating is available through
`--max-economics-break-even-calls`. The selected/rejected decision and every
measured economics value are retained in `hybrid_project_plan.json`; build-time
and artifact-size measurements for the final selected bundles are also retained
in `hybrid_project_manifest.json`.

In the recorded three-case suite, the internal update loop achieved a weighted
`1.623x` speedup and saved about `0.048 ms` per weighted suite run. Initialization
was slower after dispatch overhead, while summarization improved but did not meet
the selected speedup/saved-time/break-even gates. Only the update loop was built,
and all Python/Cython results still matched Fortran exactly. Break-even estimates
are workload- and machine-specific planning signals, not portable guarantees.

## Partial-loop extraction

When a procedure contains scalar setup, one hot numerical loop, and Python-suitable
post-processing, only the selected top-level `DO` loop can be compiled:

```bash
fpy-migrate analyze-partial-loop \
  samples/migration_units/partial_loop_analysis.f90 \
  --procedure run_partial_loop \
  --loop-index 1 \
  --output build/partial_loop_extraction.json \
  --ir-output build/partial_loop_kernel.ir.json

fpy-migrate build-partial-loop \
  samples/migration_units/partial_loop_analysis.f90 \
  --procedure run_partial_loop \
  --loop-index 1 \
  --build-directory build/partial_loop_bundle \
  --default-backend cython-optimized
```

The generated wrapper preserves this ordering:

```text
Python scalar setup
    -> selectable Python/safe-Cython/optimized-Cython loop kernel
    -> Python reduction and scalar post-processing
```

A loop is selected explicitly by 1-based top-level index. The initial safe subset
blocks calls inside the selected loop, local arrays, and local scalars read before
an unconditional Python-side definition. Nested-region slicing is not guessed.
COMMON/module fields become explicit numerical kernel arguments while the state
object remains owned by Python.

```python
state = runtime.create_common_field()
total, peak = runtime.run_partial_loop(
    state,
    12,
    0.4,
    backend="cython-optimized",
)
```

The milestone fixture leaves `bias = scale * relaxation_factor` and the final
pressure reduction in Python. Only the pressure-update loop is compiled. All
three generated backends match compiled Fortran exactly for the complete state
and scalar outputs.

## Cython candidate selection and generation

```bash
# Rank the selected root and its included dependencies
fpy-migrate analyze-kernels \
  samples/migration_units/sor_sweep.f90 \
  --procedure sor_sweep \
  --output build/sor_sweep.candidates.json

# Generate safety-checked Cython Pure Python Mode code
fpy-migrate translate-cython \
  samples/migration_units/sor_sweep.f90 \
  --procedure sor_sweep \
  --candidate-output build/sor_sweep.candidates.json \
  --ir-output build/sor_sweep.cython.ir.json \
  --output generated/sor_sweep_cython.py

# Compile it in an isolated build directory
fpy-migrate compile-cython \
  generated/sor_sweep_cython.py \
  --module-name generated_sor_cython \
  --build-directory build/generated_sor_cython
```

The safe generated Cython version deliberately keeps `boundscheck`,
`wraparound`, and `initializedcheck` enabled. After equivalence passes, an
optimised source can be generated with `--mode optimized`. It disables those
checks, requires contiguous numerical arrays, and inlines supported scalar leaf
calls without changing the numerical update order.

```bash
fpy-migrate translate-cython \
  samples/migration_units/sor_sweep.f90 \
  --procedure sor_sweep \
  --mode optimized \
  --output generated/sor_sweep_cython_optimized.py

fpy-migrate compile-cython \
  generated/sor_sweep_cython_optimized.py \
  --module-name generated_sor_cython_optimized \
  --build-directory build/generated_sor_cython_optimized \
  --mode optimized
```

## Kernel benchmark

```bash
fpy-migrate benchmark-kernel \
  samples/migration_units/sor_sweep.f90 \
  --procedure sor_sweep \
  --build-directory build/sor_sweep_benchmark \
  --output reports/sor_sweep_benchmark.json \
  --size 32x17 --size 64x33 --size 128x65
```

The benchmark adaptively repeats each backend until the requested timing window
is reached. It records seconds per call, speedups, one-sweep summaries, and
Python/Cython full-array differences. Performance is machine-specific; the
report must not be treated as a portable guarantee.

## Kernel candidate states

- `AUTO`: numeric procedure with a supported IR and useful loop/array structure;
- `REVIEW_REQUIRED`: supported but unlikely to benefit by itself, or explicitly
  marked for review;
- `BLOCKED`: unsupported types, unresolved calls, or a blocked Migration IR.

A no-loop helper can be included as a dependency of an `AUTO` root while still
being classified `REVIEW_REQUIRED` as a standalone performance target.

## Common generated-backend API

```python
from fpy_migrate.backends import load_generated_backend

python_backend = load_generated_backend("python", "generated/sor_sweep.py")
cython_backend = load_generated_backend(
    "cython",
    "build/generated_sor_cython/lib/generated_sor_cython.so",
    module_name="generated_sor_cython",
)

pressure, residual = cython_backend.call("sor_sweep", *arguments)
```

Cython typed-memoryview results are exposed as zero-copy NumPy views so callers
receive the same array-oriented API from the Python and Cython backends.

## Python call conversion

Fortran output arguments are converted into Python return values. For example:

```fortran
call periodic_neighbors(i, ntheta, iw, ie)
```

becomes:

```python
iw, ie = periodic_neighbors(i, ntheta)
```

An `intent(inout)` array remains an input and is also returned. This keeps the
mutation explicit during migration and supports direct three-backend comparison.


## Distribution packaging (Milestone 16)

After building a profile/economics-selected hybrid project, create a portable
source-only kit:

```bash
fpy-migrate prepare-distribution \
  build/hybrid/hybrid_project_manifest.json \
  --app-adapter samples/package_apps/partial_hybrid_cli.py \
  --output-directory build/windows-kit \
  --app-name lubrication_hybrid \
  --target windows-nuitka

fpy-migrate validate-distribution build/windows-kit
```

The kit deliberately excludes Linux `.so` files and other platform-specific
binaries. `tools/build_native.py` recompiles the safe and optimized Cython
sources on the target OS. `launcher.py --self-check` loads the rebuilt modules
and runs an adapter-defined known case through all backends.

For WSL/Linux verification:

```bash
cd build/windows-kit
./build_wsl.sh
```

For the final Windows x64 build, run `build_windows.ps1` in Windows PowerShell.
It builds Windows `.pyd` modules and then creates a Nuitka standalone directory.
The initial packaging design copies the generated hybrid Python payload beside
the executable; it is intended for deployment without a target-side Python
installation, not for complete source-code concealment.

For a fully offline Windows build, place compatible x86-64 wheels listed in
`required_wheels.json` under `wheelhouse/`. Microsoft C/C++ Build Tools are also
required on the build machine. The target PC should not require Python after the
standalone directory is built.

The target build also generates an installed-package inventory, a third-party
notice summary, and copies detected license files. Current standard Nuitka
releases use AGPLv3 with a runtime exception for created binaries; the exact
version and organizational commercial-compliance requirements must be reviewed
before release.

The Linux environment used for this milestone successfully rebuilt the kit and
passed the Python/safe-Cython/optimized-Cython application self-check. Actual
Windows/MSVC/Nuitka execution remains a required target-side validation step.

## Verification status

See `reports/verification/` and `reports/milestone2/` through
`reports/milestone17/`.

- automated test inventory: **73 tests** (`46` non-integration plus `27` integration); all non-integration and all new or affected compiler-heavy shards passed in Milestone 17, while the one-command full rerun reached the hosted wall-time in an unchanged complete-analysis shard;
- project-level optional Fortran backend:
  - full state kernels and extracted partial loops can be selected as `fortran`;
  - Python state objects remain the canonical state representation;
  - the generated `bind(C)`/`ctypes` boundary accepts explicit scalars and C-contiguous NumPy arrays;
  - all-Fortran and mixed Python/Fortran project runs match the original compiled Fortran within double-precision roundoff;
  - a dedicated rank-two fixture verifies logical indexing across the C-contiguous NumPy/Fortran pointer boundary;
- distribution packaging:
  - platform-specific extension binaries are excluded from the portable source kit;
  - safe and optimized Cython modules rebuild successfully in an isolated Linux/WSL-style directory;
  - package self-check passes for Python, safe Cython, and optimized Cython;
  - Windows PowerShell/Nuitka scripts are generated but have not been executed in this Linux environment;
- economics-aware kernel selection:
  - build time, extension size, measured speedup, saved time, and break-even runs are recorded;
  - only the update loop satisfies the recorded economics thresholds;
  - the selected hybrid remains exactly equivalent to Fortran;
- multi-case profile-driven selection:
  - independent standard, update-heavy, and postprocess-heavy cases retain per-case measurements;
  - candidate plans record weighted, mean, and maximum share plus 3/3 case coverage;
  - only the update loop passes the recorded cross-case thresholds;
  - Python, safe Cython, optimized Cython, and Fortran outputs remain exactly equal;
- profile-driven selection:
  - full-procedure and partial-loop candidates are timed in generated Python;
  - the recorded iterative workload assigns about 95% of candidate self time to the update loop;
  - only the measured hot partial loop is compiled, while initialization and summarization remain Python;
  - Python, safe Cython, optimized Cython, and Fortran outputs remain exactly equal;
- partial-loop extraction:
  - scalar setup and the second reduction loop remain in Python;
  - Python, safe Cython, and optimized Cython update the complete COMMON state identically;
  - all arrays and scalar outputs match compiled Fortran exactly;
- COMMON-state generated Python vs Fortran: exact state and scalar match;
- module-state generated Python vs Fortran: exact state and scalar match;
- extracted COMMON-state update kernel:
  - Python, safe Cython, and optimized Cython complete-state transitions are identical;
  - all three match the compiled Fortran state and scalar results;
- extracted module-state update kernel:
  - Python, safe Cython, and optimized Cython complete-state transitions are identical;
  - all three match the compiled Fortran state and scalar results;
- project-level COMMON hybrid generation:
  - three stateful leaf procedures are extracted from four cross-file procedures;
  - Python, safe Cython, optimized Cython, and a mixed-backend run match Fortran exactly;
- project-level module-state hybrid generation:
  - initialization, update, and summarization are independently selectable kernels;
  - all three uniform backends match Fortran arrays and scalars exactly;
- generated `compute_film` Python vs Fortran: exact match for the standard case;
- generated SOR Python vs Fortran:
  - residual difference: `0.0`;
  - maximum absolute pressure difference: `4.440892098500626e-16`;
- generated safe Cython SOR vs Fortran:
  - residual difference: `0.0`;
  - maximum absolute pressure difference: `4.440892098500626e-16`;
- generated Python vs generated safe and optimised Cython:
  - residual difference: `0.0`;
  - pressure field difference: `0.0`;
- optimised Cython benchmark speedup over generated Python: approximately `62x` to `92x` for the recorded 32x17 through 256x129 grids;
- complete generated pressure solver, standard 32x9 case:
  - all four backends converge in 163 iterations;
  - generated Python vs both generated Cython modes: exact pressure match;
  - generated Python vs Fortran: maximum absolute pressure difference
    `1.3322676295501878e-15`;
- complete-solve benchmark in the recorded Linux environment:
  - 32x9: optimised Cython approximately `68x` faster than generated Python and
    about `1.9x` slower than Fortran;
  - 64x17: optimised Cython approximately `79x` faster than generated Python and
    about `1.2x` slower than Fortran;
- complete analysis, standard 32x9 case:
  - all four backends converge in 163 iterations;
  - maximum generated-backend/Fortran pressure difference: `1.3322676295501878e-15`;
  - maximum scalar post-processing difference is at floating-point roundoff scale;
  - generated Python, safe Cython, and optimised Cython summaries are identical;
- modern Fortran vs legacy Fortran full-solver pressure field: exact match;
- modern Fortran vs handwritten Cython full-solver pressure field: exact match;
- modern Fortran vs handwritten Python full-solver pressure field: maximum
  absolute difference `3.552713678800501e-15`.

## Deliberate limitations

This is not yet a general-purpose Fortran-to-Python translator. The current IR
and generators deliberately do not support:

- derived-type component references such as `case%ntheta`;
- unresolved/external subroutine calls outside the parsed source;
- labelled loops, named `EXIT`, `CYCLE`, `GOTO`, or unbounded `DO`;
- `SELECT CASE`;
- EQUIVALENCE, pointer features, procedure pointers, or polymorphism;
- character-heavy or complex formatted I/O;
- array sections and vector subscripts;
- local automatic arrays in generated Cython procedures;
- extraction of a stateful procedure that itself calls other procedures (it remains Python orchestration);
- nested-loop-region slicing; the current partial extractor selects one top-level `DO` loop;
- automatic extraction of loops containing procedure calls or local arrays;
- preprocessor/build-system-aware multi-file source discovery;
- `nogil`, OpenMP, SIMD directives, or automatic loop reordering;
- automatic conversion between incompatible array layouts inside the hot kernel;
- generated Fortran kernels containing procedure calls or local automatic arrays;
- target-validated Windows `.dll` generation for the optional project-level Fortran backend.

Each capability is added only with a corresponding Fortran/Python/Cython
equivalence fixture.


See `docs/MILESTONE_20.md` and `reports/milestone20/` for named-constant and intrinsic-function support, `docs/MILESTONE_17.md` and `reports/milestone17/` for the project-level
Fortran kernel backend, `docs/MILESTONE_16.md` and `reports/milestone16/` for distribution-kit
preparation and self-checks, `docs/MILESTONE_15.md` and `reports/milestone15/`
for economics-aware selection, `docs/MILESTONE_14.md` and
`reports/milestone14/` for multi-case profile aggregation,
`docs/MILESTONE_13.md` for single-workload profile-driven selection, and
`docs/MILESTONE_11.md` for standalone partial-loop extraction results. Project-level hybrid generation remains under
`reports/milestone10/`, single state-kernel extraction under `reports/milestone9/`,
complete-analysis results under `reports/milestone7/`, and full-solver performance
reports under `reports/milestone6/`.

## Refactoring-tool report bridge

Milestone 18 adds a report-bundle bridge for the separate Fortran refactoring
project. The bridge accepts either an existing canonical hand-off JSON or a
directory containing multiple machine-readable JSON reports. It recognises common
inventory aliases for program units, symbols, COMMON layouts, call edges,
diagnostics, source maps, and regression cases, then writes the stable
`refactor_report.schema.json` contract used by this project.

```bash
fpy-migrate import-refactor-bundle \
  path/to/refactor-tool/reports \
  --producer-version 0.37.0 \
  --output build/refactor_handoff.json
```

The canonical report is independently cross-checked against a new fparser parse
before Migration IR or generated Python is trusted:

```bash
fpy-migrate verify-refactor-connection \
  path/to/fortran/project \
  --procedure main_solver \
  --report build/refactor_handoff.json \
  --output build/refactor_connection.json
```

The connection report compares:

- reachable program units and argument order;
- symbol category, `intent`, and rank;
- source file and line spans;
- call-graph edges;
- COMMON member position, category, and rank;
- blocking diagnostics exported by the refactoring tool.

The result is `PASS`, `REVIEW_REQUIRED`, or `BLOCKED`. A type, rank, argument,
or COMMON-layout disagreement is blocking. Missing optional evidence such as a
symbol or call entry is review-required rather than silently accepted.

`examples/refactor_tool_v037_bundle/` demonstrates a split-report layout. It is a
compatibility fixture, not a claim that every future refactoring-tool report name
or field spelling is automatically understood. Unsupported layouts fail with a
request for a canonical hand-off JSON rather than guessing.


## Named constants and intrinsic functions (Milestone 20)

Migration IR 1.2 stores scalar Fortran named constants separately from mutable
variables. The builder preserves integer, real, and logical `PARAMETER`
declarations, orders dependencies such as `nvalues = nbase + 1`, rejects cycles,
and permits constants in array extents, loop bounds, and numerical expressions.

The same IR now generates equivalent forms in all native paths:

```fortran
integer, parameter :: ntheta = 36
real(8), parameter :: pi = acos(-1.0d0)
```

```python
ntheta = 36
pi = math.acos(-1.0)
```

Cython receives typed local constants, while generated `bind(C)` Fortran keeps
`parameter` declarations. `ACOS`, `DACOS`, and type-directed `HUGE` are supported
in Python, safe Cython, optimised Cython, and generated Fortran kernels. The
generated ctypes wrapper also emits required constants before allocating
explicit-shape `intent(out)` arrays.

The controlled journal-bearing fixture under
`samples/migration_projects/legacy_parameter_project/` retains its original
`PARAMETER`, `ACOS`, and `HUGE` statements. Its generated Python calculation
converges in 173 iterations and matches the compiled Fortran scalar outputs at
double-precision roundoff scale. This milestone does not structure labelled
loops, `GOTO`, or formatted `WRITE`; those remain responsibilities of the
upstream refactoring step or later orchestration/I/O work.

Milestone-20 verification collected 86 tests: 56 non-integration and 29
compiler-heavy integration tests passed, while one normalisation test was
skipped because the active PATH did not expose `findent`. The offline wheel is
still retained under `vendor/wheels`. The four-backend constant fixture matched
with a maximum generated-Fortran array difference of
`1.1102230246251565e-16`; real and integer `HUGE` results matched exactly.

The initial constant subset is scalar numeric/logical `PARAMETER` only.
Parameter arrays and character parameters remain blocked. Generic external
INCLUDE-directory search is also deliberately deferred: the upstream
refactoring tool must resolve INCLUDE files or export a resolved include
manifest rather than having the migration tool guess search paths.


## Production-project acceptance diagnostic (Milestone 19)

Before translating a real lubrication-analysis repository, inventory it at
procedure granularity:

```bash
fpy-migrate diagnose-project \
  path/to/legacy-lubrication-code \
  --procedure main_analysis \
  --refactor-report build/refactor_handoff.json \
  --output build/project_acceptance.json \
  --csv-output build/procedure_readiness.csv \
  --construct-csv-output build/unsupported_constructs.csv
```

The diagnostic distinguishes four different questions that must not be conflated:

- can fparser parse each source file;
- can the current safe Migration IR represent each procedure;
- is each procedure directly migratable after review;
- is the complete dependency chain of the requested root available and migratable.

Each procedure is classified as `READY`, `REVIEW_REQUIRED`, or `BLOCKED`.
`BLOCKED` propagates to callers that depend on that procedure. Calls whose source
is outside the discovered project are reported separately as unresolved external
calls; the tool never invents their interface.

The JSON report includes:

- file and procedure counts and readiness rates;
- source locations and current-IR failure messages;
- unsupported-construct frequency by file and procedure;
- resolved and unresolved call edges;
- dependency-first migration order;
- a recommended vertical slice for the requested root;
- procedures that should remain in Fortran until their blockers are resolved;
- optional metadata from the canonical refactoring-tool hand-off.

The two CSV files are intended for procedure prioritisation and unsupported-construct triage in spreadsheet tools. A 100%
file parse rate does not imply that the project is migration-ready.

## Procedure-scoped Migration IR construction (Milestone 21)

A source file may contain supported numerical procedures beside unsupported
reporting or vendor-boundary procedures. Supplying `--procedure` now performs a
lightweight project inventory first, resolves the reachable call closure, and
builds full Migration IR only for that closure.

```bash
fpy-migrate build-ir \
  samples/migration_units/legacy_scoped_analysis.f90 \
  --procedure solve_reynolds \
  --output build/solve_reynolds.ir.json

fpy-migrate translate \
  samples/migration_units/legacy_scoped_analysis.f90 \
  --procedure solve_reynolds \
  --output build/solve_reynolds.py
```

The same file deliberately retains formatted `WRITE` statements in
`print_results`. They do not block the two commands above because
`solve_reynolds` does not call that procedure. Safety boundaries are unchanged:

- selecting `print_results` directly is blocked;
- selecting `run_analysis`, whose dependency closure reaches `print_results`,
  is blocked;
- omitting `--procedure` retains strict whole-project subroutine translation and
  is blocked by the formatted output;
- unresolved calls and recursion in the selected closure remain blocking;
- duplicate program-unit names remain blocking.

COMMON validation is not scoped down. The lightweight pass reads COMMON
members from every subroutine and main program in the discovered source set and
checks storage position, type, rank, and shape before generating the selected
IR. An incompatible COMMON declaration in an unreachable sibling therefore
still blocks migration.

The controlled `run_numeric` root in the same one-file fixture includes
`init_geometry`, `solve_reynolds`, and `compute_metrics` but excludes
`print_results`. Generated Python converges in 173 iterations and matches the
compiled Fortran reference with a largest scalar difference of
`4.440892098500626e-15`.

Milestone-21 verification collects 96 tests: 66 non-integration and 29
compiler-heavy integration tests passed; one `findent` normalization test was
skipped because the active PATH did not expose the executable.

## Generated main-program orchestration (Milestone 22)

A normalized Fortran main program whose executable body is a top-level `CALL`
sequence can now become a generated Python application. Migration-ready
numerical calls must come first; unsupported reporting calls may be replaced by
validated, read-only Python adapters at the end of the sequence.

```bash
fpy-migrate analyze-orchestration \
  samples/migration_units/legacy_scoped_analysis.f90 \
  --program journal_bearing_legacy \
  --adapter-config samples/python_adapters/journal_bearing_adapter_config.json \
  --output build/orchestration_plan.json

fpy-migrate build-orchestration \
  samples/migration_units/legacy_scoped_analysis.f90 \
  --program journal_bearing_legacy \
  --adapter-config samples/python_adapters/journal_bearing_adapter_config.json \
  --build-directory build/journal_bearing_app \
  --include-fortran
```

The build creates a synthetic numerical root containing the original numeric
call prefix, compiles its reachable procedures behind the existing backend
registry, generates `application.py`, copies adapter modules, and validates the
plan and manifest against dedicated JSON Schemas. The same generated `main()`
selects `python`, `cython-safe`, `cython-optimized`, or `fortran` without
changing the adapter.

The controlled journal-bearing main program converges in 173 iterations on all
four backends. Maximum scalar differences from the compiled Fortran reference
are `4.440892098500626e-15` for Python and both Cython modes and
`4.440892098500626e-16` for the generated Fortran backend.

Milestone 22 intentionally blocks arbitrary main-program statements,
interleaved I/O, numerical calls after an adapter, adapter writes to shared
state, array adapter arguments, and general `FORMAT` translation. These
boundaries are not inferred or silently rewritten.

The repository now collects 102 tests: 71 non-integration tests and 30
compiler-heavy integration tests pass, with one `findent` normalization test
skipped when the executable is unavailable on `PATH`.

## Full end-to-end acceptance gate (Milestone 23)

The supplied runnable journal-bearing sample is now a self-contained E2E fixture
under `samples/e2e/journal_bearing/`. It keeps the original fixed-form source and
`INCLUDE` files, a normalized free-form source, a controlled canonical refactor
handoff, and a validated Python output adapter together.

```bash
fpy-migrate verify-e2e \
  samples/e2e/journal_bearing/legacy \
  samples/e2e/journal_bearing/normalized/journal_bearing_normalized.f90 \
  --program journal_bearing_legacy \
  --adapter-config samples/e2e/journal_bearing/adapters/config.json \
  --handoff samples/e2e/journal_bearing/refactor_handoff.json \
  --handoff-procedure run_numeric \
  --build-directory build/journal_bearing_e2e \
  --output reports/journal_bearing_e2e.json
```

The command fingerprints both source snapshots, requires the unnormalized legacy source to remain `BLOCKED`, verifies the normalized AST
against the handoff, proves that intentional type/rank/COMMON-position/source
mismatches are blocked, compiles original and normalized Fortran baselines, and
compares Python, safe Cython, optimized Cython, and generated Fortran against the
original baseline.

Acceptance uses the complete shared state rather than formatted scalar output.
The generated application exposes `run_with_state()` and can write an NPZ
snapshot through `--state-output`. The fixture compares pressure `(36, 17)`,
film thickness `(36,)`, angle `(36,)`, all six scalar results, exact iteration
count, and finite-value status.

The original and normalized Fortran arrays are identical. All four generated
backends converge in 173 iterations. Maximum pressure-array differences from the
original Fortran result are `6.217248937900877e-15` for Python and both Cython
modes and `1.3322676295501878e-15` for generated Fortran.

The repository collects 105 pytest items. Seventy-three non-integration tests
pass, thirty compiler-heavy integration tests are run in isolated interpreter
shards, the `findent` test is skipped when the executable is absent, and the
nested-native-build E2E pytest wrapper is opt-in in this hosted environment. The
same E2E implementation runs independently from `scripts/test_all.sh` and has a
schema-valid `PASS` report.

## Direct connection to fortran-refactor-tool v0.50.0

The refactoring tool's `export-python-handoff` command produces canonical
schema-1.1 JSON. The migrator validates source SHA-256 values, qualified module
procedure scopes, CALL edges, symbols, and COMMON layouts before building
Migration IR. Unresolved production `EQUIVALENCE` evidence remains `BLOCKED`.
See `docs/refactor_v050_integration.md`.
