# v0.48.0

- Added analysis-only migration-design artifacts for byte/element-mapped partial EQUIVALENCE overlaps.
- Compares three explicit replacement designs: canonical workspace, synchronized copies, and derived storage type.
- Records canonical union size, element offsets, former-view index ranges, observed assignment directions, COMMON ownership, transitive association, and same-statement dual references.
- Prefers a derived storage type when COMMON or transitive overlay ownership is present; otherwise prefers one canonical workspace.
- Marks synchronized copies as not recommended when both aliases are written, both appear in one statement, or association is transitive.
- Generates JSON, CSV, and Markdown design artifacts without creating source edits or conversion plans.
- Added three synthetic-fixture tests; production Fortran remains untested.
