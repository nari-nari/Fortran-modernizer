# Fortran Refactoring Tool v0.41.0

v0.41.0 adds review-gated removal of a narrowly proven EQUIVALENCE complete alias.

## Added

- `equivalence-alias-suggest`
- `equivalence-alias-plan`
- reviewed representative-variable selection and regression-gate confirmation
- free- and fixed-form alias declaration removal
- source identifier unification that preserves comments and strings
- named-COMMON representative preservation
- exact post-application verification
- synthetic compiler and numerical regression demo

## Safety scope

Only two explicitly declared intrinsic scalar objects with identical type and kind are eligible. Arrays, subobjects, type punning, COMMON-to-COMMON aliasing, multiple-set statements, nested scopes, and persistent metadata are blocked.

## Validation

- 197 Python tests
- gfortran compile checks
- numerical result preservation in free- and fixed-form fixtures
- COMMON-anchored representative test
- stale-review rejection
- synthetic fixtures only; no production-code validation claim
