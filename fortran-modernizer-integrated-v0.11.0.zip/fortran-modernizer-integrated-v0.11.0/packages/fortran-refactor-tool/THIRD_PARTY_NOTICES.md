# Third-party notices

## fparser

- Project: `fparser`
- Version pinned by this repository: `0.2.4`
- License: BSD-3-Clause
- Purpose: Fortran lexical reading and syntax-tree parsing
- Distribution: installed from PyPI or a user-supplied official wheel; not vendored

## GNU Fortran

GNU Fortran (`gfortran`) is used as an external compiler for syntax diagnostics, compatibility intake, warning builds, instrumented builds, and regression tests. It is not redistributed by this repository.

## Optional tools not bundled

The CLI can report whether the following locally installed executables are present. They are not required, redistributed, downloaded, or automatically used for source analysis.

- CamFort — upstream license reported as Apache-2.0; policy: future optional cross-check only
- findent — policy: possible optional formatter backend after local license/version approval
- fortls — MIT; policy: possible symbol/reference cross-check only

See `docs/external_tool_policy.md`.

## Optional local tool: findent

findent 4.3.6 may be installed separately for explicit cross-checks. It is not bundled, downloaded, or required by this project. Upstream license: BSD-3-Clause.
