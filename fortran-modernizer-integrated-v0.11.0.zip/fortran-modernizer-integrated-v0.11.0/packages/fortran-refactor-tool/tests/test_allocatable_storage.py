from __future__ import annotations

import hashlib
import json
import subprocess
import tempfile
import unittest
from pathlib import Path

from fortran_refactor.allocatable_storage import (
    write_allocatable_storage_plan,
    write_allocatable_storage_suggestions,
)
from fortran_refactor.apply import apply_plan


class AllocatableStorageTest(unittest.TestCase):
    def _write_ready_project(self, root: Path) -> Path:
        source_root = root / "source"
        source_root.mkdir()
        source = source_root / "storage_demo.f90"
        source.write_text(
            """module field_store
  implicit none
  private
  integer, parameter :: nx = 3
  real :: pressure(0:nx-1)
  public :: initialize_fields, finalize_fields, set_fields, field_sum
contains
  subroutine initialize_fields()
    implicit none
  end subroutine initialize_fields

  subroutine finalize_fields()
    implicit none
  end subroutine finalize_fields

  subroutine set_fields()
    implicit none
    pressure = [1.0, 2.0, 3.0]
  end subroutine set_fields

  real function field_sum()
    implicit none
    field_sum = sum(pressure)
  end function field_sum
end module field_store

program main
  use field_store, only: initialize_fields, finalize_fields, set_fields, field_sum
  implicit none
  call initialize_fields()
  call set_fields()
  print '(f5.1)', field_sum()
  call finalize_fields()
end program main
""",
            encoding="utf-8",
        )
        return source

    def _review_selection(self, suggest_dir: Path, candidate_id: str) -> dict:
        selection = json.loads(
            (suggest_dir / "allocatable_storage_selection.json").read_text(encoding="utf-8")
        )
        candidate = next(
            item for item in selection["candidate_snapshot"] if item["candidate_id"] == candidate_id
        )
        selection["reviewed"] = True
        selection["selections"] = [
            {
                "candidate_id": candidate_id,
                "confirmed_initializer": candidate["initializer"],
                "confirmed_finalizer": candidate["finalizer"],
                "confirmed_call_order": True,
                "confirmed_regression_gate": True,
            }
        ]
        return selection

    def test_private_module_array_with_owned_lifecycle_is_ready(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            source = self._write_ready_project(root)
            before = hashlib.sha256(source.read_bytes()).hexdigest()
            result = write_allocatable_storage_suggestions([source], [], root / "suggest")
            candidate = next(item for item in result.candidates if item.variable == "pressure")
            self.assertEqual(candidate.status, "ready")
            self.assertEqual(candidate.original_shape, ("0:nx-1",))
            self.assertEqual(candidate.deferred_shape, (":",))
            self.assertEqual(candidate.initializer, "initialize_fields")
            self.assertEqual(candidate.finalizer, "finalize_fields")
            self.assertEqual(before, hashlib.sha256(source.read_bytes()).hexdigest())

    def test_reviewed_plan_applies_compiles_and_preserves_result(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            source = self._write_ready_project(root)
            suggest_dir = root / "suggest"
            result = write_allocatable_storage_suggestions([source], [], suggest_dir)
            candidate = next(item for item in result.candidates if item.variable == "pressure")
            selection = self._review_selection(suggest_dir, candidate.candidate_id)
            selection_path = root / "selection.json"
            selection_path.write_text(json.dumps(selection, indent=2) + "\n", encoding="utf-8")
            plan_dir = root / "plan"
            suggestions = write_allocatable_storage_plan([source], [], selection_path, plan_dir)
            self.assertEqual([item.id for item in suggestions], [candidate.candidate_id])
            receipt = apply_plan(
                plan_dir,
                root / "applied",
                {candidate.candidate_id},
                False,
                True,
                [],
                True,
            )
            verification = receipt["allocatable_storage_verification"][0]
            self.assertEqual(verification["variable"], "pressure")
            transformed = root / "applied" / "transformed_sources" / "storage_demo.f90"
            text = transformed.read_text(encoding="utf-8").lower()
            self.assertIn("real, allocatable :: pressure(:)", text)
            self.assertIn("allocate(pressure(0:nx-1))", text)
            self.assertEqual(text.count("if (allocated(pressure)) deallocate(pressure)"), 2)
            executable = root / "storage_demo"
            subprocess.run(["gfortran", str(transformed), "-o", str(executable)], check=True)
            output = subprocess.check_output([str(executable)], text=True).strip()
            self.assertEqual(output, "6.0")

    def test_public_or_unowned_array_is_blocked(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            source = root / "blocked.f90"
            source.write_text(
                """module public_store
  implicit none
  integer, parameter :: n = 4
  real, public :: field(n)
contains
  subroutine initialize_store()
  end subroutine initialize_store
end module public_store
""",
                encoding="utf-8",
            )
            result = write_allocatable_storage_suggestions([source], [], root / "suggest")
            candidate = result.candidates[0]
            self.assertEqual(candidate.status, "blocked")
            self.assertTrue(any("public" in blocker for blocker in candidate.blockers))
            self.assertTrue(any("finalizer" in blocker for blocker in candidate.blockers))

    def test_bound_must_be_parameter_or_initializer_argument(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            source = root / "bounds.f90"
            source.write_text(
                """module m
  implicit none
  private
  integer :: n
  real :: a(n)
contains
  subroutine initialize_m()
  end subroutine initialize_m
  subroutine finalize_m()
  end subroutine finalize_m
end module m
""",
                encoding="utf-8",
            )
            result = write_allocatable_storage_suggestions([source], [], root / "suggest")
            candidate = next(item for item in result.candidates if item.variable == "a")
            self.assertEqual(candidate.status, "blocked")
            self.assertTrue(any("allocation bounds" in blocker for blocker in candidate.blockers))

    def test_plan_requires_explicit_lifecycle_and_regression_confirmation(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            source = self._write_ready_project(root)
            suggest_dir = root / "suggest"
            result = write_allocatable_storage_suggestions([source], [], suggest_dir)
            candidate = next(item for item in result.candidates if item.variable == "pressure")
            selection = self._review_selection(suggest_dir, candidate.candidate_id)
            selection["selections"][0]["confirmed_regression_gate"] = False
            selection_path = root / "selection.json"
            selection_path.write_text(json.dumps(selection, indent=2) + "\n", encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "confirmed_regression_gate"):
                write_allocatable_storage_plan([source], [], selection_path, root / "plan")

    def test_reviewed_selection_rejects_changed_source(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            source = self._write_ready_project(root)
            suggest_dir = root / "suggest"
            result = write_allocatable_storage_suggestions([source], [], suggest_dir)
            candidate = next(item for item in result.candidates if item.variable == "pressure")
            selection = self._review_selection(suggest_dir, candidate.candidate_id)
            selection_path = root / "selection.json"
            selection_path.write_text(json.dumps(selection, indent=2) + "\n", encoding="utf-8")
            source.write_text(source.read_text(encoding="utf-8") + "! changed\n", encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "selection is stale"):
                write_allocatable_storage_plan([source], [], selection_path, root / "plan")


    def test_private_derived_type_component_applies_and_preserves_result(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            source_root = root / "source"
            source_root.mkdir()
            source = source_root / "component_demo.f90"
            source.write_text(
                """module component_state_store
  implicit none
  private
  integer, parameter :: n = 3
  type :: state_t
    real :: field(0:n-1)
  end type state_t
  public :: run_demo
contains
  subroutine initialize_state(state)
    type(state_t), intent(inout) :: state
  end subroutine initialize_state

  subroutine finalize_state(state)
    type(state_t), intent(inout) :: state
  end subroutine finalize_state

  subroutine run_demo(value)
    real, intent(out) :: value
    type(state_t) :: state
    call initialize_state(state)
    state%field = [1.0, 2.0, 3.0]
    value = sum(state%field)
    call finalize_state(state)
  end subroutine run_demo
end module component_state_store

program main
  use component_state_store, only: run_demo
  implicit none
  real :: value
  call run_demo(value)
  print '(f5.1)', value
end program main
""",
                encoding="utf-8",
            )
            suggest_dir = root / "suggest"
            result = write_allocatable_storage_suggestions([source], [], suggest_dir)
            candidate = next(item for item in result.candidates if item.storage_scope == "component")
            self.assertEqual(candidate.status, "ready")
            self.assertEqual(candidate.owner, "component_state_store%state_t")
            self.assertEqual(candidate.allocation_target, "state%field")
            selection = json.loads(
                (suggest_dir / "allocatable_storage_selection.json").read_text(encoding="utf-8")
            )
            selection["reviewed"] = True
            selection["selections"] = [{
                "candidate_id": candidate.candidate_id,
                "confirmed_initializer": candidate.initializer,
                "confirmed_finalizer": candidate.finalizer,
                "confirmed_call_order": True,
                "confirmed_regression_gate": True,
            }]
            selection_path = root / "selection.json"
            selection_path.write_text(json.dumps(selection, indent=2) + "\n", encoding="utf-8")
            plan_dir = root / "plan"
            write_allocatable_storage_plan([source], [], selection_path, plan_dir)
            receipt = apply_plan(
                plan_dir, root / "applied", {candidate.candidate_id}, False, True, [], True
            )
            verification = receipt["allocatable_storage_verification"][0]
            self.assertEqual(verification["storage_scope"], "component")
            transformed = root / "applied" / "transformed_sources" / source.name
            transformed_text = transformed.read_text(encoding="utf-8").lower()
            self.assertIn("real, allocatable :: field(:)", transformed_text)
            self.assertIn("allocate(state%field(0:n-1))", transformed_text)
            executable = root / "component_demo"
            subprocess.run(["gfortran", str(transformed), "-o", str(executable)], check=True)
            self.assertEqual(subprocess.check_output([str(executable)], text=True).strip(), "6.0")

    def test_local_work_array_applies_with_automatic_deallocation(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            source_root = root / "source"
            source_root.mkdir()
            source = source_root / "local_demo.f90"
            source.write_text(
                """subroutine compute(n, value)
  implicit none
  integer, intent(in) :: n
  real, intent(out) :: value
  real :: work(0:n-1)
  integer :: i
  do i = 0, n - 1
    work(i) = real(i + 1)
  end do
  value = sum(work)
end subroutine compute

program main
  implicit none
  real :: value
  call compute(3, value)
  print '(f5.1)', value
end program main
""",
                encoding="utf-8",
            )
            suggest_dir = root / "suggest"
            result = write_allocatable_storage_suggestions([source], [], suggest_dir)
            candidate = next(item for item in result.candidates if item.storage_scope == "local")
            self.assertEqual(candidate.status, "ready")
            self.assertTrue(candidate.automatic_deallocation)
            selection = json.loads(
                (suggest_dir / "allocatable_storage_selection.json").read_text(encoding="utf-8")
            )
            selection["reviewed"] = True
            selection["selections"] = [{
                "candidate_id": candidate.candidate_id,
                "confirmed_entry_allocation": True,
                "confirmed_regression_gate": True,
            }]
            selection_path = root / "selection.json"
            selection_path.write_text(json.dumps(selection, indent=2) + "\n", encoding="utf-8")
            plan_dir = root / "plan"
            write_allocatable_storage_plan([source], [], selection_path, plan_dir)
            receipt = apply_plan(
                plan_dir, root / "applied", {candidate.candidate_id}, False, True, [], True
            )
            verification = receipt["allocatable_storage_verification"][0]
            self.assertEqual(verification["storage_scope"], "local")
            self.assertTrue(verification["automatic_deallocation"])
            transformed = root / "applied" / "transformed_sources" / source.name
            transformed_text = transformed.read_text(encoding="utf-8").lower()
            self.assertIn("real, allocatable :: work(:)", transformed_text)
            self.assertIn("allocate(work(0:n-1))", transformed_text)
            self.assertNotIn("deallocate(work)", transformed_text)
            executable = root / "local_demo"
            subprocess.run(["gfortran", str(transformed), "-o", str(executable)], check=True)
            self.assertEqual(subprocess.check_output([str(executable)], text=True).strip(), "6.0")

    def test_public_derived_type_component_is_blocked(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            source = root / "public_component.f90"
            source.write_text(
                """module public_state
  implicit none
  integer, parameter :: n = 3
  type, public :: state_t
    real :: field(n)
  end type state_t
contains
  subroutine initialize_state(state)
    type(state_t), intent(inout) :: state
  end subroutine
  subroutine finalize_state(state)
    type(state_t), intent(inout) :: state
  end subroutine
end module public_state
""",
                encoding="utf-8",
            )
            result = write_allocatable_storage_suggestions([source], [], root / "suggest")
            candidate = next(item for item in result.candidates if item.storage_scope == "component")
            self.assertEqual(candidate.status, "blocked")
            self.assertTrue(any("derived type is public" in item for item in candidate.blockers))

    def test_saved_local_array_is_blocked(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            source = root / "saved_local.f90"
            source.write_text(
                """subroutine accumulate(value)
  implicit none
  real, intent(out) :: value
  real, save :: work(3)
  work = work + 1.0
  value = sum(work)
end subroutine accumulate
""",
                encoding="utf-8",
            )
            result = write_allocatable_storage_suggestions([source], [], root / "suggest")
            candidate = next(item for item in result.candidates if item.storage_scope == "local")
            self.assertEqual(candidate.status, "blocked")
            self.assertTrue(any("save" in item.lower() for item in candidate.blockers))

    def test_local_selection_requires_entry_allocation_confirmation(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            source = root / "local.f90"
            source.write_text(
                """subroutine compute(n)
  implicit none
  integer, intent(in) :: n
  real :: work(n)
  work = 0.0
end subroutine compute
""",
                encoding="utf-8",
            )
            suggest_dir = root / "suggest"
            result = write_allocatable_storage_suggestions([source], [], suggest_dir)
            candidate = next(item for item in result.candidates if item.storage_scope == "local")
            selection = json.loads(
                (suggest_dir / "allocatable_storage_selection.json").read_text(encoding="utf-8")
            )
            selection["reviewed"] = True
            selection["selections"] = [{
                "candidate_id": candidate.candidate_id,
                "confirmed_entry_allocation": False,
                "confirmed_regression_gate": True,
            }]
            selection_path = root / "selection.json"
            selection_path.write_text(json.dumps(selection, indent=2) + "\n", encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "confirmed_entry_allocation"):
                write_allocatable_storage_plan([source], [], selection_path, root / "plan")


if __name__ == "__main__":
    unittest.main()
