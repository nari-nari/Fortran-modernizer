import json
import struct
import tempfile
import unittest
from pathlib import Path

from fortran_refactor.project import load_project_config
from fortran_refactor.project_assessment import run_configured_regression
from fortran_refactor.regression_compare import (
    RegressionComparisonError,
    compare_regression_files,
    write_regression_report,
)


class RegressionCompareTest(unittest.TestCase):
    def test_text_array_reports_field_metrics_and_failure_indexes(self):
        with tempfile.TemporaryDirectory() as tmp_dir:
            root = Path(tmp_dir)
            reference = root / "reference.dat"
            actual = root / "actual.dat"
            reference.write_text("1.0 2.0 3.0\n4.0 5.0 6.0\n", encoding="utf-8")
            actual.write_text("1.0 2.0 3.0\n4.0 5.00001 6.0\n", encoding="utf-8")

            failed = compare_regression_files(
                reference,
                actual,
                {"mode": "numeric-array-text", "atol": 1.0e-8, "rtol": 0.0},
            )
            self.assertEqual(failed["status"], "failed")
            self.assertEqual(failed["reference_shape"], [2, 3])
            self.assertEqual(failed["failed_elements"], 1)
            self.assertEqual(failed["failures"][0]["index"], [1, 1])
            self.assertAlmostEqual(failed["max_absolute_error"], 1.0e-5, places=12)

            passed = compare_regression_files(
                reference,
                actual,
                {"mode": "numeric-array-text", "atol": 2.0e-5, "rtol": 0.0},
            )
            self.assertEqual(passed["status"], "pass")
            self.assertEqual(passed["failed_elements"], 0)

    def test_text_adapter_accepts_fortran_exponents_comments_columns_and_shape(self):
        with tempfile.TemporaryDirectory() as tmp_dir:
            root = Path(tmp_dir)
            reference = root / "reference.csv"
            actual = root / "actual.csv"
            content = "header a,b,c\n0,1.0D0,2.0D0 # first\n1,3.0D0,4.0D0\n"
            reference.write_text(content, encoding="utf-8")
            actual.write_text(content.replace("4.0D0", "4.0000000001D0"), encoding="utf-8")
            result = compare_regression_files(
                reference,
                actual,
                {
                    "mode": "numeric-array-text",
                    "skip_rows": 1,
                    "delimiter": ",",
                    "columns": [1, 2],
                    "shape": [2, 2],
                    "atol": 1.0e-9,
                    "rtol": 0.0,
                },
            )
            self.assertEqual(result["status"], "pass")
            self.assertEqual(result["reference_shape"], [2, 2])
            self.assertEqual(result["reference_metadata"]["selected_columns"], [1, 2])

    def test_json_adapter_selects_nested_rectangular_field(self):
        with tempfile.TemporaryDirectory() as tmp_dir:
            root = Path(tmp_dir)
            reference = root / "reference.json"
            actual = root / "actual.json"
            reference.write_text(json.dumps({"result": {"pressure": [[1.0, 2.0], [3.0, 4.0]]}}), encoding="utf-8")
            actual.write_text(json.dumps({"result": {"pressure": [[1.0, 2.0], [3.0, 4.0]]}}), encoding="utf-8")
            result = compare_regression_files(
                reference,
                actual,
                {"mode": "numeric-array-json", "json_path": "result.pressure"},
            )
            self.assertEqual(result["status"], "pass")
            self.assertEqual(result["reference_shape"], [2, 2])
            self.assertEqual(result["reference_metadata"]["json_path"], "result.pressure")

    def test_raw_binary_adapter_compares_float32_with_explicit_shape(self):
        with tempfile.TemporaryDirectory() as tmp_dir:
            root = Path(tmp_dir)
            reference = root / "reference.bin"
            actual = root / "actual.bin"
            values = [1.0, 2.0, 3.0, 4.0]
            reference.write_bytes(struct.pack("<4f", *values))
            actual.write_bytes(struct.pack("<4f", *values))
            result = compare_regression_files(
                reference,
                actual,
                {
                    "mode": "numeric-array-binary",
                    "dtype": "float32",
                    "endian": "little",
                    "shape": [2, 2],
                },
            )
            self.assertEqual(result["status"], "pass")
            self.assertEqual(result["reference_shape"], [2, 2])
            self.assertEqual(result["reference_metadata"]["dtype"], "float32")

    def test_fortran_sequential_record_adapter_validates_record_markers(self):
        with tempfile.TemporaryDirectory() as tmp_dir:
            root = Path(tmp_dir)
            reference = root / "reference.unf"
            actual = root / "actual.unf"

            def record(values):
                payload = struct.pack("<" + "d" * len(values), *values)
                marker = struct.pack("<I", len(payload))
                return marker + payload + marker

            content = record([1.0, 2.0]) + record([3.0, 4.0])
            reference.write_bytes(content)
            actual.write_bytes(content)
            result = compare_regression_files(
                reference,
                actual,
                {
                    "mode": "numeric-array-fortran-record",
                    "dtype": "float64",
                    "endian": "little",
                    "record_marker_bytes": 4,
                    "shape": [2, 2],
                },
            )
            self.assertEqual(result["status"], "pass")
            self.assertEqual(result["reference_metadata"]["records"], 2)
            self.assertEqual(result["reference_metadata"]["record_payload_bytes"], [16, 16])
            changed = root / "changed.unf"
            changed.write_bytes(record([1.0, 2.0]) + record([3.1, 4.0]))
            changed_result = compare_regression_files(
                reference,
                changed,
                {
                    "mode": "numeric-array-fortran-record",
                    "dtype": "float64",
                    "endian": "little",
                    "record_marker_bytes": 4,
                    "shape": [2, 2],
                    "atol": 0.0,
                    "rtol": 0.0,
                },
            )
            self.assertEqual(changed_result["status"], "failed")
            self.assertEqual(changed_result["index_order"], "fortran")
            self.assertEqual(changed_result["max_absolute_error_index"], [0, 1])

            broken = root / "broken.unf"
            broken.write_bytes(content[:-1] + b"\x01")
            with self.assertRaises(RegressionComparisonError):
                compare_regression_files(
                    reference,
                    broken,
                    {
                        "mode": "numeric-array-fortran-record",
                        "dtype": "float64",
                        "endian": "little",
                    },
                )

    def test_history_adapter_compares_iteration_labels_and_residual_columns(self):
        with tempfile.TemporaryDirectory() as tmp_dir:
            root = Path(tmp_dir)
            reference = root / "reference.hist"
            actual = root / "actual.hist"
            reference.write_text("0 1.0 10.0\n1 0.1 9.0\n2 0.01 8.0\n", encoding="utf-8")
            actual.write_text("0 1.0 10.0\n1 0.10000000001 9.0\n2 0.01 8.0\n", encoding="utf-8")
            result = compare_regression_files(
                reference,
                actual,
                {
                    "mode": "numeric-history",
                    "iteration_column": 0,
                    "value_columns": [1],
                    "atol": 1.0e-9,
                    "rtol": 0.0,
                },
            )
            self.assertEqual(result["status"], "pass")
            self.assertTrue(result["iteration_labels_equal"])
            self.assertEqual(result["reference_iterations"], 3)
            self.assertEqual(result["reference_final_values"], [0.01])

            actual.write_text("0 1.0 10.0\n2 0.1 9.0\n3 0.01 8.0\n", encoding="utf-8")
            mismatch = compare_regression_files(
                reference,
                actual,
                {"mode": "numeric-history", "value_columns": [1]},
            )
            self.assertEqual(mismatch["status"], "failed")
            self.assertFalse(mismatch["iteration_labels_equal"])
            self.assertEqual(mismatch["iteration_mismatch"]["index"], 1)


    def test_numeric_key_value_keeps_legacy_extra_key_compatibility(self):
        with tempfile.TemporaryDirectory() as tmp_dir:
            root = Path(tmp_dir)
            reference = root / "reference.out"
            actual = root / "actual.out"
            reference.write_text("LOAD = 1.0D0\n", encoding="utf-8")
            actual.write_text("load = 1.0D0\nextra = 2.0D0\n", encoding="utf-8")
            compatible = compare_regression_files(
                reference,
                actual,
                {"mode": "numeric-key-value"},
            )
            self.assertEqual(compatible["status"], "pass")
            self.assertEqual(compatible["unexpected_keys"], ["extra"])
            strict = compare_regression_files(
                reference,
                actual,
                {"mode": "numeric-key-value", "allow_extra_keys": False},
            )
            self.assertEqual(strict["status"], "failed")
            self.assertEqual(strict["failed_keys"], 1)

    def test_report_writer_creates_json_and_markdown(self):
        with tempfile.TemporaryDirectory() as tmp_dir:
            root = Path(tmp_dir)
            reference = root / "reference.dat"
            actual = root / "actual.dat"
            reference.write_text("1 2 3\n", encoding="utf-8")
            actual.write_text("1 2 3\n", encoding="utf-8")
            output = root / "report"
            result = write_regression_report(
                reference,
                actual,
                {"mode": "numeric-array-text"},
                output,
            )
            self.assertEqual(result["status"], "pass")
            self.assertTrue((output / "comparison.json").is_file())
            self.assertTrue((output / "comparison.md").is_file())
            self.assertIn("PASS", (output / "comparison.md").read_text(encoding="utf-8"))

    def test_project_pipeline_uses_rich_comparison_adapter(self):
        with tempfile.TemporaryDirectory() as tmp_dir:
            root = Path(tmp_dir)
            (root / "dummy.f90").write_text("program dummy\nend program dummy\n", encoding="utf-8")
            (root / "reference.dat").write_text("1 2\n3 4\n", encoding="utf-8")
            (root / "actual.dat").write_text("1 2\n3 4.0000001\n", encoding="utf-8")
            config = {
                "schema_version": 1,
                "project": {"name": "regression", "root": "."},
                "sources": {"paths": ["dummy.f90"], "include_globs": ["**/*.f90"], "exclude_globs": []},
                "fortran": {"include_dirs": [], "fixed_line_length": 72},
                "compiler": {"enabled": False},
                "regression": {
                    "enabled": True,
                    "working_directory": ".",
                    "build_commands": [],
                    "run_commands": [],
                    "comparisons": [
                        {
                            "mode": "numeric-array-text",
                            "reference": "reference.dat",
                            "actual": "actual.dat",
                            "atol": 1.0e-6,
                            "rtol": 0.0,
                        }
                    ],
                },
                "assessment": {"performance_budget_seconds": 60.0},
            }
            config_path = root / "fortran-refactor.json"
            config_path.write_text(json.dumps(config), encoding="utf-8")
            project = load_project_config(config_path)
            result = run_configured_regression(project, root / "reports")
            self.assertEqual(result["status"], "pass")
            self.assertEqual(result["comparisons"][0]["reference_shape"], [2, 2])
            self.assertEqual(result["comparisons"][0]["failed_elements"], 0)


if __name__ == "__main__":
    unittest.main()
