import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import fortran_refactor.extract as extract_module
from fortran_refactor.diagnostics import build_analysis_result
from fortran_refactor.models import ParseResult
from fortran_refactor.reporting import write_reports
from fortran_refactor.source import split_program_units


class ReportingTest(unittest.TestCase):
    @patch.object(
        extract_module,
        "parse_with_fparser",
        side_effect=lambda unit, include_dirs: ParseResult(True, "test-parser", None, 1),
    )
    def test_report_bundle_is_written(self, _mock_parser):
        source = Path("samples/diagnostic_fixtures/common_type_mismatch.for").resolve()
        units = [extract_module.analyze_unit(unit, []) for unit in split_program_units(source)]
        result = build_analysis_result(units)
        with tempfile.TemporaryDirectory() as tmp_dir:
            output = Path(tmp_dir) / "reports"
            write_reports(result, output)
            expected = {
                "summary.md",
                "analysis.json",
                "parseability.csv",
                "program_units.csv",
                "variables.csv",
                "common_blocks.csv",
                "common_diagnostics.csv",
                "calls.csv",
                "procedure_signatures.csv",
                "call_diagnostics.csv",
                "implicit_symbols.csv",
                "typo_candidates.csv",
                "call_graph.dot",
            }
            self.assertLessEqual(expected, {path.name for path in output.iterdir()})
            payload = json.loads((output / "analysis.json").read_text(encoding="utf-8"))
            self.assertEqual(len(payload["units"]), 2)


if __name__ == "__main__":
    unittest.main()
