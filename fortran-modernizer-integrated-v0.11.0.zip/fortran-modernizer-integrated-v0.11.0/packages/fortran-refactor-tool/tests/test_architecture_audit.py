from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path

from fortran_refactor.architecture_audit import write_architecture_audit


class ArchitectureAuditTest(unittest.TestCase):
    @property
    def fixture_root(self) -> Path:
        return Path(__file__).resolve().parents[1] / "samples" / "architecture_fixtures"

    def test_classifies_kernel_io_and_shared_state(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            audit = write_architecture_audit([self.fixture_root], [], Path(temp))
            by_name = {item.program_unit: item for item in audit.units}

            kernel = by_name["pressure_kernel"]
            self.assertEqual(kernel.role, "numerical-kernel")
            self.assertEqual(kernel.io_statements, 0)
            self.assertGreaterEqual(kernel.state_isolation, 90)
            self.assertGreaterEqual(kernel.testability, 80)
            self.assertTrue(any(item["program_unit"] == "pressure_kernel" and item["status"] == "review-candidate" for item in audit.kernel_candidates))

            reader = by_name["read_case"]
            self.assertEqual(reader.role, "input-output")
            self.assertGreater(reader.io_statements, 0)
            self.assertIn("embedded I/O", reader.blockers)

            legacy = by_name["legacy_step"]
            self.assertEqual(legacy.risk, "high")
            self.assertIn("shared-state write", legacy.blockers)
            self.assertIn("SAVE state", legacy.blockers)
            self.assertLess(legacy.reentrancy, 50)

    def test_detects_fixed_form_array_write_to_common(self) -> None:
        source = """      SUBROUTINE STEP(A)
      IMPLICIT NONE
      DOUBLE PRECISION A,P(2)
      COMMON /FIELD/ P
      P(1)=A
      END
"""
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            path = root / "step.for"
            path.write_text(source, encoding="utf-8")
            audit = write_architecture_audit([path], [], root / "report")
            unit = audit.units[0]
            self.assertEqual(unit.shared_state_writes, 1)
            self.assertIn("shared-state write", unit.blockers)

    def test_writes_non_modifying_evidence_bundle(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            output = Path(temp)
            before = {path: path.read_bytes() for path in self.fixture_root.glob("*.f90")}
            write_architecture_audit([self.fixture_root], [], output)
            for name in (
                "architecture_units.csv",
                "kernel_candidates.csv",
                "public_interface_candidates.csv",
                "state_dependencies.csv",
                "io_dependencies.csv",
                "side_effects.csv",
                "call_graph.csv",
                "call_graph.dot",
                "architecture_audit.json",
                "architecture_audit.md",
            ):
                self.assertTrue((output / name).is_file(), name)
            payload = json.loads((output / "architecture_audit.json").read_text(encoding="utf-8"))
            self.assertIn("scope_note", payload["summary"])
            self.assertEqual(before, {path: path.read_bytes() for path in self.fixture_root.glob("*.f90")})
            report = (output / "architecture_audit.md").read_text(encoding="utf-8")
            self.assertIn("does not translate code", report)
            self.assertIn("ordinary Fortran", report)


if __name__ == "__main__":
    unittest.main()
