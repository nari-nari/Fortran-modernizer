from __future__ import annotations

import json
import shutil
import subprocess
import tempfile
import unittest
from pathlib import Path

from fortran_refactor.apply import apply_plan
from fortran_refactor.fixed_to_free import FixedToFreeError, write_fixed_to_free_plan


class FixedToFreeTest(unittest.TestCase):
    @property
    def project_root(self) -> Path:
        return Path(__file__).resolve().parents[1]

    @property
    def fixture(self) -> Path:
        return self.project_root / "samples" / "legacy_runnable"

    def test_conversion_plan_and_apply_preserve_program(self) -> None:
        if shutil.which("findent") is None or shutil.which("gfortran") is None:
            self.skipTest("findent and gfortran are required for conversion integration")
        with tempfile.TemporaryDirectory() as temp:
            base = Path(temp)
            source = base / "legacy_runnable"
            shutil.copytree(self.fixture, source)
            include_dir = source / "include"
            original_exe = base / "original"
            original_compile = subprocess.run(
                [
                    "gfortran", "-std=legacy", "-ffixed-line-length-72",
                    "-I", str(include_dir), str(source / "journal_bearing_legacy.for"),
                    "-o", str(original_exe),
                ],
                capture_output=True, text=True, check=False,
            )
            self.assertEqual(original_compile.returncode, 0, original_compile.stderr)
            original_output = subprocess.run(
                [str(original_exe)], capture_output=True, text=True, check=True
            ).stdout

            plan = base / "plan"
            suggestions = write_fixed_to_free_plan(
                [source], [include_dir], plan, input_line_length=72
            )
            self.assertEqual(len(suggestions), 1)
            self.assertEqual(suggestions[0].safety, "approval-required", suggestions[0].rationale)
            receipt = apply_plan(
                plan,
                base / "applied",
                selected_ids={"F2F-0001"},
                all_automatic=False,
                approve_review=True,
                include_dirs=[include_dir],
                run_compile_check=True,
            )
            transformed = Path(receipt["transformed_root"])
            self.assertFalse((transformed / "journal_bearing_legacy.for").exists())
            free_source = transformed / "journal_bearing_legacy.f90"
            self.assertTrue(free_source.is_file())
            self.assertIn("&", free_source.read_text(encoding="utf-8"))
            self.assertTrue(receipt["fixed_to_free_verification"])

            converted_exe = base / "converted"
            converted_compile = subprocess.run(
                [
                    "gfortran", "-std=legacy", "-I", str(transformed / "include"),
                    str(free_source), "-o", str(converted_exe),
                ],
                capture_output=True, text=True, check=False,
            )
            self.assertEqual(converted_compile.returncode, 0, converted_compile.stderr)
            converted_output = subprocess.run(
                [str(converted_exe)], capture_output=True, text=True, check=True
            ).stdout
            self.assertEqual(converted_output, original_output)

            mapping = (plan / "source_mapping.csv").read_text(encoding="utf-8")
            self.assertIn("journal_bearing_legacy.f90", mapping)
            manifest = json.loads((plan / "manifest.json").read_text(encoding="utf-8"))
            self.assertEqual(manifest["kind"], "fixed-to-free-plan")

    def test_external_include_is_blocked(self) -> None:
        if shutil.which("findent") is None:
            self.skipTest("findent unavailable")
        with tempfile.TemporaryDirectory() as temp:
            base = Path(temp)
            source = base / "src"
            external = base / "external"
            source.mkdir()
            external.mkdir()
            (external / "x.inc").write_text("      INTEGER X\n", encoding="utf-8")
            (source / "main.for").write_text(
                "      PROGRAM X\n      INCLUDE 'x.inc'\n      END\n", encoding="utf-8"
            )
            suggestions = write_fixed_to_free_plan(
                [source], [external], base / "plan"
            )
            self.assertEqual(suggestions[0].safety, "blocked")
            self.assertIn("outside the selected source root", suggestions[0].rationale)

    def test_invalid_extension_is_rejected(self) -> None:
        if shutil.which("findent") is None:
            self.skipTest("findent unavailable")
        with self.assertRaises(FixedToFreeError):
            write_fixed_to_free_plan([self.fixture], [], Path("unused"), output_extension="f90")


if __name__ == "__main__":
    unittest.main()
