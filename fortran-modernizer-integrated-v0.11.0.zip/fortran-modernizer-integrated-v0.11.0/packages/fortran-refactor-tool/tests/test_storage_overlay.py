from __future__ import annotations

import csv
import json
import shutil
import subprocess
import tempfile
import unittest
from pathlib import Path

from fortran_refactor.apply import apply_plan
from fortran_refactor.extract import analyze_unit
from fortran_refactor.source import split_program_units
from fortran_refactor.storage_overlay import write_storage_overlay_plan


class StorageOverlayTest(unittest.TestCase):
    @property
    def fixture_dir(self) -> Path:
        return Path(__file__).resolve().parents[1] / "samples" / "storage_overlay"

    def test_equivalence_is_extracted_from_ast(self) -> None:
        unit = analyze_unit(split_program_units(self.fixture_dir / "equivalence_overlay.for", [])[0], [])
        self.assertTrue(unit.parse.success)
        self.assertEqual(len(unit.equivalence_objects), 6)
        first = unit.equivalence_objects[0]
        self.assertEqual(first.base_name, "d")
        self.assertEqual(first.subscripts, ("1",))
        self.assertEqual(unit.parse.fallback_fact_count, 0)

    def test_plan_reports_byte_offsets_and_type_punning(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            output = Path(temp) / "plan"
            write_storage_overlay_plan([self.fixture_dir], [], output)
            with (output / "overlap_regions.csv").open(encoding="utf-8") as handle:
                rows = list(csv.DictReader(handle))
            classifications = {row["classification"] for row in rows}
            self.assertIn("exact-type-punning", classifications)
            self.assertTrue((output / "storage_layout.csv").is_file())
            self.assertTrue((output / "equivalence_sets.csv").is_file())
            report = (output / "storage_overlay_report.md").read_text(encoding="utf-8")
            self.assertIn("analysis-first", report)

    def test_compatible_blank_common_can_be_named_and_applied(self) -> None:
        if shutil.which("gfortran") is None:
            self.skipTest("gfortran unavailable")
        with tempfile.TemporaryDirectory() as temp:
            base = Path(temp)
            source = base / "source"
            source.mkdir()
            shutil.copy2(self.fixture_dir / "blank_common.for", source / "blank_common.for")
            plan = base / "plan"
            suggestions = write_storage_overlay_plan([source], [], plan)
            self.assertEqual(suggestions[0].safety, "approval-required")
            receipt = apply_plan(
                plan,
                base / "applied",
                selected_ids={suggestions[0].id},
                all_automatic=False,
                approve_review=True,
                include_dirs=[],
                run_compile_check=True,
            )
            transformed = Path(receipt["transformed_root"])
            text = (transformed / "blank_common.for").read_text(encoding="utf-8").lower()
            self.assertEqual(text.count("common /frt_blank_common/"), 2)
            exe = base / "demo"
            completed = subprocess.run(
                ["gfortran", "-std=legacy", str(transformed / "blank_common.for"), "-o", str(exe)],
                capture_output=True,
                text=True,
                check=False,
            )
            self.assertEqual(completed.returncode, 0, completed.stderr)
            run = subprocess.run([str(exe)], capture_output=True, text=True, check=False)
            self.assertEqual(run.returncode, 0, run.stderr)
            self.assertIn("13.000", run.stdout)

    def test_blank_common_with_equivalence_is_blocked(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            source = Path(temp) / "source"
            source.mkdir()
            (source / "x.for").write_text(
                "      SUBROUTINE X\n"
                "      DOUBLE PRECISION A,B\n"
                "      COMMON A,B\n"
                "      EQUIVALENCE (A,B)\n"
                "      END\n",
                encoding="utf-8",
            )
            suggestions = write_storage_overlay_plan([source], [], Path(temp) / "plan")
            self.assertEqual(suggestions[0].safety, "blocked")
            self.assertIn("equivalence touches", suggestions[0].rationale.lower())

    def test_partial_overlap_maps_byte_and_element_ranges(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            source = root / "partial.f90"
            source.write_text(
                """program partial
  implicit none
  real :: a(10), b(10), value
  equivalence (a(3), b(1))
  a = 0.0
  b(1) = 2.0
  value = a(3) + b(2)
  print *, value
end program partial
""",
                encoding="utf-8",
            )
            output = root / "plan"
            write_storage_overlay_plan([source], [], output)
            payload = json.loads(
                (output / "partial_overlap_candidates.json").read_text(encoding="utf-8")
            )
            self.assertEqual(payload["candidate_count"], 1)
            candidate = payload["candidates"][0]
            self.assertEqual(candidate["status"], "analysis-only")
            self.assertEqual(candidate["review_readiness"], "mapped")
            self.assertEqual(candidate["overlap_bytes"], 32)
            self.assertEqual(candidate["relationship"], "left-tail-overlaps-right-head")
            self.assertEqual(candidate["left_storage"]["overlap_linear_element_start"], 3)
            self.assertEqual(candidate["left_storage"]["overlap_linear_element_end"], 10)
            self.assertEqual(candidate["left_storage"]["overlap_fortran_index_start"], [3])
            self.assertEqual(candidate["right_storage"]["overlap_linear_element_start"], 1)
            self.assertEqual(candidate["right_storage"]["overlap_linear_element_end"], 8)
            self.assertEqual(candidate["simultaneous_reference_lines"], [7])
            self.assertTrue((output / "partial_overlap_candidates.csv").is_file())
            self.assertIn("Analysis-only", (output / "partial_overlap_candidates.md").read_text(encoding="utf-8"))

    def test_partial_overlap_maps_multidimensional_fortran_indices(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            source = root / "partial_2d.f90"
            source.write_text(
                """subroutine partial_2d(value)
  implicit none
  real, intent(out) :: value
  real :: a(2:3,4:5), b(2,2)
  equivalence (a(2,5), b(1,1))
  a = 1.0
  value = sum(b)
end subroutine partial_2d
""",
                encoding="utf-8",
            )
            output = root / "plan"
            write_storage_overlay_plan([source], [], output)
            candidate = json.loads(
                (output / "partial_overlap_candidates.json").read_text(encoding="utf-8")
            )["candidates"][0]
            self.assertEqual(candidate["overlap_bytes"], 8)
            self.assertEqual(candidate["left_storage"]["overlap_fortran_index_start"], [2, 5])
            self.assertEqual(candidate["left_storage"]["overlap_fortran_index_end"], [3, 5])
            self.assertEqual(candidate["right_storage"]["overlap_fortran_index_start"], [1, 1])
            self.assertEqual(candidate["right_storage"]["overlap_fortran_index_end"], [2, 1])

    def test_partial_overlap_records_common_and_transitive_evidence(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            source = root / "partial_chain.f90"
            source.write_text(
                """subroutine partial_chain(value)
  implicit none
  real, intent(out) :: value
  integer :: flag
  real :: a(6), b(6), c(6)
  common /state/ flag, a
  equivalence (a(3), b(1)), (b(3), c(1))
  a = 0.0
  c(1) = 4.0
  value = a(5)
end subroutine partial_chain
""",
                encoding="utf-8",
            )
            output = root / "plan"
            write_storage_overlay_plan([source], [], output)
            candidates = json.loads(
                (output / "partial_overlap_candidates.json").read_text(encoding="utf-8")
            )["candidates"]
            by_pair = {frozenset((item["left"], item["right"])): item for item in candidates}
            ab = by_pair[frozenset(("a", "b"))]
            self.assertEqual(ab["left_storage"]["common_block"], "state")
            self.assertEqual(ab["left_storage"]["common_position"], 2)
            self.assertEqual(ab["left_storage"]["common_packed_offset_bytes"], 4)
            ac = by_pair[frozenset(("a", "c"))]
            self.assertTrue(ac["transitive_association"] )
            self.assertEqual(ac["direct_equivalence_sets"], [])

    def test_partial_type_punning_mid_element_is_needs_manual_proof(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            source = root / "misaligned.for"
            source.write_text(
                """      SUBROUTINE MISALIGNED
      DOUBLE PRECISION D(2)
      INTEGER I(4)
      EQUIVALENCE (D(2),I(2))
      D(1)=1.0D0
      RETURN
      END
""",
                encoding="utf-8",
            )
            output = root / "plan"
            write_storage_overlay_plan([source], [], output)
            candidate = json.loads(
                (output / "partial_overlap_candidates.json").read_text(encoding="utf-8")
            )["candidates"][0]
            self.assertEqual(candidate["classification"], "partial-incompatible-overlap")
            self.assertEqual(candidate["review_readiness"], "needs-manual-proof")
            self.assertFalse(candidate["left_storage"]["element_aligned"] )
            self.assertIn("overlap starts or ends inside an array element", candidate["blockers"])
            self.assertIn("storage-incompatible", " ".join(candidate["blockers"]))


    def test_mapped_partial_overlap_emits_three_analysis_only_design_options(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            output = Path(temp) / "plan"
            write_storage_overlay_plan([self.fixture_dir], [], output)
            payload = json.loads(
                (output / "partial_overlap_migration_options.json").read_text(encoding="utf-8")
            )
            self.assertEqual(payload["status"], "analysis-only")
            self.assertGreaterEqual(payload["design_count"], 2)
            by_unit = {item["program_unit"]: item for item in payload["designs"]}
            design = by_unit["partial_overlap_demo"]
            self.assertEqual(design["preferred_option"], "canonical-workspace")
            self.assertEqual(
                {item["option_id"] for item in design["options"]},
                {"canonical-workspace", "synchronized-copies", "derived-storage-type"},
            )
            canonical = next(item for item in design["options"] if item["option_id"] == "canonical-workspace")
            self.assertEqual(canonical["storage_model"]["union_elements"], 12)
            self.assertEqual(canonical["storage_model"]["left_element_offset_zero_based"], 0)
            self.assertEqual(canonical["storage_model"]["right_element_offset_zero_based"], 2)
            copies = next(item for item in design["options"] if item["option_id"] == "synchronized-copies")
            self.assertEqual(copies["status"], "not-recommended")
            self.assertTrue((output / "partial_overlap_migration_options.csv").is_file())
            self.assertIn("Analysis-only", (output / "partial_overlap_migration_options.md").read_text(encoding="utf-8"))

    def test_common_or_transitive_overlap_prefers_derived_storage_type(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            source = root / "partial_chain.f90"
            source.write_text(
                """subroutine partial_chain(value)
  implicit none
  real, intent(out) :: value
  integer :: flag
  real :: a(6), b(6), c(6)
  common /state/ flag, a
  equivalence (a(3), b(1)), (b(3), c(1))
  a = 0.0
  c(1) = 4.0
  value = a(5)
end subroutine partial_chain
""",
                encoding="utf-8",
            )
            output = root / "plan"
            write_storage_overlay_plan([source], [], output)
            designs = json.loads(
                (output / "partial_overlap_migration_options.json").read_text(encoding="utf-8")
            )["designs"]
            self.assertTrue(designs)
            self.assertTrue(any(item["preferred_option"] == "derived-storage-type" for item in designs))
            common_design = next(item for item in designs if item["decision_factors"]["common_storage_touched"])
            derived = next(item for item in common_design["options"] if item["option_id"] == "derived-storage-type")
            self.assertEqual(derived["status"], "recommended")

    def test_canonical_workspace_contract_and_fixture_are_generated(self) -> None:
        if shutil.which("gfortran") is None:
            self.skipTest("gfortran unavailable")
        with tempfile.TemporaryDirectory() as temp:
            output = Path(temp) / "plan"
            write_storage_overlay_plan([self.fixture_dir], [], output)
            payload = json.loads(
                (output / "canonical_workspace_mapping_contracts.json").read_text(encoding="utf-8")
            )
            self.assertEqual(payload["status"], "analysis-only")
            by_unit = {item["program_unit"]: item for item in payload["contracts"]}
            contract = by_unit["partial_overlap_demo"]
            self.assertEqual(contract["workspace"]["element_count"], 12)
            views = {item["name"]: item for item in contract["views"]}
            self.assertEqual(views["a"]["workspace_start_one_based"], 1)
            self.assertEqual(views["a"]["workspace_end_one_based"], 10)
            self.assertEqual(views["b"]["workspace_start_one_based"], 3)
            self.assertEqual(views["b"]["workspace_end_one_based"], 12)
            self.assertEqual(contract["overlap"]["workspace_start_one_based"], 3)
            self.assertEqual(contract["overlap"]["workspace_end_one_based"], 10)
            self.assertEqual(contract["fixture_status"], "ready")
            fixture = output / contract["fixture"]["source"]
            self.assertTrue(fixture.is_file())
            executable = Path(temp) / "workspace_fixture"
            compile_run = subprocess.run(
                ["gfortran", str(fixture), "-o", str(executable)],
                capture_output=True, text=True, check=False,
            )
            self.assertEqual(compile_run.returncode, 0, compile_run.stderr)
            run = subprocess.run([str(executable)], capture_output=True, text=True, check=False)
            self.assertEqual(run.returncode, 0, run.stderr)
            self.assertIn(contract["fixture"]["expected_stdout"], run.stdout)

    def test_multidimensional_workspace_contract_preserves_column_major_mapping(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            output = Path(temp) / "plan"
            write_storage_overlay_plan([self.fixture_dir], [], output)
            payload = json.loads(
                (output / "canonical_workspace_mapping_contracts.json").read_text(encoding="utf-8")
            )
            contract = next(
                item for item in payload["contracts"]
                if item["program_unit"] == "partial_overlap_2d"
            )
            views = {item["name"]: item for item in contract["views"]}
            self.assertEqual(views["a"]["bounds"][0], {"source": "2 : 3", "lower": 2, "upper": 3, "extent": 2})
            self.assertEqual(views["a"]["bounds"][1]["lower"], 4)
            self.assertEqual(views["a"]["workspace_start_one_based"], 1)
            self.assertEqual(views["b"]["workspace_start_one_based"], 3)
            self.assertEqual(contract["overlap"]["left_fortran_index_start"], [2, 5])
            self.assertEqual(contract["overlap"]["right_fortran_index_start"], [1, 1])

    def test_scalar_common_or_transitive_contract_fixture_is_blocked(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            output = Path(temp) / "plan"
            write_storage_overlay_plan([self.fixture_dir], [], output)
            payload = json.loads(
                (output / "canonical_workspace_mapping_contracts.json").read_text(encoding="utf-8")
            )
            contract = next(
                item for item in payload["contracts"]
                if item["program_unit"] == "storage_overlay_sample"
            )
            self.assertEqual(contract["fixture_status"], "blocked")
            self.assertIn("standalone fixture requires two array views", contract["fixture_blockers"])
            self.assertIsNone(contract["fixture"]["source"])

    def test_equivalence_free_refactor_fixture_contains_module_and_accessors(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            output = Path(temp) / "plan"
            write_storage_overlay_plan([self.fixture_dir], [], output)
            payload = json.loads(
                (output / "canonical_workspace_refactor_fixtures.json").read_text(encoding="utf-8")
            )
            self.assertEqual(payload["status"], "synthetic-only")
            package = next(
                item for item in payload["packages"]
                if item["program_unit"] == "partial_overlap_demo"
            )
            self.assertEqual(package["status"], "ready")
            module_path = output / package["files"]["workspace_module"]
            refactored_path = output / package["files"]["refactored_program"]
            legacy_path = output / package["files"]["legacy_program"]
            module_text = module_path.read_text(encoding="utf-8").lower()
            refactored_text = refactored_path.read_text(encoding="utf-8").lower()
            legacy_text = legacy_path.read_text(encoding="utf-8").lower()
            self.assertNotIn("equivalence", module_text)
            self.assertNotIn("equivalence", refactored_text)
            self.assertIn("equivalence", legacy_text)
            self.assertIn("subroutine set_a", module_text)
            self.assertIn("function get_a", module_text)
            self.assertIn("subroutine set_a_linear", module_text)
            self.assertTrue((output / package["files"]["comparison_manifest"]).is_file())

    def test_equivalence_free_refactor_fixture_matches_legacy_stdout(self) -> None:
        if shutil.which("gfortran") is None:
            self.skipTest("gfortran unavailable")
        with tempfile.TemporaryDirectory() as temp:
            output = Path(temp) / "plan"
            write_storage_overlay_plan([self.fixture_dir], [], output)
            payload = json.loads(
                (output / "canonical_workspace_refactor_fixtures.json").read_text(encoding="utf-8")
            )
            ready = [item for item in payload["packages"] if item["status"] == "ready"]
            self.assertGreaterEqual(len(ready), 2)
            for package in ready:
                package_dir = output / "canonical_workspace_refactor_fixtures" / package["contract_id"]
                legacy_exe = package_dir / "legacy"
                refactored_exe = package_dir / "refactored"
                legacy_compile = subprocess.run(
                    ["gfortran", "legacy_equivalence_program.f90", "-o", str(legacy_exe)],
                    cwd=package_dir, capture_output=True, text=True, check=False,
                )
                self.assertEqual(legacy_compile.returncode, 0, legacy_compile.stderr)
                refactored_compile = subprocess.run(
                    [
                        "gfortran", "canonical_workspace_module.f90",
                        "refactored_workspace_program.f90", "-o", str(refactored_exe),
                    ],
                    cwd=package_dir, capture_output=True, text=True, check=False,
                )
                self.assertEqual(refactored_compile.returncode, 0, refactored_compile.stderr)
                legacy_run = subprocess.run(
                    [str(legacy_exe)], cwd=package_dir, capture_output=True, text=True, check=False
                )
                refactored_run = subprocess.run(
                    [str(refactored_exe)], cwd=package_dir, capture_output=True, text=True, check=False
                )
                self.assertEqual(legacy_run.returncode, 0, legacy_run.stderr)
                self.assertEqual(refactored_run.returncode, 0, refactored_run.stderr)
                self.assertEqual(legacy_run.stdout, refactored_run.stdout)

    def test_common_or_transitive_contract_blocks_equivalence_free_refactor_fixture(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            output = Path(temp) / "plan"
            write_storage_overlay_plan([self.fixture_dir], [], output)
            payload = json.loads(
                (output / "canonical_workspace_refactor_fixtures.json").read_text(encoding="utf-8")
            )
            blocked = next(
                item for item in payload["packages"]
                if item["program_unit"] == "storage_overlay_sample"
            )
            self.assertEqual(blocked["status"], "blocked")
            self.assertIsNone(blocked["files"]["workspace_module"] )
            self.assertTrue(blocked["blockers"] )

    def test_unmapped_partial_overlap_does_not_receive_migration_design(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            source = root / "misaligned.for"
            source.write_text(
                """      SUBROUTINE MISALIGNED
      DOUBLE PRECISION D(2)
      INTEGER I(4)
      EQUIVALENCE (D(2),I(2))
      D(1)=1.0D0
      RETURN
      END
""",
                encoding="utf-8",
            )
            output = root / "plan"
            write_storage_overlay_plan([source], [], output)
            payload = json.loads(
                (output / "partial_overlap_migration_options.json").read_text(encoding="utf-8")
            )
            self.assertEqual(payload["design_count"], 0)



if __name__ == "__main__":
    unittest.main()
