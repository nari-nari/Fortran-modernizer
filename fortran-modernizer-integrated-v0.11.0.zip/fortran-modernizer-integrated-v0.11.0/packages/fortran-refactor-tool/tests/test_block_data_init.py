from __future__ import annotations

import shutil
import subprocess
import tempfile
import unittest
from pathlib import Path

from fortran_refactor.apply import apply_plan
from fortran_refactor.block_data_init import write_block_data_initialization_plan
from fortran_refactor.source import split_program_units


class BlockDataInitializationTest(unittest.TestCase):
    @property
    def fixture_dir(self) -> Path:
        return Path(__file__).resolve().parents[1] / "samples" / "block_data_initialization"

    def test_named_block_data_is_split_and_planned(self) -> None:
        units = split_program_units(self.fixture_dir / "init.for", [])
        self.assertEqual(len(units), 1)
        self.assertEqual(units[0].kind, "block_data")
        self.assertEqual(units[0].name, "fluid_init")
        with tempfile.TemporaryDirectory() as temp:
            plan = Path(temp) / "plan"
            suggestions = write_block_data_initialization_plan([self.fixture_dir], [], plan)
            self.assertEqual(suggestions[0].safety, "approval-required")
            self.assertEqual(suggestions[0].details["expected_assignments"], 6)
            generated = suggestions[0].details["generated_files"][0]["content"].lower()
            self.assertIn("logical, save :: initialized", generated)
            self.assertIn("mu = 0.01d0", generated)
            self.assertIn("a(3) = 3.0d0", generated)
            patch = (plan / "proposed_changes.patch").read_text(encoding="utf-8").lower()
            self.assertIn("call initialize_legacy_block_data()", patch)
            self.assertIn("block data fluid_init migrated", patch)

    def test_apply_compiles_and_preserves_initialized_values(self) -> None:
        if shutil.which("gfortran") is None:
            self.skipTest("gfortran unavailable")
        with tempfile.TemporaryDirectory() as temp:
            base = Path(temp)
            source = base / "source"
            shutil.copytree(self.fixture_dir, source)
            plan = base / "plan"
            suggestions = write_block_data_initialization_plan([source], [], plan)
            receipt = apply_plan(
                plan,
                base / "applied",
                selected_ids={suggestions[0].id},
                all_automatic=False,
                approve_review=True,
                include_dirs=[],
                run_compile_check=True,
            )
            self.assertEqual(receipt["fparser_success"], receipt["fparser_program_units"])
            self.assertEqual(len(receipt["block_data_verification"]), 1)
            transformed = Path(receipt["transformed_root"])
            build = base / "build"
            build.mkdir()
            exe = build / "demo"
            completed = subprocess.run(
                [
                    "gfortran",
                    "-std=legacy",
                    "-ffixed-line-length-72",
                    str(transformed / "generated_initialization" / "legacy_block_data_initialization.f90"),
                    str(transformed / "init.for"),
                    str(transformed / "main.for"),
                    "-o",
                    str(exe),
                ],
                capture_output=True,
                text=True,
                check=False,
            )
            self.assertEqual(completed.returncode, 0, completed.stderr)
            run = subprocess.run([str(exe)], capture_output=True, text=True, check=False)
            self.assertEqual(run.returncode, 0, run.stderr)
            self.assertIn("859.010", run.stdout)

    def test_data_implied_do_is_blocked(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            source = Path(temp) / "source"
            source.mkdir()
            (source / "main.for").write_text(
                "      PROGRAM P\n"
                "      INTEGER A(3)\n"
                "      COMMON /C/ A\n"
                "      WRITE(*,*) A(1)\n"
                "      END\n",
                encoding="utf-8",
            )
            (source / "init.for").write_text(
                "      BLOCK DATA B\n"
                "      INTEGER I,A(3)\n"
                "      COMMON /C/ A\n"
                "      DATA (A(I),I=1,3) /1,2,3/\n"
                "      END\n",
                encoding="utf-8",
            )
            suggestions = write_block_data_initialization_plan([source], [], Path(temp) / "plan")
            self.assertEqual(suggestions[0].safety, "blocked")
            self.assertIn("implied-do", suggestions[0].rationale.lower())

    def test_duplicate_initialization_is_blocked(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            source = Path(temp) / "source"
            source.mkdir()
            (source / "main.for").write_text(
                "      PROGRAM P\n"
                "      INTEGER A\n"
                "      COMMON /C/ A\n"
                "      WRITE(*,*) A\n"
                "      END\n",
                encoding="utf-8",
            )
            for name, value in (("B1", 1), ("B2", 2)):
                (source / f"{name}.for").write_text(
                    f"      BLOCK DATA {name}\n"
                    "      INTEGER A\n"
                    "      COMMON /C/ A\n"
                    f"      DATA A /{value}/\n"
                    "      END\n",
                    encoding="utf-8",
                )
            suggestions = write_block_data_initialization_plan([source], [], Path(temp) / "plan")
            self.assertEqual(suggestions[0].safety, "blocked")
            self.assertIn("duplicate initialization", suggestions[0].rationale.lower())


if __name__ == "__main__":
    unittest.main()
