import tempfile
import unittest
from pathlib import Path
from subprocess import CompletedProcess
from unittest.mock import patch

from fortran_refactor.compiler import VerificationError, available_compiler_profiles, compile_check


class CompilerIsolationTest(unittest.TestCase):
    def _run_profile(self, profile: str):
        tmp = tempfile.TemporaryDirectory()
        root = Path(tmp.name)
        source = root / "sample.for"
        source.write_text("      PROGRAM DEMO\n      END\n", encoding="utf-8")
        output = root / "reports" / "compiler"
        patches = (
            patch("fortran_refactor.compiler.shutil.which", return_value="/usr/bin/gfortran"),
            patch(
                "fortran_refactor.compiler.subprocess.run",
                return_value=CompletedProcess(args=[], returncode=0, stdout="", stderr=""),
            ),
        )
        first = patches[0].start()
        run = patches[1].start()
        self.addCleanup(patches[1].stop)
        self.addCleanup(patches[0].stop)
        self.addCleanup(tmp.cleanup)
        result = compile_check([source.resolve()], [], output.resolve(), profile=profile)
        return result, run, output.resolve()

    def test_compile_check_runs_in_output_directory_to_avoid_stale_mod_shadowing(self):
        result, run, output = self._run_profile("standard")
        self.assertEqual(result["returncode"], 0)
        self.assertEqual(run.call_args.kwargs["cwd"], output)

    def test_absoft_profile_uses_compatibility_flags_without_fixed_72_override(self):
        result, run, _ = self._run_profile("absoft-compat")
        command = run.call_args.args[0]
        self.assertEqual(result["mode"], "syntax")
        self.assertIn("-fdec", command)
        self.assertIn("-fdollar-ok", command)
        self.assertIn("-fdec-structure", command)
        self.assertIn("-ffixed-line-length-none", command)
        self.assertNotIn("-ffixed-line-length-72", command)
        self.assertIn("-fsyntax-only", command)

    def test_uninitialized_profiles_compile_objects(self):
        warning, warning_run, _ = self._run_profile("uninitialized-warning")
        warning_command = warning_run.call_args.args[0]
        self.assertEqual(warning["mode"], "object")
        self.assertIn("-Wmaybe-uninitialized", warning_command)
        self.assertIn("-c", warning_command)
        self.assertNotIn("-fsyntax-only", warning_command)

        poison, poison_run, _ = self._run_profile("uninitialized-poison")
        poison_command = poison_run.call_args.args[0]
        self.assertIn("-finit-real=snan", poison_command)
        self.assertIn("-ffpe-trap=invalid,zero,overflow", poison_command)
        self.assertIn("-c", poison_command)

    def test_unknown_profile_is_rejected(self):
        with tempfile.TemporaryDirectory() as tmp_dir, patch(
            "fortran_refactor.compiler.shutil.which", return_value="/usr/bin/gfortran"
        ):
            source = Path(tmp_dir) / "sample.f90"
            source.write_text("program demo\nend program demo\n", encoding="utf-8")
            with self.assertRaises(VerificationError):
                compile_check([source], [], Path(tmp_dir) / "out", profile="missing")

    def test_profile_catalog_is_defensive_copy(self):
        profiles = available_compiler_profiles()
        profiles["standard"]["flags"].append("-broken")
        self.assertNotIn("-broken", available_compiler_profiles()["standard"]["flags"])


if __name__ == "__main__":
    unittest.main()
