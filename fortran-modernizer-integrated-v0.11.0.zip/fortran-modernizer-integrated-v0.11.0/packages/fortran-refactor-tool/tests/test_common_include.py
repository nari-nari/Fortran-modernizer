import json
import shutil
import tempfile
import unittest
from pathlib import Path

from fortran_refactor.apply import ApplyError, apply_plan
from fortran_refactor.common_include import write_common_include_plan
from fortran_refactor.diagnostics import build_analysis_result
from fortran_refactor.extract import analyze_unit
from fortran_refactor.source import split_program_units


class CommonIncludePlanTest(unittest.TestCase):
    def _analyze_files(self, files: list[Path], include_dirs: list[Path]):
        return build_analysis_result(
            [
                analyze_unit(unit, include_dirs)
                for source in files
                for unit in split_program_units(source)
            ]
        )

    def test_plan_normalizes_aliases_and_generates_include(self):
        source = Path("samples/legacy_runnable/journal_bearing_legacy.for").resolve()
        result = self._analyze_files([source], [source.parent / "include"])
        with tempfile.TemporaryDirectory() as tmp_dir:
            output = Path(tmp_dir) / "plan"
            suggestions = write_common_include_plan(result, output)
            self.assertEqual(len(suggestions), 1)
            item = suggestions[0]
            self.assertEqual(item.safety, "approval-required")
            names = [entry["name"] for entry in item.details["canonical_entries"]]
            self.assertEqual(names, ["p", "h", "theta"])
            self.assertEqual(
                item.details["aliases_by_program_unit"]["init_geometry"],
                {"press": "p", "film": "h", "angle": "theta"},
            )
            preview = output / "transformed_sources/journal_bearing_legacy.for"
            text = preview.read_text(encoding="utf-8").upper()
            self.assertIn("INCLUDE 'FIELD_COMMON.INC'", text)
            self.assertNotIn("COMMON /FIELD/ PRESS,FILM,ANGLE", text)
            self.assertIn("THETA(I)=", text)
            include = output / "transformed_sources/generated_common/field_common.inc"
            self.assertTrue(include.is_file())
            self.assertIn("COMMON /FIELD/ P", include.read_text(encoding="utf-8"))

    def test_layout_mismatch_is_blocked(self):
        source = Path("samples/diagnostic_fixtures/common_type_mismatch.for").resolve()
        result = self._analyze_files([source], [])
        with tempfile.TemporaryDirectory() as tmp_dir:
            suggestions = write_common_include_plan(result, Path(tmp_dir) / "plan")
            self.assertEqual(len(suggestions), 1)
            self.assertEqual(suggestions[0].safety, "blocked")
            self.assertIn("COMMON_", suggestions[0].rationale)

    def test_apply_requires_approval_and_verifies_generated_include(self):
        with tempfile.TemporaryDirectory() as tmp_dir:
            base = Path(tmp_dir)
            source_root = base / "source"
            shutil.copytree("samples/legacy_runnable", source_root)
            source = source_root / "journal_bearing_legacy.for"
            result = self._analyze_files([source], [source_root / "include"])
            plan = base / "plan"
            write_common_include_plan(result, plan)

            with self.assertRaises(ApplyError):
                apply_plan(
                    plan,
                    base / "unapproved",
                    selected_ids={"COM-0001"},
                    all_automatic=False,
                    approve_review=False,
                    include_dirs=[source_root / "include"],
                    run_compile_check=False,
                )

            receipt = apply_plan(
                plan,
                base / "applied",
                selected_ids={"COM-0001"},
                all_automatic=False,
                approve_review=True,
                include_dirs=[source_root / "include"],
                run_compile_check=True,
            )
            transformed = Path(receipt["transformed_root"])
            self.assertEqual(receipt["fparser_success"], receipt["fparser_program_units"])
            self.assertEqual(receipt["generated_files"], ["generated_common/field_common.inc"])
            self.assertTrue((transformed / "generated_common/field_common.inc").is_file())
            source_text = (transformed / "journal_bearing_legacy.for").read_text(encoding="utf-8").upper()
            self.assertNotIn("COMMON /FIELD/ PRESS,FILM,ANGLE", source_text)
            self.assertNotIn("PRESS(I,J)", source_text)
            manifest = json.loads((plan / "manifest.json").read_text(encoding="utf-8"))
            self.assertEqual(manifest["generated_include_dirs"], ["generated_common"])


if __name__ == "__main__":
    unittest.main()
