import json
import tempfile
import unittest
from pathlib import Path

from fortran_refactor.apply import ApplyError, apply_plan
from fortran_refactor.diagnostics import build_analysis_result
from fortran_refactor.extract import analyze_unit
from fortran_refactor.procedure_partition import write_procedure_partition_plan
from fortran_refactor.source import discover_fortran_files, split_program_units


class ProcedureModulePartitionTest(unittest.TestCase):
    def _analyze_tree(self, root: Path):
        return build_analysis_result(
            [
                analyze_unit(unit, [])
                for source in discover_fortran_files([root])
                for unit in split_program_units(source)
            ]
        )

    def _write_graph_sample(self, root: Path) -> Path:
        root.mkdir(parents=True, exist_ok=True)
        source = root / "graph.for"
        source.write_text(
            "      PROGRAM GRAPH_DEMO\n"
            "      IMPLICIT NONE\n"
            "      CALL ALPHA\n"
            "      CALL DELTA\n"
            "      END\n"
            "      SUBROUTINE ALPHA\n"
            "      IMPLICIT NONE\n"
            "      CALL BETA\n"
            "      END\n"
            "      SUBROUTINE BETA\n"
            "      IMPLICIT NONE\n"
            "      END\n"
            "      SUBROUTINE GAMMA\n"
            "      IMPLICIT NONE\n"
            "      CALL BETA\n"
            "      END\n"
            "      SUBROUTINE DELTA\n"
            "      IMPLICIT NONE\n"
            "      END\n",
            encoding="utf-8",
        )
        return source

    def test_partition_creates_multiple_modules_and_cross_module_use(self):
        with tempfile.TemporaryDirectory() as tmp_dir:
            base = Path(tmp_dir)
            source_root = base / "source"
            self._write_graph_sample(source_root)
            plan = base / "plan"
            items = write_procedure_partition_plan(
                self._analyze_tree(source_root),
                plan,
                max_procedures_per_module=2,
            )
            self.assertEqual(len(items), 1)
            item = items[0]
            self.assertEqual(item.safety, "approval-required")
            self.assertEqual(len(item.details["module_groups"]), 2)
            mapping = item.details["procedure_to_module"]
            self.assertEqual(mapping["alpha"], mapping["gamma"])
            self.assertEqual(mapping["beta"], mapping["delta"])
            self.assertNotEqual(mapping["alpha"], mapping["beta"])

            alpha_module = mapping["alpha"]
            beta_module = mapping["beta"]
            group = next(
                group for group in item.details["module_groups"]
                if group["module_name"] == alpha_module
            )
            self.assertEqual(group["dependencies"], {beta_module: ["beta"]})
            generated = (
                plan
                / "transformed_sources"
                / "generated_modules"
                / f"{alpha_module}.for"
            ).read_text(encoding="utf-8").lower()
            self.assertIn(f"use {beta_module}, only: beta", generated)
            main = (plan / "transformed_sources/graph.for").read_text(encoding="utf-8").lower()
            self.assertIn(f"use {alpha_module}, only: alpha", main)
            self.assertIn(f"use {beta_module}, only: delta", main)

            partition = json.loads((plan / "module_partition.json").read_text(encoding="utf-8"))
            self.assertEqual(len(partition["module_groups"]), 2)
            self.assertTrue((plan / "module_partition.csv").is_file())
            self.assertTrue((plan / "module_dependencies.dot").is_file())

    def test_apply_requires_approval_and_verifies_all_modules(self):
        with tempfile.TemporaryDirectory() as tmp_dir:
            base = Path(tmp_dir)
            source_root = base / "source"
            self._write_graph_sample(source_root)
            plan = base / "plan"
            write_procedure_partition_plan(
                self._analyze_tree(source_root),
                plan,
                max_procedures_per_module=2,
            )
            with self.assertRaises(ApplyError):
                apply_plan(
                    plan,
                    base / "unapproved",
                    selected_ids={"PART-0001"},
                    all_automatic=False,
                    approve_review=False,
                    include_dirs=[],
                    run_compile_check=False,
                )
            receipt = apply_plan(
                plan,
                base / "applied",
                selected_ids={"PART-0001"},
                all_automatic=False,
                approve_review=True,
                include_dirs=[],
                run_compile_check=True,
            )
            self.assertEqual(receipt["remaining_external_procedures"], [])
            self.assertEqual(receipt["missing_procedure_modules"], [])
            self.assertEqual(receipt["missing_explicit_uses"], [])
            self.assertEqual(receipt["compile_check"]["returncode"], 0)
            transformed = Path(receipt["transformed_root"])
            modules = [
                unit
                for source in discover_fortran_files([transformed])
                for unit in split_program_units(source)
                if unit.kind == "module"
            ]
            self.assertEqual(len(modules), 2)

    def test_recursive_scc_is_never_split(self):
        with tempfile.TemporaryDirectory() as tmp_dir:
            base = Path(tmp_dir)
            root = base / "source"
            root.mkdir()
            (root / "cycle.for").write_text(
                "      PROGRAM DEMO\n"
                "      IMPLICIT NONE\n"
                "      CALL START\n"
                "      END\n"
                "      SUBROUTINE START\n"
                "      IMPLICIT NONE\n"
                "      CALL LEFT\n"
                "      END\n"
                "      SUBROUTINE LEFT\n"
                "      IMPLICIT NONE\n"
                "      CALL RIGHT\n"
                "      END\n"
                "      SUBROUTINE RIGHT\n"
                "      IMPLICIT NONE\n"
                "      CALL LEFT\n"
                "      END\n",
                encoding="utf-8",
            )
            plan = base / "plan"
            item = write_procedure_partition_plan(
                self._analyze_tree(root),
                plan,
                max_procedures_per_module=1,
            )[0]
            self.assertEqual(item.safety, "approval-required")
            mapping = item.details["procedure_to_module"]
            self.assertEqual(mapping["left"], mapping["right"])
            recursive_group = next(
                group for group in item.details["module_groups"]
                if "left" in group["procedures"]
            )
            self.assertTrue(recursive_group["oversized_scc"])

    def test_single_module_limit_is_reported_as_not_needed(self):
        with tempfile.TemporaryDirectory() as tmp_dir:
            base = Path(tmp_dir)
            root = base / "source"
            self._write_graph_sample(root)
            item = write_procedure_partition_plan(
                self._analyze_tree(root),
                base / "plan",
                max_procedures_per_module=12,
            )[0]
            self.assertEqual(item.safety, "not-needed")
            self.assertIn("procedure-module-plan", item.rationale)


if __name__ == "__main__":
    unittest.main()
