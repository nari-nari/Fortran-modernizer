import unittest
from subprocess import CompletedProcess
from unittest.mock import patch

from fortran_refactor.external_tools import external_tool_status


class ExternalToolPolicyTest(unittest.TestCase):
    def test_optional_tools_are_never_required(self):
        with patch("fortran_refactor.external_tools.shutil.which", return_value=None), patch(
            "fortran_refactor.external_tools.subprocess.run"
        ) as run:
            status = external_tool_status()
        self.assertFalse(run.called)
        self.assertEqual(set(status), {"camfort", "findent", "fortls"})
        self.assertTrue(all(not row["required"] for row in status.values()))
        self.assertEqual(status["camfort"]["integration"], "not-enabled")

    def test_version_probe_uses_no_shell_and_timeout(self):
        def which(name: str):
            return f"/opt/tools/{name}"

        with patch("fortran_refactor.external_tools.shutil.which", side_effect=which), patch(
            "fortran_refactor.external_tools.subprocess.run",
            return_value=CompletedProcess(args=[], returncode=0, stdout="tool 1.0\n", stderr=""),
        ) as run:
            status = external_tool_status()
        self.assertTrue(all(row["available"] for row in status.values()))
        self.assertTrue(all(row["version"] == "tool 1.0" for row in status.values()))
        self.assertFalse(run.call_args.kwargs["shell"])
        self.assertEqual(run.call_args.kwargs["timeout"], 5)


if __name__ == "__main__":
    unittest.main()
