from __future__ import annotations

import hashlib
import subprocess
import tempfile
import unittest
from pathlib import Path

from fortran_refactor.apply import apply_plan
from fortran_refactor.kind_standardization import write_kind_standardization_plan


class KindStandardizationTest(unittest.TestCase):
    def test_free_form_plan_merges_iso_imports_and_runs(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            source_root = root / "source"
            source_root.mkdir()
            source = source_root / "demo.f90"
            source.write_text(
                """module m
  use, intrinsic :: iso_fortran_env, only: int32
  implicit none
  double precision :: scale = 2.0d0
contains
  double precision function evaluate(x)
    double precision, intent(in) :: x
    evaluate = scale*x
  end function evaluate
end module m
program main
  use m
  implicit none
  double precision :: value
  value = evaluate(3.0d0)
  print '(f6.3)', value
end program main
""",
                encoding="utf-8",
            )
            plan = root / "plan"
            result = write_kind_standardization_plan([source], [], plan)
            self.assertEqual(result.summary["blocked"], 0)
            preview = (plan / "transformed_sources" / "demo.f90").read_text(encoding="utf-8")
            self.assertIn("only: int32, real64", preview.lower())
            self.assertIn("real(real64) function evaluate", preview.lower())
            applied = root / "applied"
            receipt = apply_plan(plan, applied, {"KIND-0001"}, False, True, [], True)
            self.assertEqual(receipt["fparser_success"], 2)
            self.assertEqual(receipt["kind_standardization_verification"][0]["converted_occurrences"], 4)
            transformed = applied / "transformed_sources" / "demo.f90"
            executable = root / "demo"
            subprocess.run(["gfortran", str(transformed), "-o", str(executable)], check=True)
            self.assertEqual(subprocess.check_output([str(executable)], text=True).strip(), "6.000")

    def test_fixed_form_continuation_is_reflowed(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            source = root / "legacy.for"
            source.write_text(
                """      PROGRAM MAIN
      IMPLICIT NONE
      DOUBLE PRECISION ALPHA,BETA,GAMMA,
     1                 DELTA,EPSILON,ZETA
      INTEGER*4 I
      ALPHA=2.0D0
      I=3
      PRINT *,ALPHA+I
      END
""",
                encoding="utf-8",
            )
            plan = root / "plan"
            result = write_kind_standardization_plan([source], [], plan)
            self.assertEqual(result.summary["approval_required"], 2)
            preview = (plan / "transformed_sources" / "legacy.for").read_text(encoding="utf-8")
            self.assertIn("iso_fortran_env", preview.lower())
            self.assertIn("REAL(real64)", preview)
            self.assertLessEqual(max(len(line) for line in preview.splitlines()), 72)

    def test_numeric_and_logical_kinds_are_blocked_by_default(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            source = root / "legacy.f90"
            source.write_text(
                """subroutine legacy(x, flag)
  implicit none
  real(kind=8), intent(inout) :: x
  logical*4, intent(in) :: flag
  if (flag) x = x + 1.0d0
end subroutine legacy
""",
                encoding="utf-8",
            )
            result = write_kind_standardization_plan([source], [], root / "plan")
            self.assertEqual(result.summary["approval_required"], 0)
            self.assertEqual(result.summary["blocked"], 2)
            reasons = " ".join(item.reason for item in result.occurrences)
            self.assertIn("processor-dependent", reasons)
            self.assertIn("logical kinds", reasons)

    def test_planning_does_not_modify_source(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            source = root / "legacy.f90"
            source.write_text("subroutine s\n double precision :: x\n x=1.0d0\nend\n", encoding="utf-8")
            before = hashlib.sha256(source.read_bytes()).hexdigest()
            result = write_kind_standardization_plan([source], [], root / "plan")
            self.assertEqual(result.summary["source_modifications"], 0)
            after = hashlib.sha256(source.read_bytes()).hexdigest()
            self.assertEqual(before, after)


if __name__ == "__main__":
    unittest.main()
