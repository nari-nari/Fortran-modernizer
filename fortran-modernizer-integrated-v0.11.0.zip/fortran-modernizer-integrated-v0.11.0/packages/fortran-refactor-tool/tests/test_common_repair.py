import csv
import json
import shutil
import tempfile
import unittest
from pathlib import Path

from fortran_refactor.apply import ApplyError, apply_plan
from fortran_refactor.common_repair import write_common_repair_plan
from fortran_refactor.diagnostics import build_analysis_result
from fortran_refactor.extract import analyze_unit
from fortran_refactor.source import split_program_units


class CommonRepairPlanTest(unittest.TestCase):
    def _analyze(self, source: Path):
        return build_analysis_result(
            [analyze_unit(unit, []) for unit in split_program_units(source)]
        )

    def test_type_mismatch_produces_two_verified_alternatives(self):
        source = Path("samples/diagnostic_fixtures/common_type_mismatch.for").resolve()
        result = self._analyze(source)
        with tempfile.TemporaryDirectory() as tmp_dir:
            output = Path(tmp_dir) / "plan"
            suggestions = write_common_repair_plan(result, output)
            self.assertEqual(len(suggestions), 2)
            self.assertTrue(all(item.kind == "repair_common_layout" for item in suggestions))
            self.assertTrue(all(item.safety == "approval-required" for item in suggestions))
            self.assertTrue(all(item.details["preview_status"] == "pass" for item in suggestions))
            patches = [
                (output / "candidates" / item.id / "proposed_changes.patch").read_text(encoding="utf-8")
                for item in suggestions
            ]
            self.assertTrue(any("+      DOUBLE PRECISION RHO" in patch for patch in patches))
            self.assertTrue(any("+      REAL RHO" in patch for patch in patches))
            options = json.loads((output / "common_repair_options.json").read_text(encoding="utf-8"))
            self.assertFalse(options["reviewed"])
            self.assertIsNone(options["blocks"][0]["selected_candidate_id"])
            with (output / "candidate_impacts.csv").open(encoding="utf-8", newline="") as handle:
                rows = list(csv.DictReader(handle))
            self.assertEqual(len(rows), 4)
            self.assertTrue(any("kind" in row["changes"] for row in rows))

    def test_order_candidate_can_be_applied_and_removes_layout_errors(self):
        with tempfile.TemporaryDirectory() as tmp_dir:
            base = Path(tmp_dir)
            source_root = base / "source"
            source_root.mkdir()
            shutil.copy2(
                "samples/diagnostic_fixtures/common_order_mismatch.for",
                source_root / "common_order_mismatch.for",
            )
            source = source_root / "common_order_mismatch.for"
            result = self._analyze(source)
            plan = base / "plan"
            suggestions = write_common_repair_plan(result, plan)
            first = suggestions[0]
            receipt = apply_plan(
                plan,
                base / "applied",
                selected_ids={first.id},
                all_automatic=False,
                approve_review=True,
                include_dirs=[],
                run_compile_check=True,
            )
            self.assertEqual(receipt["remaining_selected_repair_diagnostics"], 0)
            transformed = Path(receipt["transformed_root"]) / "common_order_mismatch.for"
            text = transformed.read_text(encoding="utf-8").upper()
            self.assertEqual(text.count("COMMON /MIXED/ PRESS,NODES"), 2)

    def test_count_extension_is_applicable_but_removal_is_analysis_only(self):
        source = Path("samples/diagnostic_fixtures/common_count_mismatch.for").resolve()
        result = self._analyze(source)
        with tempfile.TemporaryDirectory() as tmp_dir:
            output = Path(tmp_dir) / "plan"
            suggestions = write_common_repair_plan(result, output)
            by_count = {
                len(item.details["canonical_entries"]): item
                for item in suggestions
            }
            self.assertEqual(by_count[3].safety, "approval-required")
            self.assertEqual(by_count[3].details["preview_status"], "pass")
            patch = (output / "candidates" / by_count[3].id / "proposed_changes.patch").read_text(encoding="utf-8")
            self.assertIn("+      DOUBLE PRECISION Z", patch)
            self.assertIn("+      COMMON /STATE/ X,Y,Z", patch)
            self.assertEqual(by_count[2].safety, "manual-review")
            self.assertTrue(any("remove COMMON storage" in item for item in by_count[2].details["blockers"]))

    def test_apply_rejects_two_candidates_for_same_block(self):
        source = Path("samples/diagnostic_fixtures/common_shape_mismatch.for").resolve()
        result = self._analyze(source)
        with tempfile.TemporaryDirectory() as tmp_dir:
            base = Path(tmp_dir)
            plan = base / "plan"
            suggestions = write_common_repair_plan(result, plan)
            with self.assertRaisesRegex(ApplyError, "exactly one COMMON repair candidate"):
                apply_plan(
                    plan,
                    base / "applied",
                    selected_ids={item.id for item in suggestions},
                    all_automatic=False,
                    approve_review=True,
                    include_dirs=[],
                    run_compile_check=False,
                )


if __name__ == "__main__":
    unittest.main()
