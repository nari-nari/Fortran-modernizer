from __future__ import annotations

import json
import shutil
import tempfile
import unittest
from pathlib import Path

from fortran_refactor.apply import ApplyError, apply_plan
from fortran_refactor.fixed_form import format_fixed_statement, write_fixed_form_rewrite_plan


class FixedFormRewriteTest(unittest.TestCase):
    @property
    def fixture(self) -> Path:
        return Path(__file__).resolve().parents[1] / "samples" / "absoft_compatibility" / "multiline_declarations.for"

    def test_formatter_preserves_label_and_respects_72_columns(self) -> None:
        physical = [
            "12345 DOUBLE PRECISION ALPHA,BETA,GAMMA,DELTA,EPSILON,ZETA,ETA,THETA,\n",
            "     1 IOTA,KAPPA,LAMBDA,MU,NU,XI,OMICRON,PI,RHO,SIGMA,TAU\n",
        ]
        replacement, error = format_fixed_statement(
            "DOUBLE PRECISION ALPHA,BETA,GAMMA,DELTA,EPSILON,ZETA,ETA,THETA,IOTA,KAPPA,LAMBDA,MU,NU,XI,OMICRON,PI,RHO,SIGMA,TAU",
            physical,
            line_length=72,
        )
        self.assertIsNone(error)
        lines = replacement.splitlines()
        self.assertTrue(lines[0].startswith("12345 "))
        self.assertTrue(lines[1].startswith("     1"))
        self.assertTrue(all(len(line) <= 72 for line in lines))

    def test_formatter_blocks_inline_comment_and_sequence_field(self) -> None:
        _, comment_error = format_fixed_statement(
            "CALL FOO(A,B)",
            ["      CALL FOO(A, ! keep\n", "     1 B)\n"],
        )
        self.assertIn("inline comment", comment_error or "")
        _, sequence_error = format_fixed_statement(
            "CALL FOO(A,B)",
            ["      CALL FOO(A,                                                        000100\n", "     1 B)\n"],
        )
        self.assertIn("sequence", sequence_error or "")

    def test_plan_reflows_ast_backed_multiline_statements(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            output = Path(temp) / "plan"
            suggestions = write_fixed_form_rewrite_plan([self.fixture], [], output, line_length=72)
            applicable = [item for item in suggestions if item.safety == "approval-required"]
            self.assertEqual(len(applicable), 1)
            self.assertEqual(len(applicable[0].details["edits"]), 3)
            inventory = (output / "statement_inventory.csv").read_text(encoding="utf-8")
            self.assertIn("Type_Declaration_Stmt", inventory)
            self.assertIn("Common_Stmt", inventory)
            self.assertIn("Call_Stmt", inventory)
            preview = output / "transformed_sources" / self.fixture.name
            text = preview.read_text(encoding="utf-8")
            self.assertIn("DOUBLE PRECISION A,B,C, D,E,F", text)
            self.assertNotIn("     2                    E,F", text)
            self.assertTrue(all(len(line.expandtabs(8)) <= 72 for line in text.splitlines()))


    def test_single_overlength_statement_is_reflowed(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            source = Path(temp) / "long.for"
            source.write_text(
                "      SUBROUTINE LONG_DECL\n"
                "      IMPLICIT NONE\n"
                "      DOUBLE PRECISION ALPHA,BETA,GAMMA,DELTA,EPSILON,ZETA,ETA,THETA,IOTA,KAPPA,LAMBDA,MU\n"
                "      END\n",
                encoding="utf-8",
            )
            output = Path(temp) / "plan"
            suggestions = write_fixed_form_rewrite_plan([source], [], output, line_length=72)
            item = next(entry for entry in suggestions if entry.safety == "approval-required")
            self.assertEqual(len(item.details["edits"]), 1)
            preview = output / "transformed_sources" / "long.for"
            self.assertTrue(all(len(line) <= 72 for line in preview.read_text().splitlines()))

    def test_apply_range_plan_to_copy_and_reject_stale_source(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            base = Path(temp)
            source_root = base / "source"
            source_root.mkdir()
            source = source_root / self.fixture.name
            shutil.copy2(self.fixture, source)
            plan = base / "plan"
            suggestions = write_fixed_form_rewrite_plan([source], [], plan, line_length=72)
            ids = {item.id for item in suggestions if item.safety == "approval-required"}
            receipt = apply_plan(
                plan,
                base / "applied",
                selected_ids=ids,
                all_automatic=False,
                approve_review=True,
                include_dirs=[],
                run_compile_check=True,
            )
            transformed = Path(receipt["transformed_root"]) / source.name
            self.assertTrue(transformed.is_file())
            self.assertEqual(receipt["fparser_success"], receipt["fparser_program_units"])
            self.assertNotEqual(transformed.read_text(encoding="utf-8"), source.read_text(encoding="utf-8"))

            source.write_text(source.read_text(encoding="utf-8") + "C stale\n", encoding="utf-8")
            with self.assertRaises(ApplyError):
                apply_plan(
                    plan,
                    base / "stale",
                    selected_ids=ids,
                    all_automatic=False,
                    approve_review=True,
                    include_dirs=[],
                    run_compile_check=False,
                )


if __name__ == "__main__":
    unittest.main()
