import json
import tempfile
import unittest
from pathlib import Path

from fortran_refactor.diagnostics import build_analysis_result
from fortran_refactor.extract import analyze_unit
from fortran_refactor.procedure_domain_suggest import write_procedure_domain_suggestions
from fortran_refactor.procedure_domains import write_procedure_domain_plan
from fortran_refactor.source import discover_fortran_files, split_program_units


class ProcedureDomainSuggestionTest(unittest.TestCase):
    def _analyze_tree(self, root: Path):
        return build_analysis_result(
            [
                analyze_unit(unit, [])
                for source in discover_fortran_files([root])
                for unit in split_program_units(source)
            ]
        )

    def test_lubrication_names_produce_review_required_draft(self):
        project = Path(__file__).resolve().parents[1]
        result = build_analysis_result(
            [
                analyze_unit(unit, [project / "samples/legacy_runnable/include"])
                for source in discover_fortran_files([project / "samples/legacy_runnable"])
                for unit in split_program_units(source)
            ]
        )
        with tempfile.TemporaryDirectory() as tmp_dir:
            output = Path(tmp_dir)
            proposal = write_procedure_domain_suggestions(result, output)
            draft = json.loads((output / "classification_draft.json").read_text(encoding="utf-8"))
            self.assertFalse(draft["reviewed"])
            mapping = {
                procedure: domain["name"]
                for domain in draft["domains"]
                for procedure in domain["procedures"]
            }
            self.assertEqual(mapping["init_geometry"], "geometry")
            self.assertEqual(mapping["solve_reynolds"], "solver")
            self.assertEqual(mapping["compute_metrics"], "postprocess")
            self.assertEqual(mapping["print_results"], "output")
            self.assertEqual(proposal["procedure_count"], 4)
            for name in [
                "domain_evidence.csv",
                "procedure_profiles.csv",
                "relationship_evidence.csv",
                "proposed_domain_graph.dot",
                "review_guide.md",
            ]:
                self.assertTrue((output / name).is_file(), name)

    def test_comment_terms_can_classify_non_descriptive_name(self):
        with tempfile.TemporaryDirectory() as tmp_dir:
            root = Path(tmp_dir) / "source"
            root.mkdir()
            (root / "comments.for").write_text(
                "      PROGRAM DEMO\n"
                "      CALL STEP_A\n"
                "      END\n"
                "C     Update thermal temperature heat and energy fields.\n"
                "      SUBROUTINE STEP_A\n"
                "      END\n",
                encoding="utf-8",
            )
            output = Path(tmp_dir) / "proposal"
            proposal = write_procedure_domain_suggestions(self._analyze_tree(root), output)
            row = proposal["assignments"][0]
            self.assertEqual(row["suggested_domain"], "thermal")
            self.assertIn(row["confidence"], {"medium", "high"})
            self.assertEqual(row["assignment_source"], "semantic-evidence")

    def test_call_neighbour_propagates_only_one_agreed_domain(self):
        with tempfile.TemporaryDirectory() as tmp_dir:
            root = Path(tmp_dir) / "source"
            root.mkdir()
            (root / "calls.for").write_text(
                "      PROGRAM DEMO\n"
                "      CALL HELPER_X\n"
                "      END\n"
                "      SUBROUTINE HELPER_X\n"
                "      CALL SOLVE_PRESSURE\n"
                "      END\n"
                "      SUBROUTINE SOLVE_PRESSURE\n"
                "      END\n",
                encoding="utf-8",
            )
            proposal = write_procedure_domain_suggestions(
                self._analyze_tree(root), Path(tmp_dir) / "proposal"
            )
            rows = {row["procedure"]: row for row in proposal["assignments"]}
            self.assertEqual(rows["solve_pressure"]["suggested_domain"], "solver")
            self.assertEqual(rows["helper_x"]["suggested_domain"], "solver")
            self.assertEqual(rows["helper_x"]["assignment_source"], "call-neighbour-propagation")
            self.assertEqual(rows["helper_x"]["confidence"], "low")

    def test_mutual_recursion_is_kept_in_one_suggested_domain(self):
        with tempfile.TemporaryDirectory() as tmp_dir:
            root = Path(tmp_dir) / "source"
            root.mkdir()
            (root / "recursive.for").write_text(
                "      PROGRAM DEMO\n"
                "      CALL SOLVE_LEFT\n"
                "      END\n"
                "      SUBROUTINE SOLVE_LEFT\n"
                "      CALL HELPER_RIGHT\n"
                "      END\n"
                "      SUBROUTINE HELPER_RIGHT\n"
                "      CALL SOLVE_LEFT\n"
                "      END\n",
                encoding="utf-8",
            )
            proposal = write_procedure_domain_suggestions(
                self._analyze_tree(root), Path(tmp_dir) / "proposal"
            )
            rows = {row["procedure"]: row for row in proposal["assignments"]}
            self.assertEqual(
                rows["solve_left"]["suggested_domain"],
                rows["helper_right"]["suggested_domain"],
            )
            self.assertEqual(rows["solve_left"]["recursive_group"], ["helper_right", "solve_left"])

    def test_relationship_report_records_shared_common_state(self):
        with tempfile.TemporaryDirectory() as tmp_dir:
            root = Path(tmp_dir) / "source"
            root.mkdir()
            (root / "state.for").write_text(
                "      PROGRAM DEMO\n"
                "      CALL STEP_ONE\n"
                "      CALL STEP_TWO\n"
                "      END\n"
                "      SUBROUTINE STEP_ONE\n"
                "      DOUBLE PRECISION P(4)\n"
                "      COMMON /FIELD/ P\n"
                "      END\n"
                "      SUBROUTINE STEP_TWO\n"
                "      DOUBLE PRECISION Q(4)\n"
                "      COMMON /FIELD/ Q\n"
                "      END\n",
                encoding="utf-8",
            )
            output = Path(tmp_dir) / "proposal"
            write_procedure_domain_suggestions(self._analyze_tree(root), output)
            rows = (output / "relationship_evidence.csv").read_text(encoding="utf-8")
            self.assertIn("field", rows)
            self.assertIn("step_one", rows)
            self.assertIn("step_two", rows)

    def test_generated_draft_must_be_reviewed_before_domain_plan(self):
        with tempfile.TemporaryDirectory() as tmp_dir:
            base = Path(tmp_dir)
            root = base / "source"
            root.mkdir()
            (root / "simple.for").write_text(
                "      PROGRAM DEMO\n"
                "      CALL PRINT_RESULTS\n"
                "      END\n"
                "      SUBROUTINE PRINT_RESULTS\n"
                "      END\n",
                encoding="utf-8",
            )
            result = self._analyze_tree(root)
            proposal_dir = base / "proposal"
            write_procedure_domain_suggestions(result, proposal_dir)
            draft_path = proposal_dir / "classification_draft.json"
            with self.assertRaisesRegex(ValueError, "reviewed=false"):
                write_procedure_domain_plan(result, base / "blocked-plan", draft_path)

            payload = json.loads(draft_path.read_text(encoding="utf-8"))
            payload["reviewed"] = True
            reviewed = base / "reviewed.json"
            reviewed.write_text(json.dumps(payload, indent=2), encoding="utf-8")
            item = write_procedure_domain_plan(result, base / "approved-plan", reviewed)[0]
            self.assertEqual(item.safety, "approval-required")


if __name__ == "__main__":
    unittest.main()
