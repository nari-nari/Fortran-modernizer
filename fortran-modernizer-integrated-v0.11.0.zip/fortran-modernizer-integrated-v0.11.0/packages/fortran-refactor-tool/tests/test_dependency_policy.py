import tomllib
import unittest
from pathlib import Path


FPARSER_WHEEL_URL = (
    "https://files.pythonhosted.org/packages/31/1e/"
    "4c11c71d4a80e680ede45a2493cb1248e52da776e6f3cca841cc57a8f69c/"
    "fparser-0.2.4-py3-none-any.whl"
)
FPARSER_SHA256 = "sha256:a1bd198c07fdff55570b80a7b119aeafb588e9097c11e0a74ea67744a9a1a478"


class DependencyPolicyTest(unittest.TestCase):
    def test_pyproject_uses_normal_pypi_dependency_and_lock_pins_wheel(self):
        pyproject = tomllib.loads(Path("pyproject.toml").read_text(encoding="utf-8"))
        self.assertEqual(pyproject["project"]["dependencies"], ["fparser==0.2.4"])
        self.assertFalse(pyproject["tool"]["uv"]["package"])

        lock = tomllib.loads(Path("uv.lock").read_text(encoding="utf-8"))
        project = next(package for package in lock["package"] if package["name"] == "fortran-refactor-tool")
        self.assertEqual(project["version"], pyproject["project"]["version"])
        fparser = next(package for package in lock["package"] if package["name"] == "fparser")
        self.assertEqual(fparser["version"], "0.2.4")
        self.assertEqual(fparser["source"]["registry"], "https://pypi.org/simple")
        self.assertEqual(fparser["wheels"][0]["url"], FPARSER_WHEEL_URL)
        self.assertEqual(fparser["wheels"][0]["hash"], FPARSER_SHA256)


if __name__ == "__main__":
    unittest.main()
