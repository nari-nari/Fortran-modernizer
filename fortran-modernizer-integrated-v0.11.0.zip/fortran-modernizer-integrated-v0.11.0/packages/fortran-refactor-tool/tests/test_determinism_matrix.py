from __future__ import annotations

import json
import shutil
import tempfile
import unittest
from pathlib import Path

from fortran_refactor.determinism_matrix import (
    DeterminismMatrixError,
    run_determinism_matrix,
    validate_determinism_matrix_config,
)
from fortran_refactor.project import load_project_config
from fortran_refactor.project_assessment import run_configured_regression


@unittest.skipUnless(shutil.which("gfortran"), "gfortran is required")
class DeterminismMatrixTests(unittest.TestCase):
    def _source(self, root: Path, *, macro_value: bool = False) -> None:
        body = """program matrix_demo
  use omp_lib
  implicit none
  integer :: i, unit
  real(8) :: total
  total = 0.0d0
!$omp parallel do reduction(+:total)
  do i = 1, 1000
    total = total + dble(i)
  end do
!$omp end parallel do
#ifdef VALUE
  total = total + dble(VALUE)
#endif
  open(newunit=unit, file='field.dat', status='replace', action='write')
  write(unit, '(ES24.16)') total
  close(unit)
end program matrix_demo
"""
        (root / "solver.F90").write_text(body, encoding="utf-8")

    def _config(self) -> dict:
        return {
            "runs": 2,
            "working_directory": ".",
            "compilers": [
                {"name": "gfortran", "command": "gfortran", "flags": ["-fopenmp", "-cpp"]}
            ],
            "optimization_levels": [
                {"name": "O0", "flags": ["-O0"]},
                {"name": "O2", "flags": ["-O2"]},
            ],
            "thread_counts": [1, 2],
            "build_commands": [[
                "{compiler}", "{compiler_flags}", "{optimization_flags}",
                "solver.F90", "-o", "{executable}",
            ]],
            "run_command": ["./{executable}"],
            "cleanup_commands": [["rm", "-f", "{executable}", "field.dat"]],
            "artifacts": [{
                "name": "field",
                "path": "field.dat",
                "mode": "numeric-array-text",
                "atol": 0.0,
                "rtol": 0.0,
                "remove_before_run": True,
            }],
            "cross_variant": {"enabled": True, "baseline": "gfortran__O0__t1"},
        }

    def test_openmp_compiler_optimization_thread_matrix_passes(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            self._source(root)
            result = run_determinism_matrix(self._config(), root / "report", base_dir=root)
            self.assertEqual(result["status"], "pass")
            self.assertEqual(result["summary"]["variants_requested"], 4)
            self.assertEqual(result["summary"]["variants_passed"], 4)
            self.assertEqual(result["summary"]["cross_variant_comparisons"], 3)
            self.assertTrue((root / "report" / "determinism-matrix.json").is_file())
            self.assertTrue((root / "report" / "determinism-matrix.csv").is_file())
            self.assertFalse((root / "frt-matrix-gfortran__O0__t1").exists())

    def test_cross_variant_difference_is_detected(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            self._source(root)
            config = self._config()
            config["thread_counts"] = [1]
            config["optimization_levels"] = [
                {"name": "base", "flags": ["-O0", "-DVALUE=1"]},
                {"name": "changed", "flags": ["-O0", "-DVALUE=2"]},
            ]
            config["cross_variant"]["baseline"] = "gfortran__base__t1"
            result = run_determinism_matrix(config, root / "report", base_dir=root)
            self.assertEqual(result["status"], "failed")
            self.assertEqual(result["summary"]["variants_passed"], 2)
            self.assertEqual(result["summary"]["cross_variant_failures"], 1)
            self.assertEqual(result["cross_variant_comparisons"][0]["status"], "failed")

    def test_optional_unavailable_compiler_is_skipped(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            self._source(root)
            config = self._config()
            config["optimization_levels"] = [{"name": "O0", "flags": ["-O0"]}]
            config["thread_counts"] = [1]
            config["compilers"].append({
                "name": "missing", "command": "definitely-not-a-fortran-compiler", "required": False
            })
            result = run_determinism_matrix(config, root / "report", base_dir=root)
            self.assertEqual(result["status"], "pass")
            self.assertEqual(result["summary"]["variants_passed"], 1)
            self.assertEqual(result["summary"]["variants_skipped"], 1)

    def test_project_pipeline_runs_matrix_gate(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            self._source(root)
            matrix = self._config()
            matrix["optimization_levels"] = [{"name": "O0", "flags": ["-O0"]}]
            matrix["thread_counts"] = [1]
            config = {
                "schema_version": 1,
                "project": {"name": "matrix", "root": "."},
                "sources": {"paths": ["solver.F90"], "include_globs": ["**/*.F90"], "exclude_globs": []},
                "fortran": {"include_dirs": [], "fixed_line_length": 72},
                "compiler": {"enabled": False},
                "regression": {
                    "enabled": True,
                    "working_directory": ".",
                    "build_commands": [],
                    "run_commands": [],
                    "comparisons": [],
                    "cases": [],
                    "determinism": {"enabled": False},
                    "determinism_matrix": {"enabled": True, **matrix},
                },
                "assessment": {"performance_budget_seconds": 60.0},
            }
            path = root / "fortran-refactor.json"
            path.write_text(json.dumps(config), encoding="utf-8")
            project = load_project_config(path)
            result = run_configured_regression(project, root / "reports")
            self.assertEqual(result["status"], "pass")
            self.assertEqual(result["determinism_matrix"]["status"], "pass")

    def test_validation_rejects_duplicate_thread_counts(self) -> None:
        config = self._config()
        config["thread_counts"] = [1, 1]
        with self.assertRaises(DeterminismMatrixError):
            validate_determinism_matrix_config(config)


if __name__ == "__main__":
    unittest.main()
