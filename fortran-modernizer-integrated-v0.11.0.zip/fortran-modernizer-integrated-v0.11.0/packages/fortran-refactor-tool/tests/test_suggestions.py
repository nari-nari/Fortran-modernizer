import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import fortran_refactor.extract as extract_module
from fortran_refactor.diagnostics import build_analysis_result
from fortran_refactor.models import ParseResult
from fortran_refactor.source import split_program_units
from fortran_refactor.suggestions import write_suggestions


class SuggestionsTest(unittest.TestCase):
    @patch.object(
        extract_module,
        "parse_with_fparser",
        side_effect=lambda unit, include_dirs: ParseResult(True, "test-parser", None, 1),
    )
    def test_typo_preview_is_non_destructive(self, _mock_parser):
        source = Path("samples/diagnostic_fixtures/implicit_typo.for").resolve()
        original = source.read_text(encoding="utf-8")
        units = [extract_module.analyze_unit(unit, []) for unit in split_program_units(source)]
        result = build_analysis_result(units)

        with tempfile.TemporaryDirectory() as tmp_dir:
            output = Path(tmp_dir) / "suggestions"
            suggestions = write_suggestions(result, output)
            self.assertEqual(len(suggestions), 1)
            self.assertEqual(suggestions[0].safety, "automatic-preview")
            self.assertTrue(suggestions[0].applied_to_preview)
            self.assertEqual(source.read_text(encoding="utf-8"), original)

            patch = (output / "proposed_changes.patch").read_text(encoding="utf-8")
            self.assertIn("-      RESIDUALL=PRESSURE", patch)
            self.assertIn("+      RESIDUAL=PRESSURE", patch)
            preview_files = list((output / "transformed_sources").rglob("implicit_typo.for"))
            self.assertEqual(len(preview_files), 1)
            preview = preview_files[0].read_text(encoding="utf-8")
            self.assertIn("RESIDUAL=PRESSURE", preview)
            self.assertNotIn("RESIDUALL=PRESSURE", preview)

            payload = json.loads((output / "suggestions.json").read_text(encoding="utf-8"))
            self.assertEqual(payload[0]["kind"], "rename_implicit_typo")


if __name__ == "__main__":
    unittest.main()
