from __future__ import annotations

import hashlib
import json
import subprocess
import tempfile
import unittest
from pathlib import Path

from fortran_refactor.repeated_call import write_repeated_call_harness_suggestions


class RepeatedCallHarnessTest(unittest.TestCase):
    def setUp(self) -> None:
        self.root = Path(__file__).resolve().parents[1]
        self.fixture = self.root / "samples" / "testability" / "testable_kernels.f90"
        self.common_fixture = self.root / "samples" / "testability" / "common_equivalence_kernels.f"

    def test_generates_stateless_and_state_risk_harnesses(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            output = Path(tmp) / "report"
            result = write_repeated_call_harness_suggestions(
                [self.fixture], [], output, selected_units=["scale_values", "cached_kernel"]
            )
            by_name = {item.procedure: item for item in result.candidates}
            self.assertEqual(by_name["scale_values"].status, "ready")
            self.assertEqual(by_name["cached_kernel"].status, "state-risk-candidate")
            self.assertIn("SAVE state", by_name["cached_kernel"].state_risks)
            self.assertTrue((output / by_name["cached_kernel"].harness_path).is_file())
            source = (output / by_name["scale_values"].harness_path).read_text(encoding="utf-8")
            self.assertEqual(source.count("call scale_values"), 2)
            self.assertIn("frt_initial_values", source)
            self.assertIn("FRT_REPEAT results", source)

    def test_stateless_harness_passes_and_save_state_fails(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            output = root / "report"
            result = write_repeated_call_harness_suggestions(
                [self.fixture], [], output, selected_units=["scale_values", "cached_kernel"]
            )
            by_name = {item.procedure: item for item in result.candidates}
            scale_exe = root / "scale_repeat"
            cached_exe = root / "cached_repeat"
            scale_compile = subprocess.run(
                ["gfortran", str(self.fixture), str(output / by_name["scale_values"].harness_path), "-o", str(scale_exe)],
                text=True,
                capture_output=True,
            )
            self.assertEqual(scale_compile.returncode, 0, scale_compile.stderr)
            scale_run = subprocess.run([str(scale_exe)], text=True, capture_output=True)
            self.assertEqual(scale_run.returncode, 0, scale_run.stderr)
            self.assertIn("FRT_REPEAT results PASS", scale_run.stdout)

            cached_compile = subprocess.run(
                ["gfortran", str(self.fixture), str(output / by_name["cached_kernel"].harness_path), "-o", str(cached_exe)],
                text=True,
                capture_output=True,
            )
            self.assertEqual(cached_compile.returncode, 0, cached_compile.stderr)
            cached_run = subprocess.run([str(cached_exe)], text=True, capture_output=True)
            self.assertNotEqual(cached_run.returncode, 0)
            self.assertIn("FRT_REPEAT result FAIL", cached_run.stdout)
            self.assertIn("FRT_REPEAT_FAILURES 1", cached_run.stdout)


    def _approve_common_fixture(self, path: Path, *, procedure: str) -> Path:
        payload = json.loads(path.read_text(encoding="utf-8"))
        payload["reviewed"] = True
        for item in payload["candidates"]:
            item["approved"] = item["procedure"] == procedure
        approved = path.with_name(f"approved_{procedure}.json")
        approved.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
        return approved

    def test_common_fixture_template_then_approved_harness(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            draft_output = root / "draft"
            draft = write_repeated_call_harness_suggestions(
                [self.common_fixture], [], draft_output, selected_units=["common_step"]
            )
            candidate = draft.candidates[0]
            self.assertEqual(candidate.fixture_status, "template-required")
            self.assertEqual(candidate.status, "blocked")
            self.assertEqual(candidate.common_blocks, ("state_ok",))
            self.assertEqual(candidate.equivalence_sets, 1)
            self.assertFalse(candidate.harness_path)
            fixture_path = draft_output / "common_state_fixture.json"
            fixture = json.loads(fixture_path.read_text(encoding="utf-8"))
            self.assertFalse(fixture["reviewed"])
            self.assertEqual(fixture["candidates"][0]["members"][0]["equivalence_aliases"], ["x_alias"])

            approved = self._approve_common_fixture(fixture_path, procedure="common_step")
            final_output = root / "final"
            final = write_repeated_call_harness_suggestions(
                [self.common_fixture], [], final_output, selected_units=["common_step"], state_fixture=approved
            )
            candidate = final.candidates[0]
            self.assertEqual(candidate.fixture_status, "approved")
            self.assertEqual(candidate.status, "state-risk-candidate")
            self.assertEqual(candidate.observed_common_count, 2)
            harness = final_output / candidate.harness_path
            source = harness.read_text(encoding="utf-8")
            self.assertIn("common /state_ok/ x, y", source)
            self.assertIn("frt_initial_common_state_ok_x", source)
            self.assertIn("FRT_REPEAT common_state_ok_x", source)

            executable = root / "common_step_repeat"
            compile_result = subprocess.run(
                ["gfortran", str(self.common_fixture), str(harness), "-o", str(executable)],
                text=True, capture_output=True,
            )
            self.assertEqual(compile_result.returncode, 0, compile_result.stderr)
            run_result = subprocess.run([str(executable)], text=True, capture_output=True)
            self.assertEqual(run_result.returncode, 0, run_result.stderr)
            self.assertIn("FRT_REPEAT common_state_ok_x PASS", run_result.stdout)
            self.assertIn("FRT_REPEAT common_state_ok_y PASS", run_result.stdout)

    def test_common_fixture_exposes_save_state_through_common_observation(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            draft_output = root / "draft"
            write_repeated_call_harness_suggestions(
                [self.common_fixture], [], draft_output, selected_units=["common_cached"]
            )
            approved = self._approve_common_fixture(
                draft_output / "common_state_fixture.json", procedure="common_cached"
            )
            final_output = root / "final"
            result = write_repeated_call_harness_suggestions(
                [self.common_fixture], [], final_output, selected_units=["common_cached"], state_fixture=approved
            )
            candidate = result.candidates[0]
            self.assertIn("SAVE state", candidate.state_risks)
            executable = root / "common_cached_repeat"
            compile_result = subprocess.run(
                ["gfortran", str(self.common_fixture), str(final_output / candidate.harness_path), "-o", str(executable)],
                text=True, capture_output=True,
            )
            self.assertEqual(compile_result.returncode, 0, compile_result.stderr)
            run_result = subprocess.run([str(executable)], text=True, capture_output=True)
            self.assertNotEqual(run_result.returncode, 0)
            self.assertIn("FRT_REPEAT common_state_bad_y FAIL", run_result.stdout)
            self.assertIn("FRT_REPEAT_FAILURES 1", run_result.stdout)

    def test_type_punning_equivalence_remains_blocked(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            output = Path(tmp) / "report"
            result = write_repeated_call_harness_suggestions(
                [self.common_fixture], [], output, selected_units=["common_type_pun"]
            )
            candidate = result.candidates[0]
            self.assertEqual(candidate.status, "blocked")
            self.assertTrue(any("type-punning" in item for item in candidate.blockers))
            self.assertEqual(candidate.equivalence_sets, 0)

    def test_unreviewed_common_fixture_is_rejected(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            draft_output = root / "draft"
            write_repeated_call_harness_suggestions(
                [self.common_fixture], [], draft_output, selected_units=["common_step"]
            )
            with self.assertRaisesRegex(ValueError, "reviewed=true"):
                write_repeated_call_harness_suggestions(
                    [self.common_fixture], [], root / "final", selected_units=["common_step"],
                    state_fixture=draft_output / "common_state_fixture.json",
                )

    def test_generation_does_not_modify_source(self) -> None:
        before = hashlib.sha256(self.fixture.read_bytes()).hexdigest()
        with tempfile.TemporaryDirectory() as tmp:
            write_repeated_call_harness_suggestions(
                [self.fixture], [], Path(tmp) / "report", selected_units=["cached_kernel"]
            )
        self.assertEqual(before, hashlib.sha256(self.fixture.read_bytes()).hexdigest())


if __name__ == "__main__":
    unittest.main()
