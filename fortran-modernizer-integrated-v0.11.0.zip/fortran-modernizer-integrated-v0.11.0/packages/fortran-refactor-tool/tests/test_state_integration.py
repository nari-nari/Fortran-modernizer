from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path

from fortran_refactor.apply import apply_plan
from fortran_refactor.state_integration import (
    write_state_integration_plan,
    write_state_integration_suggestions,
)


STORAGE = """module shared_storage
  implicit none
  private
  public :: field, scale
  real, save :: field(4)
  real, save :: scale
end module shared_storage
"""

MODEL_TYPES = """module model_types
  implicit none
  private
  public :: simulation_t

  type :: simulation_t
    integer :: case_id = 0
  end type simulation_t
end module model_types
"""

WORKERS = """module workers
  implicit none
contains
  subroutine initialize()
    use shared_storage, only: field, scale
    implicit none
    integer :: i
    scale = 2.0
    do i = 1, 4
      field(i) = scale * real(i)
    end do
  end subroutine initialize

  subroutine total_value(total)
    use shared_storage, only: field
    implicit none
    real, intent(out) :: total
    total = sum(field)
  end subroutine total_value
end module workers
"""

MAIN = """program demo
  use workers, only: initialize, total_value
  implicit none
  real :: total
  call initialize()
  call total_value(total)
  if (abs(total - 20.0) > 1.0e-6) error stop 1
end program demo
"""


class StateIntegrationTests(unittest.TestCase):
    def _tree(self, root: Path) -> list[Path]:
        src = root / "src"
        src.mkdir()
        (src / "shared_storage.f90").write_text(STORAGE, encoding="utf-8")
        (src / "model_types.f90").write_text(MODEL_TYPES, encoding="utf-8")
        (src / "workers.f90").write_text(WORKERS, encoding="utf-8")
        (src / "main.f90").write_text(MAIN, encoding="utf-8")
        return sorted(src.glob("*.f90"))

    def _classification(self, root: Path) -> Path:
        path = root / "state_objects.json"
        path.write_text(
            json.dumps(
                {
                    "schema_version": 1,
                    "reviewed": True,
                    "source_module": "shared_storage",
                    "types_module": "shared_data_types",
                    "types_file": "generated_types/shared_data_types.f90",
                    "objects": [
                        {"name": "parameters", "type_name": "shared_parameters_t", "variables": ["scale"]},
                        {"name": "state", "type_name": "shared_state_t", "variables": ["field"]},
                    ],
                },
                indent=2,
            ),
            encoding="utf-8",
        )
        return path

    def _selection(self, root: Path, candidate_id: str) -> Path:
        path = root / f"selection-{candidate_id}.json"
        path.write_text(
            json.dumps(
                {
                    "schema_version": 1,
                    "reviewed": True,
                    "selected_candidate_id": candidate_id,
                },
                indent=2,
            ),
            encoding="utf-8",
        )
        return path

    def test_suggests_four_strategy_families(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            files = self._tree(root)
            output = root / "suggest"
            payload = write_state_integration_suggestions(
                files, [], self._classification(root), output
            )
            strategies = {item["strategy"] for item in payload["candidates"]}
            self.assertEqual(
                strategies,
                {
                    "new-independent-types",
                    "add-types-to-existing-module",
                    "extend-existing-type",
                    "contain-new-types-in-existing-type",
                },
            )
            self.assertFalse(payload["reviewed"])
            self.assertTrue((output / "integration_comparison.md").is_file())

    def _plan_and_apply(self, root: Path, candidate_id: str) -> Path:
        files = self._tree(root)
        classification = self._classification(root)
        plan = root / "plan"
        suggestions = write_state_integration_plan(
            files,
            [],
            classification,
            self._selection(root, candidate_id),
            plan,
        )
        self.assertEqual(suggestions[0].safety, "approval-required")
        receipt = apply_plan(
            plan,
            root / "applied",
            {"STATEINT-0001"},
            all_automatic=False,
            approve_review=True,
            include_dirs=[],
            run_compile_check=True,
        )
        self.assertEqual(receipt["compile_check"]["returncode"], 0)
        self.assertTrue(receipt["state_object_verification"])
        return Path(receipt["transformed_root"])

    def test_add_types_to_existing_module_compiles(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            transformed = self._plan_and_apply(root, "INTEG-MODULE-MODEL-TYPES")
            model = (transformed / "model_types.f90").read_text(encoding="utf-8").lower()
            workers = (transformed / "workers.f90").read_text(encoding="utf-8").lower()
            self.assertIn("type :: shared_parameters_t", model)
            self.assertIn("type :: shared_state_t", model)
            self.assertIn("use model_types, only:", workers)

    def test_extend_existing_type_compiles(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            transformed = self._plan_and_apply(root, "INTEG-EXTEND-MODEL-TYPES-SIMULATION-T")
            model = (transformed / "model_types.f90").read_text(encoding="utf-8").lower()
            workers = (transformed / "workers.f90").read_text(encoding="utf-8").lower()
            self.assertIn("real :: field(4)", model)
            self.assertIn("real :: scale", model)
            self.assertIn("simulation%field", workers)
            self.assertIn("type(simulation_t)", workers)

    def test_contain_new_types_in_existing_type_compiles(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            transformed = self._plan_and_apply(root, "INTEG-CONTAIN-MODEL-TYPES-SIMULATION-T")
            model = (transformed / "model_types.f90").read_text(encoding="utf-8").lower()
            workers = (transformed / "workers.f90").read_text(encoding="utf-8").lower()
            self.assertIn("type(shared_parameters_t) :: parameters", model)
            self.assertIn("type(shared_state_t) :: state", model)
            self.assertIn("simulation%state%field", workers)
            self.assertIn("simulation%parameters%scale", workers)


if __name__ == "__main__":
    unittest.main()
