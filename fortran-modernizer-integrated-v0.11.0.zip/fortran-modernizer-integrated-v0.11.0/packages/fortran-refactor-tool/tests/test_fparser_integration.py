import importlib.metadata
import unittest
from pathlib import Path

from fortran_refactor.fparser_adapter import parse_with_fparser
from fortran_refactor.source import split_program_units


class FparserIntegrationTest(unittest.TestCase):
    def test_required_fparser_parses_all_supplied_program_units(self):
        try:
            version = importlib.metadata.version("fparser")
        except importlib.metadata.PackageNotFoundError as exc:
            self.fail(f"mandatory dependency fparser 0.2.4 is not installed: {exc}")
        self.assertEqual(version, "0.2.4")

        files = [
            Path("samples/reference/journal_bearing_reference.f90"),
            Path("samples/legacy_runnable/journal_bearing_legacy.for"),
            *sorted(Path("samples/diagnostic_fixtures").glob("*.for")),
        ]
        failures = []
        for path in files:
            for unit in split_program_units(path.resolve()):
                result = parse_with_fparser(
                    unit,
                    [Path("samples/legacy_runnable/include").resolve()],
                )
                if not result.success:
                    failures.append(f"{path}:{unit.start_line}:{unit.name}: {result.error}")
        self.assertEqual(failures, [], "\n".join(failures))


if __name__ == "__main__":
    unittest.main()
