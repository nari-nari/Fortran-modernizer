from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from fortran_refactor.workspace import (
    WorkspaceError,
    create_checkpoint,
    initialize_workspace,
    resume_checkpoint,
    workspace_history,
    workspace_status,
)


class WorkspaceTest(unittest.TestCase):
    def test_checkpoint_history_and_resume_verify_snapshot_hash(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            project = root / "project"
            project.mkdir()
            (project / "sample.for").write_text(
                "      SUBROUTINE S\n      END\n", encoding="utf-8"
            )
            workspace = initialize_workspace(project, project / ".frt-workspace")
            receipt = create_checkpoint(workspace, project, "assessment", note="baseline")
            self.assertEqual(receipt.sequence, 1)
            self.assertEqual(len(workspace_history(workspace)), 1)
            status = workspace_status(workspace)
            self.assertTrue(status["current"]["snapshot_intact"])
            resumed = resume_checkpoint(workspace)
            self.assertEqual(resumed["stage"], "assessment")
            self.assertTrue(Path(resumed["snapshot"]).is_dir())

    def test_modified_snapshot_is_rejected(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            project = root / "project"
            project.mkdir()
            (project / "sample.for").write_text("      END\n", encoding="utf-8")
            workspace = initialize_workspace(project, project / ".frt-workspace")
            receipt = create_checkpoint(workspace, project, "baseline")
            (Path(receipt.snapshot) / "sample.for").write_text("changed\n", encoding="utf-8")
            with self.assertRaises(WorkspaceError):
                resume_checkpoint(workspace)


if __name__ == "__main__":
    unittest.main()
