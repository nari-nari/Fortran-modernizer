from __future__ import annotations

import hashlib
import json
import tempfile
import unittest
from pathlib import Path

from fortran_refactor.state_lifecycle import write_state_lifecycle_suggestions


class StateLifecycleTest(unittest.TestCase):
    @property
    def fixtures(self) -> Path:
        return Path(__file__).resolve().parents[1] / "samples" / "state_lifecycle"

    def test_classifies_constants_resources_and_save_state(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            result = write_state_lifecycle_suggestions([self.fixtures], [], Path(temp))
        by_name = {(item.owner, item.name): item for item in result.entities}

        self.assertEqual(by_name[("state_store", "rk")].proposed_action, "keep-module-parameter")
        self.assertEqual(by_name[("state_store", "tolerance")].proposed_action, "module-parameter")
        cache = by_name[("state_store", "work_cache")]
        self.assertEqual(cache.proposed_action, "explicit-initialize-finalize")
        self.assertFalse(cache.blockers)
        self.assertIn("fill_cache", cache.writers)

        counter = by_name[("update_value", "call_counter")]
        self.assertEqual(counter.proposed_action, "state-object-component")
        self.assertEqual(counter.inferred_lifetime, "procedure-static")

    def test_detects_initializer_and_finalizer(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            result = write_state_lifecycle_suggestions([self.fixtures], [], Path(temp))
        roles = {(row["procedure"], row["lifecycle_role"]) for row in result.lifecycle_procedures}
        self.assertIn(("initialize_state", "initialize"), roles)
        self.assertIn(("finalize_state", "finalize"), roles)

    def test_writes_review_bundle_without_modifying_source(self) -> None:
        before = {path: hashlib.sha256(path.read_bytes()).hexdigest() for path in self.fixtures.glob("*.f90")}
        with tempfile.TemporaryDirectory() as temp:
            output = Path(temp)
            result = write_state_lifecycle_suggestions([self.fixtures], [], output)
            expected = {
                "state_entities.csv", "state_accesses.csv", "lifecycle_procedures.csv",
                "state_groups.csv", "state_lifecycle.json", "state_lifecycle_review.json",
                "state_lifecycle.md", "state_dependency.dot",
            }
            self.assertTrue(expected.issubset({path.name for path in output.iterdir()}))
            payload = json.loads((output / "state_lifecycle_review.json").read_text(encoding="utf-8"))
            self.assertFalse(payload["reviewed"])
            self.assertEqual(len(payload["entities"]), result.summary["persistent_entities"])
            self.assertEqual(result.summary["source_modifications"], 0)
        after = {path: hashlib.sha256(path.read_bytes()).hexdigest() for path in self.fixtures.glob("*.f90")}
        self.assertEqual(before, after)

    def test_bare_save_is_blocked(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            source = root / "bare_save.f90"
            source.write_text(
                "subroutine persistent_step(x)\n"
                "  implicit none\n"
                "  real(8), intent(inout) :: x\n"
                "  integer :: count\n"
                "  save\n"
                "  count = count + 1\n"
                "  x = x + count\n"
                "end subroutine persistent_step\n",
                encoding="utf-8",
            )
            result = write_state_lifecycle_suggestions([source], [], root / "report")
        count = next(item for item in result.entities if item.name == "count")
        self.assertEqual(count.status, "blocked")
        self.assertIn("bare SAVE gives every local procedure lifetime", count.blockers)


if __name__ == "__main__":
    unittest.main()
