from __future__ import annotations

import json
import sys
import tempfile
import unittest
from pathlib import Path

from fortran_refactor.determinism import (
    DeterminismCheckError,
    run_determinism_check,
    validate_determinism_config,
)
from fortran_refactor.project import load_project_config
from fortran_refactor.project_assessment import run_configured_regression


class DeterminismCheckTest(unittest.TestCase):
    def _writer(self, root: Path, *, varying: bool) -> Path:
        script = root / "writer.py"
        if varying:
            body = """
from pathlib import Path
state = Path('state.txt')
value = int(state.read_text()) + 1 if state.exists() else 1
state.write_text(str(value))
Path('field.dat').write_text(f'1.0 2.0 {value}.0\\n')
print(f'run-value={value}')
"""
        else:
            body = """
from pathlib import Path
Path('field.dat').write_text('1.0 2.0 3.0\\n')
print('stable-run')
"""
        script.write_text(body.strip() + "\n", encoding="utf-8")
        return script

    def test_repeated_command_and_numeric_artifact_pass(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            script = self._writer(root, varying=False)
            config = {
                "runs": 3,
                "working_directory": ".",
                "run_command": [sys.executable, script.name],
                "compare_stdout": True,
                "artifacts": [
                    {
                        "name": "field",
                        "path": "field.dat",
                        "mode": "numeric-array-text",
                        "shape": [3],
                        "atol": 0.0,
                        "rtol": 0.0,
                        "remove_before_run": True,
                    }
                ],
            }
            result = run_determinism_check(config, root / "report", base_dir=root)
            self.assertEqual(result["status"], "pass")
            self.assertEqual(result["runs_completed"], 3)
            self.assertEqual(len(result["comparisons"]), 4)
            self.assertTrue((root / "report" / "determinism.json").is_file())
            self.assertTrue((root / "report" / "runs" / "run-003" / "stdout.txt").is_file())

    def test_detects_cross_process_output_variation(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            script = self._writer(root, varying=True)
            config = {
                "runs": 3,
                "working_directory": ".",
                "run_command": [sys.executable, script.name],
                "artifacts": [
                    {
                        "name": "field",
                        "path": "field.dat",
                        "mode": "numeric-array-text",
                        "atol": 0.0,
                        "rtol": 0.0,
                        "remove_before_run": True,
                    }
                ],
            }
            result = run_determinism_check(config, root / "report", base_dir=root)
            self.assertEqual(result["status"], "failed")
            self.assertEqual(result["summary"]["comparison_failures"], 2)
            self.assertTrue(all(item["status"] == "failed" for item in result["comparisons"]))

    def test_stale_artifact_is_rejected_by_default(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "field.dat").write_text("1 2 3\n", encoding="utf-8")
            script = root / "noop.py"
            script.write_text("print('done')\n", encoding="utf-8")
            config = {
                "runs": 2,
                "run_command": [sys.executable, script.name],
                "artifacts": [{"name": "field", "path": "field.dat", "mode": "numeric-array-text"}],
            }
            result = run_determinism_check(config, root / "report", base_dir=root)
            self.assertEqual(result["status"], "failed")
            self.assertEqual(result["runs"][0]["artifacts"][0]["status"], "stale")

    def test_validation_requires_observable_evidence(self) -> None:
        with self.assertRaises(DeterminismCheckError):
            validate_determinism_config({"runs": 2, "run_command": ["true"]})

    def test_project_pipeline_runs_configured_determinism_gate(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "dummy.f90").write_text("program dummy\nend program dummy\n", encoding="utf-8")
            script = self._writer(root, varying=False)
            config = {
                "schema_version": 1,
                "project": {"name": "determinism", "root": "."},
                "sources": {"paths": ["dummy.f90"], "include_globs": ["**/*.f90"], "exclude_globs": []},
                "fortran": {"include_dirs": [], "fixed_line_length": 72},
                "compiler": {"enabled": False},
                "regression": {
                    "enabled": True,
                    "working_directory": ".",
                    "build_commands": [],
                    "run_commands": [],
                    "comparisons": [],
                    "determinism": {
                        "enabled": True,
                        "runs": 2,
                        "run_command": [sys.executable, script.name],
                        "compare_stdout": True,
                    },
                },
                "assessment": {"performance_budget_seconds": 60.0},
            }
            config_path = root / "fortran-refactor.json"
            config_path.write_text(json.dumps(config), encoding="utf-8")
            project = load_project_config(config_path)
            result = run_configured_regression(project, root / "reports")
            self.assertEqual(result["status"], "pass")
            self.assertEqual(result["determinism"]["status"], "pass")
            self.assertTrue((root / "reports" / "determinism" / "determinism.json").is_file())

    def test_json_report_is_machine_readable(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            script = self._writer(root, varying=False)
            config = {
                "runs": 2,
                "run_command": [sys.executable, script.name],
                "compare_stdout": True,
            }
            run_determinism_check(config, root / "report", base_dir=root)
            payload = json.loads((root / "report" / "determinism.json").read_text(encoding="utf-8"))
            self.assertEqual(payload["status"], "pass")
            self.assertEqual(payload["summary"]["comparisons"], 1)


if __name__ == "__main__":
    unittest.main()
