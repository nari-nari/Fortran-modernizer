from __future__ import annotations

import hashlib
import json
import shutil
import subprocess
import tempfile
import unittest
from pathlib import Path

from fortran_refactor.apply import apply_plan
from fortran_refactor.equivalence_alias import (
    write_equivalence_alias_plan,
    write_equivalence_alias_suggestions,
)


class EquivalenceAliasTest(unittest.TestCase):
    def _approve(self, suggest_dir: Path, candidate_id: str, representative: str) -> Path:
        selection = json.loads(
            (suggest_dir / "equivalence_alias_selection.json").read_text(encoding="utf-8")
        )
        selection["reviewed"] = True
        for row in selection["selections"]:
            if row["candidate_id"] == candidate_id:
                row["approved"] = True
                row["representative"] = representative
                row["regression_tests_reviewed"] = True
                row["storage_size_probe_reviewed"] = True
                row["storage_size_probe_matrix_reviewed"] = True
        path = suggest_dir.parent / "reviewed-equivalence-alias.json"
        path.write_text(json.dumps(selection, indent=2) + "\n", encoding="utf-8")
        return path

    def test_same_type_scalar_complete_alias_is_ready_without_source_modification(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            source = root / "demo.f90"
            source.write_text(
                """program demo
  implicit none
  real :: primary, alias, result
  equivalence (primary, alias)
  primary = 2.0
  result = alias + 3.0
  print '(f4.1)', result
end program demo
""",
                encoding="utf-8",
            )
            before = hashlib.sha256(source.read_bytes()).hexdigest()
            result = write_equivalence_alias_suggestions([source], [], root / "suggest")
            self.assertEqual(result.summary["ready_candidates"], 1)
            candidate = result.candidates[0]
            self.assertEqual(candidate.status, "ready")
            self.assertEqual(candidate.allowed_representatives, ("primary", "alias"))
            self.assertEqual(candidate.recommended_representative, "primary")
            self.assertEqual(before, hashlib.sha256(source.read_bytes()).hexdigest())


    def test_same_type_whole_array_complete_alias_is_ready_without_source_modification(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            source = root / "array_demo.f90"
            source.write_text(
                """program array_demo
  implicit none
  real :: primary(0:2, 1:2), alias(0:2, 1:2)
  equivalence (primary, alias)
  primary = 1.0
  print '(f4.1)', sum(alias)
end program array_demo
""",
                encoding="utf-8",
            )
            before = hashlib.sha256(source.read_bytes()).hexdigest()
            result = write_equivalence_alias_suggestions([source], [], root / "suggest")
            self.assertEqual(result.summary["whole_array_ready_candidates"], 1)
            candidate = result.candidates[0]
            self.assertEqual(candidate.status, "ready")
            self.assertEqual(candidate.alias_form, "whole-array")
            self.assertEqual(candidate.rank, 2)
            self.assertEqual(candidate.shape, ("0:2", "1:2"))
            self.assertEqual(candidate.allowed_representatives, ("primary", "alias"))
            self.assertEqual(before, hashlib.sha256(source.read_bytes()).hexdigest())

    def test_reviewed_whole_array_plan_applies_compiles_and_preserves_result(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            source_root = root / "source"
            source_root.mkdir()
            source = source_root / "array_demo.f90"
            source.write_text(
                """program array_demo
  implicit none
  integer :: i, j
  real :: primary(0:2, 1:2), alias(0:2, 1:2), result
  equivalence (primary, alias)
  do j = 1, 2
    do i = 0, 2
      primary(i,j) = real(i + 10*j)
    end do
  end do
  alias(1,2) = alias(1,2) + 5.0
  result = sum(alias)
  print '(f6.1)', result
end program array_demo
""",
                encoding="utf-8",
            )
            original_exe = root / "original-array"
            subprocess.run(["gfortran", str(source), "-o", str(original_exe)], check=True)
            original_output = subprocess.check_output([str(original_exe)], text=True).strip()

            suggest_dir = root / "suggest"
            result = write_equivalence_alias_suggestions([source], [], suggest_dir)
            candidate = result.candidates[0]
            self.assertEqual(candidate.status, "ready")
            selection = self._approve(suggest_dir, candidate.candidate_id, "primary")
            plan_dir = root / "plan"
            suggestions = write_equivalence_alias_plan([source], [], selection, plan_dir)
            self.assertEqual(suggestions[0].details["alias_form"], "whole-array")
            self.assertEqual(suggestions[0].details["shape"], ["0:2", "1:2"])
            receipt = apply_plan(
                plan_dir,
                root / "applied",
                {candidate.candidate_id},
                False,
                True,
                [],
                True,
            )
            self.assertTrue(receipt["equivalence_alias_verification"][0]["equivalence_removed"])
            transformed = root / "applied" / "transformed_sources" / "array_demo.f90"
            text = transformed.read_text(encoding="utf-8").lower()
            self.assertNotIn("equivalence", text)
            self.assertNotRegex(text, r"\balias\b")
            self.assertIn("real :: primary(0:2, 1:2), result", text)
            self.assertIn("primary(1,2) = primary(1,2) + 5.0", text)
            transformed_exe = root / "transformed-array"
            subprocess.run(["gfortran", str(transformed), "-o", str(transformed_exe)], check=True)
            transformed_output = subprocess.check_output([str(transformed_exe)], text=True).strip()
            self.assertEqual(transformed_output, original_output)
            self.assertEqual(transformed_output, "101.0")

    def test_whole_array_bounds_must_match_exactly(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            source = root / "mismatch.f90"
            source.write_text(
                """subroutine mismatch()
  implicit none
  real :: zero_based(0:2), one_based(1:3)
  equivalence (zero_based, one_based)
end subroutine mismatch
""",
                encoding="utf-8",
            )
            result = write_equivalence_alias_suggestions([source], [], root / "suggest")
            candidate = result.candidates[0]
            self.assertEqual(candidate.status, "blocked")
            self.assertTrue(any("lower bounds" in item for item in candidate.blockers))

    def test_named_common_whole_array_is_forced_as_representative(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            source = root / "common_array.f90"
            source.write_text(
                """subroutine common_array_step(value)
  implicit none
  real, intent(out) :: value
  real :: storage(0:2), storage_alias(0:2)
  common /state/ storage
  equivalence (storage, storage_alias)
  storage_alias = [1.0, 2.0, 3.0]
  value = sum(storage)
end subroutine common_array_step
""",
                encoding="utf-8",
            )
            result = write_equivalence_alias_suggestions([source], [], root / "suggest")
            candidate = result.candidates[0]
            self.assertEqual(candidate.status, "ready")
            self.assertEqual(candidate.alias_form, "whole-array")
            self.assertEqual(candidate.common_objects, ("storage",))
            self.assertEqual(candidate.allowed_representatives, ("storage",))

    def test_reviewed_plan_applies_compiles_and_preserves_result(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            source_root = root / "source"
            source_root.mkdir()
            source = source_root / "demo.f90"
            source.write_text(
                """program demo
  implicit none
  real :: primary, alias, result
  equivalence (primary, alias)
  primary = 2.0
  result = alias + 3.0
  print '(f4.1)', result
end program demo
""",
                encoding="utf-8",
            )
            original_exe = root / "original"
            subprocess.run(["gfortran", str(source), "-o", str(original_exe)], check=True)
            original_output = subprocess.check_output([str(original_exe)], text=True).strip()

            suggest_dir = root / "suggest"
            result = write_equivalence_alias_suggestions([source], [], suggest_dir)
            candidate = result.candidates[0]
            selection = self._approve(suggest_dir, candidate.candidate_id, "primary")
            plan_dir = root / "plan"
            suggestions = write_equivalence_alias_plan([source], [], selection, plan_dir)
            self.assertEqual(len(suggestions), 1)
            receipt = apply_plan(
                plan_dir,
                root / "applied",
                {candidate.candidate_id},
                False,
                True,
                [],
                True,
            )
            self.assertTrue(receipt["equivalence_alias_verification"][0]["equivalence_removed"])
            transformed = root / "applied" / "transformed_sources" / "demo.f90"
            text = transformed.read_text(encoding="utf-8").lower()
            self.assertNotIn("equivalence", text)
            self.assertNotRegex(text, r"\balias\b")
            self.assertIn("real :: primary, result", text)
            transformed_exe = root / "transformed"
            subprocess.run(["gfortran", str(transformed), "-o", str(transformed_exe)], check=True)
            transformed_output = subprocess.check_output([str(transformed_exe)], text=True).strip()
            self.assertEqual(transformed_output, original_output)
            self.assertEqual(transformed_output, "5.0")

    def test_named_common_object_is_forced_as_representative(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            source = root / "common.f90"
            source.write_text(
                """subroutine common_step(value)
  implicit none
  real, intent(out) :: value
  real :: storage, alias
  common /state/ storage
  equivalence (storage, alias)
  alias = 7.0
  value = storage
end subroutine common_step
""",
                encoding="utf-8",
            )
            result = write_equivalence_alias_suggestions([source], [], root / "suggest")
            candidate = result.candidates[0]
            self.assertEqual(candidate.status, "ready")
            self.assertEqual(candidate.common_objects, ("storage",))
            self.assertEqual(candidate.allowed_representatives, ("storage",))
            self.assertEqual(candidate.recommended_representative, "storage")

    def test_type_punning_array_subobject_and_common_to_common_are_blocked(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            source = root / "blocked.f90"
            source.write_text(
                """subroutine type_pun()
  implicit none
  real :: r
  integer :: i
  equivalence (r, i)
end subroutine type_pun

subroutine array_alias()
  implicit none
  real :: a(2), b
  equivalence (a(1), b)
end subroutine array_alias

subroutine common_alias()
  implicit none
  real :: a, b
  common /state/ a, b
  equivalence (a, b)
end subroutine common_alias
""",
                encoding="utf-8",
            )
            result = write_equivalence_alias_suggestions([source], [], root / "suggest")
            by_unit = {item.program_unit: item for item in result.candidates}
            self.assertEqual(by_unit["type_pun"].status, "blocked")
            self.assertTrue(any("identical type" in item for item in by_unit["type_pun"].blockers))
            self.assertEqual(by_unit["array_alias"].status, "blocked")
            self.assertTrue(any("subobjects" in item for item in by_unit["array_alias"].blockers))
            self.assertEqual(by_unit["common_alias"].status, "blocked")
            self.assertTrue(any("COMMON layout" in item for item in by_unit["common_alias"].blockers))

    def test_fixed_form_alias_removal_and_stale_selection_rejection(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            source = root / "demo.for"
            source.write_text(
                """      PROGRAM DEMO
      REAL A,B,R
      EQUIVALENCE (A,B)
      A=2.0
      R=B+3.0
      PRINT '(F4.1)',R
      END
""",
                encoding="utf-8",
            )
            suggest_dir = root / "suggest"
            result = write_equivalence_alias_suggestions([source], [], suggest_dir)
            candidate = result.candidates[0]
            self.assertEqual(candidate.status, "ready")
            selection = self._approve(suggest_dir, candidate.candidate_id, "a")
            plan_dir = root / "plan"
            write_equivalence_alias_plan([source], [], selection, plan_dir)
            transformed = plan_dir / "transformed_sources" / "demo.for"
            executable = root / "demo"
            subprocess.run(["gfortran", str(transformed), "-o", str(executable)], check=True)
            self.assertEqual(subprocess.check_output([str(executable)], text=True).strip(), "5.0")

            source.write_text(source.read_text(encoding="utf-8") + "C CHANGED\n", encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "selection is stale"):
                write_equivalence_alias_plan([source], [], selection, root / "stale-plan")

    def test_first_element_array_anchors_are_analysis_only(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            source = root / "anchor.f90"
            source.write_text(
                """subroutine anchor_step(value)
  implicit none
  real, intent(out) :: value
  real :: primary(0:2, 1:2), alias(0:2, 1:2)
  equivalence (primary(0,1), alias(0,1))
  primary = 1.0
  value = sum(alias)
end subroutine anchor_step
""",
                encoding="utf-8",
            )
            suggest_dir = root / "suggest"
            result = write_equivalence_alias_suggestions([source], [], suggest_dir)
            candidate = result.candidates[0]
            self.assertEqual(candidate.status, "analysis-only")
            self.assertEqual(candidate.alias_form, "array-element-anchor")
            self.assertEqual(candidate.object_expressions, ("primary(0, 1)", "alias(0, 1)"))
            self.assertEqual(candidate.anchor_subscripts, (("0", "1"), ("0", "1")))
            self.assertEqual(candidate.anchor_linear_offsets, (0, 0))
            self.assertEqual(candidate.anchor_first_elements, (True, True))
            self.assertEqual(candidate.total_elements, 6)
            self.assertEqual(candidate.analysis_mode, "review-only-first-element-anchor")
            self.assertEqual(result.summary["analysis_only_candidates"], 1)
            self.assertTrue((suggest_dir / "equivalence_element_anchor_candidates.json").exists())
            payload = json.loads((suggest_dir / "equivalence_element_anchor_candidates.json").read_text(encoding="utf-8"))
            self.assertEqual(payload["summary"]["analysis_only_candidates"], 1)
            self.assertEqual(payload["candidates"][0]["anchor_linear_offsets"], [0, 0])
            self.assertEqual(hashlib.sha256(source.read_bytes()).hexdigest(), candidate.source_sha256)

    def test_fixed_form_first_element_anchor_is_analysis_only(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            source = root / "anchor.for"
            source.write_text(
                """      SUBROUTINE ANCHOR_FIXED(VALUE)
      REAL VALUE,A(3),B(3)
      EQUIVALENCE (A(1),B(1))
      A(1)=1.0
      A(2)=2.0
      A(3)=3.0
      VALUE=B(1)+B(2)+B(3)
      END
""",
                encoding="utf-8",
            )
            result = write_equivalence_alias_suggestions([source], [], root / "suggest")
            candidate = result.candidates[0]
            self.assertEqual(candidate.source_form, "fixed")
            self.assertEqual(candidate.status, "analysis-only")
            self.assertEqual(candidate.anchor_linear_offsets, (0, 0))
            self.assertEqual(candidate.total_elements, 3)

    def test_nonfirst_or_symbolic_array_anchors_remain_blocked(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            source = root / "blocked_anchor.f90"
            source.write_text(
                """subroutine nonfirst()
  implicit none
  real :: a(0:2), b(0:2)
  equivalence (a(1), b(1))
end subroutine nonfirst

subroutine symbolic(n)
  implicit none
  integer, intent(in) :: n
  real :: a(0:n), b(0:n)
  equivalence (a(0), b(0))
end subroutine symbolic
""",
                encoding="utf-8",
            )
            result = write_equivalence_alias_suggestions([source], [], root / "suggest")
            by_unit = {item.program_unit: item for item in result.candidates}
            nonfirst = by_unit["nonfirst"]
            self.assertEqual(nonfirst.status, "blocked")
            self.assertEqual(nonfirst.anchor_linear_offsets, (1, 1))
            self.assertEqual(nonfirst.anchor_first_elements, (False, False))
            self.assertTrue(any("first storage element" in item for item in nonfirst.blockers))
            symbolic = by_unit["symbolic"]
            self.assertEqual(symbolic.status, "blocked")
            self.assertTrue(any("constant integer literals" in item for item in symbolic.blockers))

    def test_analysis_only_anchor_cannot_enter_plan(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            source = root / "anchor.f90"
            source.write_text(
                """subroutine anchor_step()
  implicit none
  real :: a(2), b(2)
  equivalence (a(1), b(1))
  a = b
end subroutine anchor_step
""",
                encoding="utf-8",
            )
            suggest_dir = root / "suggest"
            result = write_equivalence_alias_suggestions([source], [], suggest_dir)
            candidate = result.candidates[0]
            self.assertEqual(candidate.status, "analysis-only")
            selection = json.loads((suggest_dir / "equivalence_alias_selection.json").read_text(encoding="utf-8"))
            selection["reviewed"] = True
            for row in selection["selections"]:
                if row["candidate_id"] == candidate.candidate_id:
                    row["approved"] = True
                    row["regression_tests_reviewed"] = True
            reviewed = root / "reviewed.json"
            reviewed.write_text(json.dumps(selection), encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "is not applicable"):
                write_equivalence_alias_plan([source], [], reviewed, root / "plan")


    def test_first_element_anchor_emits_review_readiness_and_storage_evidence(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            source = root / "proof.f90"
            source.write_text(
                """subroutine proof_step(value)
  implicit none
  real, intent(out) :: value
  real :: primary(0:2, 1:2), alias(0:2, 1:2)
  equivalence (primary(0,1), alias(0,1))
  primary = 1.0
  value = sum(alias(:,1:2))
end subroutine proof_step
""",
                encoding="utf-8",
            )
            suggest_dir = root / "suggest"
            result = write_equivalence_alias_suggestions([source], [], suggest_dir)
            candidate = result.candidates[0]
            self.assertEqual(candidate.status, "analysis-only")
            self.assertEqual(candidate.review_readiness, "review-ready")
            self.assertEqual(candidate.element_storage_bytes, 4)
            self.assertEqual(candidate.total_storage_bytes, 24)
            self.assertIn("assumption", candidate.storage_size_basis)
            self.assertTrue(all(candidate.proof_checks.values()))
            self.assertEqual(candidate.promotion_blockers, ())
            self.assertEqual(candidate.reference_contexts["primary"]["assignment_target"], 1)
            self.assertEqual(candidate.reference_contexts["alias"]["array_section"], 1)
            self.assertEqual(result.summary["review_ready_anchor_candidates"], 1)
            payload = json.loads(
                (suggest_dir / "equivalence_element_anchor_candidates.json").read_text(encoding="utf-8")
            )
            self.assertEqual(payload["mode"], "analysis-only-proof-review")
            self.assertEqual(payload["summary"]["review_ready_candidates"], 1)

    def test_dual_reference_anchor_requires_manual_proof(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            source = root / "dual.f90"
            source.write_text(
                """subroutine dual_step(value)
  implicit none
  real, intent(out) :: value
  real :: a(2), b(2)
  equivalence (a(1), b(1))
  a = 1.0
  value = dot_product(a, b)
end subroutine dual_step
""",
                encoding="utf-8",
            )
            result = write_equivalence_alias_suggestions([source], [], root / "suggest")
            candidate = result.candidates[0]
            self.assertEqual(candidate.status, "analysis-only")
            self.assertEqual(candidate.review_readiness, "needs-manual-proof")
            self.assertTrue(candidate.simultaneous_reference_lines)
            self.assertFalse(candidate.proof_checks["no_same_statement_dual_reference"])
            self.assertTrue(any("same executable statement" in item for item in candidate.promotion_blockers))

    def test_common_anchor_records_layout_and_forces_common_representative(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            source = root / "common_anchor.f90"
            source.write_text(
                """subroutine common_anchor(value)
  implicit none
  real, intent(out) :: value
  integer :: flag
  real :: storage(0:2), alias(0:2)
  common /state/ flag, storage
  equivalence (storage(0), alias(0))
  storage = 2.0
  value = sum(alias)
end subroutine common_anchor
""",
                encoding="utf-8",
            )
            result = write_equivalence_alias_suggestions([source], [], root / "suggest")
            candidate = result.candidates[0]
            self.assertEqual(candidate.allowed_representatives, ("storage",))
            self.assertEqual(candidate.review_readiness, "review-ready")
            storage = candidate.common_layout["storage"]
            self.assertTrue(storage["member"])
            self.assertEqual(storage["block"], "state")
            self.assertEqual(storage["position"], 2)
            self.assertEqual(storage["packed_offset_bytes"], 4)
            self.assertEqual(storage["member_size_bytes"], 12)
            self.assertTrue(candidate.proof_checks["common_layout_preserved"])


    @unittest.skipUnless(shutil.which("gfortran"), "gfortran is required")
    def test_compiler_storage_size_probe_promotes_first_element_anchor_and_plan_applies(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            source = root / "anchor_probe.f90"
            source.write_text(
                """program anchor_probe
  implicit none
  real :: primary(0:2), alias(0:2)
  equivalence (primary(0), alias(0))
  primary = [1.0, 2.0, 3.0]
  print '(f4.1)', sum(alias)
end program anchor_probe
""",
                encoding="utf-8",
            )
            suggest_dir = root / "suggest"
            result = write_equivalence_alias_suggestions(
                [source], [], suggest_dir, storage_size_compiler="gfortran"
            )
            candidate = result.candidates[0]
            self.assertEqual(candidate.status, "ready")
            self.assertEqual(candidate.analysis_mode, "transformable-compiler-verified-first-element-anchor")
            self.assertTrue(candidate.storage_probe_verified)
            self.assertEqual(candidate.storage_probe_status, "verified")
            self.assertEqual(candidate.storage_probe_element_bits, (32, 32))
            self.assertEqual(candidate.storage_probe_element_bytes, 4)
            self.assertEqual(candidate.storage_probe_total_bytes, 12)
            self.assertTrue(candidate.proof_checks["compiler_storage_size_verified"])
            self.assertEqual(result.summary["compiler_verified_anchor_candidates"], 1)
            self.assertEqual(result.summary["transformable_anchor_candidates"], 1)
            self.assertTrue((suggest_dir / "storage_size_probe" / "probe_results.json").exists())

            selection = json.loads(
                (suggest_dir / "equivalence_alias_selection.json").read_text(encoding="utf-8")
            )
            selection["reviewed"] = True
            row = selection["selections"][0]
            row["approved"] = True
            row["representative"] = "primary"
            row["regression_tests_reviewed"] = True
            row["storage_size_probe_reviewed"] = True
            reviewed = root / "reviewed.json"
            reviewed.write_text(json.dumps(selection, indent=2) + "\n", encoding="utf-8")

            suggestions = write_equivalence_alias_plan([source], [], reviewed, root / "plan")
            self.assertEqual(len(suggestions), 1)
            self.assertTrue(suggestions[0].details["storage_probe_verified"])
            transformed = root / "plan" / "transformed_sources" / "anchor_probe.f90"
            text = transformed.read_text(encoding="utf-8").lower()
            self.assertNotIn("equivalence", text)
            self.assertNotRegex(text, r"\balias\b")
            executable = root / "anchor_probe"
            subprocess.run(["gfortran", str(transformed), "-o", str(executable)], check=True)
            self.assertEqual(subprocess.check_output([str(executable)], text=True).strip(), "6.0")

    @unittest.skipUnless(shutil.which("gfortran"), "gfortran is required")
    def test_compiler_verified_anchor_requires_explicit_probe_review(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            source = root / "review_gate.f90"
            source.write_text(
                """subroutine review_gate(value)
  implicit none
  real, intent(out) :: value
  real :: a(2), b(2)
  equivalence (a(1), b(1))
  a = 1.0
  value = sum(b)
end subroutine review_gate
""",
                encoding="utf-8",
            )
            suggest_dir = root / "suggest"
            result = write_equivalence_alias_suggestions(
                [source], [], suggest_dir, storage_size_compiler="gfortran"
            )
            candidate = result.candidates[0]
            self.assertEqual(candidate.status, "ready")
            selection = json.loads(
                (suggest_dir / "equivalence_alias_selection.json").read_text(encoding="utf-8")
            )
            selection["reviewed"] = True
            selection["selections"][0]["approved"] = True
            selection["selections"][0]["regression_tests_reviewed"] = True
            reviewed = root / "reviewed.json"
            reviewed.write_text(json.dumps(selection), encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "storage_size_probe_reviewed=true"):
                write_equivalence_alias_plan([source], [], reviewed, root / "plan")

    def test_missing_storage_size_compiler_keeps_anchor_analysis_only(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            source = root / "missing_compiler.f90"
            source.write_text(
                """subroutine missing_compiler(value)
  implicit none
  real, intent(out) :: value
  real :: a(2), b(2)
  equivalence (a(1), b(1))
  a = 1.0
  value = sum(b)
end subroutine missing_compiler
""",
                encoding="utf-8",
            )
            result = write_equivalence_alias_suggestions(
                [source], [], root / "suggest", storage_size_compiler="frt-no-such-compiler"
            )
            candidate = result.candidates[0]
            self.assertEqual(candidate.status, "analysis-only")
            self.assertFalse(candidate.storage_probe_verified)
            self.assertEqual(candidate.storage_probe_status, "compiler-not-found")
            self.assertEqual(result.summary["compiler_verified_anchor_candidates"], 0)

    @unittest.skipUnless(shutil.which("gfortran"), "gfortran is required")
    def test_manual_proof_anchor_is_not_promoted_by_storage_size_probe(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            source = root / "manual.f90"
            source.write_text(
                """subroutine manual(value)
  implicit none
  real, intent(out) :: value
  real :: a(2), b(2)
  equivalence (a(1), b(1))
  a = 1.0
  value = dot_product(a, b)
end subroutine manual
""",
                encoding="utf-8",
            )
            result = write_equivalence_alias_suggestions(
                [source], [], root / "suggest", storage_size_compiler="gfortran"
            )
            candidate = result.candidates[0]
            self.assertEqual(candidate.review_readiness, "needs-manual-proof")
            self.assertEqual(candidate.status, "analysis-only")
            self.assertFalse(candidate.storage_probe_verified)
            self.assertEqual(result.summary["transformable_anchor_candidates"], 0)


    @unittest.skipUnless(shutil.which("gfortran"), "gfortran is required")
    def test_storage_size_probe_matrix_consensus_promotes_and_applies(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            source = root / "matrix_anchor.f90"
            source.write_text(
                """program matrix_anchor
  implicit none
  real :: primary(0:2), alias(0:2)
  equivalence (primary(0), alias(0))
  primary = [1.0, 2.0, 3.0]
  print '(f4.1)', sum(alias)
end program matrix_anchor
""",
                encoding="utf-8",
            )
            config = root / "matrix.json"
            config.write_text(
                json.dumps(
                    {
                        "schema_version": 1,
                        "profiles": [
                            {"name": "gfortran-O0", "compiler": "gfortran", "flags": ["-O0"]},
                            {"name": "gfortran-O2", "compiler": "gfortran", "flags": ["-O2"]},
                        ],
                    },
                    indent=2,
                ) + "\n",
                encoding="utf-8",
            )
            suggest_dir = root / "suggest"
            result = write_equivalence_alias_suggestions(
                [source], [], suggest_dir, storage_size_matrix_config=config
            )
            candidate = result.candidates[0]
            self.assertEqual(candidate.status, "ready")
            self.assertTrue(candidate.storage_probe_matrix_consensus)
            self.assertEqual(
                candidate.storage_probe_matrix_verified_profiles,
                ("gfortran-O0", "gfortran-O2"),
            )
            self.assertEqual(candidate.storage_probe_element_bits, (32, 32))
            self.assertEqual(result.summary["matrix_consensus_anchor_candidates"], 1)
            matrix_report = json.loads(
                (suggest_dir / "storage_size_probe_matrix" / "matrix_results.json").read_text(
                    encoding="utf-8"
                )
            )
            self.assertEqual(matrix_report["consensus_candidates"], 1)

            selection = json.loads(
                (suggest_dir / "equivalence_alias_selection.json").read_text(encoding="utf-8")
            )
            selection["reviewed"] = True
            row = selection["selections"][0]
            row["approved"] = True
            row["representative"] = "primary"
            row["regression_tests_reviewed"] = True
            row["storage_size_probe_reviewed"] = True
            row["storage_size_probe_matrix_reviewed"] = True
            reviewed = root / "reviewed.json"
            reviewed.write_text(json.dumps(selection, indent=2) + "\n", encoding="utf-8")
            suggestions = write_equivalence_alias_plan([source], [], reviewed, root / "plan")
            self.assertEqual(len(suggestions), 1)
            self.assertTrue(suggestions[0].details["storage_probe_matrix_consensus"])
            transformed = root / "plan" / "transformed_sources" / source.name
            executable = root / "matrix_anchor"
            subprocess.run(["gfortran", str(transformed), "-o", str(executable)], check=True)
            self.assertEqual(subprocess.check_output([str(executable)], text=True).strip(), "6.0")

    @unittest.skipUnless(shutil.which("gfortran"), "gfortran is required")
    def test_storage_size_probe_matrix_requires_explicit_matrix_review(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            source = root / "review_matrix.f90"
            source.write_text(
                """subroutine review_matrix(value)
  implicit none
  real, intent(out) :: value
  real :: a(2), b(2)
  equivalence (a(1), b(1))
  a = 1.0
  value = sum(b)
end subroutine review_matrix
""",
                encoding="utf-8",
            )
            config = root / "matrix.json"
            config.write_text(
                json.dumps(
                    {
                        "profiles": [
                            {"name": "O0", "compiler": "gfortran", "flags": ["-O0"]},
                            {"name": "O2", "compiler": "gfortran", "flags": ["-O2"]},
                        ]
                    }
                ),
                encoding="utf-8",
            )
            suggest_dir = root / "suggest"
            write_equivalence_alias_suggestions(
                [source], [], suggest_dir, storage_size_matrix_config=config
            )
            selection = json.loads(
                (suggest_dir / "equivalence_alias_selection.json").read_text(encoding="utf-8")
            )
            selection["reviewed"] = True
            row = selection["selections"][0]
            row["approved"] = True
            row["regression_tests_reviewed"] = True
            row["storage_size_probe_reviewed"] = True
            reviewed = root / "reviewed.json"
            reviewed.write_text(json.dumps(selection), encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "storage_size_probe_matrix_reviewed=true"):
                write_equivalence_alias_plan([source], [], reviewed, root / "plan")

    @unittest.skipUnless(shutil.which("gfortran"), "gfortran is required")
    def test_storage_size_probe_matrix_detects_inconsistent_default_real_size(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            source = root / "matrix_conflict.f90"
            source.write_text(
                """subroutine matrix_conflict(value)
  implicit none
  real, intent(out) :: value
  real :: a(2), b(2)
  equivalence (a(1), b(1))
  a = 1.0
  value = sum(b)
end subroutine matrix_conflict
""",
                encoding="utf-8",
            )
            config = root / "matrix.json"
            config.write_text(
                json.dumps(
                    {
                        "profiles": [
                            {"name": "default-real", "compiler": "gfortran", "flags": ["-O0"]},
                            {"name": "default-real-8", "compiler": "gfortran", "flags": ["-O0", "-fdefault-real-8"]},
                        ]
                    }
                ),
                encoding="utf-8",
            )
            result = write_equivalence_alias_suggestions(
                [source], [], root / "suggest", storage_size_matrix_config=config
            )
            candidate = result.candidates[0]
            self.assertEqual(candidate.status, "analysis-only")
            self.assertFalse(candidate.storage_probe_matrix_consensus)
            self.assertIn(
                "STORAGE_SIZE matrix profiles reported inconsistent element or total sizes",
                candidate.promotion_blockers,
            )

    @unittest.skipUnless(shutil.which("gfortran"), "gfortran is required")
    def test_storage_size_probe_matrix_skips_missing_optional_compiler(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            source = root / "matrix_optional.f90"
            source.write_text(
                """subroutine matrix_optional(value)
  implicit none
  real, intent(out) :: value
  real :: a(2), b(2)
  equivalence (a(1), b(1))
  a = 1.0
  value = sum(b)
end subroutine matrix_optional
""",
                encoding="utf-8",
            )
            config = root / "matrix.json"
            config.write_text(
                json.dumps(
                    {
                        "profiles": [
                            {"name": "required", "compiler": "gfortran", "flags": ["-O0"]},
                            {"name": "optional-missing", "compiler": "frt-no-such-compiler", "required": False},
                        ]
                    }
                ),
                encoding="utf-8",
            )
            result = write_equivalence_alias_suggestions(
                [source], [], root / "suggest", storage_size_matrix_config=config
            )
            candidate = result.candidates[0]
            self.assertEqual(candidate.status, "ready")
            self.assertTrue(candidate.storage_probe_matrix_consensus)
            self.assertEqual(candidate.storage_probe_matrix_skipped_profiles, ("optional-missing",))

    def test_storage_size_probe_matrix_config_validation(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            source = root / "dummy.f90"
            source.write_text("program dummy\nend program dummy\n", encoding="utf-8")
            config = root / "bad.json"
            config.write_text(
                json.dumps(
                    {
                        "profiles": [
                            {"name": "same", "compiler": "gfortran"},
                            {"name": "same", "compiler": "gfortran"},
                        ]
                    }
                ),
                encoding="utf-8",
            )
            with self.assertRaisesRegex(ValueError, "duplicate STORAGE_SIZE matrix profile name"):
                write_equivalence_alias_suggestions(
                    [source], [], root / "suggest", storage_size_matrix_config=config
                )


if __name__ == "__main__":
    unittest.main()
