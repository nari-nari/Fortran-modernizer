import json
import shutil
import tempfile
import unittest
from pathlib import Path

from fortran_refactor.diagnostics import build_analysis_result
from fortran_refactor.extract import analyze_unit
from fortran_refactor.implicit_none import write_implicit_none_plan
from fortran_refactor.source import split_program_units


class ImplicitNonePlanTest(unittest.TestCase):
    def _analyze(self, source: Path, include_dir: Path):
        return build_analysis_result(
            [analyze_unit(unit, [include_dir]) for unit in split_program_units(source)]
        )

    def test_plan_blocks_unit_with_typo_and_previews_other_units(self):
        source = Path("samples/legacy_runnable/journal_bearing_legacy.for").resolve()
        include_dir = source.parent / "include"
        result = self._analyze(source, include_dir)

        with tempfile.TemporaryDirectory() as tmp_dir:
            output = Path(tmp_dir) / "plan"
            suggestions = write_implicit_none_plan(result, output)
            status = {item.program_unit: item.safety for item in suggestions}
            self.assertEqual(status["solve_reynolds"], "blocked")
            self.assertEqual(status["init_geometry"], "approval-required")
            self.assertTrue((output / "proposed_changes.patch").is_file())
            patch = (output / "proposed_changes.patch").read_text(encoding="utf-8")
            self.assertIn("+      IMPLICIT NONE", patch)
            self.assertNotIn("RESIDUALL", patch)

    def test_plan_after_typo_repair_declares_loop_indices(self):
        with tempfile.TemporaryDirectory() as tmp_dir:
            root = Path(tmp_dir) / "source"
            shutil.copytree("samples/legacy_runnable", root)
            source = root / "journal_bearing_legacy.for"
            text = source.read_text(encoding="utf-8").replace("RESIDUALL=RESIDUAL", "RESIDUAL=RESIDUAL")
            source.write_text(text, encoding="utf-8")
            result = self._analyze(source, root / "include")
            output = Path(tmp_dir) / "plan"
            suggestions = write_implicit_none_plan(result, output)
            solve = next(item for item in suggestions if item.program_unit == "solve_reynolds")
            self.assertEqual(solve.safety, "approval-required")
            declarations = solve.details["declarations"]
            self.assertEqual([item["name"] for item in declarations], ["i", "j"])
            payload = json.loads((output / "manifest.json").read_text(encoding="utf-8"))
            self.assertEqual(payload["kind"], "implicit-none-plan")


if __name__ == "__main__":
    unittest.main()
