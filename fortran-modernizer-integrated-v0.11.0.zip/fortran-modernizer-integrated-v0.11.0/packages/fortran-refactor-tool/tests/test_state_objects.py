from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path

from fortran_refactor.apply import ApplyError, apply_plan
from fortran_refactor.state_objects import write_state_object_plan, write_state_object_suggestions


STORAGE = """module shared_storage
  implicit none
  private
  public :: field, scale
  real, save :: field(4)
  real, save :: scale
end module shared_storage
"""

WORKERS = """module workers
  implicit none
contains
  subroutine initialize()
    use shared_storage, only: field, scale
    implicit none
    integer :: i
    scale = 2.0
    do i = 1, 4
      field(i) = scale * real(i)
    end do
  end subroutine initialize

  subroutine helper(total)
    use shared_storage, only: field
    implicit none
    real, intent(out) :: total
    total = sum(field)
  end subroutine helper

  subroutine driver(total)
    implicit none
    real, intent(out) :: total
    call helper(total)
  end subroutine driver
end module workers
"""

MAIN = """program demo
  use workers, only: initialize, driver
  implicit none
  real :: total
  call initialize()
  call driver(total)
  if (abs(total - 20.0) > 1.0e-6) error stop 1
end program demo
"""


class StateObjectTests(unittest.TestCase):
    def _tree(self, root: Path) -> list[Path]:
        src = root / "src"
        src.mkdir()
        (src / "shared_storage.f90").write_text(STORAGE, encoding="utf-8")
        (src / "workers.f90").write_text(WORKERS, encoding="utf-8")
        (src / "main.f90").write_text(MAIN, encoding="utf-8")
        return sorted(src.glob("*.f90"))

    def _config(self, root: Path, reviewed: bool) -> Path:
        path = root / "state_objects.json"
        path.write_text(
            json.dumps(
                {
                    "schema_version": 1,
                    "reviewed": reviewed,
                    "source_module": "shared_storage",
                    "types_module": "shared_data_types",
                    "types_file": "generated_types/shared_data_types.f90",
                    "objects": [
                        {"name": "parameters", "type_name": "shared_parameters_t", "variables": ["scale"]},
                        {"name": "state", "type_name": "shared_state_t", "variables": ["field"]},
                    ],
                },
                indent=2,
            ),
            encoding="utf-8",
        )
        return path

    def test_suggestion_is_unreviewed_and_records_evidence(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            files = self._tree(root)
            output = root / "suggest"
            draft = write_state_object_suggestions(files, [], "shared_storage", output)
            self.assertFalse(draft["reviewed"])
            assignment = {
                variable: item["name"]
                for item in draft["objects"]
                for variable in item["variables"]
            }
            self.assertEqual(assignment["field"], "state")
            self.assertEqual(assignment["scale"], "parameters")
            self.assertTrue((output / "shared_variable_evidence.csv").is_file())

    def test_unreviewed_config_is_rejected(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            files = self._tree(root)
            with self.assertRaises(ValueError):
                write_state_object_plan(files, [], self._config(root, False), root / "plan")

    def test_reviewed_plan_threads_objects_and_compiles(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            files = self._tree(root)
            plan = root / "plan"
            suggestions = write_state_object_plan(files, [], self._config(root, True), plan)
            self.assertEqual(suggestions[0].safety, "approval-required")
            with self.assertRaises(ApplyError):
                apply_plan(
                    plan,
                    root / "unapproved",
                    {"STATE-0001"},
                    all_automatic=False,
                    approve_review=False,
                    include_dirs=[],
                    run_compile_check=False,
                )
            receipt = apply_plan(
                plan,
                root / "applied",
                {"STATE-0001"},
                all_automatic=False,
                approve_review=True,
                include_dirs=[],
                run_compile_check=True,
            )
            transformed = Path(receipt["transformed_root"])
            worker_text = (transformed / "workers.f90").read_text(encoding="utf-8").lower()
            main_text = (transformed / "main.f90").read_text(encoding="utf-8").lower()
            types_text = (transformed / "generated_types/shared_data_types.f90").read_text(encoding="utf-8").lower()
            self.assertIn("subroutinehelper(total,state)", worker_text.replace(" ", ""))
            self.assertIn("subroutinedriver(total,state)", worker_text.replace(" ", ""))
            self.assertIn("callhelper(total,state)", worker_text.replace(" ", ""))
            self.assertIn("state%field", worker_text)
            self.assertIn("callinitialize(parameters,state)", main_text.replace(" ", ""))
            self.assertIn("type :: shared_state_t", types_text)
            self.assertTrue(receipt["state_object_verification"])
            self.assertEqual(receipt["compile_check"]["returncode"], 0)


if __name__ == "__main__":
    unittest.main()
