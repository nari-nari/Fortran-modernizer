from __future__ import annotations

import hashlib
import json
import subprocess
import tempfile
import unittest
from pathlib import Path

from fortran_refactor.apply import apply_plan
from fortran_refactor.public_api import write_public_api_plan, write_public_api_suggestions


class PublicApiTest(unittest.TestCase):
    @property
    def fixtures(self) -> Path:
        return Path(__file__).resolve().parents[1] / "samples" / "public_api"

    def test_builds_preserve_and_project_minimal_candidates(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            result = write_public_api_suggestions([self.fixtures], [], Path(temp))
        module = next(item for item in result.modules if item.module == "solver_services")
        self.assertFalse(module.private_default)
        self.assertIn("debug_scale", module.current_public_names)
        self.assertEqual(set(module.project_required_names), {"rk", "solve", "evaluate"})
        candidates = {item.strategy: item for item in result.candidates if item.module == "solver_services"}
        self.assertEqual(set(candidates), {"preserve-current", "project-minimal"})
        self.assertIn("internal_sum", candidates["project-minimal"].removed_public_names)
        self.assertEqual(set(candidates["project-minimal"].public_names), {"rk", "solve", "evaluate"})

    def test_reviewed_minimal_plan_applies_and_runs(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            suggest_dir = root / "suggest"
            write_public_api_suggestions([self.fixtures], [], suggest_dir)
            selection = json.loads((suggest_dir / "public_api_selection.json").read_text(encoding="utf-8"))
            selection["reviewed"] = True
            entry = next(item for item in selection["modules"] if item["module"] == "solver_services")
            entry["selected_candidate_id"] = "API-MINIMAL-solver-services"
            selection["modules"] = [entry]
            selection_path = root / "selection.json"
            selection_path.write_text(json.dumps(selection, indent=2) + "\n", encoding="utf-8")
            plan_dir = root / "plan"
            suggestions = write_public_api_plan([self.fixtures], [], selection_path, plan_dir)
            self.assertEqual(suggestions[0].safety, "approval-required")
            receipt = apply_plan(
                plan_dir,
                root / "applied",
                {"API-0001"},
                False,
                True,
                [],
                True,
            )
            self.assertEqual(receipt["public_api_verification"][0]["public_names"], ["evaluate", "rk", "solve"])
            transformed = root / "applied" / "transformed_sources"
            build = root / "build"
            build.mkdir()
            executable = build / "demo"
            subprocess.run(
                [
                    "gfortran", "-J", str(build), "-I", str(build),
                    str(transformed / "solver_services.f90"),
                    str(transformed / "client.f90"),
                    str(transformed / "main.f90"),
                    "-o", str(executable),
                ],
                check=True,
                capture_output=True,
                text=True,
            )
            output = subprocess.check_output([str(executable)], text=True).strip()
            self.assertEqual(output, "10.000")

    def test_unrestricted_consumer_blocks_minimal_candidate(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            (root / "m.f90").write_text(
                "module m\nimplicit none\ninteger :: x, y\nend module m\n", encoding="utf-8"
            )
            (root / "p.f90").write_text(
                "program p\nuse m\nimplicit none\nprint *, x\nend program p\n", encoding="utf-8"
            )
            result = write_public_api_suggestions([root], [], root / "report")
        candidate = next(item for item in result.candidates if item.strategy == "project-minimal")
        self.assertEqual(candidate.safety, "blocked")
        self.assertTrue(any("unrestricted project consumers" in item for item in candidate.blockers))

    def test_suggestion_does_not_modify_source(self) -> None:
        before = {path: hashlib.sha256(path.read_bytes()).hexdigest() for path in self.fixtures.glob("*.f90")}
        with tempfile.TemporaryDirectory() as temp:
            result = write_public_api_suggestions([self.fixtures], [], Path(temp))
            self.assertEqual(result.summary["source_modifications"], 0)
        after = {path: hashlib.sha256(path.read_bytes()).hexdigest() for path in self.fixtures.glob("*.f90")}
        self.assertEqual(before, after)


if __name__ == "__main__":
    unittest.main()
