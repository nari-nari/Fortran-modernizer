import json
import tempfile
import time
import unittest
from pathlib import Path

from fortran_refactor.project import ProjectConfigError, initialize_project, load_project_config
from fortran_refactor.project_assessment import assess_project, inspect_includes


class ProjectAssessmentTest(unittest.TestCase):
    def test_project_init_writes_reviewable_configuration(self):
        with tempfile.TemporaryDirectory() as tmp_dir:
            root = Path(tmp_dir) / "legacy"
            (root / "include").mkdir(parents=True)
            (root / "include" / "grid.inc").write_text("      INTEGER N\n", encoding="utf-8")
            (root / "main.for").write_text("      PROGRAM MAIN\n      END\n", encoding="utf-8")
            output = Path(tmp_dir) / "fortran-refactor.json"
            config = initialize_project(root, output)
            self.assertEqual(config["schema_version"], 1)
            self.assertIn("include", config["fortran"]["include_dirs"])
            loaded = load_project_config(output)
            self.assertEqual(loaded.root, root.resolve())
            with self.assertRaises(ProjectConfigError):
                initialize_project(root, output)

    def test_sample_project_assessment_writes_intake_bundle(self):
        config = Path("samples/config/lubrication_project.json").resolve()
        with tempfile.TemporaryDirectory() as tmp_dir:
            output = Path(tmp_dir) / "assessment"
            outcome = assess_project(config, output, run_compile=False)
            self.assertEqual(outcome.payload["inventory"]["source_files"], 1)
            self.assertEqual(outcome.payload["inventory"]["program_units"], 5)
            self.assertEqual(outcome.payload["parseability"]["failure"], 0)
            self.assertEqual(outcome.payload["frontend"]["lexical_fallback_units"], 0)
            self.assertGreater(outcome.payload["frontend"]["ast_fact_count"], 0)
            expected = {
                "assessment.json",
                "summary.md",
                "source_inventory.csv",
                "include_inventory.csv",
                "syntax_inventory.csv",
                "program_unit_capabilities.csv",
                "transformation_readiness.csv",
                "recommended_pipeline.json",
                "recommended_pipeline.md",
                "shareable_summary.json",
                "shareable_summary.md",
            }
            self.assertLessEqual(expected, {item.name for item in output.iterdir()})
            shareable = (output / "shareable_summary.json").read_text(encoding="utf-8")
            self.assertNotIn(str(outcome.project.root), shareable)
            self.assertNotIn("RESIDUALL =", shareable)
            stages = json.loads((output / "recommended_pipeline.json").read_text(encoding="utf-8"))["stages"]
            self.assertEqual(stages[0]["id"], "00-intake")
            intent_stage = next(stage for stage in stages if stage["id"] == "80-intent")
            self.assertIn(intent_stage["status"], {"ready", "blocked", "not-needed"})
            lifecycle_stage = next(stage for stage in stages if stage["id"] == "97-state-lifecycle")
            self.assertIn(lifecycle_stage["status"], {"ready", "blocked", "not-needed"})
            responsibility_stage = next(stage for stage in stages if stage["id"] == "100-responsibility-separation")
            self.assertIn(responsibility_stage["status"], {"ready", "blocked", "not-needed"})
            kind_stage = next(stage for stage in stages if stage["id"] == "120-kind-standardization")
            self.assertIn(kind_stage["status"], {"ready", "blocked", "not-needed"})
            self.assertEqual(stages[-1]["id"], "140-array-interfaces")
            self.assertIn(stages[-1]["status"], {"ready", "blocked", "not-needed"})

    def test_missing_include_is_a_blocker(self):
        with tempfile.TemporaryDirectory() as tmp_dir:
            root = Path(tmp_dir)
            (root / "broken.for").write_text(
                "      PROGRAM BROKEN\n"
                "      INCLUDE 'missing.inc'\n"
                "      END\n",
                encoding="utf-8",
            )
            config_path = root / "fortran-refactor.json"
            config_path.write_text(
                json.dumps(
                    {
                        "schema_version": 1,
                        "project": {"name": "broken", "root": "."},
                        "sources": {"paths": ["."], "include_globs": ["**/*.for"], "exclude_globs": []},
                        "fortran": {"include_dirs": [], "fixed_line_length": 72},
                        "compiler": {"enabled": False},
                        "regression": {"enabled": False},
                        "assessment": {"performance_budget_seconds": 60.0},
                    }
                ),
                encoding="utf-8",
            )
            project = load_project_config(config_path)
            records = inspect_includes([root / "broken.for"], project)
            self.assertEqual(records[0].status, "missing")
            outcome = assess_project(config_path, root / "reports", run_compile=False)
            self.assertGreater(outcome.blockers, 0)
            intake = outcome.payload["stage_readiness"][0]
            self.assertEqual(intake["status"], "blocked")

    def test_absoft_compatibility_constructs_and_compiler_profile_are_reported(self):
        with tempfile.TemporaryDirectory() as tmp_dir:
            root = Path(tmp_dir)
            (root / "compat.for").write_text(
                "      MODULE TYPES_MOD\n"
                "      TYPE ITEM_T\n"
                "      INTEGER VALUE\n"
                "      END TYPE ITEM_T\n"
                "      END MODULE TYPES_MOD\n"
                "      SUBROUTINE TOUCH(ITEM,WORK$1)\n"
                "      USE TYPES_MOD\n"
                "      TYPE(ITEM_T) ITEM\n"
                "      INTEGER WORK$1\n"
                "      ITEM.VALUE = WORK$1\n"
                "      END\n",
                encoding="utf-8",
            )
            config_path = root / "fortran-refactor.json"
            config_path.write_text(
                json.dumps(
                    {
                        "schema_version": 1,
                        "project": {"name": "absoft", "root": "."},
                        "sources": {"paths": ["."], "include_globs": ["**/*.for"], "exclude_globs": []},
                        "fortran": {"include_dirs": [], "fixed_line_length": 72},
                        "compiler": {"enabled": False, "profile": "absoft-compat"},
                        "regression": {"enabled": False},
                        "assessment": {"performance_budget_seconds": 60.0},
                    }
                ),
                encoding="utf-8",
            )
            outcome = assess_project(config_path, root / "reports", run_compile=False)
            self.assertEqual(outcome.payload["compiler"]["profile"], "absoft-compat")
            self.assertGreaterEqual(outcome.payload["constructs"].get("dot_component", 0), 1)
            self.assertGreaterEqual(outcome.payload["constructs"].get("dollar_identifier", 0), 1)
            self.assertEqual(outcome.payload["frontend"]["lexical_fallback_units"], 0)

    def test_scale_fixture_10000_lines_80_units_within_budget(self):
        with tempfile.TemporaryDirectory() as tmp_dir:
            root = Path(tmp_dir)
            total_lines = 0
            for file_index in range(4):
                lines = []
                for local_index in range(20):
                    number = file_index * 20 + local_index + 1
                    lines.extend(
                        [
                            f"      SUBROUTINE SCALE_{number:03d}(X)\n",
                            "      IMPLICIT NONE\n",
                            "      DOUBLE PRECISION X\n",
                        ]
                    )
                    lines.extend(f"C     SCALE FILLER {number:03d} {item:03d}\n" for item in range(120))
                    lines.extend(["      X = X + 1.0D0\n", "      RETURN\n", "      END\n"])
                path = root / f"legacy_{file_index + 1}.for"
                path.write_text("".join(lines), encoding="utf-8")
                total_lines += len(lines)
            self.assertGreaterEqual(total_lines, 10000)
            config_path = root / "fortran-refactor.json"
            config_path.write_text(
                json.dumps(
                    {
                        "schema_version": 1,
                        "project": {"name": "scale-80", "root": "."},
                        "sources": {"paths": ["."], "include_globs": ["**/*.for"], "exclude_globs": []},
                        "fortran": {"include_dirs": [], "fixed_line_length": 72},
                        "compiler": {"enabled": False},
                        "regression": {"enabled": False},
                        "assessment": {"performance_budget_seconds": 60.0},
                    }
                ),
                encoding="utf-8",
            )
            started = time.perf_counter()
            outcome = assess_project(config_path, root / "reports", run_compile=False)
            wall_time = time.perf_counter() - started
            self.assertEqual(outcome.payload["inventory"]["source_files"], 4)
            self.assertEqual(outcome.payload["inventory"]["program_units"], 80)
            self.assertGreaterEqual(outcome.payload["inventory"]["source_lines"], 10000)
            self.assertEqual(outcome.payload["parseability"]["success"], 80)
            self.assertLess(wall_time, 60.0)
            self.assertEqual(outcome.payload["performance"]["status"], "pass")


if __name__ == "__main__":
    unittest.main()
