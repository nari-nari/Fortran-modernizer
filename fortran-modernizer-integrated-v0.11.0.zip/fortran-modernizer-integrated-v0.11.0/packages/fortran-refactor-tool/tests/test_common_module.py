import json
import shutil
import tempfile
import unittest
from pathlib import Path

from fortran_refactor.apply import ApplyError, apply_plan
from fortran_refactor.common_include import write_common_include_plan
from fortran_refactor.common_module import write_common_module_plan
from fortran_refactor.diagnostics import build_analysis_result
from fortran_refactor.extract import analyze_unit
from fortran_refactor.implicit_none import write_implicit_none_plan
from fortran_refactor.source import discover_fortran_files, split_program_units
from fortran_refactor.suggestions import write_suggestions


class CommonModulePlanTest(unittest.TestCase):
    def _analyze_tree(self, root: Path, include_dirs: list[Path]):
        return build_analysis_result(
            [
                analyze_unit(unit, include_dirs)
                for source in discover_fortran_files([root])
                for unit in split_program_units(source)
            ]
        )

    def _prepare_centralized_tree(self, base: Path) -> Path:
        source_root = base / "source"
        shutil.copytree("samples/legacy_runnable", source_root)
        include_dir = source_root / "include"

        typo_plan = base / "typo-plan"
        write_suggestions(self._analyze_tree(source_root, [include_dir]), typo_plan)
        stage1 = apply_plan(
            typo_plan,
            base / "stage1",
            selected_ids=set(),
            all_automatic=True,
            approve_review=False,
            include_dirs=[include_dir],
            run_compile_check=False,
        )
        stage1_root = Path(stage1["transformed_root"])

        implicit_plan = base / "implicit-plan"
        implicit_items = write_implicit_none_plan(
            self._analyze_tree(stage1_root, [stage1_root / "include"]), implicit_plan
        )
        implicit_ids = {item.id for item in implicit_items if item.safety == "approval-required"}
        stage2 = apply_plan(
            implicit_plan,
            base / "stage2",
            selected_ids=implicit_ids,
            all_automatic=False,
            approve_review=True,
            include_dirs=[stage1_root / "include"],
            run_compile_check=False,
        )
        stage2_root = Path(stage2["transformed_root"])

        common_plan = base / "common-plan"
        common_items = write_common_include_plan(
            self._analyze_tree(stage2_root, [stage2_root / "include"]), common_plan
        )
        common_ids = {item.id for item in common_items if item.safety == "approval-required"}
        stage3 = apply_plan(
            common_plan,
            base / "stage3",
            selected_ids=common_ids,
            all_automatic=False,
            approve_review=True,
            include_dirs=[stage2_root / "include"],
            run_compile_check=False,
        )
        return Path(stage3["transformed_root"])

    def test_plan_generates_module_and_minimal_use_only_lists(self):
        with tempfile.TemporaryDirectory() as tmp_dir:
            base = Path(tmp_dir)
            stage3 = self._prepare_centralized_tree(base)
            include_dirs = [stage3 / "include", stage3 / "generated_common"]
            plan = base / "module-plan"
            items = write_common_module_plan(
                self._analyze_tree(stage3, include_dirs),
                plan,
                include_dirs=include_dirs,
            )
            self.assertEqual(len(items), 1)
            item = items[0]
            self.assertEqual(item.safety, "approval-required")
            self.assertEqual(item.details["module_name"], "field_common_module")
            self.assertEqual(item.details["dependency_includes"], ["legacy_grid.inc"])
            self.assertEqual(item.details["use_lines_by_program_unit"]["journal_bearing_legacy"], "")
            self.assertIn(
                "ONLY: H, THETA",
                item.details["use_lines_by_program_unit"]["init_geometry"],
            )
            module = plan / "transformed_sources/generated_modules/field_common_module.f90"
            self.assertTrue(module.is_file())
            module_text = module.read_text(encoding="utf-8").lower()
            self.assertIn("module field_common_module", module_text)
            self.assertIn("include 'legacy_grid.inc'", module_text)
            self.assertNotIn("common /field/", module_text)
            old_include = plan / "transformed_sources/generated_common/field_common.inc"
            self.assertNotIn("common /field/", old_include.read_text(encoding="utf-8").lower())

    def test_apply_requires_approval_and_removes_selected_common(self):
        with tempfile.TemporaryDirectory() as tmp_dir:
            base = Path(tmp_dir)
            stage3 = self._prepare_centralized_tree(base)
            include_dirs = [stage3 / "include", stage3 / "generated_common"]
            plan = base / "module-plan"
            write_common_module_plan(
                self._analyze_tree(stage3, include_dirs),
                plan,
                include_dirs=include_dirs,
            )
            with self.assertRaises(ApplyError):
                apply_plan(
                    plan,
                    base / "unapproved",
                    selected_ids={"MOD-0001"},
                    all_automatic=False,
                    approve_review=False,
                    include_dirs=include_dirs,
                    run_compile_check=False,
                )

            receipt = apply_plan(
                plan,
                base / "applied",
                selected_ids={"MOD-0001"},
                all_automatic=False,
                approve_review=True,
                include_dirs=include_dirs,
                run_compile_check=True,
            )
            transformed = Path(receipt["transformed_root"])
            self.assertEqual(receipt["fparser_success"], receipt["fparser_program_units"])
            self.assertEqual(receipt["remaining_selected_module_common_entries"], 0)
            self.assertTrue((transformed / "generated_modules/field_common_module.f90").is_file())
            source_text = (transformed / "journal_bearing_legacy.for").read_text(encoding="utf-8").lower()
            self.assertNotIn("include 'field_common.inc'", source_text)
            self.assertIn("use field_common_module, only: h, theta", source_text)
            include_text = (transformed / "generated_common/field_common.inc").read_text(encoding="utf-8").lower()
            self.assertNotIn("common /field/", include_text)
            self.assertEqual(receipt["compile_check"]["returncode"], 0)

    def test_noncentralized_common_is_blocked(self):
        source = Path("samples/legacy_runnable").resolve()
        include_dirs = [source / "include"]
        with tempfile.TemporaryDirectory() as tmp_dir:
            items = write_common_module_plan(
                self._analyze_tree(source, include_dirs),
                Path(tmp_dir) / "plan",
                include_dirs=include_dirs,
            )
            self.assertEqual(items[0].safety, "blocked")
            self.assertIn("common-include-plan", items[0].rationale.lower())


if __name__ == "__main__":
    unittest.main()
