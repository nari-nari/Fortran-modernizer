import unittest
from pathlib import Path
from unittest.mock import patch

import fortran_refactor.extract as extract_module
from fortran_refactor.diagnostics import build_analysis_result
from fortran_refactor.models import ParseResult
from fortran_refactor.source import split_program_units


def _analyze(path: str):
    units = [
        extract_module.analyze_unit(unit, [])
        for unit in split_program_units(Path(path).resolve())
    ]
    return build_analysis_result(units)


class CallInterfaceDiagnosticsTest(unittest.TestCase):
    @patch.object(
        extract_module,
        "parse_with_fparser",
        side_effect=lambda unit, include_dirs: ParseResult(True, "test-parser", None, 1),
    )
    def test_type_mismatch(self, _mock_parser):
        result = _analyze("samples/diagnostic_fixtures/call_argument_type_mismatch.for")
        codes = [diagnostic.code for diagnostic in result.diagnostics]
        self.assertEqual(codes, ["CALL_ARGUMENT_TYPE_MISMATCH"])

    @patch.object(
        extract_module,
        "parse_with_fparser",
        side_effect=lambda unit, include_dirs: ParseResult(True, "test-parser", None, 1),
    )
    def test_kind_mismatch(self, _mock_parser):
        result = _analyze("samples/diagnostic_fixtures/call_argument_kind_mismatch.for")
        codes = [diagnostic.code for diagnostic in result.diagnostics]
        self.assertEqual(codes, ["CALL_ARGUMENT_KIND_MISMATCH"])

    @patch.object(
        extract_module,
        "parse_with_fparser",
        side_effect=lambda unit, include_dirs: ParseResult(True, "test-parser", None, 1),
    )
    def test_rank_mismatch(self, _mock_parser):
        result = _analyze("samples/diagnostic_fixtures/call_argument_rank_mismatch.for")
        codes = [diagnostic.code for diagnostic in result.diagnostics]
        self.assertEqual(codes, ["CALL_ARGUMENT_RANK_MISMATCH"])

    @patch.object(
        extract_module,
        "parse_with_fparser",
        side_effect=lambda unit, include_dirs: ParseResult(True, "test-parser", None, 1),
    )
    def test_valid_scalar_and_array_calls(self, _mock_parser):
        result = _analyze("samples/diagnostic_fixtures/call_argument_valid.for")
        call_errors = [
            diagnostic for diagnostic in result.diagnostics
            if diagnostic.code.startswith("CALL_")
        ]
        self.assertEqual(call_errors, [])


if __name__ == "__main__":
    unittest.main()
