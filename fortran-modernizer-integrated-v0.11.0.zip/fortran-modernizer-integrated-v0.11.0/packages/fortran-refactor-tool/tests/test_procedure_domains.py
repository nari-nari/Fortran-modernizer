import json
import tempfile
import unittest
from pathlib import Path

from fortran_refactor.apply import ApplyError, apply_plan
from fortran_refactor.diagnostics import build_analysis_result
from fortran_refactor.extract import analyze_unit
from fortran_refactor.procedure_domains import write_procedure_domain_plan
from fortran_refactor.source import discover_fortran_files, split_program_units


class ProcedureDomainPlanTest(unittest.TestCase):
    def _analyze_tree(self, root: Path):
        return build_analysis_result(
            [
                analyze_unit(unit, [])
                for source in discover_fortran_files([root])
                for unit in split_program_units(source)
            ]
        )

    def _write_graph_sample(self, root: Path) -> Path:
        root.mkdir(parents=True, exist_ok=True)
        source = root / "graph.for"
        source.write_text(
            "      PROGRAM GRAPH_DEMO\n"
            "      IMPLICIT NONE\n"
            "      CALL ALPHA\n"
            "      CALL DELTA\n"
            "      END\n"
            "      SUBROUTINE ALPHA\n"
            "      IMPLICIT NONE\n"
            "      CALL BETA\n"
            "      END\n"
            "      SUBROUTINE BETA\n"
            "      IMPLICIT NONE\n"
            "      END\n"
            "      SUBROUTINE GAMMA\n"
            "      IMPLICIT NONE\n"
            "      CALL BETA\n"
            "      END\n"
            "      SUBROUTINE DELTA\n"
            "      IMPLICIT NONE\n"
            "      END\n",
            encoding="utf-8",
        )
        return source

    def _write_config(self, path: Path, payload: dict) -> Path:
        path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
        return path

    def test_explicit_and_pattern_rules_create_named_domain_modules(self):
        with tempfile.TemporaryDirectory() as tmp_dir:
            base = Path(tmp_dir)
            root = base / "source"
            self._write_graph_sample(root)
            config = self._write_config(
                base / "domains.json",
                {
                    "schema_version": 1,
                    "unclassified": {"policy": "block"},
                    "domains": [
                        {
                            "name": "workflow",
                            "module_prefix": "workflow_procedures",
                            "procedures": ["alpha"],
                            "patterns": ["^gamma$"],
                        },
                        {
                            "name": "kernel",
                            "module_prefix": "kernel_procedures",
                            "procedures": ["beta", "delta"],
                        },
                    ],
                },
            )
            plan = base / "plan"
            item = write_procedure_domain_plan(
                self._analyze_tree(root), plan, config
            )[0]
            self.assertEqual(item.safety, "approval-required")
            mapping = item.details["procedure_to_module"]
            self.assertEqual(mapping["alpha"], "workflow_procedures_module")
            self.assertEqual(mapping["gamma"], "workflow_procedures_module")
            self.assertEqual(mapping["beta"], "kernel_procedures_module")
            workflow = next(
                group for group in item.details["module_groups"]
                if group["domain"] == "workflow"
            )
            self.assertEqual(
                workflow["dependencies"],
                {"kernel_procedures_module": ["beta"]},
            )
            generated = (
                plan
                / "transformed_sources/generated_modules/workflow_procedures_module.for"
            ).read_text(encoding="utf-8").lower()
            self.assertIn("use kernel_procedures_module, only: beta", generated)
            assignment = json.loads(
                (plan / "domain_assignment.json").read_text(encoding="utf-8")
            )
            self.assertEqual(assignment["status"], "approval-required")
            self.assertTrue((plan / "domain_assignment.csv").is_file())
            self.assertTrue((plan / "domain_dependencies.dot").is_file())
            self.assertTrue((plan / "classification_snapshot.json").is_file())

    def test_explicit_assignment_takes_precedence_over_pattern(self):
        with tempfile.TemporaryDirectory() as tmp_dir:
            base = Path(tmp_dir)
            root = base / "source"
            self._write_graph_sample(root)
            config = self._write_config(
                base / "domains.json",
                {
                    "domains": [
                        {
                            "name": "explicit_domain",
                            "module_prefix": "explicit_group",
                            "procedures": ["alpha", "beta", "gamma", "delta"],
                        },
                        {
                            "name": "pattern_domain",
                            "module_prefix": "pattern_group",
                            "patterns": ["^alpha$"],
                        },
                    ]
                },
            )
            item = write_procedure_domain_plan(
                self._analyze_tree(root), base / "plan", config
            )[0]
            self.assertEqual(item.safety, "approval-required")
            row = next(row for row in item.details["assignments"] if row["procedure"] == "alpha")
            self.assertEqual(row["domain"], "explicit_domain")
            self.assertEqual(row["assignment_source"], "explicit")

    def test_ambiguous_pattern_match_is_blocked(self):
        with tempfile.TemporaryDirectory() as tmp_dir:
            base = Path(tmp_dir)
            root = base / "source"
            root.mkdir()
            (root / "ambiguous.for").write_text(
                "      PROGRAM DEMO\n"
                "      IMPLICIT NONE\n"
                "      CALL SOLVE_MAIN\n"
                "      END\n"
                "      SUBROUTINE SOLVE_MAIN\n"
                "      IMPLICIT NONE\n"
                "      END\n",
                encoding="utf-8",
            )
            config = self._write_config(
                base / "domains.json",
                {
                    "domains": [
                        {"name": "solver", "module_prefix": "solver", "patterns": ["^solve_"]},
                        {"name": "main", "module_prefix": "main_steps", "patterns": ["main$"]},
                    ]
                },
            )
            item = write_procedure_domain_plan(
                self._analyze_tree(root), base / "plan", config
            )[0]
            self.assertEqual(item.safety, "blocked")
            self.assertIn("solve_main", item.details["ambiguous_matches"])
            self.assertIn("multiple functional domains", item.rationale)

    def test_recursive_scc_cannot_cross_domains(self):
        with tempfile.TemporaryDirectory() as tmp_dir:
            base = Path(tmp_dir)
            root = base / "source"
            root.mkdir()
            (root / "cycle.for").write_text(
                "      PROGRAM DEMO\n"
                "      IMPLICIT NONE\n"
                "      CALL LEFT\n"
                "      END\n"
                "      SUBROUTINE LEFT\n"
                "      IMPLICIT NONE\n"
                "      CALL RIGHT\n"
                "      END\n"
                "      SUBROUTINE RIGHT\n"
                "      IMPLICIT NONE\n"
                "      CALL LEFT\n"
                "      END\n",
                encoding="utf-8",
            )
            config = self._write_config(
                base / "domains.json",
                {
                    "domains": [
                        {"name": "left_domain", "module_prefix": "left_group", "procedures": ["left"]},
                        {"name": "right_domain", "module_prefix": "right_group", "procedures": ["right"]},
                    ]
                },
            )
            item = write_procedure_domain_plan(
                self._analyze_tree(root), base / "plan", config
            )[0]
            self.assertEqual(item.safety, "blocked")
            self.assertTrue(item.details["cross_domain_sccs"])
            self.assertIn("mutually recursive", item.rationale)

    def test_domain_dependency_cycle_is_blocked(self):
        with tempfile.TemporaryDirectory() as tmp_dir:
            base = Path(tmp_dir)
            root = base / "source"
            root.mkdir()
            (root / "domain_cycle.for").write_text(
                "      PROGRAM DEMO\n"
                "      IMPLICIT NONE\n"
                "      CALL A1\n"
                "      CALL B2\n"
                "      END\n"
                "      SUBROUTINE A1\n"
                "      IMPLICIT NONE\n"
                "      CALL B1\n"
                "      END\n"
                "      SUBROUTINE A2\n"
                "      IMPLICIT NONE\n"
                "      END\n"
                "      SUBROUTINE B1\n"
                "      IMPLICIT NONE\n"
                "      END\n"
                "      SUBROUTINE B2\n"
                "      IMPLICIT NONE\n"
                "      CALL A2\n"
                "      END\n",
                encoding="utf-8",
            )
            config = self._write_config(
                base / "domains.json",
                {
                    "domains": [
                        {"name": "domain_a", "module_prefix": "domain_a", "procedures": ["a1", "a2"]},
                        {"name": "domain_b", "module_prefix": "domain_b", "procedures": ["b1", "b2"]},
                    ]
                },
            )
            item = write_procedure_domain_plan(
                self._analyze_tree(root), base / "plan", config
            )[0]
            self.assertEqual(item.safety, "blocked")
            self.assertTrue(item.details["domain_cycle"])
            self.assertIn("cyclic module dependency", item.rationale)

    def test_large_domain_is_split_by_its_own_size_target(self):
        with tempfile.TemporaryDirectory() as tmp_dir:
            base = Path(tmp_dir)
            root = base / "source"
            self._write_graph_sample(root)
            config = self._write_config(
                base / "domains.json",
                {
                    "domains": [
                        {
                            "name": "all_steps",
                            "module_prefix": "all_steps",
                            "procedures": ["alpha", "beta", "gamma", "delta"],
                            "max_procedures_per_module": 2,
                        }
                    ]
                },
            )
            item = write_procedure_domain_plan(
                self._analyze_tree(root), base / "plan", config
            )[0]
            self.assertEqual(item.safety, "approval-required")
            self.assertEqual(len(item.details["module_groups"]), 2)
            self.assertEqual(
                {group["domain"] for group in item.details["module_groups"]},
                {"all_steps"},
            )
            self.assertTrue(
                all(group["procedure_count"] <= 2 for group in item.details["module_groups"])
            )

    def test_apply_requires_approval_and_compiles_domain_modules(self):
        with tempfile.TemporaryDirectory() as tmp_dir:
            base = Path(tmp_dir)
            root = base / "source"
            self._write_graph_sample(root)
            config = self._write_config(
                base / "domains.json",
                {
                    "domains": [
                        {
                            "name": "workflow",
                            "module_prefix": "workflow_procedures",
                            "procedures": ["alpha", "gamma"],
                        },
                        {
                            "name": "kernel",
                            "module_prefix": "kernel_procedures",
                            "procedures": ["beta", "delta"],
                        },
                    ]
                },
            )
            plan = base / "plan"
            write_procedure_domain_plan(self._analyze_tree(root), plan, config)
            with self.assertRaises(ApplyError):
                apply_plan(
                    plan,
                    base / "unapproved",
                    selected_ids={"DOMAIN-0001"},
                    all_automatic=False,
                    approve_review=False,
                    include_dirs=[],
                    run_compile_check=False,
                )
            receipt = apply_plan(
                plan,
                base / "applied",
                selected_ids={"DOMAIN-0001"},
                all_automatic=False,
                approve_review=True,
                include_dirs=[],
                run_compile_check=True,
            )
            self.assertEqual(receipt["remaining_external_procedures"], [])
            self.assertEqual(receipt["missing_procedure_modules"], [])
            self.assertEqual(receipt["missing_explicit_uses"], [])
            self.assertEqual(receipt["compile_check"]["returncode"], 0)


if __name__ == "__main__":
    unittest.main()
