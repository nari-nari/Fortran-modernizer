import shutil
import unittest
from pathlib import Path

from fortran_refactor.compiler import verify_sample


@unittest.skipIf(shutil.which("gfortran") is None, "gfortran is required")
class RegressionSampleTest(unittest.TestCase):
    def test_reference_and_legacy_results_match(self):
        result = verify_sample(Path("."))
        self.assertTrue(all(value == 0.0 for value in result["absolute_differences"].values()))
        self.assertGreater(result["values"]["max_pressure"], 0.0)
        self.assertAlmostEqual(result["values"]["min_film"], 0.4)


if __name__ == "__main__":
    unittest.main()
