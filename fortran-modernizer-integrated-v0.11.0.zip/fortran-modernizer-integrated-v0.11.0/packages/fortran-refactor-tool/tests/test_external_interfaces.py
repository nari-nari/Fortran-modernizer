from __future__ import annotations

import shutil
import subprocess
import tempfile
import unittest
from pathlib import Path

from fortran_refactor.apply import apply_plan
from fortran_refactor.external_interfaces import write_external_interface_plan


class ExternalInterfaceMigrationTest(unittest.TestCase):
    @property
    def fixture_dir(self) -> Path:
        return Path(__file__).resolve().parents[1] / "samples" / "external_interfaces"

    def test_plan_generates_abstract_and_explicit_interfaces(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            plan = Path(temp) / "plan"
            suggestions = write_external_interface_plan([self.fixture_dir], [], plan)
            self.assertEqual(len(suggestions), 1)
            item = suggestions[0]
            self.assertEqual(item.safety, "approval-required")
            generated = item.details["generated_files"][0]["content"]
            self.assertIn("abstract interface", generated.lower())
            self.assertIn("procedure(apply_callback_callback_interface)", generated.lower())
            patch = (plan / "proposed_changes.patch").read_text(encoding="utf-8")
            self.assertIn("USE legacy_external_interfaces", patch)
            self.assertIn("PROCEDURE(apply_callback_callback_interface)", patch)
            preview = (plan / "transformed_sources" / "external_procedures.for").read_text(encoding="utf-8")
            self.assertNotIn("EXTERNAL CALLBACK", preview.upper())

    def test_apply_compiles_with_strict_interface_warnings(self) -> None:
        if shutil.which("gfortran") is None:
            self.skipTest("gfortran unavailable")
        with tempfile.TemporaryDirectory() as temp:
            base = Path(temp)
            source = base / "source"
            shutil.copytree(self.fixture_dir, source)
            plan = base / "plan"
            suggestions = write_external_interface_plan([source], [], plan)
            receipt = apply_plan(
                plan,
                base / "applied",
                selected_ids={suggestions[0].id},
                all_automatic=False,
                approve_review=True,
                include_dirs=[],
                run_compile_check=True,
            )
            transformed = Path(receipt["transformed_root"])
            build = base / "build"
            build.mkdir()
            exe = build / "demo"
            completed = subprocess.run(
                [
                    "gfortran",
                    "-std=legacy",
                    "-Wall",
                    "-Wextra",
                    "-Werror=implicit-interface",
                    "-Werror=implicit-procedure",
                    "-J",
                    str(build),
                    "-I",
                    str(build),
                    str(transformed / "generated_interfaces" / "legacy_external_interfaces.f90"),
                    str(transformed / "external_procedures.for"),
                    str(transformed / "external_driver.for"),
                    "-o",
                    str(exe),
                ],
                capture_output=True,
                text=True,
                check=False,
            )
            self.assertEqual(completed.returncode, 0, completed.stderr)
            run = subprocess.run([str(exe)], capture_output=True, text=True, check=False)
            self.assertEqual(run.returncode, 0)
            self.assertIn("6.000", run.stdout)

    def test_unresolved_external_is_blocked(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            source = Path(temp) / "missing.for"
            source.write_text(
                "      SUBROUTINE DRIVER(F,X,Y)\n"
                "      DOUBLE PRECISION F,X,Y\n"
                "      EXTERNAL F\n"
                "      Y=F(X)\n"
                "      END\n",
                encoding="utf-8",
            )
            plan = Path(temp) / "plan"
            suggestions = write_external_interface_plan([source], [], plan)
            self.assertEqual(suggestions[0].safety, "blocked")
            self.assertIn("actual procedure", suggestions[0].rationale.lower())


if __name__ == "__main__":
    unittest.main()
