from __future__ import annotations

import hashlib
import json
import re
import subprocess
import tempfile
import unittest
from pathlib import Path

from fortran_refactor.apply import apply_plan
from fortran_refactor.control_flow import (
    write_control_flow_plan,
    write_control_flow_suggestions,
)


class ControlFlowModernizationTest(unittest.TestCase):
    def _write_project(self, root: Path) -> Path:
        source_root = root / "source"
        source_root.mkdir()
        source = source_root / "control_demo.f90"
        source.write_text(
            """program control_demo
  implicit none
  integer :: i, s, x
  s = 0
  do 100 i = 1, 3
    s = s + i
100 continue
  x = -1
  if (x) 10, 20, 30
10 s = s + 10
  go to 40
20 s = s + 20
  go to 40
30 s = s + 30
40 continue
  go to 50
  s = 999
50 continue
  print '(i0)', s
end program control_demo
""",
            encoding="utf-8",
        )
        return source

    def _review_all_ready(self, suggest_dir: Path) -> tuple[dict, list[str]]:
        suggestions = json.loads(
            (suggest_dir / "control_flow_suggestions.json").read_text(encoding="utf-8")
        )
        selection = json.loads(
            (suggest_dir / "control_flow_selection.json").read_text(encoding="utf-8")
        )
        ready = [item for item in suggestions["candidates"] if item["status"] == "ready"]
        selection["reviewed"] = True
        selection["selections"] = [
            {
                "candidate_id": item["candidate_id"],
                "confirmed_semantics": True,
                "confirmed_regression_gate": True,
            }
            for item in ready
        ]
        return selection, [item["candidate_id"] for item in ready]

    def test_detects_ready_and_blocked_constructs_without_modifying_source(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            source = self._write_project(root)
            before = hashlib.sha256(source.read_bytes()).hexdigest()
            result = write_control_flow_suggestions([source], [], root / "suggest")
            self.assertEqual(before, hashlib.sha256(source.read_bytes()).hexdigest())
            ready_kinds = {item.construct_kind for item in result.candidates if item.status == "ready"}
            self.assertEqual(ready_kinds, {"labelled_do", "arithmetic_if", "forward_goto"})
            shared = [
                item
                for item in result.candidates
                if item.construct_kind == "forward_goto" and item.target_labels == ("40",)
            ]
            self.assertEqual(len(shared), 2)
            self.assertTrue(all(item.status == "blocked" for item in shared))
            self.assertTrue(all(any("additional references" in b for b in item.blockers) for item in shared))

    def test_reviewed_plan_applies_compiles_and_preserves_result(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            source = self._write_project(root)
            suggest_dir = root / "suggest"
            write_control_flow_suggestions([source], [], suggest_dir)
            selection, ids = self._review_all_ready(suggest_dir)
            self.assertEqual(len(ids), 3)
            selection_path = root / "selection.json"
            selection_path.write_text(json.dumps(selection, indent=2) + "\n", encoding="utf-8")
            plan_dir = root / "plan"
            suggestions = write_control_flow_plan([source], [], selection_path, plan_dir)
            self.assertEqual({item.id for item in suggestions}, set(ids))
            receipt = apply_plan(plan_dir, root / "applied", set(ids), False, True, [], True)
            self.assertEqual(len(receipt["control_flow_verification"]), 3)
            transformed = root / "applied" / "transformed_sources" / source.name
            text = transformed.read_text(encoding="utf-8").lower()
            self.assertIn(": do i = 1, 3", text)
            self.assertIn("associate (frt_arith_if_", text)
            self.assertIn(": block", text)
            self.assertNotIn("if (x) 10, 20, 30", text)
            executable = root / "control_demo"
            subprocess.run(["gfortran", str(transformed), "-o", str(executable)], check=True)
            output = subprocess.check_output([str(executable)], text=True).strip()
            self.assertEqual(output, "16")

    def test_shared_do_terminal_label_is_blocked(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            source = root / "shared.f"
            source.write_text(
                """      PROGRAM SHARED
      INTEGER I,J,S
      S=0
      DO 100 I=1,2
      DO 100 J=1,2
      S=S+1
  100 CONTINUE
      PRINT *,S
      END
""",
                encoding="utf-8",
            )
            result = write_control_flow_suggestions([source], [], root / "suggest")
            loops = [item for item in result.candidates if item.construct_kind == "labelled_do"]
            self.assertEqual(len(loops), 2)
            self.assertTrue(all(item.status == "blocked" for item in loops))

    def test_complex_goto_is_inventory_only(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            source = root / "computed.f90"
            source.write_text(
                """program computed
  implicit none
  integer :: i
  i = 1
  go to (10, 20), i
10 continue
20 continue
end program computed
""",
                encoding="utf-8",
            )
            result = write_control_flow_suggestions([source], [], root / "suggest")
            item = next(candidate for candidate in result.candidates if candidate.construct_kind == "complex_goto")
            self.assertEqual(item.status, "blocked")
            self.assertTrue(any("manual control-flow analysis" in blocker for blocker in item.blockers))

    def test_plan_requires_review_confirmations_and_rejects_stale_source(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            source = self._write_project(root)
            suggest_dir = root / "suggest"
            write_control_flow_suggestions([source], [], suggest_dir)
            selection, _ = self._review_all_ready(suggest_dir)
            selection["selections"][0]["confirmed_semantics"] = False
            selection_path = root / "selection.json"
            selection_path.write_text(json.dumps(selection, indent=2) + "\n", encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "confirmed_semantics"):
                write_control_flow_plan([source], [], selection_path, root / "plan1")

            selection, _ = self._review_all_ready(suggest_dir)
            selection_path.write_text(json.dumps(selection, indent=2) + "\n", encoding="utf-8")
            source.write_text(source.read_text(encoding="utf-8") + "! changed\n", encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "selection is stale"):
                write_control_flow_plan([source], [], selection_path, root / "plan2")


    def test_cfg_backed_cycle_exit_post_loop_and_shared_return_apply(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            source_dir = root / "source"
            source_dir.mkdir()
            source = source_dir / "cfg_demo.f90"
            source.write_text(
                """program cfg_demo
  implicit none
  integer :: result
  call calculate(result)
  print '(i0)', result
contains
  subroutine calculate(result)
    integer, intent(out) :: result
    integer :: i, j
    result = 0
    do 100 i = 1, 3
      if (i == 2) go to 100
      result = result + i
100 continue
    j = 0
10 continue
    j = j + 1
    result = result + 1
    if (j < 3) goto 10
    do i = 1, 5
      if (i == 3) goto 200
      result = result + 1
    end do
200 continue
    if (result < 0) goto 900
    if (result == 999) go to 900
    result = result + 10
900 return
  end subroutine calculate
end program cfg_demo
""",
                encoding="utf-8",
            )
            suggest_dir = root / "suggest"
            result = write_control_flow_suggestions([source], [], suggest_dir)
            ready = [item for item in result.candidates if item.status == "ready"]
            advanced = {
                item.construct_kind: item
                for item in ready
                if item.construct_kind in {
                    "shared_do_cycle",
                    "structured_do_exit",
                    "backward_conditional_loop",
                    "shared_return_exit",
                }
            }
            self.assertEqual(
                set(advanced),
                {
                    "shared_do_cycle",
                    "structured_do_exit",
                    "backward_conditional_loop",
                    "shared_return_exit",
                },
            )
            self.assertTrue(all(item.cfg_evidence.get("relevant_edges") for item in advanced.values()))

            selection = json.loads(
                (suggest_dir / "control_flow_selection.json").read_text(encoding="utf-8")
            )
            selected_ids = sorted(item.candidate_id for item in advanced.values())
            selection["reviewed"] = True
            selection["selections"] = [
                {
                    "candidate_id": candidate_id,
                    "confirmed_semantics": True,
                    "confirmed_regression_gate": True,
                }
                for candidate_id in selected_ids
            ]
            selection_path = root / "selection.json"
            selection_path.write_text(json.dumps(selection, indent=2) + "\n", encoding="utf-8")
            plan_dir = root / "plan"
            suggestions = write_control_flow_plan([source], [], selection_path, plan_dir)
            self.assertEqual({item.id for item in suggestions}, set(selected_ids))
            receipt = apply_plan(
                plan_dir, root / "applied", set(selected_ids), False, True, [], True
            )
            self.assertEqual(len(receipt["control_flow_verification"]), 4)
            transformed = root / "applied" / "transformed_sources" / source.name
            text = transformed.read_text(encoding="utf-8").lower()
            self.assertIn("cycle frt_do_cycle_", text)
            self.assertIn("exit frt_do_exit_", text)
            self.assertIn("frt_post_loop_", text)
            self.assertIn("if (result < 0) return", text)
            self.assertNotRegex(text, r"\b(?:go\s*to|goto)\b")
            executable = root / "cfg_demo"
            subprocess.run(["gfortran", str(transformed), "-o", str(executable)], check=True)
            output = subprocess.check_output([str(executable)], text=True).strip()
            self.assertEqual(output, "19")

    def test_multiple_back_edges_and_shared_cleanup_apply(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            source_dir = root / "source"
            source_dir.mkdir()
            source = source_dir / "advanced_cfg.f90"
            source.write_text(
                """program advanced_cfg
  implicit none
  integer :: result
  call calculate(result)
  print '(i0)', result
contains
  subroutine calculate(result)
    integer, intent(out) :: result
    integer :: i
    logical :: failed
    result = 0
    i = 0
10  continue
    i = i + 1
    result = result + 1
    if (i == 2) goto 10
    result = result + 2
    if (i < 4) goto 10
    failed = .false.
    if (failed) goto 900
    result = result + 5
    if (result < 0) goto 900
    result = result + 7
900 result = result + 10
    result = result + 20
    return
  end subroutine calculate
end program advanced_cfg
""",
                encoding="utf-8",
            )
            original_exe = root / "original"
            subprocess.run(["gfortran", str(source), "-o", str(original_exe)], check=True)
            expected = subprocess.check_output([str(original_exe)], text=True).strip()

            suggest_dir = root / "suggest"
            result = write_control_flow_suggestions([source], [], suggest_dir)
            advanced = {
                item.construct_kind: item
                for item in result.candidates
                if item.status == "ready"
                and item.construct_kind in {"multiple_backward_loop", "cleanup_block_exit"}
            }
            self.assertEqual(set(advanced), {"multiple_backward_loop", "cleanup_block_exit"})
            self.assertTrue(all(item.cfg_evidence.get("relevant_edges") for item in advanced.values()))

            selection = json.loads(
                (suggest_dir / "control_flow_selection.json").read_text(encoding="utf-8")
            )
            selected_ids = sorted(item.candidate_id for item in advanced.values())
            selection["reviewed"] = True
            selection["selections"] = [
                {
                    "candidate_id": candidate_id,
                    "confirmed_semantics": True,
                    "confirmed_regression_gate": True,
                }
                for candidate_id in selected_ids
            ]
            selection_path = root / "selection.json"
            selection_path.write_text(json.dumps(selection, indent=2) + "\n", encoding="utf-8")
            plan_dir = root / "plan"
            write_control_flow_plan([source], [], selection_path, plan_dir)
            receipt = apply_plan(
                plan_dir, root / "applied", set(selected_ids), False, True, [], True
            )
            self.assertEqual(len(receipt["control_flow_verification"]), 2)
            transformed = root / "applied" / "transformed_sources" / source.name
            text = transformed.read_text(encoding="utf-8").lower()
            self.assertIn("cycle frt_multi_loop_", text)
            self.assertIn("end block frt_cleanup_", text)
            self.assertNotRegex(text, r"\b(?:go\s*to|goto)\b")
            executable = root / "advanced_cfg"
            subprocess.run(["gfortran", str(transformed), "-o", str(executable)], check=True)
            self.assertEqual(subprocess.check_output([str(executable)], text=True).strip(), expected)
            self.assertEqual(expected, "52")

    def test_multiple_back_edge_loop_with_nested_construct_is_blocked(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            source = root / "nested_multi.f90"
            source.write_text(
                """program nested_multi
  implicit none
  integer :: i
  i = 0
10 continue
  i = i + 1
  if (i == 1) goto 10
  if (i < 3) then
    i = i + 1
  end if
  if (i < 4) goto 10
  print *, i
end program nested_multi
""",
                encoding="utf-8",
            )
            result = write_control_flow_suggestions([source], [], root / "suggest")
            item = next(
                candidate
                for candidate in result.candidates
                if candidate.construct_kind == "multiple_backward_loop"
            )
            self.assertEqual(item.status, "blocked")
            self.assertTrue(
                any("structured construct boundary" in blocker for blocker in item.blockers)
            )

    def test_cleanup_block_with_other_branch_is_blocked(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            source = root / "cleanup_branch.f90"
            source.write_text(
                """subroutine cleanup_branch(x, failed)
  implicit none
  integer, intent(inout) :: x
  logical, intent(in) :: failed
  if (failed) goto 900
  x = x + 1
  if (x < 0) goto 800
  if (x == 99) goto 900
  x = x + 2
800 continue
  x = x + 3
900 x = x + 10
  call touch(x)
  return
contains
  subroutine touch(value)
    integer, intent(inout) :: value
    value = value + 1
  end subroutine touch
end subroutine cleanup_branch
""",
                encoding="utf-8",
            )
            result = write_control_flow_suggestions([source], [], root / "suggest")
            item = next(
                candidate
                for candidate in result.candidates
                if candidate.construct_kind == "cleanup_block_exit"
            )
            self.assertEqual(item.status, "blocked")
            self.assertTrue(any("another branch" in blocker for blocker in item.blockers))

    def test_remaining_conditional_goto_is_inventory_only(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            source = root / "unsupported.f90"
            source.write_text(
                """program unsupported
  implicit none
  integer :: x
  x = 1
  if (x > 0) goto 100
  x = 2
100 x = x + 1
  print *, x
end program unsupported
""",
                encoding="utf-8",
            )
            result = write_control_flow_suggestions([source], [], root / "suggest")
            item = next(
                candidate
                for candidate in result.candidates
                if candidate.construct_kind == "conditional_goto_cfg"
            )
            self.assertEqual(item.status, "blocked")
            self.assertTrue(item.cfg_evidence["relevant_edges"])
            self.assertTrue(any("does not match" in blocker for blocker in item.blockers))

    def test_backward_loop_with_nested_construct_is_blocked(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            source = root / "nested.f90"
            source.write_text(
                """program nested
  implicit none
  integer :: i
  i = 0
10 continue
  if (i < 2) then
    i = i + 1
  end if
  if (i < 3) goto 10
  print *, i
end program nested
""",
                encoding="utf-8",
            )
            result = write_control_flow_suggestions([source], [], root / "suggest")
            item = next(
                candidate
                for candidate in result.candidates
                if candidate.construct_kind == "backward_conditional_loop"
            )
            self.assertEqual(item.status, "blocked")
            self.assertTrue(any("structured construct boundary" in blocker for blocker in item.blockers))

    def test_shared_do_cycle_fixed_form_compiles(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            source_dir = root / "source"
            source_dir.mkdir()
            source = source_dir / "cycle.f"
            source.write_text(
                """      PROGRAM CYCLEDEMO
      INTEGER I,S
      S=0
      DO 100 I=1,3
      IF (I.EQ.2) GOTO 100
      S=S+I
  100 CONTINUE
      PRINT '(I0)',S
      END
""",
                encoding="utf-8",
            )
            suggest_dir = root / "suggest"
            result = write_control_flow_suggestions([source], [], suggest_dir)
            candidate = next(
                item
                for item in result.candidates
                if item.construct_kind == "shared_do_cycle"
            )
            self.assertEqual(candidate.status, "ready")
            selection = json.loads(
                (suggest_dir / "control_flow_selection.json").read_text(encoding="utf-8")
            )
            selection["reviewed"] = True
            selection["selections"] = [{
                "candidate_id": candidate.candidate_id,
                "confirmed_semantics": True,
                "confirmed_regression_gate": True,
            }]
            selection_path = root / "selection.json"
            selection_path.write_text(json.dumps(selection, indent=2) + "\n", encoding="utf-8")
            plan_dir = root / "plan"
            write_control_flow_plan([source], [], selection_path, plan_dir)
            apply_plan(plan_dir, root / "applied", {candidate.candidate_id}, False, True, [], True)
            transformed = root / "applied" / "transformed_sources" / source.name
            executable = root / "cycle_demo"
            subprocess.run(["gfortran", str(transformed), "-o", str(executable)], check=True)
            self.assertEqual(subprocess.check_output([str(executable)], text=True).strip(), "4")


    def test_multiple_back_edges_and_cleanup_fixed_form_compile(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            source_dir = root / "source"
            source_dir.mkdir()
            source = source_dir / "advanced_fixed.f"
            source.write_text(
                """      PROGRAM ADVFIX
      INTEGER R
      CALL CALC(R)
      PRINT '(I0)',R
      END
      SUBROUTINE CALC(R)
      INTEGER R,I
      LOGICAL FAIL
      R=0
      I=0
   10 CONTINUE
      I=I+1
      R=R+1
      IF (I.EQ.2) GOTO 10
      R=R+2
      IF (I.LT.4) GOTO 10
      FAIL=.FALSE.
      IF (FAIL) GOTO 900
      R=R+5
      IF (R.LT.0) GOTO 900
      R=R+7
  900 R=R+10
      R=R+20
      RETURN
      END
""",
                encoding="utf-8",
            )
            suggest_dir = root / "suggest"
            result = write_control_flow_suggestions([source], [], suggest_dir)
            ready = [
                item for item in result.candidates
                if item.status == "ready"
                and item.construct_kind in {"multiple_backward_loop", "cleanup_block_exit"}
            ]
            self.assertEqual(len(ready), 2)
            selection = json.loads(
                (suggest_dir / "control_flow_selection.json").read_text(encoding="utf-8")
            )
            selection["reviewed"] = True
            selection["selections"] = [
                {
                    "candidate_id": item.candidate_id,
                    "confirmed_semantics": True,
                    "confirmed_regression_gate": True,
                }
                for item in ready
            ]
            selection_path = root / "selection.json"
            selection_path.write_text(json.dumps(selection, indent=2) + "\n", encoding="utf-8")
            plan_dir = root / "plan"
            write_control_flow_plan([source], [], selection_path, plan_dir)
            ids = {item.candidate_id for item in ready}
            apply_plan(plan_dir, root / "applied", ids, False, True, [], True)
            transformed = root / "applied" / "transformed_sources" / source.name
            executable = root / "advanced_fixed"
            subprocess.run(["gfortran", str(transformed), "-o", str(executable)], check=True)
            self.assertEqual(subprocess.check_output([str(executable)], text=True).strip(), "52")



    def test_conditional_cleanup_extracts_internal_procedure_and_preserves_result(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            source_dir = root / "source"
            source_dir.mkdir()
            source = source_dir / "conditional_cleanup.f90"
            source.write_text(
                """program cleanup_demo
  implicit none
  integer :: result
  call calculate(result, .true.)
  print '(i0)', result
end program cleanup_demo

subroutine calculate(result, add_extra)
  implicit none
  integer, intent(out) :: result
  logical, intent(in) :: add_extra
  logical :: failed
  result = 5
  failed = .false.
  if (failed) goto 900
  result = result + 2
  if (result < 0) goto 900
  result = result + 3
900 if (add_extra) then
    result = result + 10
  else
    result = result + 20
  end if
  result = result + 1
  return
end subroutine calculate
""",
                encoding="utf-8",
            )
            original = root / "original"
            subprocess.run(["gfortran", str(source), "-o", str(original)], check=True)
            expected = subprocess.check_output([str(original)], text=True).strip()

            suggest_dir = root / "suggest"
            result = write_control_flow_suggestions([source], [], suggest_dir)
            candidate = next(
                item for item in result.candidates
                if item.construct_kind == "cleanup_internal_procedure"
            )
            self.assertEqual(candidate.status, "ready")
            self.assertIn("cleanup_procedure", candidate.cfg_evidence)

            selection = json.loads(
                (suggest_dir / "control_flow_selection.json").read_text(encoding="utf-8")
            )
            selection["reviewed"] = True
            selection["selections"] = [{
                "candidate_id": candidate.candidate_id,
                "confirmed_semantics": True,
                "confirmed_regression_gate": True,
            }]
            selection_path = root / "selection.json"
            selection_path.write_text(json.dumps(selection, indent=2) + "\n", encoding="utf-8")
            plan_dir = root / "plan"
            write_control_flow_plan([source], [], selection_path, plan_dir)
            receipt = apply_plan(
                plan_dir, root / "applied", {candidate.candidate_id}, False, True, [], True
            )
            self.assertEqual(len(receipt["control_flow_verification"]), 1)
            transformed = root / "applied" / "transformed_sources" / source.name
            text = transformed.read_text(encoding="utf-8").lower()
            self.assertIn("contains", text)
            self.assertIn("subroutine frt_cleanup_proc_", text)
            self.assertIn("call frt_cleanup_proc_", text)
            self.assertIn("end block frt_cleanup_", text)
            self.assertNotRegex(text, r"\b(?:go\s*to|goto)\b")
            executable = root / "transformed"
            subprocess.run(["gfortran", str(transformed), "-o", str(executable)], check=True)
            self.assertEqual(subprocess.check_output([str(executable)], text=True).strip(), expected)
            self.assertEqual(expected, "21")

    def test_conditional_cleanup_extends_existing_contains_section(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            source_dir = root / "source"
            source_dir.mkdir()
            source = source_dir / "cleanup_contains.f90"
            source.write_text(
                """program cleanup_contains_demo
  implicit none
  integer :: result
  call calculate(result, .true.)
  print '(i0)', result
end program cleanup_contains_demo

subroutine calculate(result, add_extra)
  implicit none
  integer, intent(out) :: result
  logical, intent(in) :: add_extra
  logical :: failed
  result = 5
  failed = .false.
  if (failed) goto 900
  call add_two(result)
  if (result < 0) goto 900
  result = result + 3
900 if (add_extra) then
    result = result + 10
  else
    result = result + 20
  end if
  result = result + 1
  return
contains
  subroutine add_two(value)
    integer, intent(inout) :: value
    value = value + 2
  end subroutine add_two
end subroutine calculate
""",
                encoding="utf-8",
            )
            original = root / "original"
            subprocess.run(["gfortran", str(source), "-o", str(original)], check=True)
            expected = subprocess.check_output([str(original)], text=True).strip()
            suggest_dir = root / "suggest"
            result = write_control_flow_suggestions([source], [], suggest_dir)
            candidate = next(
                item for item in result.candidates
                if item.construct_kind == "cleanup_internal_procedure"
            )
            self.assertEqual(candidate.status, "ready")
            selection = json.loads(
                (suggest_dir / "control_flow_selection.json").read_text(encoding="utf-8")
            )
            selection["reviewed"] = True
            selection["selections"] = [{
                "candidate_id": candidate.candidate_id,
                "confirmed_semantics": True,
                "confirmed_regression_gate": True,
            }]
            selection_path = root / "selection.json"
            selection_path.write_text(json.dumps(selection, indent=2) + "\n", encoding="utf-8")
            plan_dir = root / "plan"
            write_control_flow_plan([source], [], selection_path, plan_dir)
            apply_plan(plan_dir, root / "applied", {candidate.candidate_id}, False, True, [], True)
            transformed = root / "applied" / "transformed_sources" / source.name
            text = transformed.read_text(encoding="utf-8").lower()
            self.assertEqual(len(re.findall(r"(?m)^\s*contains\s*$", text)), 1)
            self.assertIn("subroutine add_two", text)
            self.assertIn("subroutine frt_cleanup_proc_", text)
            executable = root / "transformed"
            subprocess.run(["gfortran", str(transformed), "-o", str(executable)], check=True)
            self.assertEqual(subprocess.check_output([str(executable)], text=True).strip(), expected)
            self.assertEqual(expected, "21")

    def test_conditional_cleanup_fixed_form_applies_and_preserves_result(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            source_dir = root / "source"
            source_dir.mkdir()
            source = source_dir / "conditional_cleanup.f"
            source.write_text(
                """      PROGRAM DEMO
      INTEGER R
      R=5
      CALL CLEANUP(R,.TRUE.)
      WRITE(*,'(I0)') R
      END
      SUBROUTINE CLEANUP(R,FLAG)
      INTEGER R
      LOGICAL FLAG,FAIL
      FAIL=.FALSE.
      IF (FAIL) GOTO 900
      R=R+2
      IF (R.LT.0) GOTO 900
      R=R+3
  900 IF (FLAG) THEN
      R=R+10
      ELSE
      R=R+20
      END IF
      R=R+1
      RETURN
      END
""",
                encoding="utf-8",
            )
            original = root / "original"
            subprocess.run(["gfortran", str(source), "-o", str(original)], check=True)
            expected = subprocess.check_output([str(original)], text=True).strip()
            suggest_dir = root / "suggest"
            result = write_control_flow_suggestions([source], [], suggest_dir)
            candidate = next(
                item for item in result.candidates
                if item.construct_kind == "cleanup_internal_procedure"
            )
            self.assertEqual(candidate.status, "ready")
            selection = json.loads(
                (suggest_dir / "control_flow_selection.json").read_text(encoding="utf-8")
            )
            selection["reviewed"] = True
            selection["selections"] = [{
                "candidate_id": candidate.candidate_id,
                "confirmed_semantics": True,
                "confirmed_regression_gate": True,
            }]
            selection_path = root / "selection.json"
            selection_path.write_text(json.dumps(selection, indent=2) + "\n", encoding="utf-8")
            plan_dir = root / "plan"
            write_control_flow_plan([source], [], selection_path, plan_dir)
            apply_plan(plan_dir, root / "applied", {candidate.candidate_id}, False, True, [], True)
            transformed = root / "applied" / "transformed_sources" / source.name
            text = transformed.read_text(encoding="utf-8").upper()
            self.assertIn("CONTAINS", text)
            self.assertIn("SUBROUTINE FRT_CLEANUP_PROC_", text)
            self.assertNotRegex(text, r"\b(?:GO\s*TO|GOTO)\b")
            executable = root / "transformed"
            subprocess.run(["gfortran", str(transformed), "-o", str(executable)], check=True)
            self.assertEqual(subprocess.check_output([str(executable)], text=True).strip(), expected)
            self.assertEqual(expected, "21")

    def test_two_entry_irreducible_region_normalizes_to_dispatch_loop(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            source_dir = root / "source"
            source_dir.mkdir()
            source = source_dir / "irreducible_dispatch.f90"
            source.write_text(
                """program demo
  implicit none
  integer :: a, b
  call irreducible(.true., 7, a)
  call irreducible(.false., 7, b)
  print '(i0,1x,i0)', a, b
end program demo

subroutine irreducible(flag, n, result)
  implicit none
  logical, intent(in) :: flag
  integer, intent(in) :: n
  integer, intent(out) :: result
  result = 0
  if (flag) goto 20
10 result = result + 1
  if (result < n) goto 20
  return
20 result = result + 2
  if (result < n) goto 10
  return
end subroutine irreducible
""",
                encoding="utf-8",
            )
            original = root / "original"
            subprocess.run(["gfortran", str(source), "-o", str(original)], check=True)
            expected = subprocess.check_output([str(original)], text=True).strip()
            suggest_dir = root / "suggest"
            result = write_control_flow_suggestions([source], [], suggest_dir)
            candidate = next(
                item for item in result.candidates
                if item.construct_kind == "irreducible_dispatch_loop"
            )
            self.assertEqual(candidate.status, "ready")
            self.assertEqual(
                candidate.cfg_evidence["normalization_strategy"],
                "local_integer_dispatch_loop",
            )
            selection = json.loads(
                (suggest_dir / "control_flow_selection.json").read_text(encoding="utf-8")
            )
            selection["reviewed"] = True
            selection["selections"] = [{
                "candidate_id": candidate.candidate_id,
                "confirmed_semantics": True,
                "confirmed_regression_gate": True,
            }]
            selection_path = root / "selection.json"
            selection_path.write_text(json.dumps(selection, indent=2) + "\n", encoding="utf-8")
            plan_dir = root / "plan"
            write_control_flow_plan([source], [], selection_path, plan_dir)
            apply_plan(plan_dir, root / "applied", {candidate.candidate_id}, False, True, [], True)
            transformed = root / "applied" / "transformed_sources" / source.name
            text = transformed.read_text(encoding="utf-8").lower()
            self.assertIn("select case", text)
            self.assertIn("integer :: frt_dispatch_state_", text)
            self.assertNotRegex(text, r"\b(?:go\s*to|goto)\b")
            executable = root / "transformed"
            subprocess.run(["gfortran", str(transformed), "-o", str(executable)], check=True)
            self.assertEqual(subprocess.check_output([str(executable)], text=True).strip(), expected)
            self.assertEqual(expected, "8 7")

    def test_three_state_irreducible_region_writes_state_machine_design_bundle(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            source = root / "three_state.f90"
            original = """subroutine machine(entry, limit, result, status)
  implicit none
  integer, intent(in) :: entry, limit
  integer, intent(out) :: result, status
  result = 0
  status = 0
  if (entry == 2) goto 20
  if (entry == 3) goto 30
10 result = result + 1
  if (result < limit) goto 20
  status = 10
  return
20 result = result + 2
  if (result < limit) goto 30
  status = 20
  return
30 result = result + 3
  if (result < limit) goto 10
  if (result == limit) goto 40
  status = 30
  return
40 status = 99
  return
end subroutine machine
"""
            source.write_text(original, encoding="utf-8")
            output = root / "suggest"
            result = write_control_flow_suggestions([source], [], output)

            candidate = next(
                item for item in result.candidates
                if item.construct_kind == "irreducible_state_machine_candidate"
            )
            self.assertEqual(candidate.status, "blocked")
            proposal = candidate.cfg_evidence["state_machine_candidate"]
            self.assertEqual(proposal["status"], "review-only")
            self.assertEqual(proposal["state_count"], 3)
            self.assertEqual(proposal["entry_count"], 3)
            self.assertEqual(proposal["transition_count"], 3)
            self.assertEqual(proposal["exit_count"], 3)
            self.assertEqual(
                [state["state_id"] for state in proposal["states"]],
                ["label_10", "label_20", "label_30"],
            )
            transitions = {
                (row["source_state"], row["target_state"])
                for row in proposal["transition_table"]
            }
            self.assertEqual(
                transitions,
                {
                    ("label_10", "label_20"),
                    ("label_20", "label_30"),
                    ("label_30", "label_10"),
                },
            )
            variables = proposal["variable_summary"]
            self.assertIn("result", variables["definite_reads"])
            self.assertIn("result", variables["definite_writes"])
            self.assertIn("status", variables["definite_writes"])
            self.assertIn("entry", variables["required_variables"])
            self.assertIn("limit", variables["required_variables"])
            self.assertEqual(source.read_text(encoding="utf-8"), original)

            payload = json.loads(
                (output / "irreducible_state_machine_candidates.json").read_text(encoding="utf-8")
            )
            self.assertEqual(payload["summary"]["candidate_count"], 1)
            self.assertEqual(payload["summary"]["state_count"], 3)
            self.assertTrue((output / "irreducible_state_machine_candidates.csv").is_file())
            markdown = (output / "irreducible_state_machine_candidates.md").read_text(encoding="utf-8")
            self.assertIn("label_10", markdown)
            self.assertIn("Transitions", markdown)

    def test_state_machine_candidate_records_unknown_call_argument_effects(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            source = root / "calls.f90"
            source.write_text(
                """subroutine machine(flag, x)
  implicit none
  integer, intent(in) :: flag
  integer, intent(inout) :: x
  if (flag == 2) goto 20
  if (flag == 3) goto 30
10 call state_a(x)
  if (x < 9) goto 20
  return
20 call state_b(x)
  if (x < 9) goto 30
  return
30 call state_c(x)
  if (x < 9) goto 10
  return
end subroutine machine
""",
                encoding="utf-8",
            )
            result = write_control_flow_suggestions([source], [], root / "suggest")
            candidate = next(
                item for item in result.candidates
                if item.construct_kind == "irreducible_state_machine_candidate"
            )
            proposal = candidate.cfg_evidence["state_machine_candidate"]
            self.assertEqual(
                proposal["variable_summary"]["call_argument_access_unknown"], ["x"]
            )
            self.assertTrue(
                any("CALL arguments" in warning for warning in candidate.warnings)
            )

    def test_state_machine_candidate_cannot_enter_transformation_plan(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            source = root / "machine.f90"
            source.write_text(
                """subroutine machine(flag, x)
  implicit none
  integer, intent(in) :: flag
  integer, intent(inout) :: x
  if (flag == 2) goto 20
  if (flag == 3) goto 30
10 x = x + 1
  if (x < 9) goto 20
  return
20 x = x + 2
  if (x < 9) goto 30
  return
30 x = x + 3
  if (x < 9) goto 10
  return
end subroutine machine
""",
                encoding="utf-8",
            )
            suggest = root / "suggest"
            result = write_control_flow_suggestions([source], [], suggest)
            candidate = next(
                item for item in result.candidates
                if item.construct_kind == "irreducible_state_machine_candidate"
            )
            selection = json.loads(
                (suggest / "control_flow_selection.json").read_text(encoding="utf-8")
            )
            selection["reviewed"] = True
            selection["selections"] = [{
                "candidate_id": candidate.candidate_id,
                "confirmed_semantics": True,
                "confirmed_regression_gate": True,
            }]
            selection_path = root / "selection.json"
            selection_path.write_text(json.dumps(selection, indent=2) + "\n", encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "not applicable"):
                write_control_flow_plan([source], [], selection_path, root / "plan")

    def test_irreducible_cfg_region_is_inventory_only(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            source = root / "irreducible.f90"
            source.write_text(
                """subroutine irreducible(flag, n, result)
  implicit none
  logical, intent(in) :: flag
  integer, intent(in) :: n
  integer, intent(out) :: result
  result = 0
  if (flag) goto 20
10 result = result + 1
  if (result == 1) goto 20
  if (result < n) goto 20
  return
20 result = result + 2
  if (result < n) goto 10
  return
end subroutine irreducible
""",
                encoding="utf-8",
            )
            result = write_control_flow_suggestions([source], [], root / "suggest")
            candidate = next(
                item for item in result.candidates
                if item.construct_kind == "irreducible_cfg_region"
            )
            self.assertEqual(candidate.status, "blocked")
            self.assertEqual(len(candidate.cfg_evidence["entry_nodes"]), 2)
            self.assertGreaterEqual(len(candidate.cfg_evidence["internal_edges"]), 2)
            self.assertTrue(any("multiple distinct entry" in item for item in candidate.blockers))


if __name__ == "__main__":
    unittest.main()
