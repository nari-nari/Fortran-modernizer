from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path

from fortran_refactor.apply import ApplyError, apply_plan
from fortran_refactor.intent_analysis import write_intent_plan


ROOT = Path(__file__).resolve().parents[1]
FIXTURE = ROOT / "samples" / "diagnostic_fixtures" / "intent_propagation.for"


class IntentAnalysisTests(unittest.TestCase):
    def test_propagates_effects_and_keeps_unknown_calls_blocked(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            output = Path(tmp) / "plan"
            suggestions = write_intent_plan([FIXTURE], [], output)
            candidates = json.loads((output / "intent_candidates.json").read_text(encoding="utf-8"))
            by_key = {(item["procedure"], item["argument"]): item for item in candidates}

            self.assertEqual(by_key[("intent_helper", "input_value")]["suggested_intent"], "in")
            self.assertEqual(by_key[("intent_helper", "output_value")]["suggested_intent"], "out")
            self.assertEqual(by_key[("intent_driver", "x")]["suggested_intent"], "in")
            self.assertEqual(by_key[("intent_driver", "y")]["suggested_intent"], "out")
            self.assertEqual(by_key[("intent_driver", "z")]["suggested_intent"], "out")
            # A partial array definition is intentionally not promoted to INTENT(OUT).
            self.assertEqual(by_key[("intent_driver", "a")]["suggested_intent"], "inout")
            self.assertEqual(by_key[("intent_accumulate", "total")]["suggested_intent"], "inout")
            self.assertEqual(by_key[("intent_accumulate", "delta")]["suggested_intent"], "in")
            self.assertEqual(by_key[("intent_unknown", "value")]["status"], "blocked")
            self.assertTrue(any(item.safety == "approval-required" for item in suggestions))
            self.assertTrue((output / "argument_access.csv").is_file())
            self.assertTrue((output / "proposed_changes.patch").read_text(encoding="utf-8"))

    def test_approved_plan_applies_to_copy_and_verifies_intents(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            tmp_path = Path(tmp)
            source_root = tmp_path / "src"
            source_root.mkdir()
            source = source_root / FIXTURE.name
            source.write_text(FIXTURE.read_text(encoding="utf-8"), encoding="utf-8")
            plan = tmp_path / "plan"
            suggestions = write_intent_plan([source], [], plan)
            selected = {item.id for item in suggestions if item.safety == "approval-required"}
            receipt = apply_plan(
                plan,
                tmp_path / "applied",
                selected,
                all_automatic=False,
                approve_review=True,
                include_dirs=[],
                run_compile_check=True,
            )
            transformed = (tmp_path / "applied" / "transformed_sources" / source.name).read_text(encoding="utf-8")
            self.assertIn("INTENT(IN) :: X", transformed)
            self.assertIn("INTENT(OUT) :: Y", transformed)
            self.assertIn("INTENT(INOUT) :: A(N)", transformed)
            self.assertTrue(receipt["verified_intent_expectations"])

    def test_review_flag_is_required(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            tmp_path = Path(tmp)
            source_root = tmp_path / "src"
            source_root.mkdir()
            source = source_root / FIXTURE.name
            source.write_text(FIXTURE.read_text(encoding="utf-8"), encoding="utf-8")
            plan = tmp_path / "plan"
            suggestions = write_intent_plan([source], [], plan)
            selected = {item.id for item in suggestions if item.safety == "approval-required"}
            with self.assertRaises(ApplyError):
                apply_plan(
                    plan,
                    tmp_path / "applied",
                    selected,
                    all_automatic=False,
                    approve_review=False,
                    include_dirs=[],
                    run_compile_check=False,
                )

    def test_existing_intent_conflict_is_blocked(self) -> None:
        source_text = """      SUBROUTINE CONFLICT(X)
      IMPLICIT NONE
      DOUBLE PRECISION, INTENT(IN) :: X
      X=X+1.0D0
      END
"""
        with tempfile.TemporaryDirectory() as tmp:
            tmp_path = Path(tmp)
            source = tmp_path / "conflict.for"
            source.write_text(source_text, encoding="utf-8")
            output = tmp_path / "plan"
            write_intent_plan([source], [], output)
            candidates = json.loads((output / "intent_candidates.json").read_text(encoding="utf-8"))
            self.assertEqual(candidates[0]["suggested_intent"], "inout")
            self.assertEqual(candidates[0]["status"], "blocked")
            self.assertIn("conflicts", " ".join(candidates[0]["blockers"]))

    def test_writable_alias_is_blocked(self) -> None:
        source_text = """      SUBROUTINE ALIAS_DRIVER(X)
      IMPLICIT NONE
      DOUBLE PRECISION X
      CALL ALIAS_HELPER(X,X)
      END

      SUBROUTINE ALIAS_HELPER(A,B)
      IMPLICIT NONE
      DOUBLE PRECISION A,B
      B=A+1.0D0
      END
"""
        with tempfile.TemporaryDirectory() as tmp:
            tmp_path = Path(tmp)
            source = tmp_path / "alias.for"
            source.write_text(source_text, encoding="utf-8")
            output = tmp_path / "plan"
            write_intent_plan([source], [], output)
            candidates = json.loads((output / "intent_candidates.json").read_text(encoding="utf-8"))
            driver = next(item for item in candidates if item["procedure"] == "alias_driver")
            self.assertEqual(driver["status"], "blocked")
            self.assertIn("aliased actual", " ".join(driver["blockers"]))

    def test_contained_subroutine_is_discovered(self) -> None:
        source_text = """module contained_mod
  implicit none
contains
  subroutine contained_scale(x, factor)
    real :: x, factor
    x = x * factor
  end subroutine contained_scale
end module contained_mod
"""
        with tempfile.TemporaryDirectory() as tmp:
            tmp_path = Path(tmp)
            source = tmp_path / "contained.f90"
            source.write_text(source_text, encoding="utf-8")
            output = tmp_path / "plan"
            write_intent_plan([source], [], output)
            candidates = json.loads((output / "intent_candidates.json").read_text(encoding="utf-8"))
            by_arg = {item["argument"]: item for item in candidates}
            self.assertEqual(by_arg["x"]["suggested_intent"], "inout")
            self.assertEqual(by_arg["factor"]["suggested_intent"], "in")


if __name__ == "__main__":
    unittest.main()
