import unittest
from unittest.mock import patch

import fortran_refactor.extract as extract_module
from fortran_refactor.diagnostics import build_analysis_result
from fortran_refactor.models import ParseResult
from fortran_refactor.source import discover_fortran_files, split_program_units


def _analyze(paths):
    units = []
    for path in discover_fortran_files(paths):
        for source in split_program_units(path):
            units.append(extract_module.analyze_unit(source, []))
    return build_analysis_result(units)


class DiagnosticsTest(unittest.TestCase):
    @patch.object(
        extract_module,
        "parse_with_fparser",
        side_effect=lambda unit, include_dirs: ParseResult(True, "test-parser", None, 1),
    )
    def test_expected_fixture_diagnostics(self, _mock_parser):
        result = _analyze(["samples/diagnostic_fixtures"])
        codes = [diagnostic.code for diagnostic in result.diagnostics]
        self.assertEqual(codes.count("COMMON_COUNT_MISMATCH"), 1)
        self.assertEqual(codes.count("COMMON_KIND_MISMATCH"), 1)
        self.assertEqual(codes.count("COMMON_SHAPE_MISMATCH"), 1)
        self.assertEqual(codes.count("COMMON_TYPE_MISMATCH"), 2)
        self.assertEqual(codes.count("CALL_ARGUMENT_COUNT_MISMATCH"), 1)
        self.assertEqual(codes.count("CALL_ARGUMENT_TYPE_MISMATCH"), 1)
        self.assertEqual(codes.count("CALL_ARGUMENT_KIND_MISMATCH"), 1)
        self.assertEqual(codes.count("CALL_ARGUMENT_RANK_MISMATCH"), 1)
        self.assertEqual(codes.count("CALL_ARGUMENT_UNRESOLVED"), 0)
        self.assertEqual(codes.count("IMPLICIT_TYPO_CANDIDATE"), 1)

    @patch.object(
        extract_module,
        "parse_with_fparser",
        side_effect=lambda unit, include_dirs: ParseResult(True, "test-parser", None, 1),
    )
    def test_runnable_legacy_only_has_compatible_common_aliases(self, _mock_parser):
        result = _analyze(["samples/legacy_runnable"])
        common_errors = [
            diagnostic
            for diagnostic in result.diagnostics
            if diagnostic.code.startswith("COMMON_") and diagnostic.severity == "error"
        ]
        aliases = [
            diagnostic
            for diagnostic in result.diagnostics
            if diagnostic.code == "COMMON_NAME_DIFFERENCE"
        ]
        self.assertEqual(common_errors, [])
        self.assertEqual(len(aliases), 6)


if __name__ == "__main__":
    unittest.main()
