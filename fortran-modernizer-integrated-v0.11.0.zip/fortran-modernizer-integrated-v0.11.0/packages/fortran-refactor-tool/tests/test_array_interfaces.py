from __future__ import annotations

import hashlib
import json
import subprocess
import tempfile
import unittest
from pathlib import Path

from fortran_refactor.apply import apply_plan
from fortran_refactor.array_interfaces import (
    write_array_interface_plan,
    write_array_interface_suggestions,
)


class ArrayInterfaceTest(unittest.TestCase):
    def _write_ready_project(self, root: Path) -> Path:
        source_root = root / "source"
        source_root.mkdir()
        source = source_root / "demo.f90"
        source.write_text(
            """module kernels
  implicit none
  private
  public :: run
contains
  subroutine scale(n, a, b)
    integer, intent(in) :: n
    real, intent(inout) :: a(n), b(0:n-1)
    a = 2.0*a
    b = b + 1.0
  end subroutine scale

  subroutine run(n, x, y)
    integer, intent(in) :: n
    real, intent(inout) :: x(n), y(0:n-1)
    call scale(n, x, y)
  end subroutine run
end module kernels
program main
  use kernels, only: run
  implicit none
  real :: x(3) = [1.0, 2.0, 3.0]
  real :: y(0:2) = [4.0, 5.0, 6.0]
  call run(3, x, y)
  print '(6f5.1)', x, y
end program main
""",
            encoding="utf-8",
        )
        return source

    def test_private_module_procedure_with_exact_call_shapes_is_ready(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            source = self._write_ready_project(root)
            before = hashlib.sha256(source.read_bytes()).hexdigest()
            result = write_array_interface_suggestions([source], [], root / "suggest")
            ready = next(item for item in result.candidates if item.procedure == "scale")
            self.assertEqual(ready.status, "ready")
            self.assertEqual(ready.dummies, ("a", "b"))
            self.assertEqual(ready.proposed_shapes["a"], (":",))
            self.assertEqual(ready.proposed_shapes["b"], ("0:",))
            self.assertEqual(ready.proven_call_sites, 1)
            self.assertEqual(before, hashlib.sha256(source.read_bytes()).hexdigest())

    def test_reviewed_plan_applies_compiles_and_preserves_results(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            source = self._write_ready_project(root)
            suggest_dir = root / "suggest"
            result = write_array_interface_suggestions([source], [], suggest_dir)
            candidate = next(item for item in result.candidates if item.procedure == "scale")
            selection = json.loads((suggest_dir / "array_interface_selection.json").read_text(encoding="utf-8"))
            selection["reviewed"] = True
            selection["selected_candidate_ids"] = [candidate.candidate_id]
            selection_path = root / "selection.json"
            selection_path.write_text(json.dumps(selection, indent=2) + "\n", encoding="utf-8")
            plan_dir = root / "plan"
            suggestions = write_array_interface_plan([source], [], selection_path, plan_dir)
            self.assertEqual(suggestions[0].id, candidate.candidate_id)
            receipt = apply_plan(
                plan_dir,
                root / "applied",
                {candidate.candidate_id},
                False,
                True,
                [],
                True,
            )
            self.assertEqual(receipt["array_interface_verification"][0]["dummies"], ["a", "b"])
            transformed = root / "applied" / "transformed_sources" / "demo.f90"
            text = transformed.read_text(encoding="utf-8").lower()
            self.assertIn("a(:), b(0:)", text)
            executable = root / "demo"
            subprocess.run(["gfortran", str(transformed), "-o", str(executable)], check=True)
            output = subprocess.check_output([str(executable)], text=True).strip()
            self.assertEqual(output, "2.0  4.0  6.0  5.0  6.0  7.0")

    def test_shape_mismatch_and_array_section_are_blocked(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            source = root / "blocked.f90"
            source.write_text(
                """module m
  implicit none
  private
contains
  subroutine kernel(n, a)
    integer, intent(in) :: n
    real, intent(inout) :: a(n)
    a = a + 1.0
  end subroutine kernel
  subroutine caller(n, x)
    integer, intent(in) :: n
    real, intent(inout) :: x(n+1)
    call kernel(n, x(1:n))
  end subroutine caller
end module m
""",
                encoding="utf-8",
            )
            result = write_array_interface_suggestions([source], [], root / "suggest")
            candidate = next(item for item in result.candidates if item.procedure == "kernel")
            self.assertEqual(candidate.status, "blocked")
            self.assertTrue(any("not a whole named array" in item for item in candidate.blockers))

    def test_reviewed_selection_rejects_changed_source(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            source = self._write_ready_project(root)
            suggest_dir = root / "suggest"
            result = write_array_interface_suggestions([source], [], suggest_dir)
            candidate = next(item for item in result.candidates if item.procedure == "scale")
            selection = json.loads((suggest_dir / "array_interface_selection.json").read_text(encoding="utf-8"))
            selection["reviewed"] = True
            selection["selected_candidate_ids"] = [candidate.candidate_id]
            selection_path = root / "selection.json"
            selection_path.write_text(json.dumps(selection, indent=2) + "\n", encoding="utf-8")
            source.write_text(source.read_text(encoding="utf-8") + "! changed after review\n", encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "selection is stale"):
                write_array_interface_plan([source], [], selection_path, root / "plan")

    def test_public_procedure_is_blocked_and_unreviewed_selection_rejected(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            source = root / "public.f90"
            source.write_text(
                """module m
  implicit none
contains
  subroutine public_kernel(n, a)
    integer, intent(in) :: n
    real, intent(inout) :: a(n)
  end subroutine public_kernel
end module m
""",
                encoding="utf-8",
            )
            suggest_dir = root / "suggest"
            result = write_array_interface_suggestions([source], [], suggest_dir)
            candidate = result.candidates[0]
            self.assertEqual(candidate.status, "blocked")
            self.assertTrue(any("external callers" in item for item in candidate.blockers))
            with self.assertRaisesRegex(ValueError, "not reviewed"):
                write_array_interface_plan(
                    [source], [], suggest_dir / "array_interface_selection.json", root / "plan"
                )


if __name__ == "__main__":
    unittest.main()
