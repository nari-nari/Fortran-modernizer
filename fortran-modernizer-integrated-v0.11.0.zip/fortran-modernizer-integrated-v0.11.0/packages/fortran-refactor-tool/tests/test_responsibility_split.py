from __future__ import annotations

import hashlib
import json
import tempfile
import unittest
from pathlib import Path

from fortran_refactor.responsibility_split import write_responsibility_split_suggestions


class ResponsibilitySplitTest(unittest.TestCase):
    def setUp(self) -> None:
        self.root = Path(__file__).resolve().parents[1]
        self.fixtures = self.root / "samples" / "responsibility_fixtures"

    def test_finds_io_and_compute_boundaries(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            result = write_responsibility_split_suggestions(
                [self.fixtures], [], Path(temp)
            )
        self.assertEqual(result.summary["mixed_io_compute_units"], 2)
        self.assertEqual(result.summary["candidate_regions"], 4)
        self.assertEqual(result.summary["review_candidates"], 3)
        self.assertEqual(result.summary["blocked_candidates"], 1)

        compute = next(
            item for item in result.candidates
            if item.program_unit == "solve_case" and item.responsibility == "compute-core"
        )
        self.assertEqual(compute.status, "review-candidate")
        self.assertEqual(set(compute.inputs), {"n", "scale", "values"})
        self.assertEqual(set(compute.outputs), {"results"})
        self.assertIn("i", compute.localizable)

    def test_early_return_blocks_io_extraction(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            result = write_responsibility_split_suggestions(
                [self.fixtures], [], Path(temp)
            )
        risky = next(item for item in result.candidates if item.program_unit == "risky_reader")
        self.assertEqual(risky.status, "blocked")
        self.assertIn("early RETURN inside candidate", risky.blockers)
        evidence = [
            row for row in result.control_flow_risks
            if row["candidate_id"] == risky.candidate_id
        ]
        self.assertTrue(any(row["risk_kind"] == "early-return" for row in evidence))

    def test_external_format_label_blocks_extraction(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            source = root / "format_case.for"
            source.write_text(
                "      SUBROUTINE FORMAT_CASE(X)\n"
                "      IMPLICIT NONE\n"
                "      DOUBLE PRECISION X\n"
                "      WRITE(6,100) X\n"
                "      X = X + 1.0D0\n"
                "  100 FORMAT(1X,F10.3)\n"
                "      END\n",
                encoding="utf-8",
            )
            result = write_responsibility_split_suggestions(
                [source], [], root / "report", min_compute_statements=1
            )
        io_candidate = next(item for item in result.candidates if item.responsibility == "output-io")
        self.assertEqual(io_candidate.status, "blocked")
        self.assertIn("FORMAT label crosses candidate boundary", io_candidate.blockers)

    def test_writes_review_artifacts_without_modifying_source(self) -> None:
        before = {
            path: hashlib.sha256(path.read_bytes()).hexdigest()
            for path in self.fixtures.glob("*.f90")
        }
        with tempfile.TemporaryDirectory() as temp:
            output = Path(temp)
            write_responsibility_split_suggestions(
                [self.fixtures], [], output, selected_units=["solve_case"]
            )
            expected = {
                "responsibility_units.csv",
                "separation_candidates.csv",
                "boundary_variables.csv",
                "control_flow_risks.csv",
                "io_dependencies.csv",
                "responsibility_split.json",
                "responsibility_split.md",
            }
            self.assertTrue(expected.issubset({path.name for path in output.iterdir()}))
            payload = json.loads((output / "responsibility_split.json").read_text(encoding="utf-8"))
            self.assertFalse(payload["scope"]["modifies_source"])
            self.assertEqual(payload["summary"]["program_units_reviewed"], 1)
            self.assertEqual(len(list((output / "snippets").glob("*.txt"))), 3)

        after = {
            path: hashlib.sha256(path.read_bytes()).hexdigest()
            for path in self.fixtures.glob("*.f90")
        }
        self.assertEqual(before, after)


if __name__ == "__main__":
    unittest.main()
