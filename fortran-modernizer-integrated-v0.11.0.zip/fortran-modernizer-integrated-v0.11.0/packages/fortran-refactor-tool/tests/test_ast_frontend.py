from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from fortran_refactor.diagnostics import build_analysis_result
from fortran_refactor.extract import analyze_unit
from fortran_refactor.reporting import write_reports
from fortran_refactor.source import split_program_units


class AstFrontendTest(unittest.TestCase):
    @property
    def fixture_root(self) -> Path:
        return Path(__file__).resolve().parents[1] / "samples" / "absoft_compatibility"

    def _analyze(self, name: str):
        path = self.fixture_root / name
        return [analyze_unit(unit, []) for unit in split_program_units(path)]

    def test_ast_extracts_external_function_metadata(self) -> None:
        units = self._analyze("external_procedures.for")
        apply_callback = next(unit for unit in units if unit.source.name == "apply_callback")
        self.assertEqual(apply_callback.parse.parse_mode, "raw")
        self.assertEqual(len(apply_callback.externals), 1)
        record = apply_callback.externals[0]
        self.assertEqual(record.name, "callback")
        self.assertEqual(record.procedure_kind, "function")
        self.assertEqual(record.declared_type.category, "real")
        self.assertEqual(record.declared_type.kind, "8")
        self.assertGreater(apply_callback.parse.ast_fact_count, 0)
        self.assertEqual(apply_callback.parse.fallback_fact_count, 0)

    def test_dot_component_requires_reported_compatibility_normalization(self) -> None:
        unit = self._analyze("dot_component.for")[0]
        self.assertTrue(unit.parse.success)
        self.assertEqual(unit.parse.parse_mode, "compatibility-normalized")
        self.assertEqual(unit.source.split_method, "fparser-ast-compatibility")
        self.assertIn("dot-component-normalized", unit.parse.compatibility_rewrites)
        self.assertTrue(any(item.name == "state_t" for item in unit.derived_types))
        self.assertTrue(any(item.name == "value" for item in unit.derived_components))
        self.assertTrue(any(item.code == "COMPATIBILITY_NORMALIZED_PARSE" for item in unit.diagnostics))

    def test_continuation_spans_come_from_ast(self) -> None:
        unit = self._analyze("multiline_declarations.for")[0]
        by_type = {item.node_type: item for item in unit.statements if item.continuation_lines}
        self.assertEqual(by_type["Type_Declaration_Stmt"].continuation_lines, 1)
        self.assertEqual(by_type["Common_Stmt"].continuation_lines, 2)
        self.assertEqual(by_type["Call_Stmt"].continuation_lines, 1)

    def test_existing_modules_and_derived_types_are_inventoried(self) -> None:
        unit = self._analyze("existing_types.f90")[0]
        self.assertEqual(unit.source.split_method, "fparser-ast")
        self.assertTrue(any(item.module == "iso_fortran_env" for item in unit.uses))
        state = next(item for item in unit.derived_types if item.name == "solver_state_t")
        self.assertEqual(state.name, "solver_state_t")
        pressure = next(item for item in unit.derived_components if item.name == "pressure")
        self.assertEqual(pressure.type.rank, 2)
        self.assertIn("allocatable", pressure.attributes)

    def test_frontend_reports_are_emitted(self) -> None:
        units = []
        for path in sorted(self.fixture_root.glob("*")):
            units.extend(analyze_unit(unit, []) for unit in split_program_units(path))
        with tempfile.TemporaryDirectory() as temp:
            output = Path(temp)
            write_reports(build_analysis_result(units), output)
            for name in (
                "frontend_coverage.csv",
                "external_procedures.csv",
                "derived_types.csv",
                "source_statements.csv",
                "use_dependencies.csv",
            ):
                self.assertTrue((output / name).is_file(), name)
            summary = (output / "summary.md").read_text(encoding="utf-8")
            self.assertIn("AST-derived facts", summary)
            self.assertIn("Compatibility-normalized AST parses", summary)


if __name__ == "__main__":
    unittest.main()
