import unittest
from pathlib import Path

from fortran_refactor.source import logical_statements, split_program_units


class SourceTest(unittest.TestCase):
    def test_split_legacy_program_units(self):
        path = Path("samples/legacy_runnable/journal_bearing_legacy.for")
        units = split_program_units(path.resolve())
        self.assertEqual(
            [unit.name for unit in units],
            [
                "journal_bearing_legacy",
                "init_geometry",
                "solve_reynolds",
                "compute_metrics",
                "print_results",
            ],
        )

    def test_fixed_form_continuation_is_joined(self):
        text = "      CALL FOO(A,B,\n     1 C,D)\n"
        statements = logical_statements(text, "fixed")
        self.assertEqual(len(statements), 1)
        self.assertEqual(statements[0].text, "CALL FOO(A,B, C,D)")


if __name__ == "__main__":
    unittest.main()
