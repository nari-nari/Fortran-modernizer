import shutil
import tempfile
import unittest
from pathlib import Path

from fortran_refactor.apply import ApplyError, apply_plan
from fortran_refactor.common_include import write_common_include_plan
from fortran_refactor.common_module import write_common_module_plan
from fortran_refactor.compiler import _order_sources
from fortran_refactor.diagnostics import build_analysis_result
from fortran_refactor.extract import analyze_unit
from fortran_refactor.implicit_none import write_implicit_none_plan
from fortran_refactor.procedure_module import write_procedure_module_plan
from fortran_refactor.source import discover_fortran_files, split_program_units
from fortran_refactor.suggestions import write_suggestions


class ProcedureModulePlanTest(unittest.TestCase):
    def _analyze_tree(self, root: Path, include_dirs: list[Path]):
        return build_analysis_result(
            [
                analyze_unit(unit, include_dirs)
                for source in discover_fortran_files([root])
                for unit in split_program_units(source)
            ]
        )

    def _prepare_common_module_tree(self, base: Path) -> Path:
        source_root = base / "source"
        shutil.copytree("samples/legacy_runnable", source_root)
        include_dir = source_root / "include"

        typo_plan = base / "typo-plan"
        write_suggestions(self._analyze_tree(source_root, [include_dir]), typo_plan)
        stage1 = apply_plan(
            typo_plan,
            base / "stage1",
            selected_ids=set(),
            all_automatic=True,
            approve_review=False,
            include_dirs=[include_dir],
            run_compile_check=False,
        )
        stage1_root = Path(stage1["transformed_root"])

        implicit_plan = base / "implicit-plan"
        implicit_items = write_implicit_none_plan(
            self._analyze_tree(stage1_root, [stage1_root / "include"]), implicit_plan
        )
        stage2 = apply_plan(
            implicit_plan,
            base / "stage2",
            selected_ids={item.id for item in implicit_items if item.safety == "approval-required"},
            all_automatic=False,
            approve_review=True,
            include_dirs=[stage1_root / "include"],
            run_compile_check=False,
        )
        stage2_root = Path(stage2["transformed_root"])

        common_plan = base / "common-plan"
        common_items = write_common_include_plan(
            self._analyze_tree(stage2_root, [stage2_root / "include"]), common_plan
        )
        stage3 = apply_plan(
            common_plan,
            base / "stage3",
            selected_ids={item.id for item in common_items if item.safety == "approval-required"},
            all_automatic=False,
            approve_review=True,
            include_dirs=[stage2_root / "include"],
            run_compile_check=False,
        )
        stage3_root = Path(stage3["transformed_root"])

        include_dirs = [stage3_root / "include", stage3_root / "generated_common"]
        module_plan = base / "common-module-plan"
        module_items = write_common_module_plan(
            self._analyze_tree(stage3_root, include_dirs),
            module_plan,
            include_dirs=include_dirs,
        )
        stage4 = apply_plan(
            module_plan,
            base / "stage4",
            selected_ids={item.id for item in module_items if item.safety == "approval-required"},
            all_automatic=False,
            approve_review=True,
            include_dirs=include_dirs,
            run_compile_check=False,
        )
        return Path(stage4["transformed_root"])

    def test_plan_moves_external_subroutines_and_adds_use_only(self):
        with tempfile.TemporaryDirectory() as tmp_dir:
            base = Path(tmp_dir)
            stage4 = self._prepare_common_module_tree(base)
            plan = base / "procedure-plan"
            items = write_procedure_module_plan(
                self._analyze_tree(stage4, [stage4 / "include"]),
                plan,
            )
            self.assertEqual(len(items), 1)
            item = items[0]
            self.assertEqual(item.safety, "approval-required")
            self.assertEqual(item.details["module_name"], "legacy_procedures_module")
            self.assertEqual(
                item.details["procedure_names"],
                ["compute_metrics", "init_geometry", "print_results", "solve_reynolds"],
            )
            preview_main = (plan / "transformed_sources/journal_bearing_legacy.for").read_text(
                encoding="utf-8"
            ).lower()
            self.assertIn("use legacy_procedures_module, only:", preview_main)
            self.assertNotIn("subroutine init_geometry", preview_main)
            generated = plan / "transformed_sources/generated_modules/legacy_procedures_module.for"
            self.assertTrue(generated.is_file())
            generated_text = generated.read_text(encoding="utf-8").lower()
            self.assertIn("module legacy_procedures_module", generated_text)
            self.assertIn("contains", generated_text)
            self.assertIn("subroutine solve_reynolds", generated_text)

    def test_apply_requires_approval_and_establishes_explicit_interfaces(self):
        with tempfile.TemporaryDirectory() as tmp_dir:
            base = Path(tmp_dir)
            stage4 = self._prepare_common_module_tree(base)
            plan = base / "procedure-plan"
            write_procedure_module_plan(
                self._analyze_tree(stage4, [stage4 / "include"]),
                plan,
            )
            with self.assertRaises(ApplyError):
                apply_plan(
                    plan,
                    base / "unapproved",
                    selected_ids={"PROC-0001"},
                    all_automatic=False,
                    approve_review=False,
                    include_dirs=[stage4 / "include"],
                    run_compile_check=False,
                )

            receipt = apply_plan(
                plan,
                base / "applied",
                selected_ids={"PROC-0001"},
                all_automatic=False,
                approve_review=True,
                include_dirs=[stage4 / "include"],
                run_compile_check=True,
            )
            transformed = Path(receipt["transformed_root"])
            self.assertEqual(receipt["remaining_external_procedures"], [])
            self.assertEqual(receipt["missing_procedure_modules"], [])
            self.assertEqual(receipt["missing_explicit_uses"], [])
            self.assertEqual(receipt["compile_check"]["returncode"], 0)
            self.assertNotIn(
                "implicit interface",
                receipt["compile_check"]["stderr"].lower(),
            )
            units = [
                unit
                for source in discover_fortran_files([transformed])
                for unit in split_program_units(source)
            ]
            self.assertFalse(any(unit.kind == "subroutine" for unit in units))
            self.assertTrue(
                any(unit.kind == "module" and unit.name == "legacy_procedures_module" for unit in units)
            )

    def test_module_sources_are_ordered_by_use_dependency(self):
        with tempfile.TemporaryDirectory() as tmp_dir:
            root = Path(tmp_dir)
            storage = root / "z_storage.f90"
            procedures = root / "a_procedures.f90"
            main = root / "main.f90"
            storage.write_text("module storage_mod\nend module storage_mod\n", encoding="utf-8")
            procedures.write_text(
                "module procedures_mod\n  use storage_mod\nend module procedures_mod\n",
                encoding="utf-8",
            )
            main.write_text("program demo\n  use procedures_mod\nend program demo\n", encoding="utf-8")
            self.assertEqual(_order_sources([main, procedures, storage]), [storage, procedures, main])

    def test_selected_subroutine_calling_unmigrated_external_is_blocked(self):
        with tempfile.TemporaryDirectory() as tmp_dir:
            root = Path(tmp_dir) / "source"
            root.mkdir()
            source = root / "example.for"
            source.write_text(
                "      PROGRAM DEMO\n"
                "      IMPLICIT NONE\n"
                "      CALL WORK\n"
                "      END\n"
                "      SUBROUTINE WORK\n"
                "      IMPLICIT NONE\n"
                "      CALL VENDOR_ROUTINE\n"
                "      END\n",
                encoding="utf-8",
            )
            plan = Path(tmp_dir) / "plan"
            items = write_procedure_module_plan(self._analyze_tree(root, []), plan)
            self.assertEqual(items[0].safety, "blocked")
            self.assertIn("non-migrated external subroutines", items[0].rationale)


if __name__ == "__main__":
    unittest.main()
