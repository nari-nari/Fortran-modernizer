from __future__ import annotations

import hashlib
import json
from pathlib import Path

from fortran_refactor.diagnostics import build_analysis_result
from fortran_refactor.extract import analyze_unit
from fortran_refactor.python_handoff import write_python_handoff
from fortran_refactor.source import discover_fortran_files, split_program_units


def _analysis(paths: list[str], include_dirs: list[Path] | None = None):
    includes = include_dirs or []
    units = []
    for path in discover_fortran_files(paths):
        for unit in split_program_units(path, includes):
            units.append(analyze_unit(unit, includes))
    return build_analysis_result(units)


def test_exports_calls_common_types_and_source_hash(tmp_path: Path) -> None:
    source = Path("samples/legacy_runnable").resolve()
    result = _analysis([str(source)], [source])

    target = write_python_handoff(
        result,
        tmp_path / "handoff.json",
        source_root=source,
    )
    payload = json.loads(target.read_text(encoding="utf-8"))

    assert payload["schema_version"] == "1.1"
    assert payload["producer_version"] == "0.50.0"
    assert len(payload["calls"]) == 4
    assert payload["calls"][0]["caller"] == "journal_bearing_legacy"
    assert payload["calls"][0]["callee"] == "init_geometry"

    field = next(item for item in payload["common_blocks"] if item["name"] == "field")
    declaration = next(
        item for item in field["declarations"]
        if item["program_unit"] == "journal_bearing_legacy"
    )
    assert declaration["members"][0] == {
        "position": 1,
        "name": "p",
        "category": "real",
        "kind": "8",
        "rank": 2,
        "shape": ["ntheta", "nz"],
        "char_length": None,
        "explicit": True,
    }

    source_entry = payload["source_map"][0]
    source_path = source / source_entry["source_file"]
    assert source_entry["sha256"] == hashlib.sha256(source_path.read_bytes()).hexdigest()


def test_exports_module_procedures_as_qualified_scopes(tmp_path: Path) -> None:
    source = Path("samples/existing_structure_integration").resolve()
    result = _analysis([str(source)])

    target = write_python_handoff(
        result,
        tmp_path / "handoff.json",
        source_root=source,
    )
    payload = json.loads(target.read_text(encoding="utf-8"))

    units = {item["scope_id"]: item for item in payload["program_units"]}
    assert units["workers::initialize"]["parent_unit"] == "workers"
    assert units["workers::initialize"]["start_line"] == 4
    assert units["workers::initialize"]["end_line"] == 12
    assert units["workers::total_value"]["arguments"] == ["total"]

    symbols = {
        (item["scope_id"], item["name"]): item
        for item in payload["symbols"]
    }
    assert symbols[("workers::initialize", "i")]["role"] == "local"
    assert symbols[("workers::total_value", "total")]["role"] == "argument"
