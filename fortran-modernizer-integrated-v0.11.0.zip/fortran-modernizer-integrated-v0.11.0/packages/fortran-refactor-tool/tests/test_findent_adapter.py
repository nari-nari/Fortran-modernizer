from __future__ import annotations

import shutil
import tempfile
import unittest
from pathlib import Path

from fortran_refactor.findent_adapter import FindentError, verify_with_findent


class FindentAdapterTest(unittest.TestCase):
    @property
    def fixture(self) -> Path:
        return Path(__file__).resolve().parents[1] / "samples" / "absoft_compatibility" / "multiline_declarations.for"

    def test_optional_cross_check(self) -> None:
        if shutil.which("findent") is None:
            self.skipTest("findent unavailable")
        with tempfile.TemporaryDirectory() as temp:
            result = verify_with_findent([self.fixture], [], Path(temp), line_length=72)
            self.assertTrue(result["all_verified"])
            self.assertEqual(len(result["files"]), 1)
            self.assertTrue((Path(temp) / "findent_verification.json").is_file())

    def test_missing_findent_is_explicit(self) -> None:
        from unittest.mock import patch
        with patch("fortran_refactor.findent_adapter.shutil.which", return_value=None):
            with self.assertRaises(FindentError):
                verify_with_findent([self.fixture], [], Path("unused"))


if __name__ == "__main__":
    unittest.main()
