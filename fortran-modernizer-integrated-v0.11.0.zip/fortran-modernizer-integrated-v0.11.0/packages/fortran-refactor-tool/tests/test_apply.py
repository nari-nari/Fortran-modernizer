import json
import shutil
import tempfile
import unittest
from pathlib import Path

from fortran_refactor.apply import ApplyError, apply_plan
from fortran_refactor.diagnostics import build_analysis_result
from fortran_refactor.extract import analyze_unit
from fortran_refactor.implicit_none import write_implicit_none_plan
from fortran_refactor.source import split_program_units
from fortran_refactor.suggestions import write_suggestions


class ApplyPlanTest(unittest.TestCase):
    def _result(self, source: Path, include_dir: Path):
        return build_analysis_result(
            [analyze_unit(unit, [include_dir]) for unit in split_program_units(source)]
        )

    def test_apply_automatic_typo_to_copy_and_reject_stale_plan(self):
        with tempfile.TemporaryDirectory() as tmp_dir:
            base = Path(tmp_dir)
            source_root = base / "source"
            shutil.copytree("samples/legacy_runnable", source_root)
            source = source_root / "journal_bearing_legacy.for"
            original = source.read_text(encoding="utf-8")
            plan = base / "plan"
            write_suggestions(self._result(source, source_root / "include"), plan)

            receipt = apply_plan(
                plan,
                base / "applied",
                selected_ids=set(),
                all_automatic=True,
                approve_review=False,
                include_dirs=[source_root / "include"],
                run_compile_check=False,
            )
            transformed = Path(receipt["transformed_root"]) / "journal_bearing_legacy.for"
            self.assertIn("RESIDUAL=RESIDUAL", transformed.read_text(encoding="utf-8"))
            self.assertNotIn("RESIDUALL=RESIDUAL", transformed.read_text(encoding="utf-8"))
            self.assertEqual(source.read_text(encoding="utf-8"), original)

            source.write_text(original + "C stale\n", encoding="utf-8")
            with self.assertRaises(ApplyError):
                apply_plan(
                    plan,
                    base / "stale",
                    selected_ids=set(),
                    all_automatic=True,
                    approve_review=False,
                    include_dirs=[source_root / "include"],
                    run_compile_check=False,
                )

    def test_implicit_none_requires_explicit_approval(self):
        with tempfile.TemporaryDirectory() as tmp_dir:
            base = Path(tmp_dir)
            source_root = base / "source"
            shutil.copytree("samples/legacy_runnable", source_root)
            source = source_root / "journal_bearing_legacy.for"
            source.write_text(
                source.read_text(encoding="utf-8").replace("RESIDUALL=RESIDUAL", "RESIDUAL=RESIDUAL"),
                encoding="utf-8",
            )
            plan = base / "plan"
            write_implicit_none_plan(self._result(source, source_root / "include"), plan)
            ids = {
                item["id"]
                for item in json.loads((plan / "suggestions.json").read_text(encoding="utf-8"))
                if item["safety"] == "approval-required"
            }
            with self.assertRaises(ApplyError):
                apply_plan(
                    plan,
                    base / "unapproved",
                    selected_ids=ids,
                    all_automatic=False,
                    approve_review=False,
                    include_dirs=[source_root / "include"],
                    run_compile_check=False,
                )

            receipt = apply_plan(
                plan,
                base / "approved",
                selected_ids=ids,
                all_automatic=False,
                approve_review=True,
                include_dirs=[source_root / "include"],
                run_compile_check=False,
            )
            transformed = Path(receipt["transformed_root"]) / "journal_bearing_legacy.for"
            text = transformed.read_text(encoding="utf-8")
            self.assertEqual(text.upper().count("IMPLICIT NONE"), 5)
            self.assertNotIn("IMPLICIT REAL", text.upper())
            self.assertEqual(receipt["fparser_success"], receipt["fparser_program_units"])


if __name__ == "__main__":
    unittest.main()
