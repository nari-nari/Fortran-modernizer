from __future__ import annotations

import hashlib
import json
import subprocess
import tempfile
import unittest
from pathlib import Path

from fortran_refactor.test_harness import write_test_harness_suggestions


class TestHarnessSuggestionTest(unittest.TestCase):
    def setUp(self) -> None:
        self.root = Path(__file__).resolve().parents[1]
        self.fixture = self.root / "samples" / "testability" / "testable_kernels.f90"

    def test_generates_module_procedure_harnesses(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            output = Path(temp) / "report"
            result = write_test_harness_suggestions([self.fixture], [], output)
            by_name = {item.procedure: item for item in result.candidates}
            self.assertEqual(by_name["scale_values"].status, "ready")
            self.assertEqual(by_name["weighted_energy"].status, "ready")
            self.assertTrue((output / by_name["scale_values"].harness_path).is_file())
            self.assertEqual(by_name["noisy_kernel"].status, "blocked")
            self.assertIn("embedded I/O", by_name["noisy_kernel"].blockers)
            self.assertEqual(by_name["cached_kernel"].status, "blocked")
            self.assertIn("SAVE state", by_name["cached_kernel"].blockers)

    def test_argument_contract_and_shape_initialization(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            output = Path(temp) / "report"
            result = write_test_harness_suggestions([self.fixture], [], output, selected_units=["scale_values"], default_array_extent=4)
            contracts = {item.name: item for item in result.arguments}
            self.assertEqual(contracts["results"].intent, "out")
            self.assertEqual(contracts["values"].shape, ("n",))
            harness = (output / result.candidates[0].harness_path).read_text(encoding="utf-8")
            self.assertIn("integer, parameter :: frt_extent = 4", harness)
            self.assertIn("n = frt_extent", harness)
            self.assertIn("real(real64) :: values(frt_extent)", harness)

    def test_generated_harness_compiles_and_runs(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            output = root / "report"
            result = write_test_harness_suggestions([self.fixture], [], output, selected_units=["scale_values"])
            harness = output / result.candidates[0].harness_path
            exe = root / "test_scale"
            compile_result = subprocess.run(["gfortran", str(self.fixture), str(harness), "-o", str(exe)], text=True, capture_output=True)
            self.assertEqual(compile_result.returncode, 0, compile_result.stderr)
            run = subprocess.run([str(exe)], text=True, capture_output=True)
            self.assertEqual(run.returncode, 0, run.stderr)
            self.assertIn("FRT_SUM results", run.stdout)
            self.assertIn("2.1937500000000000E+001", run.stdout)

    def test_report_is_non_modifying(self) -> None:
        before = hashlib.sha256(self.fixture.read_bytes()).hexdigest()
        with tempfile.TemporaryDirectory() as temp:
            output = Path(temp) / "report"
            write_test_harness_suggestions([self.fixture], [], output)
            payload = json.loads((output / "test_harness_plan.json").read_text(encoding="utf-8"))
            self.assertIn("does not modify production source", payload["summary"]["scope_note"])
            self.assertTrue((output / "test_harness_review.json").is_file())
        self.assertEqual(before, hashlib.sha256(self.fixture.read_bytes()).hexdigest())


if __name__ == "__main__":
    unittest.main()
