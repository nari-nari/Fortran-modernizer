from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path

from fortran_refactor.project import load_project_config
from fortran_refactor.project_assessment import run_configured_regression
from fortran_refactor.regression_suite import (
    RegressionSuiteError,
    run_regression_case_suite,
    validate_regression_cases,
)


class RegressionSuiteTest(unittest.TestCase):
    def test_validation_rejects_duplicate_named_groups(self) -> None:
        cases = [
            {
                "name": "nominal",
                "checkpoints": [
                    {
                        "name": "converged",
                        "comparisons": [
                            {
                                "name": "pressure",
                                "reference": "reference.dat",
                                "actual": "actual.dat",
                            },
                            {
                                "name": "pressure",
                                "reference": "reference2.dat",
                                "actual": "actual2.dat",
                            },
                        ],
                    }
                ],
            }
        ]
        with self.assertRaisesRegex(RegressionSuiteError, "Duplicate comparison name"):
            validate_regression_cases(cases)

    def test_two_cases_generate_checkpoint_and_cross_case_summaries(self) -> None:
        with tempfile.TemporaryDirectory() as tmp_dir:
            root = Path(tmp_dir)
            for case_name, perturbation in (("nominal", 0.0), ("high-load", 1.0e-8)):
                case_dir = root / case_name
                case_dir.mkdir()
                (case_dir / "initial.ref").write_text("1 2\n3 4\n", encoding="utf-8")
                (case_dir / "initial.out").write_text(
                    f"1 2\n3 {4.0 + perturbation}\n", encoding="utf-8"
                )
                (case_dir / "final.ref").write_text("0 1.0\n1 0.1\n2 0.01\n", encoding="utf-8")
                (case_dir / "final.out").write_text("0 1.0\n1 0.1\n2 0.01\n", encoding="utf-8")
            cases = [
                {
                    "name": case_name,
                    "working_directory": case_name,
                    "build_commands": [],
                    "run_commands": [],
                    "checkpoints": [
                        {
                            "name": "initialization",
                            "comparisons": [
                                {
                                    "name": "pressure",
                                    "mode": "numeric-array-text",
                                    "reference": "initial.ref",
                                    "actual": "initial.out",
                                    "atol": 1.0e-6,
                                    "rtol": 0.0,
                                }
                            ],
                        },
                        {
                            "name": "converged",
                            "comparisons": [
                                {
                                    "name": "residual",
                                    "mode": "numeric-history",
                                    "reference": "final.ref",
                                    "actual": "final.out",
                                    "iteration_column": 0,
                                    "value_columns": [1],
                                }
                            ],
                        },
                    ],
                }
                for case_name in ("nominal", "high-load")
            ]
            output = root / "reports"
            result = run_regression_case_suite(root, cases, output)
            self.assertEqual(result["status"], "pass")
            self.assertEqual(result["summary"]["cases"], 2)
            self.assertEqual(result["summary"]["checkpoints"], 4)
            self.assertEqual(result["summary"]["comparisons"], 4)
            groups = {
                (item["checkpoint"], item["comparison"]): item
                for item in result["cross_case_groups"]
            }
            self.assertEqual(groups[("initialization", "pressure")]["cases"], 2)
            self.assertEqual(groups[("initialization", "pressure")]["passed"], 2)
            self.assertEqual(
                groups[("initialization", "pressure")]["worst_max_absolute_error_case"],
                "high-load",
            )
            self.assertTrue((output / "suite.json").is_file())
            self.assertTrue((output / "suite.csv").is_file())
            self.assertIn("Cross-case groups", (output / "suite.md").read_text(encoding="utf-8"))
            self.assertTrue(
                (output / "cases" / "nominal" / "initialization" / "pressure" / "comparison.json").is_file()
            )

    def test_failed_case_is_visible_in_cross_case_group(self) -> None:
        with tempfile.TemporaryDirectory() as tmp_dir:
            root = Path(tmp_dir)
            for case_name, actual in (("nominal", "1 2\n"), ("fault", "1 3\n")):
                case_dir = root / case_name
                case_dir.mkdir()
                (case_dir / "reference.dat").write_text("1 2\n", encoding="utf-8")
                (case_dir / "actual.dat").write_text(actual, encoding="utf-8")
            cases = [
                {
                    "name": name,
                    "working_directory": name,
                    "checkpoints": [
                        {
                            "name": "final",
                            "comparisons": [
                                {
                                    "name": "field",
                                    "mode": "numeric-array-text",
                                    "reference": "reference.dat",
                                    "actual": "actual.dat",
                                    "atol": 0.0,
                                    "rtol": 0.0,
                                }
                            ],
                        }
                    ],
                }
                for name in ("nominal", "fault")
            ]
            result = run_regression_case_suite(root, cases, root / "reports")
            self.assertEqual(result["status"], "failed")
            self.assertEqual(result["summary"]["failed_cases"], 1)
            self.assertEqual(result["summary"]["failures"], 1)
            group = result["cross_case_groups"][0]
            self.assertEqual(group["status"], "failed")
            self.assertEqual(group["failed"], 1)
            self.assertEqual(group["worst_max_absolute_error_case"], "fault")
            self.assertEqual(group["worst_max_absolute_error"], 1.0)

    def test_project_pipeline_includes_named_case_suite(self) -> None:
        with tempfile.TemporaryDirectory() as tmp_dir:
            root = Path(tmp_dir)
            (root / "dummy.f90").write_text("program dummy\nend program dummy\n", encoding="utf-8")
            case_dir = root / "case1"
            case_dir.mkdir()
            (case_dir / "reference.dat").write_text("1 2 3\n", encoding="utf-8")
            (case_dir / "actual.dat").write_text("1 2 3\n", encoding="utf-8")
            config = {
                "schema_version": 1,
                "project": {"name": "suite", "root": "."},
                "sources": {"paths": ["dummy.f90"], "include_globs": ["**/*.f90"], "exclude_globs": []},
                "fortran": {"include_dirs": [], "fixed_line_length": 72},
                "compiler": {"enabled": False},
                "regression": {
                    "enabled": True,
                    "working_directory": ".",
                    "build_commands": [],
                    "run_commands": [],
                    "comparisons": [],
                    "cases": [
                        {
                            "name": "case1",
                            "working_directory": "case1",
                            "checkpoints": [
                                {
                                    "name": "final",
                                    "comparisons": [
                                        {
                                            "name": "field",
                                            "mode": "numeric-array-text",
                                            "reference": "reference.dat",
                                            "actual": "actual.dat",
                                        }
                                    ],
                                }
                            ],
                        }
                    ],
                },
                "assessment": {"performance_budget_seconds": 60.0},
            }
            config_path = root / "fortran-refactor.json"
            config_path.write_text(json.dumps(config), encoding="utf-8")
            project = load_project_config(config_path)
            result = run_configured_regression(project, root / "reports")
            self.assertEqual(result["status"], "pass")
            self.assertEqual(result["case_suite"]["status"], "pass")
            self.assertEqual(result["case_suite"]["summary"]["comparisons"], 1)
            self.assertTrue((root / "reports" / "case-suite" / "suite.csv").is_file())


if __name__ == "__main__":
    unittest.main()
