# Fortran Refactoring Tool v0.49.0

- adds machine-readable canonical workspace mapping contracts for every element-mapped partial EQUIVALENCE overlap
- records workspace union size, per-view offsets, original rank/shape/bounds, overlap index ranges, source SHA-256, and review obligations
- generates standalone synthetic Fortran mapping fixtures for direct local two-array overlays
- blocks fixture generation for COMMON-connected, transitive, scalar-mixed, unresolved-kind, and same-statement dual-use cases
- keeps all contracts and fixtures analysis/test-only and never edits production source
- increases the mandatory Python test suite from 224 to 227 tests
- validates only with synthetic fixtures; production Fortran remains untested
