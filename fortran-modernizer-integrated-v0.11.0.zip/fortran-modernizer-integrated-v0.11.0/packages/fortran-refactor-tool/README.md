# Fortran Legacy Refactoring Tool — v0.50.0

固定形式、COMMON、暗黙型、外部手続き、既存module・派生型、Absoft/DEC系拡張を含むレガシーFortranを、**元ファイルを上書きせず**に解析し、承認付きで段階的に変換するCLIです。

依存管理はuv、Fortran構文の主解析はfparser 0.2.4、コンパイラ検証はgfortranです。v0.50.0では、v0.49.0のcanonical workspace mapping contractから、`EQUIVALENCE`を含まないworkspace module、rank別・線形accessor、旧版oracleと変換後合成プログラム、stdout完全一致用manifestを生成します。これは合成置換fixtureであり、製品ソースの編集や実コードでの適用実証は行っていません。




## `EQUIVALENCE`なしのcanonical workspace合成置換fixture

```bash
./frt storage-overlay-plan source -I include \
  -o reports/storage-overlay
```

直接的・局所的・同型の2配列overlayでは、`canonical_workspace_refactor_fixtures/<contract-id>/`へ、`canonical_workspace_module.f90`、`legacy_equivalence_program.f90`、`refactored_workspace_program.f90`、`comparison_manifest.json`を生成します。moduleには元配列のrank・下限・列優先順序を保持したrank別accessorと線形accessorが含まれ、変換後合成プログラムには`EQUIVALENCE`がありません。旧版oracleと変換後版を別々にコンパイルし、4段階のview signatureをbyte-for-byteで比較します。COMMON接続、推移的overlay、同一文での両alias使用などは遮断します。これは合成fixtureであり、製品ソースを変更しません。

## canonical workspace mapping contractと合成fixture

```bash
./frt storage-overlay-plan source -I include \
  -o reports/storage-overlay
```

`canonical_workspace_mapping_contracts.json`、CSV、Markdownへ、canonical workspace全体の要素数と、各旧配列viewのworkspace開始・終了要素、zero-based offset、元shape・上下限、Fortran列優先の線形対応、重複区間を出力します。直接的な2配列overlayで、定数境界・同型・非COMMON・非推移的である場合は、`canonical_workspace_fixtures/<contract-id>/workspace_mapping_fixture.f90`も生成します。このfixtureは旧`EQUIVALENCE` viewとcontractに基づくworkspace書込みを同じ決定値で実行し、両viewが一致することをgfortranで自己検証します。COMMON接続、推移的overlay、スカラー混在、同一文での両alias参照はfixture生成を遮断します。contractとfixtureはいずれも`analysis-only`で、製品ソースは変更しません。

## 部分的なEQUIVALENCE重複の精密分析

```bash
./frt storage-overlay-plan source -I include \
  -o reports/storage-overlay
```

`partial_overlap_candidates.json`、CSV、Markdownへ、重複するglobal／local byte範囲、重複率、prefix／suffix／包含関係、要素境界整合性、Fortran列優先の線形要素範囲と多次元添字範囲、COMMON位置、直接／推移的EQUIVALENCE、参照用途を出力します。同型で要素境界に揃う場合は`mapped`、要素途中や型不一致は`needs-manual-proof`ですが、どちらも自動変換対象ではありません。詳細は[`docs/storage_overlay.md`](docs/storage_overlay.md)を参照してください。


## `STORAGE_SIZE` probeマトリクス

```bash
./frt equivalence-alias-suggest source \
  --storage-size-matrix-config samples/config/storage_size_probe_matrix.json \
  -o reports/equivalence-alias
```

JSON設定の`profiles`に、コンパイラ、フラグ、必須／任意を名前付きで定義します。各構成で同じprobeを独立にコンパイル・実行し、要素bit数、byte数、配列全体byte数を比較します。すべての必須構成と、実行可能な任意構成が一致した場合だけ`matrix-consensus`として候補を昇格します。任意コンパイラが未導入ならskipできますが、実行できた構成の不一致は失敗です。計画作成には`storage_size_probe_matrix_reviewed=true`が必要です。v0.46.0で実際に検証した実コンパイラはgfortranのみで、O0/O2と既定実数サイズ変更を合成フィクスチャで確認しています。


## 場データ・収束履歴の回帰比較

```bash
./frt regression-compare \
  reference/pressure.csv results/pressure.csv \
  --mode numeric-array-text --delimiter , --shape 101,201 \
  --atol 1e-8 --rtol 1e-6 \
  -o reports/pressure-regression
```

テキスト配列、JSON配列、rawバイナリ、Fortran非整形順次レコード、残差履歴を比較できます。最大絶対・相対誤差、RMSE、L2ノルム、失敗要素数、最悪位置、両ファイルのSHA-256をJSON/Markdownへ出力します。Fortran `D`指数を受け付け、非整形順次ファイルではレコードマーカーを検証し、既定でFortran順の添字を報告します。`fortran-refactor.json`の`regression.comparisons`からも同じアダプターを利用できます。詳細は[`docs/regression_comparison.md`](docs/regression_comparison.md)を参照してください。

## 複数ケース・名前付きチェックポイントの回帰集計

```bash
./frt regression-suite \
  --config fortran-refactor.json \
  -o reports/regression-suite
```

`regression.cases[].checkpoints[]`に、標準条件・高荷重条件などのケースと、初期化後・収束後などの比較グループを明示します。ケースごとの詳細比較に加え、同じチェックポイント名・比較名をケース横断で集計し、通過数、失敗数、最大誤差を生じたケースをJSON/CSV/Markdownへ出力します。チェックポイント名は設定上のラベルであり、任意の解析コードへ計測処理を自動挿入するものではありません。v0.38.0は合成Fortranフィクスチャでのみ検証しています。詳細は[`docs/regression_case_suites.md`](docs/regression_case_suites.md)を参照してください。

## コンパイラ・最適化・OpenMP決定性マトリクス

```bash
./frt determinism-matrix \
  --config determinism-matrix.json \
  -o reports/determinism-matrix
```

`compilers × optimization_levels × thread_counts`の直積を生成し、各構成を2回以上実行して構成内の再現性を検査します。さらに各構成のrun 1を基準構成と比較し、最適化レベルや`OMP_NUM_THREADS`が変わった場合の場データ・残差履歴・バイナリ出力の差を集計します。コマンドはargv配列で指定し、`{compiler}`、`{compiler_flags}`、`{optimization_flags}`、`{threads}`、`{variant}`、`{executable}`を安全に展開します。未導入コンパイラは`required: false`の場合だけskipできます。v0.39.0は合成OpenMPフィクスチャで検証しており、実コードや複数ベンダーコンパイラでの実証はまだ行っていません。詳細は[`docs/determinism_checks.md`](docs/determinism_checks.md)を参照してください。

## 同一ケースの複数回実行による決定性検査

```bash
./frt determinism-check \
  --config determinism.json \
  -o reports/determinism
```

同じ実行コマンドを2回以上、新しい子プロセスで実行し、run 2以降のstdout、stderr、場配列、残差履歴、バイナリ出力などをrun 1と比較します。各runの成果物はコピーして固定され、古い出力ファイルが残っただけの偽PASSを避けるため、サイズ・更新時刻・SHA-256によるfreshness検査も行います。`remove_before_run`を指定した削除は作業ディレクトリ内のファイルだけに制限されます。`regression.determinism`としてproject pipelineにも統合できます。詳細は[`docs/determinism_checks.md`](docs/determinism_checks.md)を参照してください。

## 同一プロセス内の反復呼出し検査

```bash
./frt repeated-call-harness-suggest \
  source -I include \
  --unit solve_pressure \
  --atol 1e-12 --rtol 1e-10 \
  -o reports/repeated-call
```

生成ドライバは、決定論的入力で手続きを1回呼び、`IN`/`INOUT`引数を元へ戻してから同じプロセス内でもう1回呼びます。v0.40.0では、最初の実行で`common_state_fixture.json`を生成し、レイアウト・初期値・観測対象・source hashをレビューして`--state-fixture`で再読込すると、named COMMONも初期化・保存・復元・比較できます。同型scalar aliasに限定したEQUIVALENCEもCOMMON観測経由で扱います。blank COMMON、type punning、動的shapeは遮断します。`SAVE`、module変数、`DATA`状態、cache、allocation lifecycleは`state-risk-candidate`として可視化します。詳細は[`docs/repeated_call_harnesses.md`](docs/repeated_call_harnesses.md)を参照してください。

## 構造化制御フローへの移行

```bash
./frt control-flow-suggest source -I include \
  -o reports/control-flow
```

文番号付きDO・算術IF・専用前方GOTOに加え、CFG証拠付きで、共有DO終端の`CYCLE`、構造化DOの`EXIT`、単一・複数back-edgeのpost-test `DO`、共有`RETURN`、共有cleanupのnamed `BLOCK`化と内部手続き抽出を行います。cleanup抽出はfree/fixed-formの双方に対応し、既存`CONTAINS`がある場合はそれを保持して新しい内部手続きを末尾へ追加します。さらに、2つの入口ラベル、2つの直線状態、各方向1本の条件遷移、非遷移時の即時`RETURN`という厳密な非可約CFGだけを、BLOCK局所整数と`SELECT CASE`を使うディスパッチループへ変換します。それ以外の複数入口SCC、computed/assigned GOTO、構造境界をまたぐ分岐は引き続きブロックします。生成計画はsource hash、CFG snapshot、明示レビュー、`--approve-review`、fparser、任意のgfortranコンパイル検査で保護されます。詳細は[`docs/control_flow_modernization.md`](docs/control_flow_modernization.md)を参照してください。

## 固定サイズ配列の`ALLOCATABLE`化

```bash
./frt allocatable-storage-suggest source -I include \
  -o reports/allocatable-storage
```

対象は、privateなmodule配列、privateかつ非相互運用の派生型component、および境界が手続き入口で確定する局所作業配列です。module配列とcomponentではレビュー済みinitializer/finalizerへ`ALLOCATE`/`DEALLOCATE`を挿入します。局所配列では入口に`ALLOCATE`を挿入し、Fortranの自動解放を利用します。public型、`SEQUENCE`/`BIND(C)`、`SAVE`/`DATA`、`ENTRY`、`COMMON`/`EQUIVALENCE`、構造構築子の可能性、所有者不明などはブロックします。詳細は[`docs/allocatable_storage.md`](docs/allocatable_storage.md)を参照してください。

## 配列インターフェースの近代化

```bash
./frt array-interface-suggest \
  source -I include \
  -o reports/array-interface
```

生成された`array_interface_selection.json`をコピーし、適用候補をレビューします。

```bash
./frt array-interface-plan \
  source -I include \
  --selection reviewed_array_interfaces.json \
  -o reports/array-interface-plan

./frt apply reports/array-interface-plan \
  --id ARR-0001 --approve-review --compile-check \
  -o work/array-interface
```

単純な`a(n)`→`a(:)`置換ではありません。実配列が`n`より大きいと、whole-array演算や`SIZE`が観測する範囲が変わるため、private module手続き、明示的`INTENT`、whole-array実引数、呼出し側とdummy側の境界一致を要求します。`a(0:n-1)`は`a(0:)`として下限を保持します。public API、generic binding、array section、component、assumed-size、`BIND(C)`はv0.27.0ではブロックします。詳細は[`docs/array_interface_modernization.md`](docs/array_interface_modernization.md)を参照してください。

## 計算カーネル用Fortranテストハーネス

```bash
uv run --locked --no-sync ./frt test-harness-suggest \
  source -I include --default-array-extent 3 \
  -o reports/test-harnesses
```

外部手続きとmodule内手続きを個別に解析し、型・kind・rank・shape・`INTENT`を契約化します。I/O、COMMON、`SAVE`、`DATA`、`EQUIVALENCE`、隠れたmodule状態、未解決CALLがない手続きに限り、別ファイルのFortranドライバを生成します。生成入力は決定論的ですが物理的妥当性は保証しないため、採用前にレビューが必要です。詳細は[`docs/test_harness_generation.md`](docs/test_harness_generation.md)を参照してください。

## kind・型表記の標準化

```bash
uv run --locked --no-sync ./frt kind-standardization-plan \
  source -I include --compiler gfortran \
  -o reports/kind-standardization
```

`DOUBLE PRECISION`、`REAL*n`、`INTEGER*n`、`COMPLEX*n`を、選択したコンパイラでkind・storage size・precision/rangeが一致した場合だけ、`real64`、`int32`などへ変更します。既存の`USE, INTRINSIC :: ISO_FORTRAN_ENV, ONLY:`は統合し、typed FUNCTIONも対象にします。`LOGICAL*n`、`BYTE`、未承認の数値kind、INCLUDE由来宣言は自動変換しません。詳細は[`docs/kind_standardization.md`](docs/kind_standardization.md)を参照してください。

## 安定したFortran module API

```bash
uv run --locked --no-sync ./frt public-api-suggest \
  source -I include -o reports/public-api
```

生成された`public_api_selection.json`をレビューし、互換性維持案または明示的に承認した最小API案を選びます。

```bash
uv run --locked --no-sync ./frt public-api-plan \
  source -I include \
  --selection reviewed_public_api.json \
  -o reports/public-api-plan

uv run --locked --no-sync ./frt apply reports/public-api-plan \
  -o work/public-api \
  --id API-0001 --approve-review --compile-check
```

詳細は[`docs/public_module_api.md`](docs/public_module_api.md)を参照してください。


## 共有状態の所有者・ライフサイクル監査

```bash
uv run --locked --no-sync ./frt state-lifecycle-suggest \
  source -I include -o reports/state-lifecycle
```

module定数、書換え可能なmodule変数、`SAVE`/`DATA`局所状態、`ALLOCATABLE`資源、cache/workspaceを区別し、`parameter`化、明示引数化、state/workspace型への集約、明示的initialize/finalizeの候補を提示します。この監査コマンドはコードを変更せず、`state_lifecycle_review.json`を設計レビュー記録として生成します。詳細は[`docs/state_lifecycle.md`](docs/state_lifecycle.md)を参照してください。

## 責務分割・I/O分離候補

```bash
uv run --locked --no-sync ./frt responsibility-split-suggest \
  source -I include -o reports/responsibility-split
```

入力I/O、計算コア、出力I/Oの候補範囲を、境界変数と早期RETURN・GOTO・構造化制御の所有権リスク付きで提示します。コード抽出や自動変更は行いません。詳細は[`docs/responsibility_separation.md`](docs/responsibility_separation.md)を参照してください。

## アーキテクチャ・将来移植適性監査

本ツールは引き続きFortranリファクタリングツールです。Pythonやラッパーを生成せず、状態の明示性、I/O分離、テスト可能性、再利用可能なFortranライブラリ境界を評価します。

```bash
uv run --locked --no-sync ./frt architecture-audit source -I include -o reports/architecture
```

詳細は[`docs/architecture_readiness.md`](docs/architecture_readiness.md)を参照してください。


## 限定的なEQUIVALENCE完全alias除去

```bash
./frt equivalence-alias-suggest src -I include -o reports/equivalence-alias
./frt equivalence-alias-plan src -I include \
  --selection reviewed_equivalence_alias.json -o reports/equivalence-alias-plan
./frt apply reports/equivalence-alias-plan \
  --id EQA-... --approve-review --compile-check -o work/equivalence-alias
```

v0.46.0は、scalar／bare whole-array完全aliasに加え、静的に`review-ready`な配列先頭要素アンカーを、単一コンパイラまたは複数のコンパイラ・フラグ構成からなる`STORAGE_SIZE`マトリクスで実測できます。マトリクスでは、要素bit数、byte数、配列全体byte数、コンパイラ版、フラグ、compile/runログを構成ごとに保存し、全required構成と利用可能なoptional構成が一致した候補だけを`ready`へ昇格します。計画作成には`storage_size_probe_reviewed=true`、マトリクス利用時は`storage_size_probe_matrix_reviewed=true`、および数値回帰確認が必要です。probe未実行・失敗・構成間不一致・意味上の追加確認が必要な候補は引き続き`analysis-only`です。詳細は[`docs/equivalence_alias_removal.md`](docs/equivalence_alias_removal.md)を参照してください。

### 先頭要素アンカーのコンパイラ実測

```bash
./frt equivalence-alias-suggest src \
  --storage-size-compiler gfortran \
  --storage-size-flag=-O0 \
  -o reports/equivalence-alias
```

生成された`storage_size_probe/probe_results.json`とcompile/runログを確認し、対象行で`storage_size_probe_reviewed=true`を設定してから`equivalence-alias-plan`へ進みます。

## v0.50.0の位置付け

実コードを利用できない前提を維持し、canonical workspace mapping contractを、`EQUIVALENCE`なしのmodule／accessorと旧版・変換後合成プログラムへ展開して数値的に比較できる段階です。

- workspace全体の要素数、byte範囲、各旧viewのzero-based offsetを固定
- 元のrank、shape、各次元の上下限、workspace開始・終了要素を記録
- `workspace_index = view_linear_index + offset`をFortran列優先規則として明示
- 重複区間のworkspace範囲と両viewの元添字範囲を対応付け
- 直接・局所・同型の2配列overlayにはcontract駆動の合成Fortran fixtureを生成
- COMMON接続、推移的overlay、スカラー混在などはfixture生成を遮断
- contractもfixtureも分析・検証専用で、製品ソース編集や実コード適用の主張は行わない
- eligibleなcontractからworkspace moduleとrank別／線形accessorを生成
- 旧`EQUIVALENCE` oracleとalias-free合成プログラムのstdout完全一致を検証
- COMMON接続・推移的overlayは合成置換fixture生成を遮断

詳細は`docs/storage_overlay.md`を参照してください。

## EQUIVALENCE・blank COMMONの記憶領域評価

```bash
uv run --locked --no-sync ./frt storage-overlay-plan \
  /path/to/code -I /path/to/include \
  -o reports/storage-overlay
```

`storage_layout.csv`には各変数の推定サイズ、COMMON内のpacked／natural-alignmentオフセット、EQUIVALENCE領域内の相対オフセットを出力します。`overlap_regions.csv`では、同型の完全alias、異型のtype punning、部分重なりを分離します。実際のpaddingや非標準kindはコンパイラ依存なので、両配置を併記し断定しません。

`EQUIVALENCE`の除去は分析専用です。全program unitで型・kind・rank・shapeの並びが一致し、EQUIVALENCEが触れていないblank COMMONに限り、次のようなnamed COMMON化候補を生成します。

```bash
uv run --locked --no-sync ./frt apply reports/storage-overlay \
  -o work/storage-overlay \
  --id OVL-BLANK-0001 \
  --approve-review \
  --compile-check
```

詳細は`docs/storage_overlay.md`を参照してください。

## BLOCK DATA初期化の明示化

```bash
uv run --locked --no-sync ./frt block-data-init-plan \
  /path/to/code -I /path/to/include \
  --entry-program main_program \
  -o reports/block-data-init
```

対応可能なnamed COMMONのスカラー、定数形状配列、配列要素、リテラル値、`5*0.0D0`のような反復値を明示代入へ展開します。生成initializerは保存論理フラグで二重実行を防ぎ、選択した`PROGRAM`の最初の実行文より前に呼び出されます。implied-DO、重複初期化、`EQUIVALENCE`、非定数shape、入口PROGRAMが一意でない場合は停止します。詳細は`docs/block_data_initialization.md`を参照してください。

## 既存module・派生型との統合

まず共有変数をレビュー済みのオブジェクト分類へまとめます。その分類を使って、既存構造との統合候補を比較します。

```bash
uv run --locked --no-sync ./frt state-integration-suggest \
  /path/to/code \
  -I /path/to/include \
  --classification reviewed_state_objects.json \
  -o reports/state-integration
```

比較する案は次の4種類です。

- 新しい独立types moduleを作る
- 既存moduleへ新しい型定義を追加する
- 既存派生型へ共有変数を直接追加する
- 新しい型を既存派生型の成分として包含する

生成された選択ファイルをコピーし、候補を1つ選び、`reviewed=true`にした後で計画を作ります。

```bash
uv run --locked --no-sync ./frt state-integration-plan \
  /path/to/code \
  --classification reviewed_state_objects.json \
  --selection reviewed_state_integration.json \
  -o reports/state-integration-plan

uv run --locked --no-sync ./frt apply reports/state-integration-plan \
  -o work/state-integration \
  --id STATEINT-0001 \
  --approve-review \
  --compile-check
```

`integration_candidates.csv`と`integration_comparison.md`には、module依存循環、名前衝突、公開API、初期化・コピー意味への影響が記録されます。詳細は`docs/state_integration.md`を参照してください。

## セットアップ

WSL上で展開します。

```bash
unzip fortran-refactor-tool-v0.50.0.zip
cd fortran-refactor-tool-v0.50.0
./scripts/setup_wsl.sh
```

uvとgfortranが導入済みの場合：

```bash
uv sync --locked --python python3 --no-python-downloads
uv run --locked --no-sync ./frt doctor
uv run --locked --no-sync python scripts/run_tests.py
```

オフライン環境では、公式fparser wheelを指定できます。

```bash
./scripts/setup_offline_wheel.sh /path/to/fparser-0.2.4-py3-none-any.whl
```

## EXTERNAL・外部FUNCTION・手続き引数の移行

```bash
uv run --locked --no-sync ./frt external-interface-plan \
  /path/to/code \
  -I /path/to/include \
  -o reports/external-interfaces
```

project内で定義を一意に解決できる外部手続きについて、次を提案します。

- 外部FUNCTION／SUBROUTINEの明示的interfaceを格納するmodule
- 手続き引数用の`abstract interface`
- `EXTERNAL CALLBACK`から`PROCEDURE(callback_interface) :: CALLBACK`への置換
- 呼出し側への`USE ... ONLY`追加
- 旧来の型付きEXTERNAL宣言の除去

```bash
uv run --locked --no-sync ./frt apply reports/external-interfaces \
  -o work/external-interfaces \
  --id EXT-0001 \
  --approve-review \
  --compile-check
```

未解決の外部ライブラリ手続き、複数の異なる実手続きが同じdummyへ渡される場合、重複定義は自動変換しません。詳細は`docs/external_interfaces.md`を参照してください。

## 任意のfindentクロスチェック

findentがローカルに導入済みの場合だけ、内蔵書換え器とは独立した構造クロスチェックを実行できます。

```bash
uv run --locked --no-sync ./frt findent-verify \
  /path/to/fixed-form-code \
  -I /path/to/include \
  --line-length 72 \
  -o reports/findent-check
```

findentは必須依存ではなく、自動ダウンロード・自動実行もしません。

## 固定形式の継続行・複雑文の再配置

```bash
uv run --locked --no-sync ./frt fixed-form-rewrite-plan \
  /path/to/code \
  -I /path/to/include \
  --line-length 72 \
  -o reports/fixed-form-plan
```

既定では、fparser ASTで認識できた以下を対象にします。

- 型宣言
- `COMMON`
- `CALL`

特定の種類だけに絞る場合：

```bash
uv run --locked --no-sync ./frt fixed-form-rewrite-plan \
  /path/to/code \
  --kind declaration \
  --kind common \
  --line-length 80 \
  -o reports/fixed-form-plan
```

計画結果：

```text
statement_inventory.csv
rewrite_plan.md
suggestions.json
manifest.json
proposed_changes.patch
transformed_sources/
```

差分を確認後、ファイル単位の提案IDを明示承認して別コピーへ適用します。

```bash
uv run --locked --no-sync ./frt apply reports/fixed-form-plan \
  -o work/fixed-form \
  --id FFR-0001 \
  --approve-review \
  --compile-check
```

安全条件は次のとおりです。

- raw fparser ASTと元ソースの物理行範囲が一致する
- コメントを含む継続範囲ではない
- 数字だけのシーケンス欄を失わない
- Hollerithリテラルを含まない
- 文字列・識別子の途中で分割しない
- 生成行が指定した72／80／132桁以内に収まる

詳細は`docs/fixed_form_rewriting.md`を参照してください。

## fparser AST利用状況の監査

```bash
uv run --locked --no-sync ./frt frontend-audit \
  /path/to/code \
  -I /path/to/include \
  -o reports/frontend-audit \
  --fail-on-fallback
```

主な出力：

```text
parseability.csv
frontend_coverage.csv
source_statements.csv
external_procedures.csv
derived_types.csv
use_dependencies.csv
summary.md
```

`parseability.csv`には、program unitごとに以下を記録します。

- `split_method`: `fparser-ast`、`fparser-ast-compatibility`、`lexical-fallback`
- `parse_mode`: `raw`、`compatibility-normalized`、`failed`
- `compatibility_rewrites`
- `ast_fact_count`
- `fallback_fact_count`

`--fail-on-fallback`を付けると、解析情報の抽出に字句フォールバックが使われた場合に終了コード2となります。

## Absoft互換診断

利用可能なコンパイラプロファイルを確認します。

```bash
uv run --locked --no-sync ./frt compiler-profiles
```

### 標準診断

```bash
uv run --locked --no-sync ./frt compile-check /path/to/code \
  -I /path/to/include \
  --profile standard \
  -o reports/compiler-standard
```

### Absoft/DEC互換の受入れ診断

```bash
uv run --locked --no-sync ./frt compile-check /path/to/code \
  -I /path/to/include \
  --profile absoft-compat \
  -o reports/compiler-absoft
```

このプロファイルは、gfortranで既存コードを最初に読ませるための互換性優先設定です。主に次を有効化します。

```text
-fdec
-fdollar-ok
-fdec-structure
-ffixed-line-length-none
-fallow-argument-mismatch
```

互換オプションを最終形にするのではなく、標準化が進んだ段階で一つずつ外してください。

### 未初期化変数の警告

```bash
uv run --locked --no-sync ./frt compile-check /path/to/code \
  -I /path/to/include \
  --profile uninitialized-warning \
  -o reports/uninitialized-warning
```

`-O2 -Wuninitialized -Wmaybe-uninitialized`を使ったオブジェクトビルドです。

### 未初期化値の計装ビルド

```bash
uv run --locked --no-sync ./frt compile-check /path/to/code \
  -I /path/to/include \
  --profile uninitialized-poison \
  -o reports/uninitialized-poison
```

実数のsignaling NaN、整数の番兵値、実行時検査、浮動小数点トラップを有効化したオブジェクトを生成します。未初期化利用を実際に発見するには、このフラグ群をプロジェクトの回帰実行コマンドにも適用してください。

## プロジェクト受入れ評価

```bash
uv run --locked --no-sync ./frt project-init /path/to/project \
  -o /path/to/project/fortran-refactor.json
```

Absoft互換で最初に評価する場合は設定のcompiler節を次のようにします。

```json
{
  "compiler": {
    "enabled": true,
    "command": "gfortran",
    "profile": "absoft-compat",
    "flags": []
  }
}
```

評価：

```bash
uv run --locked --no-sync ./frt assess-project \
  --config /path/to/project/fortran-refactor.json \
  -o reports/intake
```

評価レポートには、AST生解析、互換正規化解析、字句フォールバックの件数も含まれます。

## ステージ履歴と再開

```bash
uv run --locked --no-sync ./frt workspace-init /path/to/project \
  -o /path/to/project/.frt-workspace

uv run --locked --no-sync ./frt workspace-checkpoint \
  /path/to/project/.frt-workspace \
  --source-root /path/to/current-sources \
  --stage baseline-assessment \
  --note "Reviewed intake reports"

uv run --locked --no-sync ./frt workspace-status \
  /path/to/project/.frt-workspace

uv run --locked --no-sync ./frt workspace-history \
  /path/to/project/.frt-workspace

uv run --locked --no-sync ./frt workspace-resume \
  /path/to/project/.frt-workspace
```

チェックポイントはソースコピー、SHA-256、ツール版、ステージ、計画パス、レビュー注記を保存します。スナップショットが変更されていれば再開を拒否します。

## 外部OSSの方針

```bash
uv run --locked --no-sync ./frt external-tools
```

- **CamFort**: 必須依存にしません。Haskell製CLIとネイティブ依存を伴うため、本体に組み込まず、将来の任意クロスチェック候補に限定します。
- **findent**: 必須依存にしません。複雑な固定形式の再整形バックエンド候補ですが、配布・ライセンス・導入経路を確認したローカル実行ファイルだけを将来選択可能にします。
- **fortls**: 必須依存にしません。定義・参照の補助確認候補で、COMMON記憶配置の正否判定には使用しません。

現在のコア機能は、これらが無くても再現可能です。ツールが外部OSSを自動ダウンロードすることもありません。

## 実装済みの段階的変換

1. project intakeと解析可能率
2. ASTに基づく固定形式の継続宣言・COMMON・CALL再配置
3. COMMON・CALL・暗黙型の台帳と診断
3. 不整合COMMONの複数修正候補と影響分析
4. 高信頼タイプミスの提案
5. program unit単位の`IMPLICIT NONE`化
6. 互換COMMONの共通INCLUDE一本化
7. COMMONからmoduleへの移行
8. CALLグラフ・機能分類に基づくprocedure module化
9. 手続き間read/write伝播と`INTENT`候補
10. module共有状態の派生型・明示引数化
11. 提案ID・SHA-256・承認付きの非破壊適用
12. fparser・gfortran・数値回帰による適用後検証

## 安全原則

1. 元ソースを直接変更しない。
2. 数値回帰を先に固定する。
3. COMMON不整合、暗黙型廃止、module化、精度変更を同時に行わない。
4. fparser ASTを構文の主根拠とし、フォールバック利用を隠さない。
5. Absoft互換正規化は解析専用で、元ソースへ自動反映しない。
6. 意味変更を伴う変換は、提案IDと`--approve-review`を必須にする。
7. 計画後にソースが変わった場合は適用しない。
8. 未解決EXTERNAL、エイリアス、EQUIVALENCE、DATA implied-DOなどは自動変換しない。
9. CamFort等の外部CLIを必須化せず、自動ダウンロード・無断実行をしない。
10. 互換コンパイラプロファイルは受入れ用とし、最終的には標準プロファイルを通す。

## 品質ゲート

```bash
./scripts/run_acceptance.sh
```

以下を一括確認します。

- uvロックとfparser 0.2.4
- 全Pythonテスト
- 全サンプルのASTフロントエンド監査と字句フォールバック0件
- 固定形式の継続宣言・COMMON・CALL書換えデモ
- Absoft互換フィクスチャのgfortran診断
- 未初期化警告・計装ビルド
- 10,000行・80 program unitの性能試験
- COMMON修正デモ
- BLOCK DATA初期化の明示化・実行デモ
- EQUIVALENCE／blank COMMONの記憶領域評価とblank COMMON命名デモ
- 既存module・派生型統合の4案比較と包含案実行デモ
- コンパイラ検証付きkind・型表記標準化デモ
- 全7段階の潤滑解析変換
- 厳格gfortranビルド
- golden output比較
- テキスト・JSON・rawバイナリ・Fortran非整形配列の回帰比較
- 残差履歴と最悪誤差位置の比較デモ

## 現時点の未実装・制限

- project外ライブラリのEXTERNAL interfaceを推測する機能
- 複数の互換な実手続きを1つのprocedure dummyへ束ねるgenericな移行
- DATA implied-DO、非定数shape、COMMON外初期化など複雑な初期化形式
- EQUIVALENCEの自動除去（記憶領域可視化とblank COMMON命名候補は実装済み）
- 既存moduleの直接編集はfree formのみ。固定形式moduleは候補をblockedにする
- kind標準化では、D指数実数リテラル、DBLE/DCMPLX等の変換intrinsic、INCLUDE由来宣言はまだ自動変換しない

v0.21.0では、固定形式ソースとINCLUDE断片をレビュー付きで自由形式へ移行し、旧固定形式コピーの除去、fparser構造比較、gfortran、数値回帰までを独立ゲートとして実行できます。

## Fixed-form to free-form migration

After semantic refactoring stages are complete, create a reviewed project-scoped conversion plan:

```bash
uv run --locked --no-sync ./frt fixed-to-free-plan \
  work/stage7/transformed_sources \
  -I work/stage7/transformed_sources/include \
  --input-line-length 72 \
  -o reports/fixed-to-free
```

The plan uses an explicitly installed findent executable, converts fixed-form source files to `.f90`, converts referenced INCLUDE fragments in place, compares program-unit structure with fparser, and runs a gfortran preview check. It never changes the original tree. Apply only after reviewing `proposed_changes.patch`:

```bash
uv run --locked --no-sync ./frt apply reports/fixed-to-free \
  -o work/free-form \
  --id F2F-0001 \
  --approve-review \
  -I work/stage7/transformed_sources/include \
  --compile-check
```

See [`docs/fixed_to_free.md`](docs/fixed_to_free.md).

## Canonical Python-migration handoff

The integration build of v0.50.0 can export a schema-1.1 handoff without
modifying source files:

```bash
frt export-python-handoff src/ -I include/ \
  --source-root src/ \
  -o build/refactor_handoff.json
```

Unlike a generic JSON bundle importer, this command preserves CALL edges,
COMMON positions, nested type metadata, source hashes, and qualified module
procedure scopes directly from the typed analysis model. See
`INTEGRATION_NOTES_v0.50.0.md`.
