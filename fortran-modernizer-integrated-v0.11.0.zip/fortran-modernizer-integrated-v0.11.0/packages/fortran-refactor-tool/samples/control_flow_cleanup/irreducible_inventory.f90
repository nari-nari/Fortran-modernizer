subroutine irreducible_inventory(flag, n, result)
  implicit none
  logical, intent(in) :: flag
  integer, intent(in) :: n
  integer, intent(out) :: result
  result = 0
  if (flag) goto 20
10 result = result + 1
  if (result == 1) goto 20
  if (result < n) goto 20
  return
20 result = result + 2
  if (result < n) goto 10
  return
end subroutine irreducible_inventory
