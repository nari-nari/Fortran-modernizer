program cleanup_demo
  implicit none
  integer :: result
  call calculate(result, .true.)
  print '(i0)', result
end program cleanup_demo

subroutine calculate(result, add_extra)
  implicit none
  integer, intent(out) :: result
  logical, intent(in) :: add_extra
  logical :: failed
  result = 5
  failed = .false.
  if (failed) goto 900
  call add_two(result)
  if (result < 0) goto 900
  result = result + 3
900 if (add_extra) then
    result = result + 10
  else
    result = result + 20
  end if
  result = result + 1
  return
contains
  subroutine add_two(value)
    integer, intent(inout) :: value
    value = value + 2
  end subroutine add_two
end subroutine calculate
