program irreducible_demo
  implicit none
  integer :: a, b
  call irreducible(.true., 7, a)
  call irreducible(.false., 7, b)
  print '(i0,1x,i0)', a, b
end program irreducible_demo

subroutine irreducible(flag, n, result)
  implicit none
  logical, intent(in) :: flag
  integer, intent(in) :: n
  integer, intent(out) :: result
  result = 0
  if (flag) goto 20
10 result = result + 1
  if (result < n) goto 20
  return
20 result = result + 2
  if (result < n) goto 10
  return
end subroutine irreducible
