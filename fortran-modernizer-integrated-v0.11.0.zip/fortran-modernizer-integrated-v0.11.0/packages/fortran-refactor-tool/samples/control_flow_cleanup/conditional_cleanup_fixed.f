      PROGRAM CLEANFIX
      INTEGER R
      R=5
      CALL CLEANUP(R,.TRUE.)
      WRITE(*,'(I0)') R
      END
      SUBROUTINE CLEANUP(R,FLAG)
      INTEGER R
      LOGICAL FLAG,FAIL
      FAIL=.FALSE.
      IF (FAIL) GOTO 900
      R=R+2
      IF (R.LT.0) GOTO 900
      R=R+3
  900 IF (FLAG) THEN
      R=R+10
      ELSE
      R=R+20
      END IF
      R=R+1
      RETURN
      END
