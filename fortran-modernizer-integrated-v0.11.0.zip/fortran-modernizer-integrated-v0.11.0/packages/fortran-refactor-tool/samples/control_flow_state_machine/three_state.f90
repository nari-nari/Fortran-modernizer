program state_machine_demo
  implicit none
  integer :: r1, s1, r2, s2, r3, s3
  call machine(1, 7, r1, s1)
  call machine(2, 7, r2, s2)
  call machine(3, 7, r3, s3)
  print '(6(i0,1x))', r1, s1, r2, s2, r3, s3
end program state_machine_demo

subroutine machine(entry, limit, result, status)
  implicit none
  integer, intent(in) :: entry, limit
  integer, intent(out) :: result, status
  result = 0
  status = 0
  if (entry == 2) goto 20
  if (entry == 3) goto 30
10 result = result + 1
  if (result < limit) goto 20
  status = 10
  return
20 result = result + 2
  if (result < limit) goto 30
  status = 20
  return
30 result = result + 3
  if (result < limit) goto 10
  if (result == limit) goto 40
  status = 30
  return
40 status = 99
  return
end subroutine machine
