program advanced_cfg
  implicit none
  integer :: result

  call calculate(result)
  print '(i0)', result
contains
  subroutine calculate(result)
    integer, intent(out) :: result
    integer :: i
    logical :: failed

    result = 0
    i = 0
10  continue
    i = i + 1
    result = result + 1
    if (i == 2) goto 10
    result = result + 2
    if (i < 4) goto 10

    failed = .false.
    if (failed) goto 900
    result = result + 5
    if (result < 0) goto 900
    result = result + 7
900 result = result + 10
    result = result + 20
    return
  end subroutine calculate
end program advanced_cfg
