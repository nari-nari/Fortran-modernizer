program control_demo
  implicit none
  integer :: i, s, x

  s = 0
  do 100 i = 1, 3
    s = s + i
100 continue

  x = -1
  if (x) 10, 20, 30
10 s = s + 10
  go to 40
20 s = s + 20
  go to 40
30 s = s + 30
40 continue

  go to 50
  s = 999
50 continue

  print '(i0)', s
end program control_demo
