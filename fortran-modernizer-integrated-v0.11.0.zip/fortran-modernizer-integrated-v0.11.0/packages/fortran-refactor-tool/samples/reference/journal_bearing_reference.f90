module journal_bearing_reference_mod
  use iso_fortran_env, only: real64
  implicit none
  private
  public :: run_case

  integer, parameter :: dp = real64
  integer, parameter :: ntheta = 36
  integer, parameter :: nz = 17

contains

  subroutine run_case()
    real(dp) :: pressure(ntheta, nz)
    real(dp) :: film(ntheta)
    real(dp) :: theta(ntheta)
    real(dp) :: residual
    real(dp) :: load
    real(dp) :: max_pressure
    real(dp) :: min_film
    real(dp) :: friction
    integer :: iterations

    call initialize_geometry(film, theta)
    call solve_reynolds(pressure, film, theta, iterations, residual)
    call compute_metrics(pressure, film, theta, load, max_pressure, min_film, friction)
    call print_results(iterations, residual, load, max_pressure, min_film, friction)
  end subroutine run_case

  subroutine initialize_geometry(film, theta)
    real(dp), intent(out) :: film(ntheta)
    real(dp), intent(out) :: theta(ntheta)
    real(dp), parameter :: eccentricity = 0.60_dp
    real(dp), parameter :: pi = acos(-1.0_dp)
    integer :: i

    do i = 1, ntheta
      theta(i) = 2.0_dp*pi*real(i-1, dp)/real(ntheta, dp)
      film(i) = 1.0_dp + eccentricity*cos(theta(i))
    end do
  end subroutine initialize_geometry

  subroutine solve_reynolds(pressure, film, theta, iterations, residual)
    real(dp), intent(out) :: pressure(ntheta, nz)
    real(dp), intent(in) :: film(ntheta)
    real(dp), intent(in) :: theta(ntheta)
    integer, intent(out) :: iterations
    real(dp), intent(out) :: residual
    real(dp), parameter :: omega = 1.55_dp
    real(dp), parameter :: tolerance = 1.0e-10_dp
    real(dp), parameter :: aspect = 0.50_dp
    integer, parameter :: max_iterations = 25000
    real(dp), parameter :: pi = acos(-1.0_dp)
    real(dp) :: dtheta
    real(dp) :: dz
    real(dp) :: hplus
    real(dp) :: hminus
    real(dp) :: ae
    real(dp) :: aw
    real(dp) :: az
    real(dp) :: ap
    real(dp) :: rhs
    real(dp) :: pstar
    real(dp) :: updated
    real(dp) :: change
    integer :: i
    integer :: j
    integer :: ip
    integer :: im

    pressure = 0.0_dp
    dtheta = 2.0_dp*pi/real(ntheta, dp)
    dz = 1.0_dp/real(nz-1, dp)
    residual = huge(1.0_dp)

    do iterations = 1, max_iterations
      residual = 0.0_dp
      do j = 2, nz-1
        do i = 1, ntheta
          ip = i + 1
          if (ip > ntheta) ip = 1
          im = i - 1
          if (im < 1) im = ntheta
          hplus = 0.5_dp*(film(i) + film(ip))
          hminus = 0.5_dp*(film(i) + film(im))
          ae = hplus**3/dtheta**2
          aw = hminus**3/dtheta**2
          az = aspect**2*film(i)**3/dz**2
          ap = ae + aw + 2.0_dp*az
          rhs = -6.0_dp*0.60_dp*sin(theta(i))
          pstar = (ae*pressure(ip,j) + aw*pressure(im,j) &
                   + az*(pressure(i,j+1) + pressure(i,j-1)) - rhs)/ap
          updated = max(0.0_dp, pressure(i,j) + omega*(pstar-pressure(i,j)))
          change = abs(updated-pressure(i,j))
          residual = max(residual, change)
          pressure(i,j) = updated
        end do
      end do
      if (residual < tolerance) exit
    end do
  end subroutine solve_reynolds

  subroutine compute_metrics(pressure, film, theta, load, max_pressure, min_film, friction)
    real(dp), intent(in) :: pressure(ntheta, nz)
    real(dp), intent(in) :: film(ntheta)
    real(dp), intent(in) :: theta(ntheta)
    real(dp), intent(out) :: load
    real(dp), intent(out) :: max_pressure
    real(dp), intent(out) :: min_film
    real(dp), intent(out) :: friction
    real(dp), parameter :: pi = acos(-1.0_dp)
    real(dp) :: dtheta
    real(dp) :: dz
    real(dp) :: load_x
    real(dp) :: load_y
    integer :: i
    integer :: j

    dtheta = 2.0_dp*pi/real(ntheta, dp)
    dz = 1.0_dp/real(nz-1, dp)
    load_x = 0.0_dp
    load_y = 0.0_dp
    do j = 2, nz-1
      do i = 1, ntheta
        load_x = load_x + pressure(i,j)*cos(theta(i))*dtheta*dz
        load_y = load_y + pressure(i,j)*sin(theta(i))*dtheta*dz
      end do
    end do
    load = sqrt(load_x**2 + load_y**2)
    max_pressure = maxval(pressure)
    min_film = minval(film)
    friction = 0.0_dp
    do i = 1, ntheta
      friction = friction + dtheta/film(i)
    end do
  end subroutine compute_metrics

  subroutine print_results(iterations, residual, load, max_pressure, min_film, friction)
    integer, intent(in) :: iterations
    real(dp), intent(in) :: residual
    real(dp), intent(in) :: load
    real(dp), intent(in) :: max_pressure
    real(dp), intent(in) :: min_film
    real(dp), intent(in) :: friction

    write(*,'(A,I0)') 'iterations=', iterations
    write(*,'(A,ES24.16)') 'residual=', residual
    write(*,'(A,ES24.16)') 'load=', load
    write(*,'(A,ES24.16)') 'max_pressure=', max_pressure
    write(*,'(A,ES24.16)') 'min_film=', min_film
    write(*,'(A,ES24.16)') 'friction=', friction
  end subroutine print_results

end module journal_bearing_reference_mod

program journal_bearing_reference
  use journal_bearing_reference_mod, only: run_case
  implicit none
  call run_case()
end program journal_bearing_reference
