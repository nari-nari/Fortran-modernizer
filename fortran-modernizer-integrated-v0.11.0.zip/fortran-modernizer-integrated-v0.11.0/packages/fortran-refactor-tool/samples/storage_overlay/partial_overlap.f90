program partial_overlap_demo
  implicit none
  real :: a(10), b(10)

  equivalence (a(3), b(1))

  a = 0.0
  b(1) = 2.0
  print '(f4.1)', a(3)
end program partial_overlap_demo

subroutine partial_overlap_2d(value)
  implicit none
  real, intent(out) :: value
  real :: a(2:3,4:5), b(2,2)

  equivalence (a(2,5), b(1,1))

  a = 1.0
  value = sum(b)
end subroutine partial_overlap_2d

subroutine partial_overlap_misaligned()
  implicit none
  double precision :: d(2)
  integer :: i(4)

  equivalence (d(2), i(2))

  d(1) = 1.0d0
end subroutine partial_overlap_misaligned
