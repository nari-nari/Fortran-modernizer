program equivalence_alias_demo
  implicit none
  real :: primary, alias, result
  equivalence (primary, alias)

  primary = 2.0
  result = alias + 3.0
  print '(f4.1)', result
end program equivalence_alias_demo
