program equivalence_array_alias_demo
  implicit none
  integer :: i, j
  real :: primary(0:2, 1:2), alias(0:2, 1:2), result
  equivalence (primary, alias)

  do j = 1, 2
    do i = 0, 2
      primary(i,j) = real(i + 10*j)
    end do
  end do
  alias(1,2) = alias(1,2) + 5.0
  result = sum(alias)
  print '(f6.1)', result
end program equivalence_array_alias_demo
