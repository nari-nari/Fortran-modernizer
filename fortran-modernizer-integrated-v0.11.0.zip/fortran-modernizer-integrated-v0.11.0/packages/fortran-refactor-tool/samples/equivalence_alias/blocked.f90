subroutine type_pun_alias()
  implicit none
  real :: real_value
  integer :: integer_view
  equivalence (real_value, integer_view)
end subroutine type_pun_alias

subroutine array_element_alias()
  implicit none
  real :: values(2), scalar_view
  equivalence (values(1), scalar_view)
end subroutine array_element_alias

subroutine mismatched_array_bounds()
  implicit none
  real :: zero_based(0:2), one_based(1:3)
  equivalence (zero_based, one_based)
end subroutine mismatched_array_bounds
