program equivalence_dual_reference_review_demo
  implicit none
  real :: primary(2), alias(2), result
  equivalence (primary(1), alias(1))

  primary = [1.0, 2.0]
  result = dot_product(primary, alias)
  print '(f4.1)', result
end program equivalence_dual_reference_review_demo
