subroutine common_alias_step(value)
  implicit none
  real, intent(out) :: value
  real :: storage, storage_alias
  common /state/ storage
  equivalence (storage, storage_alias)

  storage_alias = 7.0
  value = storage
end subroutine common_alias_step
