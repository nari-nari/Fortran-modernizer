program equivalence_common_anchor_review_demo
  implicit none
  integer :: flag
  real :: storage(0:2), alias(0:2), result
  common /state_array/ flag, storage
  equivalence (storage(0), alias(0))

  flag = 1
  storage = 2.0
  result = sum(alias)
  print '(f4.1)', result
end program equivalence_common_anchor_review_demo
