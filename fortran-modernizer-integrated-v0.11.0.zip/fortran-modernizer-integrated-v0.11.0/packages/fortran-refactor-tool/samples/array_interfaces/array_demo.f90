module array_kernels
  implicit none
  private
  public :: run_demo
contains
  subroutine update_field(n, field, edge)
    integer, intent(in) :: n
    real, intent(inout) :: field(n), edge(0:n-1)
    field = 2.0*field
    edge = edge + 1.0
  end subroutine update_field

  subroutine run_demo(n, values, boundary)
    integer, intent(in) :: n
    real, intent(inout) :: values(n), boundary(0:n-1)
    call update_field(n, values, boundary)
  end subroutine run_demo
end module array_kernels

program array_interface_demo
  use array_kernels, only: run_demo
  implicit none
  real :: values(3) = [1.0, 2.0, 3.0]
  real :: boundary(0:2) = [4.0, 5.0, 6.0]
  call run_demo(3, values, boundary)
  print '(6f5.1)', values, boundary
end program array_interface_demo
