subroutine legacy_step(value)
  use shared_state, only: scale
  implicit none
  real(8), intent(inout) :: value
  integer, save :: counter = 0
  counter = counter + 1
  scale = scale + 1.0d0
  value = value * scale
end subroutine legacy_step
