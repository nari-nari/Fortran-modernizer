subroutine pressure_kernel(n, h, p)
  implicit none
  integer, intent(in) :: n
  real(8), intent(in) :: h(n)
  real(8), intent(out) :: p(n)
  integer :: i
  do i = 1, n
    p(i) = h(i) * h(i)
  end do
end subroutine pressure_kernel
