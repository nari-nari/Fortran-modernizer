module shared_state
  implicit none
  real(8) :: scale = 1.0d0
end module shared_state
