subroutine read_case(path, value, status)
  implicit none
  character(len=*), intent(in) :: path
  real(8), intent(out) :: value
  integer, intent(out) :: status
  integer :: unit_number
  status = 0
  open(newunit=unit_number, file=path, status='old', action='read', iostat=status)
  if (status /= 0) return
  read(unit_number, *, iostat=status) value
  close(unit_number)
end subroutine read_case
