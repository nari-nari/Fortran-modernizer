program architecture_demo
  implicit none
  integer :: status
  real(8) :: value
  real(8) :: h(2), p(2)
  h = [1.0d0, 2.0d0]
  call read_case('case.dat', value, status)
  if (status == 0) call pressure_kernel(2, h, p)
end program architecture_demo
