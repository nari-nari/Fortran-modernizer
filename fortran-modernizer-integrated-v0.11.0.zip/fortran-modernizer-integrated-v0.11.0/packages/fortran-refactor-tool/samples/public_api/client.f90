subroutine run_solver(value)
  use solver_services, only: rk, solve, evaluate
  implicit none
  real(rk), intent(out) :: value
  real(rk) :: values(3)
  values = [1.0_rk, 2.0_rk, 3.0_rk]
  call solve(values, value)
  value = value + evaluate(2.0_rk)
end subroutine run_solver
