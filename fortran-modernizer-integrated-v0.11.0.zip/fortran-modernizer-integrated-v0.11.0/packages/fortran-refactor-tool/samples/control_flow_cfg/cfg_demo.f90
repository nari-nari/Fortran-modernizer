program cfg_demo
  implicit none
  integer :: result

  call calculate(result)
  print '(i0)', result
contains
  subroutine calculate(result)
    integer, intent(out) :: result
    integer :: i, j

    result = 0
    do 100 i = 1, 3
      if (i == 2) go to 100
      result = result + i
100 continue

    j = 0
10 continue
    j = j + 1
    result = result + 1
    if (j < 3) goto 10

    do i = 1, 5
      if (i == 3) goto 200
      result = result + 1
    end do
200 continue

    if (result < 0) goto 900
    if (result == 999) go to 900
    result = result + 10
900 return
  end subroutine calculate
end program cfg_demo
