module workers
  implicit none
contains
  subroutine initialize()
    use shared_storage, only: field, scale
    implicit none
    integer :: i
    scale = 2.0
    do i = 1, 4
      field(i) = scale * real(i)
    end do
  end subroutine initialize

  subroutine total_value(total)
    use shared_storage, only: field
    implicit none
    real, intent(out) :: total
    total = sum(field)
  end subroutine total_value
end module workers
