module model_types
  implicit none
  private
  public :: simulation_t

  type :: simulation_t
    integer :: case_id = 0
  end type simulation_t
end module model_types
