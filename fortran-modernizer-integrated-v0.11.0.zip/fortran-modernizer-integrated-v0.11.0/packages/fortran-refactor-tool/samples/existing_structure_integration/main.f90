program existing_structure_demo
  use workers, only: initialize, total_value
  implicit none
  real :: total
  call initialize()
  call total_value(total)
  write(*,'(F8.3)') total
  if (abs(total - 20.0) > 1.0e-6) error stop 1
end program existing_structure_demo
