module shared_storage
  implicit none
  private
  public :: field, scale
  real, save :: field(4)
  real, save :: scale
end module shared_storage
