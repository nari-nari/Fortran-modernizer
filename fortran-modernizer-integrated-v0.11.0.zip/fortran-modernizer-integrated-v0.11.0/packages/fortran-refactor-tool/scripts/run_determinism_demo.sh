#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUT="${1:-$ROOT/reports/determinism-demo}"
rm -rf "$OUT"
mkdir -p "$OUT/stable" "$OUT/varying"

cat > "$OUT/stable/write_result.py" <<'PY'
from pathlib import Path
Path("field.dat").write_text("1.0 2.0 3.0\n", encoding="utf-8")
Path("residual.dat").write_text("0 1.0\n1 0.1\n2 0.01\n", encoding="utf-8")
print("stable-solver-output")
PY
cat > "$OUT/stable/config.json" <<'JSON'
{
  "schema_version": 1,
  "working_directory": ".",
  "runs": 3,
  "run_command": ["python3", "write_result.py"],
  "compare_stdout": true,
  "artifacts": [
    {
      "name": "field",
      "path": "field.dat",
      "mode": "numeric-array-text",
      "shape": [3],
      "atol": 0.0,
      "rtol": 0.0,
      "remove_before_run": true
    },
    {
      "name": "residual",
      "path": "residual.dat",
      "mode": "numeric-history",
      "iteration_column": 0,
      "value_columns": [1],
      "atol": 0.0,
      "rtol": 0.0,
      "remove_before_run": true
    }
  ]
}
JSON
"$ROOT/frt" determinism-check \
  --config "$OUT/stable/config.json" \
  -o "$OUT/stable/report"
grep -q '"status": "pass"' "$OUT/stable/report/determinism.json"

cat > "$OUT/varying/write_result.py" <<'PY'
from pathlib import Path
state = Path("state.txt")
value = int(state.read_text(encoding="utf-8")) + 1 if state.exists() else 1
state.write_text(str(value), encoding="utf-8")
Path("field.dat").write_text(f"1.0 2.0 {value}.0\n", encoding="utf-8")
PY
cat > "$OUT/varying/config.json" <<'JSON'
{
  "schema_version": 1,
  "working_directory": ".",
  "runs": 3,
  "run_command": ["python3", "write_result.py"],
  "artifacts": [
    {
      "name": "field",
      "path": "field.dat",
      "mode": "numeric-array-text",
      "atol": 0.0,
      "rtol": 0.0,
      "remove_before_run": true
    }
  ]
}
JSON
if "$ROOT/frt" determinism-check \
  --config "$OUT/varying/config.json" \
  -o "$OUT/varying/report"; then
  echo "Expected varying determinism check to fail" >&2
  exit 2
else
  status=$?
  if [[ "$status" -ne 2 ]]; then
    echo "Unexpected varying-check status: $status" >&2
    exit 2
  fi
fi
grep -q '"status": "failed"' "$OUT/varying/report/determinism.json"

"$ROOT/frt" repeated-call-harness-suggest \
  "$ROOT/samples/testability/testable_kernels.f90" \
  --unit scale_values --unit cached_kernel \
  -o "$OUT/repeated-call"

gfortran "$ROOT/samples/testability/testable_kernels.f90" \
  "$OUT/repeated-call/generated_harnesses/test_scale_values_repeated_call.f90" \
  -o "$OUT/repeated-call/test_scale_values"
"$OUT/repeated-call/test_scale_values" | tee "$OUT/repeated-call/test_scale_values.out"
grep -q 'FRT_REPEAT results PASS' "$OUT/repeated-call/test_scale_values.out"

gfortran "$ROOT/samples/testability/testable_kernels.f90" \
  "$OUT/repeated-call/generated_harnesses/test_cached_kernel_repeated_call.f90" \
  -o "$OUT/repeated-call/test_cached_kernel"
if "$OUT/repeated-call/test_cached_kernel" > "$OUT/repeated-call/test_cached_kernel.out" 2>&1; then
  echo "Expected SAVE-state repeated-call harness to fail" >&2
  exit 2
else
  status=$?
  if [[ "$status" -eq 0 ]]; then
    echo "Unexpected cached-kernel status: $status" >&2
    exit 2
  fi
fi
grep -q 'FRT_REPEAT result FAIL' "$OUT/repeated-call/test_cached_kernel.out"
grep -q 'FRT_REPEAT_FAILURES 1' "$OUT/repeated-call/test_cached_kernel.out"

echo "DETERMINISM AND REPEATED-CALL DEMO: PASS"
