#!/usr/bin/env bash
set -euo pipefail

if [[ $# -lt 1 || $# -gt 2 ]]; then
  echo "Usage: $0 /path/to/fparser-0.2.4-py3-none-any.whl [/path/to/findent-linux.whl]" >&2
  exit 2
fi

WHEEL="$(realpath "$1")"
EXPECTED="a1bd198c07fdff55570b80a7b119aeafb588e9097c11e0a74ea67744a9a1a478"
ACTUAL="$(sha256sum "$WHEEL" | awk '{print $1}')"
if [[ "$ACTUAL" != "$EXPECTED" ]]; then
  echo "fparser wheel SHA-256 mismatch" >&2
  echo "expected: $EXPECTED" >&2
  echo "actual:   $ACTUAL" >&2
  exit 2
fi

uv venv --clear --python python3 --no-python-downloads .venv
uv pip install --python .venv/bin/python --offline --no-index --no-deps "$WHEEL"
if [[ $# -eq 2 ]]; then
  FINDENT_WHEEL="$(realpath "$2")"
  uv pip install --python .venv/bin/python --offline --no-index --no-deps "$FINDENT_WHEEL"
fi

export PATH="$PWD/.venv/bin:$PATH"
./frt doctor
python scripts/run_tests.py
./frt verify-sample --project-root .
./frt assess-project --config samples/config/lubrication_project.json -o reports/offline-validation/project-assessment
./frt analyze samples/legacy_runnable samples/diagnostic_fixtures \
  -I samples/legacy_runnable/include -o reports/offline-validation/analysis
./frt suggest samples/diagnostic_fixtures -o reports/offline-validation/suggestions
./scripts/run_frontend_compat_demo.sh reports/offline-validation/frontend-compat-demo
./scripts/run_architecture_audit_demo.sh reports/offline-validation/architecture-audit-demo
./scripts/run_responsibility_split_demo.sh reports/offline-validation/responsibility-split-demo
./scripts/run_state_lifecycle_demo.sh reports/offline-validation/state-lifecycle-demo
./scripts/run_public_api_demo.sh reports/offline-validation/public-api-demo
./scripts/run_kind_standardization_demo.sh reports/offline-validation/kind-standardization-demo
./scripts/run_test_harness_demo.sh reports/offline-validation/test-harness-demo
./scripts/run_array_interface_demo.sh reports/offline-validation/array-interface-demo
./scripts/run_allocatable_storage_demo.sh reports/offline-validation/allocatable-storage-demo
./scripts/run_control_flow_demo.sh reports/offline-validation/control-flow-demo
./scripts/run_control_flow_cfg_demo.sh reports/offline-validation/control-flow-cfg-demo
./scripts/run_control_flow_advanced_demo.sh reports/offline-validation/control-flow-advanced-demo
./scripts/run_control_flow_cleanup_demo.sh reports/offline-validation/control-flow-cleanup-demo
./scripts/run_control_flow_state_machine_demo.sh reports/offline-validation/control-flow-state-machine-demo
./scripts/run_regression_compare_demo.sh reports/offline-validation/regression-compare-demo
./scripts/run_regression_suite_demo.sh reports/offline-validation/regression-suite-demo
./scripts/run_determinism_demo.sh reports/offline-validation/determinism-demo
./scripts/run_common_state_fixture_demo.sh reports/offline-validation/common-state-fixture-demo
./scripts/run_equivalence_alias_demo.sh reports/offline-validation/equivalence-alias-demo
./scripts/run_storage_size_probe_matrix_demo.sh reports/offline-validation/storage-size-probe-matrix-demo
./scripts/run_determinism_matrix_demo.sh reports/offline-validation/determinism-matrix-demo
./scripts/run_external_interface_demo.sh reports/offline-validation/external-interface-demo
./scripts/run_state_integration_demo.sh
if command -v findent >/dev/null 2>&1; then
  ./frt findent-verify samples/absoft_compatibility/multiline_declarations.for -o reports/offline-validation/findent-check
fi
./scripts/run_fixed_form_demo.sh reports/offline-validation/fixed-form-demo
./scripts/run_fixed_to_free_demo.sh reports/offline-validation/fixed-to-free-demo
./scripts/run_block_data_init_demo.sh
./scripts/run_storage_overlay_demo.sh reports/offline-validation/storage-overlay-demo
./scripts/run_common_repair_demo.sh reports/offline-validation/common-repair-demo
./scripts/run_stage_demo.sh reports/offline-validation/stage-demo

echo "OFFLINE ACCEPTANCE: PASS"
