#!/usr/bin/env bash
set -euo pipefail

OUTPUT="${1:-reports/responsibility-split-demo}"
rm -rf "$OUTPUT"
mkdir -p "$OUTPUT/build"

BEFORE="$OUTPUT/source-before.sha256"
AFTER="$OUTPUT/source-after.sha256"
find samples/responsibility_fixtures -type f -name '*.f90' -print0 | sort -z | xargs -0 sha256sum > "$BEFORE"

./frt responsibility-split-suggest \
  samples/responsibility_fixtures \
  -o "$OUTPUT/review"

python - "$OUTPUT/review/responsibility_split.json" <<'PY'
import json
import sys
from pathlib import Path
payload = json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))
summary = payload["summary"]
assert summary["mixed_io_compute_units"] == 2, summary
assert summary["candidate_regions"] == 4, summary
assert summary["review_candidates"] == 3, summary
assert summary["blocked_candidates"] == 1, summary
compute = next(item for item in payload["candidates"] if item["responsibility"] == "compute-core")
assert set(compute["inputs"]) == {"n", "scale", "values"}, compute
assert set(compute["outputs"]) == {"results"}, compute
blocked = next(item for item in payload["candidates"] if item["program_unit"] == "risky_reader")
assert "early RETURN inside candidate" in blocked["blockers"], blocked
PY

gfortran -std=f2008 -Wall -Wextra -fcheck=all \
  samples/responsibility_fixtures/mixed_solver.f90 \
  samples/responsibility_fixtures/risky_reader.f90 \
  samples/responsibility_fixtures/orchestrator.f90 \
  -o "$OUTPUT/build/responsibility_demo"
printf '1.0 2.0 3.0\n' > "$OUTPUT/build/input.dat"
(
  cd "$OUTPUT/build"
  ./responsibility_demo
)
python - "$OUTPUT/build/output.dat" <<'PY'
import sys
from pathlib import Path
values = [float(item) for item in Path(sys.argv[1]).read_text().split()]
assert values == [2.0, 4.0, 6.0], values
print("Responsibility demo values:", values)
PY

find samples/responsibility_fixtures -type f -name '*.f90' -print0 | sort -z | xargs -0 sha256sum > "$AFTER"
cmp "$BEFORE" "$AFTER"
echo "RESPONSIBILITY SPLIT DEMO: PASS"
