#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUT="${1:-$ROOT/reports/control-flow-cleanup-demo}"
rm -rf "$OUT"
mkdir -p "$OUT/build"

"$ROOT/frt" control-flow-suggest \
  "$ROOT/samples/control_flow_cleanup" \
  -o "$OUT/suggest"

python3 - "$OUT/suggest/control_flow_selection.json" \
  "$OUT/suggest/control_flow_suggestions.json" "$OUT/selection.json" "$OUT/ids.txt" <<'PY'
import json, sys
selection_path, suggestions_path, output_path, id_path = sys.argv[1:]
selection = json.load(open(selection_path, encoding="utf-8"))
suggestions = json.load(open(suggestions_path, encoding="utf-8"))
ready_cleanup = [
    item for item in suggestions["candidates"]
    if item["status"] == "ready" and item["construct_kind"] == "cleanup_internal_procedure"
]
ready_dispatch = [
    item for item in suggestions["candidates"]
    if item["status"] == "ready" and item["construct_kind"] == "irreducible_dispatch_loop"
]
blocked_irreducible = [
    item for item in suggestions["candidates"]
    if item["status"] == "blocked" and item["construct_kind"] == "irreducible_cfg_region"
]
assert len(ready_cleanup) == 2, ready_cleanup
assert {item["source_form"] for item in ready_cleanup} == {"free", "fixed"}, ready_cleanup
assert len(ready_dispatch) == 1, ready_dispatch
assert ready_dispatch[0]["cfg_evidence"]["normalization_strategy"] == "local_integer_dispatch_loop"
assert len(blocked_irreducible) == 1, blocked_irreducible
assert len(blocked_irreducible[0]["cfg_evidence"]["entry_nodes"]) == 2
selected = [*ready_cleanup, *ready_dispatch]
selection["reviewed"] = True
selection["selections"] = [
    {
        "candidate_id": item["candidate_id"],
        "confirmed_semantics": True,
        "confirmed_regression_gate": True,
    }
    for item in selected
]
open(output_path, "w", encoding="utf-8").write(json.dumps(selection, indent=2) + "\n")
open(id_path, "w", encoding="utf-8").write("\n".join(item["candidate_id"] for item in selected) + "\n")
PY

"$ROOT/frt" control-flow-plan \
  "$ROOT/samples/control_flow_cleanup" \
  --selection "$OUT/selection.json" \
  -o "$OUT/plan"

mapfile -t IDS < "$OUT/ids.txt"
APPLY_ARGS=()
for ID in "${IDS[@]}"; do
  APPLY_ARGS+=(--id "$ID")
done
"$ROOT/frt" apply "$OUT/plan" \
  -o "$OUT/applied" \
  "${APPLY_ARGS[@]}" \
  --approve-review \
  --compile-check

FREE_SRC="$OUT/applied/transformed_sources/conditional_cleanup.f90"
FIXED_SRC="$OUT/applied/transformed_sources/conditional_cleanup_fixed.f"
DISPATCH_SRC="$OUT/applied/transformed_sources/irreducible.f90"

gfortran "$FREE_SRC" -o "$OUT/build/conditional_cleanup"
"$OUT/build/conditional_cleanup" | tee "$OUT/free_output.txt"
grep -Eq '^21$' "$OUT/free_output.txt"
[[ "$(grep -Eic '^[[:space:]]*contains[[:space:]]*$' "$FREE_SRC")" -eq 1 ]]
grep -qi 'subroutine add_two' "$FREE_SRC"
grep -qi 'subroutine frt_cleanup_proc_' "$FREE_SRC"
! grep -Eqi '\b(go[[:space:]]*to|goto)\b' "$FREE_SRC"

gfortran "$FIXED_SRC" -o "$OUT/build/conditional_cleanup_fixed"
"$OUT/build/conditional_cleanup_fixed" | tee "$OUT/fixed_output.txt"
grep -Eq '^21$' "$OUT/fixed_output.txt"
grep -qi '^[[:space:]]*CONTAINS[[:space:]]*$' "$FIXED_SRC"
grep -qi 'SUBROUTINE FRT_CLEANUP_PROC_' "$FIXED_SRC"
! grep -Eqi '\b(go[[:space:]]*to|goto)\b' "$FIXED_SRC"

gfortran "$DISPATCH_SRC" -o "$OUT/build/irreducible_dispatch"
"$OUT/build/irreducible_dispatch" | tee "$OUT/dispatch_output.txt"
grep -Eq '^8 7$' "$OUT/dispatch_output.txt"
grep -qi 'select case' "$DISPATCH_SRC"
grep -qi 'integer :: frt_dispatch_state_' "$DISPATCH_SRC"
! grep -Eqi '\b(go[[:space:]]*to|goto)\b' "$DISPATCH_SRC"

echo "CONDITIONAL CLEANUP / IRREDUCIBLE CFG DEMO: PASS"
