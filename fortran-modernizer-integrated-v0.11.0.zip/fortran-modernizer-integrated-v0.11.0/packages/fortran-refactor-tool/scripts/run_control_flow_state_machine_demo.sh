#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUT="${1:-$ROOT/reports/control-flow-state-machine-demo}"
SRC="$ROOT/samples/control_flow_state_machine/three_state.f90"
rm -rf "$OUT"
mkdir -p "$OUT/build"

BEFORE="$(sha256sum "$SRC" | awk '{print $1}')"
"$ROOT/frt" control-flow-suggest \
  "$ROOT/samples/control_flow_state_machine" \
  -o "$OUT/suggest"
AFTER="$(sha256sum "$SRC" | awk '{print $1}')"
[[ "$BEFORE" == "$AFTER" ]]

python3 - "$OUT/suggest/irreducible_state_machine_candidates.json" \
  "$OUT/suggest/control_flow_selection.json" "$OUT/blocked-selection.json" <<'PY'
import json, sys
proposal_path, selection_path, blocked_path = sys.argv[1:]
payload = json.load(open(proposal_path, encoding="utf-8"))
assert payload["summary"] == {
    "candidate_count": 1,
    "state_count": 3,
    "transition_count": 3,
    "exit_count": 3,
}, payload["summary"]
item = payload["candidates"][0]
assert item["status"] == "blocked"
assert item["construct_kind"] == "irreducible_state_machine_candidate"
proposal = item["cfg_evidence"]["state_machine_candidate"]
assert [state["state_id"] for state in proposal["states"]] == ["label_10", "label_20", "label_30"]
assert {(row["source_state"], row["target_state"]) for row in proposal["transition_table"]} == {
    ("label_10", "label_20"),
    ("label_20", "label_30"),
    ("label_30", "label_10"),
}
variables = proposal["variable_summary"]
for name in ("entry", "limit", "result", "status"):
    assert name in variables["required_variables"], (name, variables)
selection = json.load(open(selection_path, encoding="utf-8"))
selection["reviewed"] = True
selection["selections"] = [{
    "candidate_id": item["candidate_id"],
    "confirmed_semantics": True,
    "confirmed_regression_gate": True,
}]
open(blocked_path, "w", encoding="utf-8").write(json.dumps(selection, indent=2) + "\n")
PY

test -s "$OUT/suggest/irreducible_state_machine_candidates.csv"
test -s "$OUT/suggest/irreducible_state_machine_candidates.md"
grep -q 'label_10' "$OUT/suggest/irreducible_state_machine_candidates.md"

if "$ROOT/frt" control-flow-plan \
  "$ROOT/samples/control_flow_state_machine" \
  --selection "$OUT/blocked-selection.json" \
  -o "$OUT/blocked-plan" >"$OUT/blocked-plan.stdout" 2>"$OUT/blocked-plan.stderr"; then
  echo "analysis-only state-machine candidate unexpectedly entered a transformation plan" >&2
  exit 1
fi
grep -q 'not applicable' "$OUT/blocked-plan.stderr"

gfortran "$SRC" -o "$OUT/build/state_machine_demo"
"$OUT/build/state_machine_demo" | tee "$OUT/output.txt"
grep -Eq '^7 10 8 20 9 30[[:space:]]*$' "$OUT/output.txt"

echo "IRREDUCIBLE STATE-MACHINE CANDIDATE DEMO: PASS"
