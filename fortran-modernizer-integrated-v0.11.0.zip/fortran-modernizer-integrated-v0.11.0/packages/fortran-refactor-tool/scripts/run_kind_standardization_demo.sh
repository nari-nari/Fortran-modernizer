#!/usr/bin/env bash
set -euo pipefail

OUTPUT="${1:-reports/kind-standardization-demo}"
rm -rf "$OUTPUT"
mkdir -p "$OUTPUT"

uv run --locked --no-sync ./frt kind-standardization-plan \
  samples/kind_standardization \
  --compiler gfortran \
  -o "$OUTPUT/plan"

uv run --locked --no-sync ./frt apply "$OUTPUT/plan" \
  -o "$OUTPUT/applied" \
  --id KIND-0001 \
  --approve-review \
  --compile-check

mkdir -p "$OUTPUT/build"
gfortran \
  "$OUTPUT/applied/transformed_sources/kind_demo.f90" \
  -o "$OUTPUT/build/kind_demo"
ACTUAL="$($OUTPUT/build/kind_demo | xargs)"
if [[ "$ACTUAL" != "6.000" ]]; then
  echo "Unexpected kind-standardization demo output: $ACTUAL" >&2
  exit 1
fi

grep -qi 'use, intrinsic :: iso_fortran_env' "$OUTPUT/applied/transformed_sources/kind_demo.f90"
grep -qi 'real(real64) function evaluate' "$OUTPUT/applied/transformed_sources/kind_demo.f90"
grep -qi 'integer(int32) :: count' "$OUTPUT/applied/transformed_sources/kind_demo.f90"

echo "KIND STANDARDIZATION DEMO: PASS"
echo "Result: $ACTUAL"
