#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUT="${1:-$ROOT/reports/control-flow-demo}"
rm -rf "$OUT"
mkdir -p "$OUT/build"

"$ROOT/frt" control-flow-suggest \
  "$ROOT/samples/control_flow" \
  -o "$OUT/suggest"

python3 - "$OUT/suggest/control_flow_selection.json" \
  "$OUT/suggest/control_flow_suggestions.json" "$OUT/selection.json" "$OUT/ids.txt" <<'PY'
import json, sys
selection_path, suggestions_path, output_path, ids_path = sys.argv[1:]
selection = json.load(open(selection_path, encoding="utf-8"))
suggestions = json.load(open(suggestions_path, encoding="utf-8"))
ready = [item for item in suggestions["candidates"] if item["status"] == "ready"]
assert len(ready) == 3, ready
assert {item["construct_kind"] for item in ready} == {
    "labelled_do", "arithmetic_if", "forward_goto"
}, ready
blocked_shared = [
    item for item in suggestions["candidates"]
    if item["construct_kind"] == "forward_goto" and item["target_labels"] == ["40"]
]
assert len(blocked_shared) == 2 and all(item["status"] == "blocked" for item in blocked_shared)
selection["reviewed"] = True
selection["selections"] = [
    {
        "candidate_id": item["candidate_id"],
        "confirmed_semantics": True,
        "confirmed_regression_gate": True,
    }
    for item in ready
]
open(output_path, "w", encoding="utf-8").write(json.dumps(selection, indent=2) + "\n")
open(ids_path, "w", encoding="utf-8").write("\n".join(item["candidate_id"] for item in ready) + "\n")
PY

"$ROOT/frt" control-flow-plan \
  "$ROOT/samples/control_flow" \
  --selection "$OUT/selection.json" \
  -o "$OUT/plan"

apply_args=()
while IFS= read -r id; do
  apply_args+=(--id "$id")
done < "$OUT/ids.txt"
"$ROOT/frt" apply "$OUT/plan" \
  -o "$OUT/applied" \
  "${apply_args[@]}" \
  --approve-review \
  --compile-check

SRC="$OUT/applied/transformed_sources/control_demo.f90"
gfortran "$SRC" -o "$OUT/build/control_demo"
"$OUT/build/control_demo" | tee "$OUT/output.txt"
grep -Eq '^16$' "$OUT/output.txt"
grep -qi ': do i = 1, 3' "$SRC"
grep -qi 'associate (frt_arith_if_' "$SRC"
grep -qi ': block' "$SRC"
! grep -qi 'if *(x) *10, *20, *30' "$SRC"
python3 - "$OUT/applied/application_receipt.json" <<'PY'
import json, sys
receipt = json.load(open(sys.argv[1], encoding="utf-8"))
items = receipt["control_flow_verification"]
assert len(items) == 3, items
assert {item["construct_kind"] for item in items} == {
    "labelled_do", "arithmetic_if", "forward_goto"
}, items
PY

echo "CONTROL FLOW DEMO: PASS"
