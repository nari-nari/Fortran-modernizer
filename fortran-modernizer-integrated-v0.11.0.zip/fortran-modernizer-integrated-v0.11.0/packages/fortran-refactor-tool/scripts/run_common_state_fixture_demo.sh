#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUT="${1:-$ROOT/reports/common-state-fixture-demo}"
SOURCE="$ROOT/samples/testability/common_equivalence_kernels.f"
rm -rf "$OUT"
mkdir -p "$OUT"

before_sha="$(sha256sum "$SOURCE" | awk '{print $1}')"

"$ROOT/frt" repeated-call-harness-suggest \
  "$SOURCE" \
  --unit common_step --unit common_cached \
  -o "$OUT/draft"

grep -q '"reviewed": false' "$OUT/draft/common_state_fixture.json"
grep -q 'reviewed COMMON state fixture is required' "$OUT/draft/repeated_call_plan.md"

python3 - "$OUT/draft/common_state_fixture.json" "$OUT/reviewed_fixture.json" <<'PY'
import json
import sys
from pathlib import Path
source = Path(sys.argv[1])
target = Path(sys.argv[2])
payload = json.loads(source.read_text(encoding="utf-8"))
payload["reviewed"] = True
for candidate in payload["candidates"]:
    candidate["approved"] = candidate["procedure"] in {"common_step", "common_cached"}
target.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
PY

"$ROOT/frt" repeated-call-harness-suggest \
  "$SOURCE" \
  --unit common_step --unit common_cached \
  --state-fixture "$OUT/reviewed_fixture.json" \
  -o "$OUT/approved"

gfortran "$SOURCE" \
  "$OUT/approved/generated_harnesses/test_common_step_repeated_call.f90" \
  -o "$OUT/test_common_step"
"$OUT/test_common_step" | tee "$OUT/test_common_step.out"
grep -q 'FRT_REPEAT common_state_ok_x PASS' "$OUT/test_common_step.out"
grep -q 'FRT_REPEAT common_state_ok_y PASS' "$OUT/test_common_step.out"
grep -q 'FRT_REPEAT_FAILURES 0' "$OUT/test_common_step.out"

gfortran "$SOURCE" \
  "$OUT/approved/generated_harnesses/test_common_cached_repeated_call.f90" \
  -o "$OUT/test_common_cached"
if "$OUT/test_common_cached" > "$OUT/test_common_cached.out" 2>&1; then
  echo "Expected COMMON/SAVE repeated-call harness to fail" >&2
  exit 2
fi
grep -q 'FRT_REPEAT common_state_bad_y FAIL' "$OUT/test_common_cached.out"
grep -q 'FRT_REPEAT_FAILURES 1' "$OUT/test_common_cached.out"

"$ROOT/frt" repeated-call-harness-suggest \
  "$SOURCE" \
  --unit common_type_pun \
  -o "$OUT/type-pun"
grep -q 'type-punning or kind-changing EQUIVALENCE is not supported' \
  "$OUT/type-pun/repeated_call_plan.md"
test ! -e "$OUT/type-pun/generated_harnesses/test_common_type_pun_repeated_call.f90"

after_sha="$(sha256sum "$SOURCE" | awk '{print $1}')"
test "$before_sha" = "$after_sha"

echo "COMMON/EQUIVALENCE REPEATED-CALL FIXTURE DEMO: PASS"
