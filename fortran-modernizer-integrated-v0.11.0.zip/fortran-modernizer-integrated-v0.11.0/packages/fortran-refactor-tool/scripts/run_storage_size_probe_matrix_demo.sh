#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUT="${1:-$ROOT/reports/storage-size-probe-matrix-demo}"
SOURCE="$ROOT/samples/equivalence_alias/anchor_analysis.for"
CONFIG="$ROOT/samples/config/storage_size_probe_matrix.json"
rm -rf "$OUT"
mkdir -p "$OUT/build"

before="$(sha256sum "$SOURCE" | awk '{print $1}')"
"$ROOT/frt" equivalence-alias-suggest \
  "$SOURCE" \
  --storage-size-matrix-config "$CONFIG" \
  -o "$OUT/suggest"

python3 - "$OUT/suggest/equivalence_alias_selection.json" \
  "$OUT/suggest/equivalence_element_anchor_candidates.json" \
  "$OUT/suggest/storage_size_probe_matrix/matrix_results.json" \
  "$OUT/reviewed.json" <<'PY'
import json, sys
selection_path, anchor_path, matrix_path, reviewed_path = sys.argv[1:]
selection = json.load(open(selection_path, encoding="utf-8"))
anchors = json.load(open(anchor_path, encoding="utf-8"))
matrix = json.load(open(matrix_path, encoding="utf-8"))
assert anchors["mode"] == "compiler-matrix-probed-review-gated-removal", anchors
assert anchors["summary"]["matrix_consensus_candidates"] == 1, anchors
assert matrix["status"] == "completed-with-skips", matrix
assert matrix["consensus_candidates"] == 1, matrix
assert matrix["optional_skipped_profiles"] == ["optional-unavailable"], matrix
candidate = anchors["candidates"][0]
assert candidate["status"] == "ready", candidate
assert candidate["storage_probe_matrix_consensus"], candidate
assert candidate["storage_probe_matrix_verified_profiles"] == ["gfortran-O0", "gfortran-O2"], candidate
assert candidate["storage_probe_matrix_skipped_profiles"] == ["optional-unavailable"], candidate
assert candidate["storage_probe_element_bits"] == [32, 32], candidate
assert candidate["storage_probe_total_bytes"] == 12, candidate
selection["reviewed"] = True
row = selection["selections"][0]
row["approved"] = True
row["representative"] = "primary"
row["regression_tests_reviewed"] = True
row["storage_size_probe_reviewed"] = True
row["storage_size_probe_matrix_reviewed"] = True
open(reviewed_path, "w", encoding="utf-8").write(json.dumps(selection, indent=2) + "\n")
PY

"$ROOT/frt" equivalence-alias-plan \
  "$SOURCE" \
  --selection "$OUT/reviewed.json" \
  -o "$OUT/plan"

candidate_id="$(python3 - "$OUT/plan/equivalence_alias_plan.json" <<'PY'
import json, sys
payload = json.load(open(sys.argv[1], encoding="utf-8"))
print(payload["selected_candidate_ids"][0])
PY
)"
"$ROOT/frt" apply "$OUT/plan" \
  --id "$candidate_id" \
  --approve-review \
  --compile-check \
  -o "$OUT/applied"

transformed="$OUT/applied/transformed_sources/anchor_analysis.for"
gfortran "$transformed" -o "$OUT/build/anchor_analysis"
"$OUT/build/anchor_analysis" | tee "$OUT/output.txt"
grep -Eq '^[[:space:]]*6\.0' "$OUT/output.txt"
! grep -qi 'EQUIVALENCE' "$transformed"
! grep -Eqi '\bALIAS\b' "$transformed"
after="$(sha256sum "$SOURCE" | awk '{print $1}')"
test "$before" = "$after"

echo "STORAGE_SIZE PROBE MATRIX DEMO: PASS"
