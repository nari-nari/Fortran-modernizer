#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUT="${1:-$ROOT/reports/array-interface-demo}"
rm -rf "$OUT"
mkdir -p "$OUT/build"

"$ROOT/frt" array-interface-suggest \
  "$ROOT/samples/array_interfaces" \
  -o "$OUT/suggest"

python3 - "$OUT/suggest/array_interface_selection.json" \
  "$OUT/suggest/array_interface_suggestions.json" "$OUT/selection.json" <<'PY'
import json, sys
selection_path, suggestions_path, output_path = sys.argv[1:]
selection = json.load(open(selection_path, encoding="utf-8"))
suggestions = json.load(open(suggestions_path, encoding="utf-8"))
ready = [item["candidate_id"] for item in suggestions["candidates"] if item["status"] == "ready"]
assert ready == ["ARR-0001"], ready
selection["reviewed"] = True
selection["selected_candidate_ids"] = ready
open(output_path, "w", encoding="utf-8").write(json.dumps(selection, indent=2) + "\n")
PY

"$ROOT/frt" array-interface-plan \
  "$ROOT/samples/array_interfaces" \
  --selection "$OUT/selection.json" \
  -o "$OUT/plan"

"$ROOT/frt" apply "$OUT/plan" \
  -o "$OUT/applied" \
  --id ARR-0001 \
  --approve-review \
  --compile-check

gfortran "$OUT/applied/transformed_sources/array_demo.f90" -o "$OUT/build/array_demo"
"$OUT/build/array_demo" | tee "$OUT/output.txt"
grep -Eq '^[[:space:]]*2\.0[[:space:]]+4\.0[[:space:]]+6\.0[[:space:]]+5\.0[[:space:]]+6\.0[[:space:]]+7\.0' "$OUT/output.txt"
grep -qi 'field(:), edge(0:)' "$OUT/applied/transformed_sources/array_demo.f90"
python3 - "$OUT/applied/application_receipt.json" <<'PY'
import json, sys
receipt = json.load(open(sys.argv[1], encoding="utf-8"))
assert receipt["array_interface_verification"][0]["dummies"] == ["edge", "field"]
assert receipt["array_interface_verification"][0]["call_sites_proven"] == 1
PY

echo "ARRAY INTERFACE DEMO: PASS"
