#!/usr/bin/env bash
set -euo pipefail

OUTPUT="${1:-reports/architecture-audit-demo}"
rm -rf "$OUTPUT"

before="$(find samples/architecture_fixtures -type f -name '*.f90' -print0 | sort -z | xargs -0 sha256sum)"
./frt architecture-audit samples/architecture_fixtures -o "$OUTPUT"
after="$(find samples/architecture_fixtures -type f -name '*.f90' -print0 | sort -z | xargs -0 sha256sum)"
[[ "$before" == "$after" ]]

python - "$OUTPUT/architecture_audit.json" <<'PY'
import json
import sys
from pathlib import Path
payload = json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))
assert payload["summary"]["program_units"] == 5
assert payload["summary"]["kernel_candidates"] == 1
assert payload["summary"]["high_risk_units"] == 1
units = {item["program_unit"]: item for item in payload["units"]}
assert units["pressure_kernel"]["role"] == "numerical-kernel"
assert units["read_case"]["role"] == "input-output"
assert "shared-state write" in units["legacy_step"]["blockers"]
PY

mkdir -p "$OUTPUT/build"
gfortran -c \
  samples/architecture_fixtures/shared_state.f90 \
  samples/architecture_fixtures/legacy_step.f90 \
  samples/architecture_fixtures/read_case.f90 \
  samples/architecture_fixtures/pressure_kernel.f90 \
  -J "$OUTPUT/build" -I "$OUTPUT/build"

echo "ARCHITECTURE AUDIT DEMO: PASS"
