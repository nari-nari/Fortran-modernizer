#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUT="${1:-$ROOT/reports/allocatable-storage-demo}"
rm -rf "$OUT"
mkdir -p "$OUT/build"

"$ROOT/frt" allocatable-storage-suggest \
  "$ROOT/samples/allocatable_storage" \
  -o "$OUT/suggest"

python3 - "$OUT/suggest/allocatable_storage_selection.json" \
  "$OUT/suggest/allocatable_storage_suggestions.json" "$OUT/selection.json" "$OUT/ids.txt" <<'PY'
import json, sys
selection_path, suggestions_path, output_path, ids_path = sys.argv[1:]
selection = json.load(open(selection_path, encoding="utf-8"))
suggestions = json.load(open(suggestions_path, encoding="utf-8"))
ready = [item for item in suggestions["candidates"] if item["status"] == "ready"]
assert len(ready) == 3, ready
assert {item["storage_scope"] for item in ready} == {"module", "component", "local"}, ready
rows = []
for item in ready:
    row = {
        "candidate_id": item["candidate_id"],
        "confirmed_regression_gate": True,
    }
    if item["storage_scope"] in {"module", "component"}:
        row.update({
            "confirmed_initializer": item["initializer"],
            "confirmed_finalizer": item["finalizer"],
            "confirmed_call_order": True,
        })
    else:
        row["confirmed_entry_allocation"] = True
    rows.append(row)
selection["reviewed"] = True
selection["selections"] = rows
open(output_path, "w", encoding="utf-8").write(json.dumps(selection, indent=2) + "\n")
open(ids_path, "w", encoding="utf-8").write("\n".join(item["candidate_id"] for item in ready) + "\n")
PY

"$ROOT/frt" allocatable-storage-plan \
  "$ROOT/samples/allocatable_storage" \
  --selection "$OUT/selection.json" \
  -o "$OUT/plan"

apply_args=()
while IFS= read -r id; do
  apply_args+=(--id "$id")
done < "$OUT/ids.txt"
"$ROOT/frt" apply "$OUT/plan" \
  -o "$OUT/applied" \
  "${apply_args[@]}" \
  --approve-review \
  --compile-check

SRC="$OUT/applied/transformed_sources"
gfortran \
  "$SRC/field_storage.f90" \
  "$SRC/state_storage.f90" \
  "$SRC/local_workspace.f90" \
  "$SRC/main.f90" \
  -o "$OUT/build/storage_demo"
"$OUT/build/storage_demo" | tee "$OUT/output.txt"
grep -Eq '^[[:space:]]*42\.0[[:space:]]+6\.0[[:space:]]+6\.0' "$OUT/output.txt"
grep -qi 'real, allocatable :: pressure(:, :)' "$SRC/field_storage.f90"
grep -qi 'allocate(pressure(0:nx-1, ny))' "$SRC/field_storage.f90"
grep -qi 'real, allocatable :: values(:)' "$SRC/state_storage.f90"
grep -qi 'allocate(state%values(0:nstate-1))' "$SRC/state_storage.f90"
grep -qi 'real, allocatable :: workspace(:)' "$SRC/local_workspace.f90"
grep -qi 'allocate(workspace(0:n-1))' "$SRC/local_workspace.f90"
! grep -qi 'deallocate(workspace)' "$SRC/local_workspace.f90"
python3 - "$OUT/applied/application_receipt.json" <<'PY'
import json, sys
receipt = json.load(open(sys.argv[1], encoding="utf-8"))
items = receipt["allocatable_storage_verification"]
assert len(items) == 3, items
assert {item["storage_scope"] for item in items} == {"module", "component", "local"}, items
local = next(item for item in items if item["storage_scope"] == "local")
assert local["automatic_deallocation"] is True
PY

echo "ALLOCATABLE STORAGE DEMO: PASS"
