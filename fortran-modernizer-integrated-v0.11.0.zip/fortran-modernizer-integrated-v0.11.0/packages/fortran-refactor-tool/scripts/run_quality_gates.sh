#!/usr/bin/env bash
set -euo pipefail

uv sync --locked --python python3 --no-python-downloads
uv run --locked --no-sync ./frt doctor
uv run --locked --no-sync python scripts/run_tests.py
uv run --locked --no-sync ./frt verify-sample --project-root .
uv run --locked --no-sync ./frt assess-project \
  --config samples/config/lubrication_project.json \
  -o reports/project-assessment
uv run --locked --no-sync ./frt analyze samples/legacy_runnable samples/diagnostic_fixtures \
  -I samples/legacy_runnable/include -o reports/latest
uv run --locked --no-sync ./frt suggest samples/diagnostic_fixtures -o reports/suggestions

./scripts/run_architecture_audit_demo.sh reports/architecture-audit-demo
./scripts/run_responsibility_split_demo.sh reports/responsibility-split-demo
./scripts/run_state_lifecycle_demo.sh reports/state-lifecycle-demo
./scripts/run_public_api_demo.sh reports/public-api-demo
./scripts/run_kind_standardization_demo.sh reports/kind-standardization-demo
./scripts/run_test_harness_demo.sh reports/test-harness-demo
./scripts/run_array_interface_demo.sh reports/array-interface-demo
./scripts/run_allocatable_storage_demo.sh reports/allocatable-storage-demo
./scripts/run_control_flow_demo.sh reports/control-flow-demo
./scripts/run_control_flow_cfg_demo.sh reports/control-flow-cfg-demo
./scripts/run_control_flow_advanced_demo.sh reports/control-flow-advanced-demo
./scripts/run_control_flow_cleanup_demo.sh reports/control-flow-cleanup-demo
./scripts/run_control_flow_state_machine_demo.sh reports/control-flow-state-machine-demo
./scripts/run_regression_compare_demo.sh reports/regression-compare-demo
./scripts/run_regression_suite_demo.sh reports/regression-suite-demo
./scripts/run_determinism_demo.sh reports/determinism-demo
./scripts/run_common_state_fixture_demo.sh reports/common-state-fixture-demo
./scripts/run_equivalence_alias_demo.sh reports/equivalence-alias-demo
./scripts/run_storage_size_probe_matrix_demo.sh reports/storage-size-probe-matrix-demo
./scripts/run_determinism_matrix_demo.sh reports/determinism-matrix-demo
./scripts/run_external_interface_demo.sh reports/external-interface-demo
./scripts/run_fixed_form_demo.sh reports/fixed-form-demo
./scripts/run_block_data_init_demo.sh
./scripts/run_storage_overlay_demo.sh reports/storage-overlay-demo
./scripts/run_common_repair_demo.sh reports/common-repair-demo
./scripts/run_stage_demo.sh reports/stage-demo
