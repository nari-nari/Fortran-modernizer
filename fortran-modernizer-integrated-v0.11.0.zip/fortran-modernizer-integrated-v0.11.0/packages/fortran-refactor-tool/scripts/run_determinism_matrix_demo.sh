#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUT="${1:-$ROOT/reports/determinism-matrix-demo}"
rm -rf "$OUT"
mkdir -p "$OUT/stable" "$OUT/varying"

cat > "$OUT/stable/solver.F90" <<'F90'
program matrix_demo
  use omp_lib
  implicit none
  integer :: i, unit
  real(8) :: total
  total = 0.0d0
!$omp parallel do reduction(+:total)
  do i = 1, 1000
    total = total + dble(i)
  end do
!$omp end parallel do
  open(newunit=unit, file='field.dat', status='replace', action='write')
  write(unit, '(ES24.16)') total
  close(unit)
end program matrix_demo
F90
cat > "$OUT/stable/config.json" <<'JSON'
{
  "working_directory": ".",
  "runs": 2,
  "compilers": [
    {"name": "gfortran", "command": "gfortran", "flags": ["-fopenmp", "-cpp"]}
  ],
  "optimization_levels": [
    {"name": "O0", "flags": ["-O0"]},
    {"name": "O2", "flags": ["-O2"]}
  ],
  "thread_counts": [1, 2],
  "build_commands": [
    ["{compiler}", "{compiler_flags}", "{optimization_flags}", "solver.F90", "-o", "{executable}"]
  ],
  "run_command": ["./{executable}"],
  "cleanup_commands": [["rm", "-f", "{executable}", "field.dat"]],
  "artifacts": [
    {
      "name": "field",
      "path": "field.dat",
      "mode": "numeric-array-text",
      "atol": 0.0,
      "rtol": 0.0,
      "remove_before_run": true
    }
  ],
  "cross_variant": {"enabled": true, "baseline": "gfortran__O0__t1"}
}
JSON
"$ROOT/frt" determinism-matrix --config "$OUT/stable/config.json" -o "$OUT/stable/report"
grep -q '"status": "pass"' "$OUT/stable/report/determinism-matrix.json"
grep -q '"variants_passed": 4' "$OUT/stable/report/determinism-matrix.json"
grep -q '"cross_variant_failures": 0' "$OUT/stable/report/determinism-matrix.json"

cat > "$OUT/varying/solver.F90" <<'F90'
program matrix_demo
  implicit none
  integer :: unit
  real(8) :: value
  value = 1.0d0
#ifdef VALUE
  value = value + dble(VALUE)
#endif
  open(newunit=unit, file='field.dat', status='replace', action='write')
  write(unit, '(ES24.16)') value
  close(unit)
end program matrix_demo
F90
cat > "$OUT/varying/config.json" <<'JSON'
{
  "working_directory": ".",
  "runs": 2,
  "compilers": [
    {"name": "gfortran", "command": "gfortran", "flags": ["-cpp"]}
  ],
  "optimization_levels": [
    {"name": "base", "flags": ["-O0", "-DVALUE=1"]},
    {"name": "changed", "flags": ["-O0", "-DVALUE=2"]}
  ],
  "thread_counts": [1],
  "build_commands": [
    ["{compiler}", "{compiler_flags}", "{optimization_flags}", "solver.F90", "-o", "{executable}"]
  ],
  "run_command": ["./{executable}"],
  "cleanup_commands": [["rm", "-f", "{executable}", "field.dat"]],
  "artifacts": [
    {
      "name": "field",
      "path": "field.dat",
      "mode": "numeric-array-text",
      "atol": 0.0,
      "rtol": 0.0,
      "remove_before_run": true
    }
  ],
  "cross_variant": {"enabled": true, "baseline": "gfortran__base__t1"}
}
JSON
if "$ROOT/frt" determinism-matrix --config "$OUT/varying/config.json" -o "$OUT/varying/report"; then
  echo "Expected cross-variant difference to fail" >&2
  exit 2
else
  status=$?
  if [[ "$status" -ne 2 ]]; then
    echo "Unexpected varying matrix status: $status" >&2
    exit 2
  fi
fi
grep -q '"status": "failed"' "$OUT/varying/report/determinism-matrix.json"
grep -q '"cross_variant_failures": 1' "$OUT/varying/report/determinism-matrix.json"

echo "DETERMINISM MATRIX DEMO: PASS"
