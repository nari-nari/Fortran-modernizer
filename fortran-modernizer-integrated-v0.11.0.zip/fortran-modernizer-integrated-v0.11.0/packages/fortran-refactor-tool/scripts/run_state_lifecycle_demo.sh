#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUT="${1:-$ROOT/reports/state-lifecycle-demo}"
rm -rf "$OUT"
mkdir -p "$OUT/build"
"$ROOT/frt" state-lifecycle-suggest "$ROOT/samples/state_lifecycle" -o "$OUT/report"
gfortran -J "$OUT/build" -I "$OUT/build" \
  "$ROOT/samples/state_lifecycle/state_store.f90" \
  "$ROOT/samples/state_lifecycle/worker.f90" \
  "$ROOT/samples/state_lifecycle/use_cache.f90" \
  "$ROOT/samples/state_lifecycle/main.f90" \
  -o "$OUT/build/demo"
"$OUT/build/demo" | tee "$OUT/output.txt"
grep -Eq '^[[:space:]]*2\.000[[:space:]]+6\.000' "$OUT/output.txt"
echo "STATE LIFECYCLE DEMO: PASS"
