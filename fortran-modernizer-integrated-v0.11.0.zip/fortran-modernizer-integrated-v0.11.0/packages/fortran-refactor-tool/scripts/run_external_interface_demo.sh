#!/usr/bin/env bash
set -euo pipefail
ROOT="${1:-reports/external-interface-demo}"
rm -rf "$ROOT"
mkdir -p "$ROOT"
PY=(uv run --locked --no-sync)
"${PY[@]}" ./frt external-interface-plan samples/external_interfaces -o "$ROOT/plan"
"${PY[@]}" ./frt apply "$ROOT/plan" -o "$ROOT/applied" --id EXT-0001 --approve-review --compile-check
mkdir -p "$ROOT/build"
gfortran -std=legacy -Wall -Wextra -Werror=implicit-interface -Werror=implicit-procedure \
  -J "$ROOT/build" -I "$ROOT/build" \
  "$ROOT/applied/transformed_sources/generated_interfaces/legacy_external_interfaces.f90" \
  "$ROOT/applied/transformed_sources/external_procedures.for" \
  "$ROOT/applied/transformed_sources/external_driver.for" \
  -o "$ROOT/build/external_demo"
"$ROOT/build/external_demo" | tee "$ROOT/result.txt"
grep -q '6.000' "$ROOT/result.txt"
echo "EXTERNAL INTERFACE DEMO: PASS"
