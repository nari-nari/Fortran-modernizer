#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUT="${1:-$ROOT/reports/public-api-demo}"
rm -rf "$OUT"
mkdir -p "$OUT/build"
"$ROOT/frt" public-api-suggest "$ROOT/samples/public_api" -o "$OUT/suggest"
python3 - "$OUT/suggest/public_api_selection.json" "$OUT/selection.json" <<'PY'
import json, sys
source, target = sys.argv[1:]
payload = json.load(open(source, encoding="utf-8"))
payload["reviewed"] = True
entry = next(item for item in payload["modules"] if item["module"] == "solver_services")
entry["selected_candidate_id"] = "API-MINIMAL-solver-services"
payload["modules"] = [entry]
open(target, "w", encoding="utf-8").write(json.dumps(payload, indent=2) + "\n")
PY
"$ROOT/frt" public-api-plan "$ROOT/samples/public_api" \
  --selection "$OUT/selection.json" -o "$OUT/plan"
"$ROOT/frt" apply "$OUT/plan" -o "$OUT/applied" \
  --id API-0001 --approve-review --compile-check
gfortran -J "$OUT/build" -I "$OUT/build" \
  "$OUT/applied/transformed_sources/solver_services.f90" \
  "$OUT/applied/transformed_sources/client.f90" \
  "$OUT/applied/transformed_sources/main.f90" \
  -o "$OUT/build/demo"
"$OUT/build/demo" | tee "$OUT/output.txt"
grep -Eq '^[[:space:]]*10\.000' "$OUT/output.txt"
python3 - "$OUT/applied/application_receipt.json" <<'PY'
import json, sys
receipt = json.load(open(sys.argv[1], encoding="utf-8"))
row = receipt["public_api_verification"][0]
assert row["private_default"] is True
assert row["public_names"] == ["evaluate", "rk", "solve"]
PY
echo "PUBLIC API DEMO: PASS"
