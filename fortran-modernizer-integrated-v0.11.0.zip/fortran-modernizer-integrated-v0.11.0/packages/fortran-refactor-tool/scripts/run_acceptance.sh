#!/usr/bin/env bash
set -euo pipefail

OUTPUT="${1:-reports/acceptance/validation.txt}"
mkdir -p "$(dirname "$OUTPUT")"
exec > >(tee "$OUTPUT") 2>&1

echo "# Fortran Refactor Tool acceptance"
echo "UTC: $(date -u +%Y-%m-%dT%H:%M:%SZ)"
echo "uv: $(uv --version)"
echo "python: $(python3 --version)"
echo "gfortran: $(gfortran --version | head -1)"
echo

uv sync --locked --python python3 --no-python-downloads
uv run --locked --no-sync ./frt doctor
uv run --locked --no-sync python scripts/run_tests.py
uv run --locked --no-sync ./frt verify-sample --project-root .
uv run --locked --no-sync ./frt assess-project \
  --config samples/config/lubrication_project.json \
  -o reports/acceptance/project-assessment
uv run --locked --no-sync ./frt analyze samples/legacy_runnable samples/diagnostic_fixtures \
  -I samples/legacy_runnable/include -o reports/acceptance/analysis
uv run --locked --no-sync ./frt suggest samples/diagnostic_fixtures -o reports/acceptance/suggestions
uv run --locked --no-sync ./scripts/run_frontend_compat_demo.sh reports/acceptance/frontend-compat-demo
./scripts/run_architecture_audit_demo.sh reports/acceptance/architecture-audit-demo
./scripts/run_responsibility_split_demo.sh reports/acceptance/responsibility-split-demo
./scripts/run_state_lifecycle_demo.sh reports/state-lifecycle-demo
./scripts/run_public_api_demo.sh reports/acceptance/public-api-demo
./scripts/run_kind_standardization_demo.sh reports/acceptance/kind-standardization-demo
./scripts/run_test_harness_demo.sh reports/acceptance/test-harness-demo
./scripts/run_array_interface_demo.sh reports/acceptance/array-interface-demo
./scripts/run_allocatable_storage_demo.sh reports/acceptance/allocatable-storage-demo
./scripts/run_control_flow_demo.sh reports/acceptance/control-flow-demo
./scripts/run_control_flow_cfg_demo.sh reports/acceptance/control-flow-cfg-demo
./scripts/run_control_flow_advanced_demo.sh reports/acceptance/control-flow-advanced-demo
./scripts/run_control_flow_cleanup_demo.sh reports/acceptance/control-flow-cleanup-demo
./scripts/run_control_flow_state_machine_demo.sh reports/acceptance/control-flow-state-machine-demo
./scripts/run_regression_compare_demo.sh reports/acceptance/regression-compare-demo
./scripts/run_regression_suite_demo.sh reports/acceptance/regression-suite-demo
./scripts/run_determinism_demo.sh reports/acceptance/determinism-demo
./scripts/run_common_state_fixture_demo.sh reports/acceptance/common-state-fixture-demo
./scripts/run_equivalence_alias_demo.sh reports/acceptance/equivalence-alias-demo
./scripts/run_storage_size_probe_matrix_demo.sh reports/acceptance/storage-size-probe-matrix-demo
./scripts/run_determinism_matrix_demo.sh reports/acceptance/determinism-matrix-demo
./scripts/run_external_interface_demo.sh reports/acceptance/external-interface-demo
./scripts/run_state_integration_demo.sh
if command -v findent >/dev/null 2>&1; then
  uv run --locked --no-sync ./frt findent-verify samples/absoft_compatibility/multiline_declarations.for -o reports/acceptance/findent-check
fi
./scripts/run_fixed_form_demo.sh reports/acceptance/fixed-form-demo
./scripts/run_fixed_to_free_demo.sh reports/acceptance/fixed-to-free-demo
./scripts/run_block_data_init_demo.sh
./scripts/run_storage_overlay_demo.sh reports/acceptance/storage-overlay-demo
./scripts/run_common_repair_demo.sh reports/acceptance/common-repair-demo
./scripts/run_stage_demo.sh reports/acceptance/stage-demo

echo
echo "ACCEPTANCE: PASS"
echo "Validation log: $OUTPUT"
