#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUT="${1:-$ROOT/reports/regression-compare-demo}"
rm -rf "$OUT"
mkdir -p "$OUT/data"

cat > "$OUT/data/pressure.reference.csv" <<'EOF'
# i,j pressure
1.000000000000D+00,2.000000000000D+00,3.000000000000D+00
4.000000000000D+00,5.000000000000D+00,6.000000000000D+00
EOF
cat > "$OUT/data/pressure.actual.csv" <<'EOF'
# i,j pressure
1.000000000000D+00,2.000000000000D+00,3.000000000000D+00
4.000000000000D+00,5.000000000100D+00,6.000000000000D+00
EOF

cat > "$OUT/data/result.reference.json" <<'EOF'
{"fields":{"temperature":[[300.0,301.0],[302.0,303.0]]}}
EOF
cat > "$OUT/data/result.actual.json" <<'EOF'
{"fields":{"temperature":[[300.0,301.0],[302.0,303.00000001]]}}
EOF

cat > "$OUT/data/residual.reference.dat" <<'EOF'
0 1.0D+00
1 1.0D-01
2 1.0D-02
3 1.0D-03
EOF
cat > "$OUT/data/residual.actual.dat" <<'EOF'
0 1.0D+00
1 1.0000000001D-01
2 1.0D-02
3 1.0D-03
EOF

python3 - "$OUT/data/field.reference.unf" "$OUT/data/field.actual.unf" <<'PY'
import struct
import sys

def record(values):
    payload = struct.pack("<" + "d" * len(values), *values)
    marker = struct.pack("<I", len(payload))
    return marker + payload + marker

reference = record([1.0, 2.0]) + record([3.0, 4.0])
actual = record([1.0, 2.0]) + record([3.0, 4.0 + 1.0e-11])
open(sys.argv[1], "wb").write(reference)
open(sys.argv[2], "wb").write(actual)
PY

"$ROOT/frt" regression-compare \
  "$OUT/data/pressure.reference.csv" "$OUT/data/pressure.actual.csv" \
  --mode numeric-array-text --delimiter , --shape 2,3 \
  --atol 1e-9 --rtol 0 -o "$OUT/pressure"

"$ROOT/frt" regression-compare \
  "$OUT/data/result.reference.json" "$OUT/data/result.actual.json" \
  --mode numeric-array-json --json-path fields.temperature \
  --atol 1e-7 --rtol 0 -o "$OUT/json"

"$ROOT/frt" regression-compare \
  "$OUT/data/field.reference.unf" "$OUT/data/field.actual.unf" \
  --mode numeric-array-fortran-record --dtype float64 --endian little \
  --record-marker-bytes 4 --shape 2,2 --atol 1e-9 --rtol 0 \
  -o "$OUT/fortran-record"

"$ROOT/frt" regression-compare \
  "$OUT/data/residual.reference.dat" "$OUT/data/residual.actual.dat" \
  --mode numeric-history --iteration-column 0 --value-column 1 \
  --atol 1e-9 --rtol 0 -o "$OUT/history"

# The same pressure difference must be rejected by a stricter gate.
if "$ROOT/frt" regression-compare \
  "$OUT/data/pressure.reference.csv" "$OUT/data/pressure.actual.csv" \
  --mode numeric-array-text --delimiter , --shape 2,3 \
  --atol 1e-12 --rtol 0 -o "$OUT/expected-failure"; then
  echo "Expected strict regression comparison to fail" >&2
  exit 2
else
  status=$?
  if [[ "$status" -ne 2 ]]; then
    echo "Unexpected strict-comparison status: $status" >&2
    exit 2
  fi
fi

grep -q '"status": "pass"' "$OUT/pressure/comparison.json"
grep -q '"reference_shape": \[' "$OUT/json/comparison.json"
grep -q '"records": 2' "$OUT/fortran-record/comparison.json"
grep -q '"iteration_labels_equal": true' "$OUT/history/comparison.json"
grep -q '"status": "failed"' "$OUT/expected-failure/comparison.json"

echo "REGRESSION COMPARISON DEMO: PASS"
