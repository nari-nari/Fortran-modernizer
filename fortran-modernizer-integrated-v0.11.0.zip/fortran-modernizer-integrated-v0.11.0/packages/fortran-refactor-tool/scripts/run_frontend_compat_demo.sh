#!/usr/bin/env bash
set -euo pipefail

OUTPUT_ROOT="${1:-reports/frontend-compat-demo}"
rm -rf "$OUTPUT_ROOT"
mkdir -p "$OUTPUT_ROOT"

./frt frontend-audit samples \
  -I samples/legacy_runnable/include \
  -o "$OUTPUT_ROOT/frontend-audit" \
  --fail-on-fallback

./frt assess-project \
  --config samples/config/absoft_compatibility_project.json \
  -o "$OUTPUT_ROOT/absoft-assessment"

./frt compile-check samples/absoft_compatibility \
  --profile absoft-compat \
  -o "$OUTPUT_ROOT/compiler-absoft"

./frt compile-check samples/absoft_compatibility/uninitialized_variable.for \
  --profile uninitialized-warning \
  -o "$OUTPUT_ROOT/uninitialized-warning"

grep -Eiq "uninitialized|may be used" "$OUTPUT_ROOT/uninitialized-warning/gfortran.txt"

./frt compile-check samples/absoft_compatibility/uninitialized_variable.for \
  --profile uninitialized-poison \
  -o "$OUTPUT_ROOT/uninitialized-poison"

./frt external-tools > "$OUTPUT_ROOT/external-tools.json"

./frt workspace-init samples/legacy_runnable \
  -o "$OUTPUT_ROOT/workspace" \
  --force
./frt workspace-checkpoint "$OUTPUT_ROOT/workspace" \
  --source-root samples/legacy_runnable \
  --stage frontend-baseline \
  --note "AST frontend and compatibility intake validated" \
  > "$OUTPUT_ROOT/workspace-checkpoint.json"
./frt workspace-status "$OUTPUT_ROOT/workspace" > "$OUTPUT_ROOT/workspace-status.json"
./frt workspace-resume "$OUTPUT_ROOT/workspace" > "$OUTPUT_ROOT/workspace-resume.json"

echo "FRONTEND COMPATIBILITY DEMO: PASS"
