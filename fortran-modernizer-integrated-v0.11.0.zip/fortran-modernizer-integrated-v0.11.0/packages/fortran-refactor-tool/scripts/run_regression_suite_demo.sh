#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUT="${1:-$ROOT/reports/regression-suite-demo}"
WORK="$OUT/project"
rm -rf "$OUT"
mkdir -p "$WORK/nominal" "$WORK/high-load"

cat > "$WORK/dummy.f90" <<'F90'
program dummy
end program dummy
F90

for case_name in nominal high-load; do
  cat > "$WORK/$case_name/solver.f90" <<'F90'
program checkpoint_solver
  implicit none
  integer :: unit_id
  real(8) :: scale

  open(newunit=unit_id, file='case.in', status='old', action='read')
  read(unit_id, *) scale
  close(unit_id)

  open(newunit=unit_id, file='initial.out', status='replace', action='write')
  write(unit_id, '(2(ES24.16,1X))') scale, 2.0d0 * scale
  write(unit_id, '(2(ES24.16,1X))') 3.0d0 * scale, 4.0d0 * scale
  close(unit_id)

  open(newunit=unit_id, file='final.out', status='replace', action='write')
  write(unit_id, '(2(ES24.16,1X))') 10.0d0 * scale, 20.0d0 * scale
  write(unit_id, '(2(ES24.16,1X))') 30.0d0 * scale, 40.0d0 * scale
  close(unit_id)

  open(newunit=unit_id, file='residual.out', status='replace', action='write')
  write(unit_id, '(I0,1X,ES24.16)') 0, 1.0d0 * scale
  write(unit_id, '(I0,1X,ES24.16)') 1, 1.0d-1 * scale
  write(unit_id, '(I0,1X,ES24.16)') 2, 1.0d-2 * scale
  close(unit_id)
end program checkpoint_solver
F90
done

printf '1.0\n' > "$WORK/nominal/case.in"
printf '2.0\n' > "$WORK/high-load/case.in"

cat > "$WORK/nominal/initial.ref" <<'EOF'
1 2
3 4
EOF
cat > "$WORK/nominal/final.ref" <<'EOF'
10 20
30 40
EOF
cat > "$WORK/nominal/residual.ref" <<'EOF'
0 1.0
1 0.1
2 0.01
EOF
cat > "$WORK/high-load/initial.ref" <<'EOF'
2 4
6 8
EOF
cat > "$WORK/high-load/final.ref" <<'EOF'
20 40
60 80
EOF
cat > "$WORK/high-load/residual.ref" <<'EOF'
0 2.0
1 0.2
2 0.02
EOF

cat > "$WORK/fortran-refactor.json" <<'JSON'
{
  "schema_version": 1,
  "project": {"name": "synthetic-checkpoint-suite", "root": "."},
  "sources": {
    "paths": ["dummy.f90"],
    "include_globs": ["**/*.f90"],
    "exclude_globs": []
  },
  "fortran": {"include_dirs": [], "fixed_line_length": 72},
  "compiler": {"enabled": false},
  "regression": {
    "enabled": true,
    "working_directory": ".",
    "build_commands": [],
    "run_commands": [],
    "comparisons": [],
    "cases": [
      {
        "name": "nominal",
        "working_directory": "nominal",
        "build_commands": [["gfortran", "solver.f90", "-o", "solver"]],
        "run_commands": [["./solver"]],
        "checkpoints": [
          {
            "name": "initialization",
            "comparisons": [
              {
                "name": "pressure",
                "mode": "numeric-array-text",
                "reference": "initial.ref",
                "actual": "initial.out",
                "shape": [2, 2],
                "atol": 1e-12,
                "rtol": 1e-12
              }
            ]
          },
          {
            "name": "converged",
            "comparisons": [
              {
                "name": "pressure",
                "mode": "numeric-array-text",
                "reference": "final.ref",
                "actual": "final.out",
                "shape": [2, 2],
                "atol": 1e-12,
                "rtol": 1e-12
              },
              {
                "name": "residual",
                "mode": "numeric-history",
                "reference": "residual.ref",
                "actual": "residual.out",
                "iteration_column": 0,
                "value_columns": [1],
                "atol": 1e-12,
                "rtol": 1e-12
              }
            ]
          }
        ]
      },
      {
        "name": "high-load",
        "working_directory": "high-load",
        "build_commands": [["gfortran", "solver.f90", "-o", "solver"]],
        "run_commands": [["./solver"]],
        "checkpoints": [
          {
            "name": "initialization",
            "comparisons": [
              {
                "name": "pressure",
                "mode": "numeric-array-text",
                "reference": "initial.ref",
                "actual": "initial.out",
                "shape": [2, 2],
                "atol": 1e-12,
                "rtol": 1e-12
              }
            ]
          },
          {
            "name": "converged",
            "comparisons": [
              {
                "name": "pressure",
                "mode": "numeric-array-text",
                "reference": "final.ref",
                "actual": "final.out",
                "shape": [2, 2],
                "atol": 1e-12,
                "rtol": 1e-12
              },
              {
                "name": "residual",
                "mode": "numeric-history",
                "reference": "residual.ref",
                "actual": "residual.out",
                "iteration_column": 0,
                "value_columns": [1],
                "atol": 1e-12,
                "rtol": 1e-12
              }
            ]
          }
        ]
      }
    ]
  },
  "assessment": {"performance_budget_seconds": 60.0}
}
JSON

"$ROOT/frt" regression-suite \
  --config "$WORK/fortran-refactor.json" \
  -o "$OUT/pass"

python3 - "$OUT/pass/suite.json" <<'PY'
import json
import sys
from pathlib import Path
payload = json.loads(Path(sys.argv[1]).read_text())
assert payload["status"] == "pass", payload
assert payload["summary"]["cases"] == 2, payload
assert payload["summary"]["checkpoints"] == 4, payload
assert payload["summary"]["comparisons"] == 6, payload
groups = {(x["checkpoint"], x["comparison"]): x for x in payload["cross_case_groups"]}
assert groups[("initialization", "pressure")]["cases"] == 2, groups
assert groups[("converged", "pressure")]["passed"] == 2, groups
assert groups[("converged", "residual")]["passed"] == 2, groups
PY

python3 - "$WORK/fortran-refactor.json" "$WORK/failure-config.json" <<'PY'
import json
import sys
from pathlib import Path
src, dst = map(Path, sys.argv[1:])
payload = json.loads(src.read_text())
for case in payload["regression"]["cases"]:
    case["build_commands"] = []
    case["run_commands"] = []
dst.write_text(json.dumps(payload, indent=2) + "\n")
PY
printf '20 40\n60 81\n' > "$WORK/high-load/final.out"
if "$ROOT/frt" regression-suite \
  --config "$WORK/failure-config.json" \
  -o "$OUT/failure"; then
  echo "Expected the intentionally perturbed multi-case suite to fail." >&2
  exit 1
fi
python3 - "$OUT/failure/suite.json" <<'PY'
import json
import sys
from pathlib import Path
payload = json.loads(Path(sys.argv[1]).read_text())
assert payload["status"] == "failed", payload
groups = {(x["checkpoint"], x["comparison"]): x for x in payload["cross_case_groups"]}
item = groups[("converged", "pressure")]
assert item["failed"] == 1, item
assert item["worst_max_absolute_error_case"] == "high-load", item
assert item["worst_max_absolute_error"] == 1.0, item
PY

echo "REGRESSION SUITE DEMO: PASS"
