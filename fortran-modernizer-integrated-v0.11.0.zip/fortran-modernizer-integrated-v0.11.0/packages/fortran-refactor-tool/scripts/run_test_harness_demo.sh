#!/usr/bin/env bash
set -euo pipefail
OUT="${1:-reports/test-harness-demo}"
rm -rf "$OUT"
uv run --locked --no-sync ./frt test-harness-suggest \
  samples/testability/testable_kernels.f90 \
  --unit scale_values --unit weighted_energy \
  --default-array-extent 3 \
  -o "$OUT"
gfortran samples/testability/testable_kernels.f90 \
  "$OUT/generated_harnesses/test_scale_values_smoke.f90" \
  -o "$OUT/test_scale_values"
"$OUT/test_scale_values" | tee "$OUT/test_scale_values.out"
grep -q 'FRT_SUM results' "$OUT/test_scale_values.out"
gfortran samples/testability/testable_kernels.f90 \
  "$OUT/generated_harnesses/test_weighted_energy_smoke.f90" \
  -o "$OUT/test_weighted_energy"
"$OUT/test_weighted_energy" | tee "$OUT/test_weighted_energy.out"
grep -q 'FRT_RESULT frt_result' "$OUT/test_weighted_energy.out"
echo 'TEST HARNESS DEMO: PASS'
