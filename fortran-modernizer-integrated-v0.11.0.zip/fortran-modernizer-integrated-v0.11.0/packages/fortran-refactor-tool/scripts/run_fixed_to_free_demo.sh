#!/usr/bin/env bash
set -euo pipefail

OUT="${1:-reports/fixed-to-free-demo}"
rm -rf "$OUT"
mkdir -p "$OUT/source"
cp -R samples/legacy_runnable/. "$OUT/source/"

ORIGINAL_EXE="$OUT/original"
FREE_EXE="$OUT/free"
gfortran -std=legacy -ffixed-line-length-72 \
  -I "$OUT/source/include" \
  "$OUT/source/journal_bearing_legacy.for" \
  -o "$ORIGINAL_EXE"
"$ORIGINAL_EXE" > "$OUT/original.out"

./frt fixed-to-free-plan "$OUT/source" \
  -I "$OUT/source/include" \
  --input-line-length 72 \
  -o "$OUT/plan"

./frt apply "$OUT/plan" \
  -o "$OUT/applied" \
  --id F2F-0001 \
  --approve-review \
  -I "$OUT/source/include" \
  --compile-check

TRANSFORMED="$OUT/applied/transformed_sources"
test ! -e "$TRANSFORMED/journal_bearing_legacy.for"
test -f "$TRANSFORMED/journal_bearing_legacy.f90"
gfortran -std=legacy \
  -I "$TRANSFORMED/include" \
  "$TRANSFORMED/journal_bearing_legacy.f90" \
  -o "$FREE_EXE"
"$FREE_EXE" > "$OUT/free.out"
diff -u "$OUT/original.out" "$OUT/free.out"

echo "FIXED TO FREE DEMO: PASS"
