#!/usr/bin/env bash
set -euo pipefail

OUT="${1:-reports/storage-overlay-demo}"
rm -rf "$OUT"
mkdir -p "$OUT"

uv run --locked --no-sync ./frt storage-overlay-plan \
  samples/storage_overlay \
  -o "$OUT/plan"

python - "$OUT/plan/partial_overlap_candidates.json" <<'PY'
import json
import sys
from pathlib import Path
payload = json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))
assert payload["status"] == "analysis-only"
assert payload["candidate_count"] >= 3
by_unit = {}
for item in payload["candidates"]:
    by_unit.setdefault(item["program_unit"], []).append(item)
main = by_unit["partial_overlap_demo"][0]
assert main["overlap_bytes"] == 32
assert main["left_storage"]["overlap_fortran_index_start"] == [3]
assert main["left_storage"]["overlap_fortran_index_end"] == [10]
assert main["right_storage"]["overlap_fortran_index_start"] == [1]
assert main["right_storage"]["overlap_fortran_index_end"] == [8]
assert main["status"] == "analysis-only"
two_d = by_unit["partial_overlap_2d"][0]
assert two_d["left_storage"]["overlap_fortran_index_start"] == [2, 5]
assert two_d["left_storage"]["overlap_fortran_index_end"] == [3, 5]
misaligned = by_unit["partial_overlap_misaligned"][0]
assert misaligned["review_readiness"] == "needs-manual-proof"
assert not misaligned["left_storage"]["element_aligned"]
print("partial overlap candidates:", payload["candidate_count"])
PY

python - "$OUT/plan/partial_overlap_migration_options.json" <<'PY'
import json
import sys
from pathlib import Path
payload = json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))
assert payload["status"] == "analysis-only"
assert payload["design_count"] >= 2
by_unit = {item["program_unit"]: item for item in payload["designs"]}
design = by_unit["partial_overlap_demo"]
assert design["preferred_option"] == "canonical-workspace"
options = {item["option_id"]: item for item in design["options"]}
assert set(options) == {"canonical-workspace", "synchronized-copies", "derived-storage-type"}
assert options["canonical-workspace"]["storage_model"]["union_elements"] == 12
assert options["synchronized-copies"]["status"] == "not-recommended"
print("partial overlap migration designs:", payload["design_count"])
PY

python - "$OUT/plan/canonical_workspace_mapping_contracts.json" <<'PY'
import json
import sys
from pathlib import Path
payload = json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))
assert payload["status"] == "analysis-only"
assert payload["contract_count"] >= 2
assert payload["fixture_ready_count"] >= 2
by_unit = {item["program_unit"]: item for item in payload["contracts"]}
contract = by_unit["partial_overlap_demo"]
assert contract["workspace"]["element_count"] == 12
views = {item["name"]: item for item in contract["views"]}
assert views["a"]["workspace_start_one_based"] == 1
assert views["a"]["workspace_end_one_based"] == 10
assert views["b"]["workspace_start_one_based"] == 3
assert views["b"]["workspace_end_one_based"] == 12
assert contract["fixture_status"] == "ready"
print("canonical workspace mapping contracts:", payload["contract_count"])
PY

fixture_index=0
while IFS= read -r fixture; do
  fixture_index=$((fixture_index + 1))
  executable="$OUT/workspace_fixture_${fixture_index}"
  gfortran "$OUT/plan/$fixture" -o "$executable"
  "$executable" | tee "$OUT/workspace_fixture_${fixture_index}.out"
  grep -q "WORKSPACE CONTRACT" "$OUT/workspace_fixture_${fixture_index}.out"
done < <(python - "$OUT/plan/canonical_workspace_mapping_contracts.json" <<'PY'
import json
import sys
from pathlib import Path
payload = json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))
for item in payload["contracts"]:
    if item["fixture_status"] == "ready":
        print(item["fixture"]["source"])
PY
)
test "$fixture_index" -ge 2

python - "$OUT/plan/canonical_workspace_refactor_fixtures.json" <<'PY'
import json
import sys
from pathlib import Path
payload = json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))
assert payload["status"] == "synthetic-only"
assert payload["ready_count"] >= 2
for item in payload["packages"]:
    if item["status"] != "ready":
        continue
    assert item["comparison"]["expected_stdout_relation"] == "byte-for-byte identical"
    assert item["comparison"]["refactored_contains_equivalence"] is False
print("canonical workspace refactor fixtures:", payload["package_count"])
PY

refactor_index=0
while IFS= read -r contract_id; do
  refactor_index=$((refactor_index + 1))
  package_dir="$OUT/plan/canonical_workspace_refactor_fixtures/$contract_id"
  legacy_executable="$OUT/legacy_refactor_${refactor_index}"
  refactored_executable="$OUT/canonical_refactor_${refactor_index}"
  legacy_output="$OUT/legacy_refactor_${refactor_index}.out"
  refactored_output="$OUT/canonical_refactor_${refactor_index}.out"
  module_dir="$OUT/mod_refactor_${refactor_index}"
  mkdir -p "$module_dir"
  ! grep -qi '^[[:space:]]*equivalence[[:space:]]*(' "$package_dir/canonical_workspace_module.f90"
  ! grep -qi '^[[:space:]]*equivalence[[:space:]]*(' "$package_dir/refactored_workspace_program.f90"
  grep -qi '^[[:space:]]*equivalence[[:space:]]*(' "$package_dir/legacy_equivalence_program.f90"
  gfortran "$package_dir/legacy_equivalence_program.f90" -o "$legacy_executable"
  gfortran -J "$module_dir" \
    "$package_dir/canonical_workspace_module.f90" \
    "$package_dir/refactored_workspace_program.f90" \
    -o "$refactored_executable"
  "$legacy_executable" > "$legacy_output"
  "$refactored_executable" > "$refactored_output"
  cmp "$legacy_output" "$refactored_output"
done < <(python - "$OUT/plan/canonical_workspace_refactor_fixtures.json" <<'PY'
import json
import sys
from pathlib import Path
payload = json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))
for item in payload["packages"]:
    if item["status"] == "ready":
        print(item["contract_id"])
PY
)
test "$refactor_index" -ge 2

uv run --locked --no-sync ./frt apply "$OUT/plan" \
  -o "$OUT/applied" \
  --id OVL-BLANK-0001 \
  --approve-review \
  --compile-check

TRANSFORMED="$OUT/applied/transformed_sources"
gfortran -std=legacy "$TRANSFORMED/blank_common.for" -o "$OUT/blank_common_demo"
"$OUT/blank_common_demo" | tee "$OUT/run.out"
grep -q "13.000" "$OUT/run.out"

gfortran "$TRANSFORMED/partial_overlap.f90" -o "$OUT/partial_overlap_demo"
"$OUT/partial_overlap_demo" | tee "$OUT/partial.out"
grep -q "2.0" "$OUT/partial.out"

echo "STORAGE OVERLAY DEMO: PASS"
