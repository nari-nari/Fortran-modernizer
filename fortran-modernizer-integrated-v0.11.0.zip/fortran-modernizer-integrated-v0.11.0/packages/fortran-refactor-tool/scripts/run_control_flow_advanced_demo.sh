#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUT="${1:-$ROOT/reports/control-flow-advanced-demo}"
rm -rf "$OUT"
mkdir -p "$OUT/build"

"$ROOT/frt" control-flow-suggest \
  "$ROOT/samples/control_flow_advanced" \
  -o "$OUT/suggest"

python3 - "$OUT/suggest/control_flow_selection.json" \
  "$OUT/suggest/control_flow_suggestions.json" "$OUT/selection.json" "$OUT/ids.txt" <<'PY'
import json, sys
selection_path, suggestions_path, output_path, ids_path = sys.argv[1:]
selection = json.load(open(selection_path, encoding="utf-8"))
suggestions = json.load(open(suggestions_path, encoding="utf-8"))
advanced_kinds = {"multiple_backward_loop", "cleanup_block_exit"}
ready = [
    item for item in suggestions["candidates"]
    if item["status"] == "ready" and item["construct_kind"] in advanced_kinds
]
assert len(ready) == 2, ready
assert {item["construct_kind"] for item in ready} == advanced_kinds, ready
assert all(item["cfg_evidence"]["relevant_edges"] for item in ready), ready
selection["reviewed"] = True
selection["selections"] = [
    {
        "candidate_id": item["candidate_id"],
        "confirmed_semantics": True,
        "confirmed_regression_gate": True,
    }
    for item in ready
]
open(output_path, "w", encoding="utf-8").write(json.dumps(selection, indent=2) + "\n")
open(ids_path, "w", encoding="utf-8").write("\n".join(item["candidate_id"] for item in ready) + "\n")
PY

"$ROOT/frt" control-flow-plan \
  "$ROOT/samples/control_flow_advanced" \
  --selection "$OUT/selection.json" \
  -o "$OUT/plan"

apply_args=()
while IFS= read -r id; do
  apply_args+=(--id "$id")
done < "$OUT/ids.txt"
"$ROOT/frt" apply "$OUT/plan" \
  -o "$OUT/applied" \
  "${apply_args[@]}" \
  --approve-review \
  --compile-check

SRC="$OUT/applied/transformed_sources/advanced_cfg.f90"
gfortran "$SRC" -o "$OUT/build/advanced_cfg"
"$OUT/build/advanced_cfg" | tee "$OUT/output.txt"
grep -Eq '^52$' "$OUT/output.txt"
grep -qi 'cycle frt_multi_loop_' "$SRC"
grep -qi 'end block frt_cleanup_' "$SRC"
! grep -Eqi '\b(go[[:space:]]*to|goto)\b' "$SRC"

echo "ADVANCED CONTROL FLOW DEMO: PASS"
