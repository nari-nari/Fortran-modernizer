#!/usr/bin/env bash
set -euo pipefail

OUTPUT_ROOT="${1:-reports/fixed-form-demo}"
rm -rf "$OUTPUT_ROOT"
mkdir -p "$OUTPUT_ROOT/source"
cp samples/absoft_compatibility/multiline_declarations.for "$OUTPUT_ROOT/source/"

./frt fixed-form-rewrite-plan \
  "$OUTPUT_ROOT/source/multiline_declarations.for" \
  --line-length 72 \
  -o "$OUTPUT_ROOT/plan"

./frt apply "$OUTPUT_ROOT/plan" \
  -o "$OUTPUT_ROOT/applied" \
  --id FFR-0001 \
  --approve-review \
  --compile-check

python3 - "$OUTPUT_ROOT/applied/transformed_sources/multiline_declarations.for" <<'PY'
from pathlib import Path
import sys
path = Path(sys.argv[1])
violations = []
for number, raw in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
    expanded = raw.expandtabs(8)
    if expanded and expanded[0] not in {"c", "C", "*", "!"} and len(expanded) > 72:
        violations.append((number, len(expanded)))
if violations:
    raise SystemExit(f"fixed-form line length violations: {violations}")
PY

grep -q "Type_Declaration_Stmt" "$OUTPUT_ROOT/plan/statement_inventory.csv"
grep -q "Common_Stmt" "$OUTPUT_ROOT/plan/statement_inventory.csv"
grep -q "Call_Stmt" "$OUTPUT_ROOT/plan/statement_inventory.csv"

echo "FIXED FORM REWRITE DEMO: PASS"
