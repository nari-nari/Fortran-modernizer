#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
OUT="${1:-reports/stage-demo}"
rm -rf "$OUT"
mkdir -p "$OUT"

# Stage 1: diagnose and apply only the high-confidence typo repair.
uv run --locked --no-sync ./frt suggest samples/legacy_runnable \
  -I samples/legacy_runnable/include \
  -o "$OUT/typo-plan"
uv run --locked --no-sync ./frt apply "$OUT/typo-plan" \
  -o "$OUT/stage1" \
  --all-automatic \
  -I samples/legacy_runnable/include \
  --compile-check

# Stage 2: re-analyze the repaired copy and introduce IMPLICIT NONE per program unit.
uv run --locked --no-sync ./frt implicit-none-plan "$OUT/stage1/transformed_sources" \
  -I "$OUT/stage1/transformed_sources/include" \
  -o "$OUT/implicit-plan"

mapfile -t IMP_IDS < <(
  uv run --locked --no-sync python - "$OUT/implicit-plan/suggestions.json" <<'PY'
import json
import sys
for item in json.load(open(sys.argv[1], encoding="utf-8")):
    if item["safety"] == "approval-required":
        print(item["id"])
PY
)
if [[ ${#IMP_IDS[@]} -eq 0 ]]; then
  echo "No eligible IMPLICIT NONE suggestions were generated." >&2
  exit 2
fi
IMP_ARGS=()
for id in "${IMP_IDS[@]}"; do
  IMP_ARGS+=(--id "$id")
done
uv run --locked --no-sync ./frt apply "$OUT/implicit-plan" \
  -o "$OUT/stage2" \
  "${IMP_ARGS[@]}" \
  --approve-review \
  -I "$OUT/stage1/transformed_sources/include" \
  --compile-check

# Stage 3: centralize the compatible FIELD COMMON into one generated INCLUDE.
uv run --locked --no-sync ./frt common-include-plan "$OUT/stage2/transformed_sources" \
  -I "$OUT/stage2/transformed_sources/include" \
  -o "$OUT/common-plan"

mapfile -t COM_IDS < <(
  uv run --locked --no-sync python - "$OUT/common-plan/suggestions.json" <<'PY'
import json
import sys
for item in json.load(open(sys.argv[1], encoding="utf-8")):
    if item["safety"] == "approval-required":
        print(item["id"])
PY
)
if [[ ${#COM_IDS[@]} -eq 0 ]]; then
  echo "No eligible COMMON INCLUDE suggestions were generated." >&2
  exit 2
fi
COM_ARGS=()
for id in "${COM_IDS[@]}"; do
  COM_ARGS+=(--id "$id")
done
uv run --locked --no-sync ./frt apply "$OUT/common-plan" \
  -o "$OUT/stage3" \
  "${COM_ARGS[@]}" \
  --approve-review \
  -I "$OUT/stage2/transformed_sources/include" \
  --compile-check

# Stage 4: migrate the centralized FIELD COMMON to one generated module.
uv run --locked --no-sync ./frt common-module-plan "$OUT/stage3/transformed_sources" \
  -I "$OUT/stage3/transformed_sources/include" \
  -I "$OUT/stage3/transformed_sources/generated_common" \
  -o "$OUT/module-plan"

mapfile -t MOD_IDS < <(
  uv run --locked --no-sync python - "$OUT/module-plan/suggestions.json" <<'PY'
import json
import sys
for item in json.load(open(sys.argv[1], encoding="utf-8")):
    if item["safety"] == "approval-required":
        print(item["id"])
PY
)
if [[ ${#MOD_IDS[@]} -eq 0 ]]; then
  echo "No eligible COMMON module suggestions were generated." >&2
  exit 2
fi
MOD_ARGS=()
for id in "${MOD_IDS[@]}"; do
  MOD_ARGS+=(--id "$id")
done
uv run --locked --no-sync ./frt apply "$OUT/module-plan" \
  -o "$OUT/stage4" \
  "${MOD_ARGS[@]}" \
  --approve-review \
  -I "$OUT/stage3/transformed_sources/include" \
  -I "$OUT/stage3/transformed_sources/generated_common" \
  --compile-check

# Stage 5a: suggest functional domains from names, comments, CALLs, and shared state.
uv run --locked --no-sync ./frt procedure-domain-suggest "$OUT/stage4/transformed_sources" \
  -I "$OUT/stage4/transformed_sources/include" \
  -o "$OUT/procedure-domain-suggestion"

# The generated draft is deliberately unusable until reviewed. For this controlled
# sample, verify the four expected assignments, add project-specific module prefixes,
# and record the explicit review decision in a separate file.
uv run --locked --no-sync python - \
  "$OUT/procedure-domain-suggestion/classification_draft.json" \
  "$OUT/reviewed-domains.json" <<'PYREVIEW'
import json
import sys
from pathlib import Path

source = Path(sys.argv[1])
target = Path(sys.argv[2])
payload = json.loads(source.read_text(encoding="utf-8"))
expected = {
    "init_geometry": "geometry",
    "solve_reynolds": "solver",
    "compute_metrics": "postprocess",
    "print_results": "output",
}
actual = {
    procedure: domain["name"]
    for domain in payload["domains"]
    for procedure in domain["procedures"]
}
if actual != expected:
    raise SystemExit(f"unexpected domain proposal: {actual}")
for domain in payload["domains"]:
    domain["module_prefix"] = "lubrication_" + domain["name"]
payload["reviewed"] = True
payload["review_note"] = "Accepted by the deterministic sample-stage review gate."
target.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
PYREVIEW

# Stage 5b: organize external subroutines using the reviewed classification.
uv run --locked --no-sync ./frt procedure-module-domain-plan "$OUT/stage4/transformed_sources" \
  -I "$OUT/stage4/transformed_sources/include" \
  --classification "$OUT/reviewed-domains.json" \
  -o "$OUT/procedure-domain-plan"

mapfile -t PROC_IDS < <(
  uv run --locked --no-sync python - "$OUT/procedure-domain-plan/suggestions.json" <<'PYJSON'
import json
import sys
for item in json.load(open(sys.argv[1], encoding="utf-8")):
    if item["safety"] == "approval-required":
        print(item["id"])
PYJSON
)
if [[ ${#PROC_IDS[@]} -eq 0 ]]; then
  echo "No eligible functional procedure-module suggestion was generated." >&2
  exit 2
fi
PROC_ARGS=()
for id in "${PROC_IDS[@]}"; do
  PROC_ARGS+=(--id "$id")
done
uv run --locked --no-sync ./frt apply "$OUT/procedure-domain-plan" \
  -o "$OUT/stage5" \
  "${PROC_ARGS[@]}" \
  --approve-review \
  -I "$OUT/stage4/transformed_sources/include" \
  --compile-check

# Stage 6: propagate dummy-argument effects and add reviewed INTENT attributes.
uv run --locked --no-sync ./frt intent-plan "$OUT/stage5/transformed_sources" \
  -I "$OUT/stage5/transformed_sources/include" \
  -o "$OUT/intent-plan"

mapfile -t INT_IDS < <(
  uv run --locked --no-sync python - "$OUT/intent-plan/suggestions.json" <<'PYINT'
import json
import sys
for item in json.load(open(sys.argv[1], encoding="utf-8")):
    if item["safety"] == "approval-required":
        print(item["id"])
PYINT
)
if [[ ${#INT_IDS[@]} -eq 0 ]]; then
  echo "No eligible INTENT suggestions were generated." >&2
  exit 2
fi
INT_ARGS=()
for id in "${INT_IDS[@]}"; do
  INT_ARGS+=(--id "$id")
done
uv run --locked --no-sync ./frt apply "$OUT/intent-plan" \
  -o "$OUT/stage6" \
  "${INT_ARGS[@]}" \
  --approve-review \
  -I "$OUT/stage5/transformed_sources/include" \
  --compile-check

# Stage 7a: propose a review-required grouping of module globals into state objects.
uv run --locked --no-sync ./frt state-object-suggest "$OUT/stage6/transformed_sources" \
  -I "$OUT/stage6/transformed_sources/include" \
  --module field_common_module \
  -o "$OUT/state-object-suggestion"

# Confirm that an unreviewed draft cannot be used as a migration plan.
if uv run --locked --no-sync ./frt state-object-plan "$OUT/stage6/transformed_sources" \
  -I "$OUT/stage6/transformed_sources/include" \
  --classification "$OUT/state-object-suggestion/state_object_draft.json" \
  -o "$OUT/unreviewed-state-object-plan"; then
  echo "Unreviewed state-object classification was accepted unexpectedly." >&2
  exit 2
fi

# Stage 7b: apply the deterministic sample's reviewed mesh/state classification.
uv run --locked --no-sync ./frt state-object-plan "$OUT/stage6/transformed_sources" \
  -I "$OUT/stage6/transformed_sources/include" \
  --classification samples/config/lubrication_state_objects.json \
  -o "$OUT/state-object-plan"
uv run --locked --no-sync ./frt apply "$OUT/state-object-plan" \
  -o "$OUT/stage7" \
  --id STATE-0001 \
  --approve-review \
  -I "$OUT/stage6/transformed_sources/include" \
  --compile-check

# Compile, run, and compare the final staged source with the frozen golden output.
mkdir -p "$OUT/final-run/mod"
gfortran \
  -std=legacy -ffixed-line-length-72 -O0 -g \
  -Wall -Wextra -Wimplicit-interface -Werror=implicit-interface \
  -J "$OUT/final-run/mod" -I "$OUT/final-run/mod" \
  -Wimplicit-procedure -Werror=implicit-procedure -Walign-commons -fcheck=all \
  -I "$OUT/stage7/transformed_sources/include" \
  "$OUT/stage7/transformed_sources/generated_types/lubrication_data_types.f90" \
  "$OUT/stage7/transformed_sources/generated_modules/lubrication_geometry_module.for" \
  "$OUT/stage7/transformed_sources/generated_modules/lubrication_solver_module.for" \
  "$OUT/stage7/transformed_sources/generated_modules/lubrication_postprocess_module.for" \
  "$OUT/stage7/transformed_sources/generated_modules/lubrication_output_module.for" \
  "$OUT/stage7/transformed_sources/journal_bearing_legacy.for" \
  -o "$OUT/final-run/journal_bearing"
"$OUT/final-run/journal_bearing" > "$OUT/final-run/output.txt"
diff -u samples/reference_results/reference.out "$OUT/final-run/output.txt"

uv run --locked --no-sync ./frt analyze "$OUT/stage7/transformed_sources" \
  -I "$OUT/stage7/transformed_sources/include" \
  -o "$OUT/final-analysis" \
  --fail-on-error

if grep -Rqi "implicit real" "$OUT/stage7/transformed_sources"; then
  echo "Legacy IMPLICIT rule remains in the final staged source." >&2
  exit 2
fi
if grep -Rqi "residuall" "$OUT/stage7/transformed_sources"; then
  echo "Typo remains in the final staged source." >&2
  exit 2
fi
if grep -RqiE "^[[:space:]]*COMMON[[:space:]]*/[[:space:]]*FIELD[[:space:]]*/" \
  "$OUT/stage7/transformed_sources"; then
  echo "Active FIELD COMMON remains after module migration." >&2
  exit 2
fi
if grep -Rqi "INCLUDE 'field_common.inc'" "$OUT/stage7/transformed_sources/journal_bearing_legacy.for"; then
  echo "FIELD COMMON INCLUDE is still used after module migration." >&2
  exit 2
fi
if [[ ! -f "$OUT/stage7/transformed_sources/generated_types/lubrication_data_types.f90" ]]; then
  echo "Generated lubrication data-types module is missing." >&2
  exit 2
fi
if grep -Rqi "USE FIELD_COMMON_MODULE" "$OUT/stage7/transformed_sources"; then
  echo "Old FIELD_COMMON_MODULE is still imported after state-object migration." >&2
  exit 2
fi
for reference in "MESH%H" "MESH%THETA" "STATE%P"; do
  if ! grep -Rqi "$reference" "$OUT/stage7/transformed_sources/generated_modules"; then
    echo "Expected state-object component reference is missing: $reference" >&2
    exit 2
  fi
done
for module in \
  lubrication_geometry_module.for \
  lubrication_solver_module.for \
  lubrication_postprocess_module.for \
  lubrication_output_module.for; do
  if [[ ! -f "$OUT/stage7/transformed_sources/generated_modules/$module" ]]; then
    echo "Generated functional procedure module is missing: $module" >&2
    exit 2
  fi
done
if grep -qiE "^[[:space:]]*SUBROUTINE[[:space:]]" "$OUT/stage7/transformed_sources/journal_bearing_legacy.for"; then
  echo "External subroutine definitions remain in the main legacy source." >&2
  exit 2
fi
for module in \
  LUBRICATION_GEOMETRY_MODULE \
  LUBRICATION_SOLVER_MODULE \
  LUBRICATION_POSTPROCESS_MODULE \
  LUBRICATION_OUTPUT_MODULE; do
  if ! grep -qi "USE $module, ONLY:" "$OUT/stage7/transformed_sources/journal_bearing_legacy.for"; then
    echo "Main program is missing functional module interface: $module" >&2
    exit 2
  fi
done
if [[ ! -f "$OUT/procedure-domain-plan/domain_assignment.csv" ]] ||
   [[ ! -f "$OUT/procedure-domain-plan/domain_dependencies.dot" ]]; then
  echo "Functional classification reports are missing." >&2
  exit 2
fi
if [[ ! -f "$OUT/procedure-domain-suggestion/domain_evidence.csv" ]] ||
   [[ ! -f "$OUT/procedure-domain-suggestion/relationship_evidence.csv" ]] ||
   [[ ! -f "$OUT/procedure-domain-suggestion/classification_draft.json" ]]; then
  echo "Automatic domain-suggestion evidence is missing." >&2
  exit 2
fi
if ! grep -q '"reviewed": false' "$OUT/procedure-domain-suggestion/classification_draft.json"; then
  echo "Generated classification draft was not protected by reviewed=false." >&2
  exit 2
fi
if [[ ! -f "$OUT/intent-plan/argument_access.csv" ]] ||
   [[ ! -f "$OUT/intent-plan/intent_candidates.csv" ]]; then
  echo "INTENT data-flow reports are missing." >&2
  exit 2
fi
for declaration in \
  "INTENT(IN) :: ITERATIONS" \
  "INTENT(OUT) :: RESIDUAL" \
  "INTENT(OUT) :: LOAD"; do
  if ! grep -Rqi "$declaration" "$OUT/stage7/transformed_sources/generated_modules"; then
    echo "Expected reviewed declaration is missing: $declaration" >&2
    exit 2
  fi
done

if [[ ! -f "$OUT/state-object-suggestion/shared_variable_evidence.csv" ]] ||
   [[ ! -f "$OUT/state-object-plan/procedure_object_arguments.csv" ]]; then
  echo "State-object classification or argument reports are missing." >&2
  exit 2
fi
if ! grep -q '"reviewed": false' "$OUT/state-object-suggestion/state_object_draft.json"; then
  echo "Generated state-object draft was not protected by reviewed=false." >&2
  exit 2
fi

echo "STAGED REFACTORING DEMO: PASS"
echo "Output: $OUT"
