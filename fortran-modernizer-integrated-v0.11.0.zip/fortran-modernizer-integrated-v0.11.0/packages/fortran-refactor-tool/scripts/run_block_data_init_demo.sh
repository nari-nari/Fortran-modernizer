#!/usr/bin/env bash
set -euo pipefail

OUTPUT="${1:-reports/block-data-init-demo}"
rm -rf "$OUTPUT"
mkdir -p "$OUTPUT"
PY=(uv run --locked --no-sync)

"${PY[@]}" ./frt block-data-init-plan samples/block_data_initialization \
  -o "$OUTPUT/plan"
"${PY[@]}" ./frt apply "$OUTPUT/plan" \
  -o "$OUTPUT/applied" \
  --id BDI-0001 \
  --approve-review \
  --compile-check

TRANSFORMED="$OUTPUT/applied/transformed_sources"
BUILD="$OUTPUT/build"
mkdir -p "$BUILD"
gfortran -std=legacy -ffixed-line-length-72 \
  -J "$BUILD" -I "$BUILD" \
  "$TRANSFORMED/generated_initialization/legacy_block_data_initialization.f90" \
  "$TRANSFORMED/init.for" \
  "$TRANSFORMED/main.for" \
  -o "$BUILD/block_data_demo"
RESULT="$($BUILD/block_data_demo | tr -d ' ')"
if [[ "$RESULT" != "859.010" ]]; then
  echo "Unexpected BLOCK DATA demo result: $RESULT" >&2
  exit 2
fi

echo "BLOCK DATA INITIALIZATION DEMO: PASS ($RESULT)"
