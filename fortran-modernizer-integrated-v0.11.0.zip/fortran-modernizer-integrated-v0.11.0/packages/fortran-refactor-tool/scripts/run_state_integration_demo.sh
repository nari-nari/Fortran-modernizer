#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
rm -rf reports/state-integration-demo work/state-integration-demo
PYTHONPATH=src uv run --locked --no-sync ./frt state-integration-suggest \
  samples/existing_structure_integration \
  --classification samples/config/existing_structure_state_objects.json \
  -o reports/state-integration-demo/suggest
PYTHONPATH=src uv run --locked --no-sync ./frt state-integration-plan \
  samples/existing_structure_integration \
  --classification samples/config/existing_structure_state_objects.json \
  --selection samples/config/existing_structure_selection.json \
  -o reports/state-integration-demo/plan
PYTHONPATH=src uv run --locked --no-sync ./frt apply \
  reports/state-integration-demo/plan \
  -o work/state-integration-demo \
  --id STATEINT-0001 \
  --approve-review \
  --compile-check
BUILD="work/state-integration-demo/build"
mkdir -p "$BUILD"
gfortran -J "$BUILD" -I "$BUILD" \
  work/state-integration-demo/transformed_sources/model_types.f90 \
  work/state-integration-demo/transformed_sources/workers.f90 \
  work/state-integration-demo/transformed_sources/main.f90 \
  -o "$BUILD/demo"
"$BUILD/demo" | tee "$BUILD/output.txt"
grep -q '20.000' "$BUILD/output.txt"
echo "STATE INTEGRATION DEMO: PASS"
