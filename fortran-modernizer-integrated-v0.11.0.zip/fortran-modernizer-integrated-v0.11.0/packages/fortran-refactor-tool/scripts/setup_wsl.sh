#!/usr/bin/env bash
set -euo pipefail

sudo apt update
sudo apt install -y curl ca-certificates python3 gfortran make graphviz git

if ! command -v uv >/dev/null 2>&1; then
  echo "uv was not found. Installing it with the official Astral installer..."
  curl -LsSf https://astral.sh/uv/install.sh | sh
  export PATH="$HOME/.local/bin:$PATH"
fi

uv --version
./scripts/run_acceptance.sh

echo "Setup and mandatory fparser integration tests completed successfully."
echo "Run commands with 'uv run --locked --no-sync ...'; activating .venv is optional."
