#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUT="${1:-$ROOT/reports/equivalence-alias-demo}"
SOURCE_ROOT="$ROOT/samples/equivalence_alias"
rm -rf "$OUT"
mkdir -p "$OUT/build"

before_demo="$(sha256sum "$SOURCE_ROOT/demo.f90" | awk '{print $1}')"
before_common="$(sha256sum "$SOURCE_ROOT/common_alias.f90" | awk '{print $1}')"
before_array="$(sha256sum "$SOURCE_ROOT/array_demo.f90" | awk '{print $1}')"
before_anchor="$(sha256sum "$SOURCE_ROOT/anchor_analysis.for" | awk '{print $1}')"
before_common_anchor="$(sha256sum "$SOURCE_ROOT/common_anchor_review.f90" | awk '{print $1}')"
before_dual_anchor="$(sha256sum "$SOURCE_ROOT/dual_reference_review.f90" | awk '{print $1}')"

"$ROOT/frt" equivalence-alias-suggest \
  "$SOURCE_ROOT" \
  --storage-size-compiler gfortran \
  -o "$OUT/suggest"

python3 - "$OUT/suggest/equivalence_alias_selection.json" \
  "$OUT/suggest/equivalence_alias_suggestions.json" \
  "$OUT/selection.json" "$OUT/ids.txt" <<'PY'
import json, sys
selection_path, suggestions_path, output_path, ids_path = sys.argv[1:]
selection = json.load(open(selection_path, encoding="utf-8"))
suggestions = json.load(open(suggestions_path, encoding="utf-8"))
ready = [item for item in suggestions["candidates"] if item["status"] == "ready"]
blocked = [item for item in suggestions["candidates"] if item["status"] == "blocked"]
analysis_only = [item for item in suggestions["candidates"] if item["status"] == "analysis-only"]
assert len(ready) == 5, ready
assert len(blocked) == 3, blocked
assert len(analysis_only) == 1, analysis_only
by_ready_unit = {item["program_unit"]: item for item in ready}
by_analysis_unit = {item["program_unit"]: item for item in analysis_only}
anchor = by_ready_unit["equivalence_anchor_analysis_demo"]
assert anchor["alias_form"] == "array-element-anchor", anchor
assert anchor["anchor_linear_offsets"] == [0, 0], anchor
assert anchor["anchor_first_elements"] == [True, True], anchor
assert anchor["total_elements"] == 3, anchor
assert anchor["analysis_mode"] == "transformable-compiler-verified-first-element-anchor", anchor
assert anchor["storage_probe_verified"], anchor
assert anchor["storage_probe_element_bits"] == [32, 32], anchor
assert anchor["review_readiness"] == "review-ready", anchor
assert anchor["element_storage_bytes"] == 4, anchor
assert anchor["total_storage_bytes"] == 12, anchor
assert all(anchor["proof_checks"].values()), anchor
common_anchor = by_ready_unit["equivalence_common_anchor_review_demo"]
assert common_anchor["storage_probe_verified"], common_anchor
assert common_anchor["review_readiness"] == "review-ready", common_anchor
assert common_anchor["allowed_representatives"] == ["storage"], common_anchor
assert common_anchor["common_layout"]["storage"]["position"] == 2, common_anchor
assert common_anchor["common_layout"]["storage"]["packed_offset_bytes"] == 4, common_anchor
dual_anchor = by_analysis_unit["equivalence_dual_reference_review_demo"]
assert dual_anchor["review_readiness"] == "needs-manual-proof", dual_anchor
assert dual_anchor["simultaneous_reference_lines"], dual_anchor
assert dual_anchor["promotion_blockers"], dual_anchor
by_unit = {item["program_unit"]: item for item in ready}
assert by_unit["common_alias_step"]["allowed_representatives"] == ["storage"]
assert by_unit["equivalence_array_alias_demo"]["alias_form"] == "whole-array"
assert by_unit["equivalence_array_alias_demo"]["shape"] == ["0:2", "1:2"]
selection["reviewed"] = True
ids = []
ready_by_id = {item["candidate_id"]: item for item in ready}
for row in selection["selections"]:
    candidate = ready_by_id.get(row["candidate_id"])
    if candidate is None:
        continue
    row["approved"] = True
    row["representative"] = (
        "primary" if candidate["program_unit"] == "equivalence_array_alias_demo"
        else candidate["recommended_representative"]
    )
    row["regression_tests_reviewed"] = True
    if candidate["alias_form"] == "array-element-anchor":
        row["storage_size_probe_reviewed"] = True
    ids.append(row["candidate_id"])
open(output_path, "w", encoding="utf-8").write(json.dumps(selection, indent=2) + "\n")
open(ids_path, "w", encoding="utf-8").write("\n".join(ids) + "\n")
PY

python3 - "$OUT/suggest/equivalence_element_anchor_candidates.json" <<'PY'
import json, sys
payload = json.load(open(sys.argv[1], encoding="utf-8"))
assert payload["mode"] == "compiler-probed-review-gated-removal", payload
assert payload["summary"]["analysis_only_candidates"] == 1, payload
assert payload["summary"]["review_ready_candidates"] == 2, payload
assert payload["summary"]["manual_proof_candidates"] == 1, payload
assert payload["summary"]["compiler_verified_candidates"] == 2, payload
assert payload["summary"]["transformable_candidates"] == 2, payload
assert payload["summary"]["source_modifications"] == 0, payload
PY

"$ROOT/frt" equivalence-alias-plan \
  "$SOURCE_ROOT" \
  --selection "$OUT/selection.json" \
  -o "$OUT/plan"

apply_args=()
while IFS= read -r id; do
  apply_args+=(--id "$id")
done < "$OUT/ids.txt"
"$ROOT/frt" apply "$OUT/plan" \
  -o "$OUT/applied" \
  "${apply_args[@]}" \
  --approve-review \
  --compile-check

SRC="$OUT/applied/transformed_sources"
gfortran "$SRC/demo.f90" -o "$OUT/build/demo"
"$OUT/build/demo" | tee "$OUT/output.txt"
grep -Eq '^[[:space:]]*5\.0' "$OUT/output.txt"
! grep -qi 'equivalence' "$SRC/demo.f90"
! grep -Eqi '\balias\b' "$SRC/demo.f90"
grep -qi 'result = primary + 3.0' "$SRC/demo.f90"
! grep -qi 'equivalence' "$SRC/common_alias.f90"
! grep -Eqi '\bstorage_alias\b' "$SRC/common_alias.f90"
grep -qi 'storage = 7.0' "$SRC/common_alias.f90"

gfortran "$SRC/array_demo.f90" -o "$OUT/build/array_demo"
"$OUT/build/array_demo" | tee "$OUT/array_output.txt"
grep -Eq '^[[:space:]]*101\.0' "$OUT/array_output.txt"
! grep -qi 'equivalence' "$SRC/array_demo.f90"
! grep -Eqi '\balias\b' "$SRC/array_demo.f90"
grep -qi 'primary(1,2) = primary(1,2) + 5.0' "$SRC/array_demo.f90"

gfortran "$SRC/anchor_analysis.for" -o "$OUT/build/anchor_analysis"
"$OUT/build/anchor_analysis" | tee "$OUT/anchor_output.txt"
grep -Eq '^[[:space:]]*6\.0' "$OUT/anchor_output.txt"
! grep -qi 'EQUIVALENCE' "$SRC/anchor_analysis.for"
! grep -Eqi '\bALIAS\b' "$SRC/anchor_analysis.for"

gfortran "$SRC/common_anchor_review.f90" -o "$OUT/build/common_anchor_review"
"$OUT/build/common_anchor_review" | tee "$OUT/common_anchor_output.txt"
grep -Eq '^[[:space:]]*6\.0' "$OUT/common_anchor_output.txt"
! grep -qi 'equivalence' "$SRC/common_anchor_review.f90"
! grep -Eqi '\balias\b' "$SRC/common_anchor_review.f90"
grep -qi 'common /state_array/ flag, storage' "$SRC/common_anchor_review.f90"

gfortran "$SRC/dual_reference_review.f90" -o "$OUT/build/dual_reference_review"
"$OUT/build/dual_reference_review" | tee "$OUT/dual_anchor_output.txt"
grep -Eq '^[[:space:]]*5\.0' "$OUT/dual_anchor_output.txt"
grep -qi 'equivalence (primary(1), alias(1))' "$SRC/dual_reference_review.f90"

python3 - "$OUT/applied/application_receipt.json" <<'PY'
import json, sys
receipt = json.load(open(sys.argv[1], encoding="utf-8"))
items = receipt["equivalence_alias_verification"]
assert len(items) == 5, items
assert all(item["equivalence_removed"] for item in items), items
assert all(item["alias_declaration_removed"] for item in items), items
PY

after_demo="$(sha256sum "$SOURCE_ROOT/demo.f90" | awk '{print $1}')"
after_common="$(sha256sum "$SOURCE_ROOT/common_alias.f90" | awk '{print $1}')"
after_array="$(sha256sum "$SOURCE_ROOT/array_demo.f90" | awk '{print $1}')"
after_anchor="$(sha256sum "$SOURCE_ROOT/anchor_analysis.for" | awk '{print $1}')"
after_common_anchor="$(sha256sum "$SOURCE_ROOT/common_anchor_review.f90" | awk '{print $1}')"
after_dual_anchor="$(sha256sum "$SOURCE_ROOT/dual_reference_review.f90" | awk '{print $1}')"
test "$before_demo" = "$after_demo"
test "$before_common" = "$after_common"
test "$before_array" = "$after_array"
test "$before_anchor" = "$after_anchor"
test "$before_common_anchor" = "$after_common_anchor"
test "$before_dual_anchor" = "$after_dual_anchor"

echo "EQUIVALENCE COMPLETE-ALIAS + COMPILER-VERIFIED FIRST-ELEMENT ANCHOR REMOVAL DEMO: PASS"
