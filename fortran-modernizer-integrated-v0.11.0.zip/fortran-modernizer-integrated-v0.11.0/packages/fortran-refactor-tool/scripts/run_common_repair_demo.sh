#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
OUT="${1:-reports/common-repair-demo}"
rm -rf "$OUT"
mkdir -p "$OUT"

uv run --locked --no-sync ./frt common-repair-plan \
  samples/diagnostic_fixtures \
  -o "$OUT/plan"

# The fixture intentionally offers two semantic alternatives per inconsistent
# block. This deterministic demo selects one candidate per block solely to test
# planning, explicit approval, application, and verification mechanics.
SELECTED=(
  CRP-FIELD2-01
  CRP-FLUID-01
  CRP-MIXED-01
  CRP-STATE-01
)
ARGS=()
for id in "${SELECTED[@]}"; do
  ARGS+=(--id "$id")
done

uv run --locked --no-sync ./frt apply "$OUT/plan" \
  -o "$OUT/applied" \
  "${ARGS[@]}" \
  --approve-review \
  --compile-check

uv run --locked --no-sync python - "$OUT/applied/verification/analysis/analysis.json" <<'PY'
import json
import sys
payload = json.load(open(sys.argv[1], encoding="utf-8"))
remaining = [
    item for item in payload["diagnostics"]
    if item["severity"] == "error" and item["code"].startswith("COMMON_")
]
if remaining:
    raise SystemExit(f"COMMON layout errors remain: {remaining}")
PY

for required in \
  layout_variants.csv \
  candidate_impacts.csv \
  common_repair_options.json \
  common_repair_options.md \
  impact_graph.dot; do
  if [[ ! -f "$OUT/plan/$required" ]]; then
    echo "Missing COMMON repair report: $required" >&2
    exit 2
  fi
done

if ! grep -q '"reviewed": false' "$OUT/plan/common_repair_options.json"; then
  echo "COMMON repair options are not protected by reviewed=false." >&2
  exit 2
fi

echo "COMMON_REPAIR_DEMO: PASS"
