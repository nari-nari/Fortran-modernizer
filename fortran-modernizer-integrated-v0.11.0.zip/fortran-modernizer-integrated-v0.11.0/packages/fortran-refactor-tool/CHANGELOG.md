# Changelog

## 0.50.0

- generates canonical workspace modules and rank-aware/linear accessor skeletons from eligible v0.49.0 mapping contracts
- generates legacy EQUIVALENCE oracle and EQUIVALENCE-free refactored synthetic programs
- adds exact-stdout comparison manifests and per-package documentation
- verifies one-dimensional and multidimensional mappings with gfortran
- blocks COMMON-connected, transitive, scalar-mixed, unresolved-bound, and dual-reference candidates
- keeps all new outputs synthetic-only and does not generate production edits
- increases the mandatory Python test suite from 227 to 230 tests
- production Fortran remains untested

## 0.49.0

- adds canonical workspace mapping contracts for every byte/element-mapped partial EQUIVALENCE overlap
- records union element count, each legacy view's one-based workspace range and zero-based offset, original bounds, and overlap correspondence
- emits per-contract JSON snapshots with source SHA-256 and explicit review obligations
- generates and compiles standalone synthetic Fortran fixtures for direct local two-array overlays
- blocks fixture generation for COMMON-connected, transitive, scalar-mixed, unresolved-kind, and same-statement dual-use cases
- keeps production source unchanged and all new artifacts analysis/test-only
- increases the mandatory Python test suite from 224 to 227 tests
- production Fortran remains untested

## 0.48.0

- adds analysis-only migration design alternatives for mapped partial overlaps
- compares canonical workspace, synchronized copies, and derived storage type options
- records union size, former-view offsets, assignment evidence, COMMON/transitive ownership, risks, and required reviews
- keeps every design option non-editing and validates only with synthetic fixtures
- increases the mandatory Python test suite from 221 to 224 tests
- production Fortran remains untested

## 0.47.0

- adds dedicated JSON, CSV, and Markdown evidence for partial EQUIVALENCE storage overlaps
- maps each overlap to global and object-local byte ranges, overlap fractions, and prefix/suffix/containment relationships
- converts element-aligned byte intervals to one-based linear element ranges and multidimensional Fortran column-major index ranges
- records direct versus transitive EQUIVALENCE association, named-COMMON positions/offsets, reference contexts, and same-statement dual-name use
- distinguishes element-aligned compatible mappings from mid-element or storage-incompatible cases requiring manual proof
- keeps every partial overlap analysis-only and generates no transformation plan
- adds one-dimensional, multidimensional, COMMON/transitive, and misaligned type-punning synthetic tests
- increases the mandatory Python test suite from 217 to 221 tests
- production Fortran remains untested

## 0.46.0

- adds JSON-defined multi-profile `STORAGE_SIZE` probe matrices for first-element array-anchor EQUIVALENCE candidates
- records independent compiler path/version/flags, compile/run logs, and candidate measurements per named profile
- distinguishes required profiles from optional unavailable profiles
- promotes candidates only when all required and every available optional profile agree on element bits, element bytes, and total bytes
- rejects available-profile disagreements, required compiler failures, stale evidence, and unreviewed matrix consensus
- preserves the v0.45.0 single-compiler CLI and selection workflow
- adds gfortran O0/O2 consensus, default-real-size conflict, optional-skip, review-gate, and config-validation synthetic tests
- increases the mandatory Python test suite from 212 to 217 tests
- production Fortran and actual multi-vendor compiler agreement remain unvalidated

## 0.45.0

- added optional compiler `STORAGE_SIZE` probes for statically review-ready first-element array-anchor EQUIVALENCE candidates
- records compiler path/version/flags, element bits/bytes, total bytes, compile/run logs, and per-candidate verification results
- promotes only compiler-verified anchors to approval-required removal candidates
- requires explicit `storage_size_probe_reviewed=true` in addition to regression-test review
- keeps compiler-missing, probe-failed, and same-statement dual-alias candidates analysis-only
- validates fixed/free-form and named-COMMON anchor removal with synthetic gfortran fixtures; production Fortran remains untested
- increases the mandatory Python test suite from 208 to 212 tests

## 0.44.0

- strengthened first-element array-anchor EQUIVALENCE analysis with reference-context inventories
- added simultaneous dual-alias statement detection and explicit promotion blockers
- added element/total storage byte estimates and size-basis reporting
- added named-COMMON block, position, packed/natural offset, and layout-preservation evidence
- classified analysis-only anchors as `review-ready` or `needs-manual-proof` without enabling edits
- added three focused tests and expanded synthetic demo coverage; production Fortran remains untested

## 0.43.0

- adds analysis-only classification for `EQUIVALENCE (A(first...), B(first...))` array-element anchor forms
- requires identical intrinsic type, kind, rank, explicit shape, and constant integer bounds
- computes Fortran column-major linear offsets and records first-storage-element evidence
- emits dedicated JSON, CSV, and Markdown element-anchor reports without modifying source
- rejects nonfirst anchors, symbolic bounds/subscripts, mixed whole/subobject forms, and every attempt to enter the edit planner
- preserves the existing scalar and bare-whole-array reviewed removal workflows
- adds fixed/free-form, multidimensional, nonfirst, symbolic-bound, and plan-rejection synthetic coverage
- increases mandatory Python tests from 201 to 205
- validation remains synthetic-fixture-only; production Fortran has not been tested

## 0.42.0

- extends `equivalence-alias-suggest` and `equivalence-alias-plan` to whole-array complete aliases
- requires identical intrinsic type, kind, rank, and normalized explicit bound expressions in every dimension
- records scalar/whole-array form, rank, and shape in candidate snapshots and plans
- rewrites whole-array assignment, element references, and intrinsic-argument references to one reviewed representative
- preserves a named-COMMON array as the forced representative when it aliases one non-COMMON array
- blocks array elements, partial overlays, differing bounds, assumed/deferred shape, type-punning, COMMON-to-COMMON aliases, and stale reviews
- adds multidimensional non-unit-lower-bound, COMMON-array, and bound-mismatch synthetic coverage
- increases mandatory Python tests from 197 to 201
- validation remains synthetic-fixture-only; production Fortran has not been tested

## 0.41.0

- adds `equivalence-alias-suggest` and `equivalence-alias-plan` for review-gated removal of same-type, same-kind scalar complete aliases
- requires exactly two explicitly declared intrinsic scalar objects and preserves a named-COMMON member as the forced representative when present
- removes the alias declaration and EQUIVALENCE statement, rewrites code identifiers while preserving comments and string literals, and verifies the alias and selected overlay are absent after application
- blocks arrays/subobjects, type-punning, multiple-set statements, COMMON-to-COMMON aliases, nested scopes, declaration metadata, stale reviews, and unreviewed regression gates
- adds free-form, fixed-form, COMMON-anchored, blocked-pattern, stale-selection, compiler, and numerical-regression coverage
- increases mandatory Python tests from 192 to 197
- validation remains synthetic-fixture-only; production Fortran has not been tested

## 0.40.0

- extends `repeated-call-harness-suggest` with reviewed named-COMMON state fixtures
- emits fixture templates containing complete block layout, deterministic values, observation choices, EQUIVALENCE evidence, and source hashes
- requires `reviewed=true`, per-candidate approval, exact layout freshness, and valid typed JSON scalar values before harness generation
- reproduces named COMMON storage in generated drivers, restores it before the second call, and compares selected COMMON members
- permits only same-type scalar two-object EQUIVALENCE aliases connected to one named-COMMON object
- blocks blank COMMON, type-punning, partial/multi-object overlays, dynamic extents, unsupported types/ranks, and stale fixtures
- adds synthetic fixed-form passing COMMON, failing COMMON+SAVE, and blocked type-punning coverage
- increases mandatory Python tests from 188 to 192
- does not claim production-code validation

## 0.39.0

- adds `determinism-matrix` for explicit compiler, optimization-level, and OpenMP-thread Cartesian products
- expands reviewed argv templates without shell execution and records resolved compilers, flags, environment, executable, build, run, and cleanup evidence
- runs the existing repeated-process determinism gate inside every variant
- compares run-1 artifacts from every successful variant against an explicit or first-successful baseline
- writes JSON, CSV, Markdown, per-variant reports, and per-artifact cross-variant comparison records
- supports optional unavailable compiler profiles while keeping required compiler failures fatal
- integrates `regression.determinism_matrix` with project regression execution
- adds synthetic gfortran OpenMP O0/O2 and one/two-thread pass coverage plus intentional cross-variant failure coverage
- increases mandatory Python tests from 183 to 188
- does not claim production-code or multi-vendor compiler validation

## 0.37.0

- adds blocked `irreducible_state_machine_candidate` evidence for nontrivial irreducible SCCs with three or more proposed states or multiple exits
- partitions SCC nodes into source-ordered basic-block states and records entry, transition, and exit tables with local edge predicates
- records conservative definite reads/writes, CALL-argument access-unknown evidence, simple exit-tail paths, required variables, and review questions
- writes dedicated JSON, CSV, and Markdown state-machine design bundles without modifying source or generating a transformation plan
- keeps the exact v0.36.0 two-entry/two-state dispatch normalization unchanged and rejects state-machine design candidates from `control-flow-plan`
- adds a synthetic three-state/multiple-exit compile-and-run demo and offline/quality/acceptance integration
- increases mandatory Python tests from 176 to 179

## 0.36.0

- extends conditional cleanup extraction to free-form hosts that already contain internal procedures without duplicating `CONTAINS`
- adds fixed-form conditional cleanup extraction with column-72 checks and host-associated internal cleanup procedures
- adds a narrowly proven `irreducible_dispatch_loop` transformation for exact two-entry/two-state SCCs using a BLOCK-local integer, `SELECT CASE`, and named-loop `CYCLE`
- retains blocked SCC inventory for non-matching irreducible regions and records the normalization strategy/state/entry-label evidence in reviewed snapshots
- expanded the compiled acceptance demo to existing-CONTAINS, fixed-form, dispatch-normalized, and still-blocked irreducible cases
- increased mandatory Python tests from 174 to 176

## 0.35.0

- extracts a shared free-form cleanup tail containing structured IF logic into one host-associated internal cleanup subroutine
- converts all simple branches to the cleanup label into EXIT from one named BLOCK, then calls the extracted cleanup exactly once before RETURN
- blocks fixed-form, PURE/ELEMENTAL, existing-CONTAINS, continued, cross-unit, unstructured, and externally entered cleanup candidates
- detects strongly connected CFG regions with multiple distinct external entry nodes and inventories them as blocked `irreducible_cfg_region` candidates with SCC edge evidence
- added an offline compile/run demo, documentation, Make/VS Code/acceptance integration, and three focused tests
- increased mandatory Python tests from 171 to 174

## 0.34.0

- converts two or more logical backward branches to one dedicated CONTINUE into a named post-test DO, using CYCLE for earlier restart edges and the final branch as the loop continuation condition
- converts two or more simple branches to a straight-line cleanup tail ending in RETURN into EXITs from one named BLOCK without duplicating cleanup side effects
- records CFG entry/exit evidence and blocks nested constructs, interior labels, unrelated branches, continued statements, external interior entries, and non-straight-line cleanup tails
- added free- and fixed-form compile/run coverage, an advanced CFG acceptance demo, CLI counts, documentation, Make/VS Code integration, and four focused tests
- increased mandatory Python tests from 167 to 171

## 0.33.0

- extended `control-flow-suggest` with lightweight CFG evidence: relevant branch/fall-through edges, region entry/exit edges, and complete label-reference lines
- converts shared labelled-DO terminal branches to named `DO` plus `CYCLE`, structured-DO post-label branches to named `DO` plus `EXIT`, and one-back-edge post-test loops to structured `DO`
- converts one or more simple branches to an exact shared `RETURN` label into direct conditional/unconditional `RETURN`
- inventories unsupported logical IF GOTO patterns and blocks multiple back-edges, nested structured post-test regions, nontrivial cleanup labels, and unresolved targets
- added fixed/free-form coverage, CFG snapshot freshness, an integrated four-pattern compile-and-run demo, documentation, Make/acceptance integration, and four focused tests
- increased mandatory Python tests from 163 to 167

## 0.32.0

- added `control-flow-suggest` to inventory labelled DO, arithmetic IF, dedicated forward GOTO, and complex GOTO constructs without modifying source
- added review-gated `control-flow-plan` and approval-protected application with source-hash freshness checks
- converts dedicated labelled DO terminals to named DO/END DO, arithmetic IF to single-evaluation ASSOCIATE plus IF, and narrow forward GOTO regions to named BLOCK plus EXIT
- blocks shared labels, continued statements, missing/non-CONTINUE targets, structured-boundary crossings, backward branches, and computed/assigned/variable-target GOTO
- added exact post-application construct-marker verification, fixed/free-form generation, compiled numerical demo coverage, documentation, Make/VS Code/acceptance integration, and five focused tests
- increased mandatory Python tests from 158 to 163

## 0.31.0

- extended `allocatable-storage-suggest` and `allocatable-storage-plan` from private module arrays to private derived-type components and procedure-local work arrays
- added typed object-dummy matching for component initializer/finalizer ownership and allocation through `object%component`
- added local entry allocation with automatic deallocation and scope-specific review confirmations
- added blockers for public/interoperable/extended/parameterized types, structure-constructor candidates, SAVE/DATA/ENTRY, coarrays, aliasing, existing allocation ownership, and unresolved bounds
- preserved original lower bounds for all three storage scopes and strengthened verification for line shifts caused by multiple selected edits
- expanded the compiled numerical demo to module, component, and local storage and added five focused tests
- increased mandatory Python tests from 153 to 158

## 0.30.0

- added `allocatable-storage-suggest` for conservative private module-array lifecycle review
- added review-gated `allocatable-storage-plan` and approval-protected application
- preserves original allocation bounds while converting declarations to deferred-shape `ALLOCATABLE` storage
- inserts idempotent allocation/reallocation and final deallocation into existing reviewed lifecycle owners
- blocks public arrays, ambiguous lifecycle, aliasing/storage association, unsafe attributes, derived types, and unresolved bounds
- added exact post-application verification, compiler/numerical demo coverage, and six focused tests
- increased mandatory Python tests from 147 to 153

## 0.29.0

- Added `determinism-check` to run one reviewed command two or more times in fresh child processes and compare run 2..N with run 1.
- Added prepare/reset commands, environment overrides, timeouts, stdout/stderr capture, immutable artifact snapshots, per-run timings and return codes, and machine-readable/Markdown reports.
- Added stale-artifact protection using pre/post size, nanosecond modification time, and SHA-256, plus explicitly requested removal restricted to files under the working directory.
- Reused all v0.28.0 numerical adapters and tolerances for repeated-run comparisons and integrated the gate under `regression.determinism` in the project pipeline.
- Added `repeated-call-harness-suggest` to call a Fortran procedure twice in one process, restore declared IN/INOUT inputs, and compare declared OUT/INOUT arguments and function results.
- Added `state-risk-candidate` evidence for SAVE, mutable module state, DATA initialization, caches, and allocation lifecycle, while conservatively blocking COMMON/EQUIVALENCE fixtures and unsafe interfaces.
- Added deterministic pass/fail demos, documentation, Make/acceptance targets, and 9 mandatory tests.
- Increased mandatory Python tests from 138 to 147.

## 0.28.0

- Added `regression-compare` for non-modifying comparison of field arrays and convergence histories.
- Added text-table, rectangular JSON, raw binary, and Fortran sequential-unformatted adapters with explicit shape and representation contracts.
- Added residual-history iteration-label validation and selected value-column comparison.
- Added elementwise absolute/relative tolerance gates, failed-element indexes, maximum errors, RMSE, absolute/relative L2 norms, extrema, and SHA-256 evidence.
- Integrated the new adapters into configured `run-pipeline --run-regression` comparisons while preserving legacy numeric key-value behavior.
- Added documentation, a deterministic pass/fail demo, Make/VS Code targets, offline/quality/acceptance integration, and 9 mandatory tests.
- Increased mandatory Python tests from 129 to 138.

## 0.27.0

- Added `array-interface-suggest` to inventory explicit-shape dummy arrays and require project-local caller-shape proof before assumed-shape modernization.
- Added conservative safety gates for public APIs, generic/procedure bindings, missing `INTENT`, non-unique procedure names, array elements/sections/components, unresolved or mismatched caller bounds, continued declarations, and `BIND(C)`.
- Added `array-interface-plan` with reviewed selection, source-hash protection, non-destructive transformed previews, unified patches, and approval-protected application.
- Preserved nondefault dummy lower bounds such as `0:n-1` as `0:` and verified the reviewed declaration after application.
- Added a deterministic compile-and-run demo, documentation, Make/VS Code targets, offline/quality/acceptance integration, and project stage `140-array-interfaces`.
- Increased mandatory Python tests from 124 to 129.

## 0.26.0

- Added `test-harness-suggest` for non-modifying, deterministic Fortran smoke-test driver generation.
- Added fparser-based discovery of both external and module-contained procedures with module accessibility checks.
- Added dummy-argument contracts covering type, kind, rank, shape, INTENT, attributes, deterministic initialization, and source traceability.
- Added explicit safety blockers for I/O, COMMON, SAVE/DATA, EQUIVALENCE, hidden module state, inaccessible procedures, unresolved direct calls, unsafe shapes, and unsupported dummy ownership.
- Added generated scalar/array result summaries, dependency-closure evidence, unreviewed adoption templates, demo, documentation, Copilot guidance, VS Code/Make targets, and project stage `130-kernel-test-harnesses`.
- Increased mandatory Python tests from 120 to 124.

## 0.25.0

- Added `kind-standardization-plan` for compiler-verified migration from legacy intrinsic type spelling to `ISO_FORTRAN_ENV` named kinds.
- Added raw-fparser-AST handling for declarations and typed FUNCTION statements in fixed and free form.
- Added representation probes for kind, storage size, precision/range, and integer range before offering `DOUBLE PRECISION`, `DOUBLE COMPLEX`, `REAL*n`, `INTEGER*n`, or `COMPLEX*n` mappings.
- Added safe merge/insertion of `USE, INTRINSIC :: ISO_FORTRAN_ENV, ONLY: ...`, including existing renames.
- Added explicit blockers for `LOGICAL*n`, `BYTE`, unsupported sizes, numeric kinds by default, INCLUDE-origin declarations, parser uncertainty, comments, semicolon statements, and local-name conflicts.
- Added application verification, documentation, demo, Copilot guidance, VS Code task, project stage `120-kind-standardization`, and four mandatory tests.
- Increased mandatory Python tests from 116 to 120.

## 0.24.0

- Added stable Fortran module API inventory and review (`public-api-suggest`).
- Added compatibility-preserving and project-minimal private-by-default API candidates.
- Added reviewed API planning and approval-protected application (`public-api-plan`, `API-*`).
- Added post-application verification of PRIVATE default and exact PUBLIC names.
- Added generic-interface, USE alias, re-export, unrestricted-consumer, and declaration-access safety checks.
- Added public API demo, project stage, documentation, Copilot prompt, VS Code task, and offline acceptance coverage.

## 0.23.0

- Added `state-lifecycle-suggest`, a non-modifying inventory of module variables, SAVE/DATA locals, caches, work arrays, constants, and dynamic resources.
- Added reader/writer evidence across `USE ONLY`, warnings for unrestricted `USE`, and explicit blockers for bare SAVE, pointer aliasing, EQUIVALENCE, compatibility parsing, and unresolved types.
- Added reviewed Fortran action proposals for constants, explicit arguments, state objects, workspace objects, ordinary locals, and initialize/finalize ownership.
- Added lifecycle-procedure evidence, ownership groups, JSON/CSV/Markdown/DOT reports, and an unreviewed lifecycle decision template.
- Added project-readiness stage `97-state-lifecycle`, a compiled demo preserving output `2.000 6.000`, Copilot review guidance, and 4 mandatory tests.
- Increased mandatory Python tests from 108 to 112.

## 0.22.0

- Added `responsibility-split-suggest`, a non-modifying review of source ranges that mix input, computation, and output responsibilities.
- Added conservative boundary-variable inference for inputs, outputs, inouts, localizable variables, and unknown procedure effects.
- Added control-flow blockers for early RETURN, process termination, unstructured/cross-boundary branches, unbalanced constructs, preprocessor lines, INCLUDE-origin statements, compatibility parsing, COMMON, and EQUIVALENCE.
- Added I/O dependency, source snippet, JSON/CSV/Markdown evidence bundles and project-readiness stage `99-responsibility-separation`.
- Added a compiled responsibility-separation demo, Copilot instructions, VS Code task, documentation, and 3 mandatory tests.
- Increased mandatory Python tests from 104 to 108.

## 0.21.0

- Added `architecture-audit`, a non-modifying assessment of Fortran architecture, testability, reusable interfaces, and future portability.
- Added separate readiness dimensions for state isolation, I/O separation, interface clarity, testability, Fortran library use, external calls, reentrancy, and future migration.
- Added role classification, direct CALL graph, I/O/state/side-effect ledgers, numerical-kernel candidates, and stable Fortran public-interface candidates.
- Critical blockers now override candidate scores.
- Explicitly excludes Python, F2PY, Cython, Firedrake, and wrapper generation from tool scope.
- Added project-readiness stage `98-architecture-readiness`, a demonstration fixture, Copilot prompt, documentation, and 3 mandatory tests.
- Increased mandatory Python tests from 101 to 104.

## 0.20.0

- Added `fixed-to-free-plan`, a findent-backed, non-destructive project-scoped conversion from `.f/.for/.ftn` to `.f90`.
- Converts referenced INCLUDE fragments inside the selected source root while preserving INCLUDE filenames.
- Requires raw fparser program-unit structure to match before and after conversion and runs a gfortran preview check.
- Added reviewed file deletion support to `apply`; old fixed-form copies are removed only from the transformed tree.
- Added fixed-to-free verification receipts, source mapping, include inventory, preview patches, a demo, and stage `100-fixed-to-free` in project assessment.
- Added 3 integration/safety tests; total mandatory tests are now 101.

## 0.19.0

- Added AST-backed extraction of EQUIVALENCE sets, objects, array subscripts, and source locations.
- Added `storage-overlay-plan` with configurable default storage sizes and packed/natural-alignment COMMON offset estimates.
- Added byte-range overlap classification for exact compatible aliases, exact type punning, partial compatible overlap, and partial incompatible overlap.
- Added storage, EQUIVALENCE, overlap, and blank-COMMON CSV reports plus a review-only migration guide.
- Added a conservative approval-required candidate that names blank COMMON only when all layouts are storage-compatible and no EQUIVALENCE object touches the block.
- Extended `apply` verification to reject residual blank COMMON and require the selected named block.
- Added project-readiness stage `47-storage-overlays`, a compiled blank-COMMON regression demo, and four mandatory tests.
- Increased mandatory Python tests from 94 to 98.


## 0.18.0

- Added `block-data-init-plan` for reviewed migration of named COMMON initialization from `BLOCK DATA` and `DATA` to an explicit idempotent initializer.
- Added AST-backed expansion of scalar targets, constant-shape arrays, array elements, literal values, and integer repetition counts.
- Added blockers for implied-DO objects, nonliteral values, nonconstant bounds, EQUIVALENCE, duplicate initialization, COMMON DATA outside BLOCK DATA, and ambiguous main programs.
- Added generated initialization modules, entry-program `USE`/`CALL` insertion, BLOCK DATA deactivation, stale-source protection, and post-application verification.
- Fixed named `BLOCK DATA` extraction in AST program-unit splitting and AST header inventory.
- Added a compiled executable regression demo preserving initialized output `859.010`.
- Added project-readiness stage `45-block-data-initialization`.
- Increased mandatory Python tests from 90 to 94.


## 0.17.0

- Added `state-integration-suggest` to compare four reviewed shared-state integration strategies against existing modules and derived types.
- Added module/derived-type inventory, component and visibility reporting, module dependency graphs, and candidate-specific public-API and initialization-risk summaries.
- Added conservative blocking for target-module `USE` cycles, target modules containing affected procedures, source-module dependencies, type/component name conflicts, non-free-form target modules, and object-argument name collisions.
- Added `state-integration-plan` and approval-protected application for: a new independent types module, adding types to an existing module, extending an existing type, and containing reviewed object types inside an existing type.
- Generalized state-object source transformation to support nested component references such as `simulation%state%field`.
- Extended post-application verification to require reviewed components in reused or extended types.
- Added a standalone existing-structure integration sample and executable regression demo.
- Added project-readiness stage `95-existing-structure-integration`.
- Increased mandatory Python tests from 86 to 90.

## 0.16.0

- Added `external-interface-plan` for project-local `EXTERNAL` procedures, external FUNCTIONs, and procedure dummy arguments.
- Added source-backed resolution of procedure actual arguments and conservative blocking for unresolved, duplicate, or ambiguous procedure bindings.
- Added generated explicit-interface modules plus `abstract interface` and `PROCEDURE(interface_name)` declarations.
- Added caller-side `USE ... ONLY` imports while leaving external implementations and linker names unchanged.
- Added strict gfortran validation with implicit-interface and implicit-procedure warnings promoted to errors, plus an executable callback regression fixture.
- Added optional `findent-verify`; findent remains unbundled and non-required, and is executed only when explicitly requested.
- Added optional second-wheel support to offline acceptance for Linux findent validation.
- Increased mandatory Python tests from 81 to 86.

## 0.15.0

- Added `fixed-form-rewrite-plan`, an AST-backed, non-destructive rewriter for continued or overlength type declarations, COMMON statements, and CALL statements.
- Added exact multi-line `replace_range` edits with source-hash and physical-range staleness protection.
- Preserved fixed-form statement labels in columns 1-5, generated deterministic continuation markers in column 6, and supported reviewed 72/80/132-column policies.
- Added conservative blockers for comments inside statement spans, numeric sequence fields, Hollerith literals, compatibility-normalized ASTs, and unbreakable tokens.
- Added statement inventory, Markdown review guide, unified patch, transformed preview, a dedicated demo, and post-application fparser/gfortran verification.
- Kept findent optional and unused by default; no external formatter is downloaded or executed.
- Increased mandatory Python tests from 76 to 81.

## 0.14.0

- Rebuilt program-unit splitting and semantic extraction around retained fparser ASTs instead of using fparser primarily as a pass/fail parser.
- Added AST extraction for declarations, dimensions, implicit maps, COMMON, CALL, USE ONLY, EXTERNAL, external FUNCTION metadata, derived types, components, and source statement spans.
- Added analysis-only Absoft compatibility normalization for `$` identifiers and dot component syntax, preserving line numbers and restoring original names in reports.
- Added frontend coverage accounting, AST/fallback fact counts, source-statement spans, and `frontend-audit --fail-on-fallback`.
- Added synthetic Absoft compatibility fixtures for dollar identifiers, dot components, continued declarations/COMMON/CALL, EXTERNAL callbacks, existing modules/types, and uninitialized variables.
- Added `standard`, `absoft-compat`, `uninitialized-warning`, and `uninitialized-poison` gfortran profiles.
- Added project-assessment reporting for frontend modes, compatibility constructs, and compiler profile.
- Added resumable workspace initialization, immutable checkpoints, source-tree SHA-256 verification, status, history, and resume commands.
- Added optional external-tool detection and an explicit policy that CamFort, findent, and fortls are not required, bundled, downloaded, or automatically used.
- Preserved every existing staged transformation and numerical regression gate.
- Increased mandatory Python tests from 62 to 76.

## 0.13.0

- Added review-protected classification of module shared variables into project-specific derived-type objects.
- Added generated type-definition modules, `object%component` source rewrites, and explicit object dummy/actual propagation through known CALL edges.
- Added conservative object INTENT inference and blockers for unsupported declarations, direct shared-variable actual arguments, unresolved external procedures, unrestricted USE, and unsafe fixed-form rewrites.
- Extended apply verification to require old storage-module removal, generated type definitions, reviewed object declarations, and successful fparser/gfortran/regression gates.
- Extended the staged lubrication demo through derived-type and explicit-argument state migration.
- Increased mandatory Python tests from 59 to 62.

## 0.12.0

- Added `intent-plan` for conservative interprocedural dummy-argument read/write propagation.
- Added source-order tracking that distinguishes input reads from reads after a definite local definition.
- Added propagation through resolvable CALL edges, including recursion fixpoint handling.
- Added blockers for unresolved external calls, aliased writable actual arguments, risky constructs, and conflicting existing INTENT attributes.
- Added reviewed `INTENT(IN)`, `INTENT(OUT)`, and `INTENT(INOUT)` declaration edits with non-destructive previews.
- Added `argument_access.csv`, `intent_candidates.csv/json`, `intent_plan.md`, and a unified diff.
- Added post-application verification that every selected dummy declaration contains the reviewed INTENT.
- Extended the staged lubrication demo and numerical regression through the INTENT stage.
- Increased mandatory Python tests from 53 to 59.

## 0.11.0

- Added `frt common-repair-plan` for genuinely incompatible named COMMON layouts.
- Treats every distinct source-backed count/type/kind/rank/shape layout as an alternative candidate; no majority layout is auto-selected.
- Added candidate support counts, confidence labels, field-level impacts, source reference counts, CALL-argument references, and estimated payload bytes.
- Added candidate-specific transformed-source previews and unified diffs, each verified with fparser before becoming machine-applicable.
- Added conservative machine edits for type/kind/shape changes, same-name order repair, and strict trailing count extension.
- Never machine-removes storage entries and blocks ambiguous mappings, continued/initialized declarations, risky storage constructs, and unsafe fixed-form line lengths.
- Extended `frt apply` to require exactly one candidate per COMMON block and to verify that selected layout errors are eliminated.
- Added `common_repair_options.json` with `reviewed=false`, layout and impact CSV reports, an impact graph, a dedicated demo, and Copilot review instructions.
- Updated project intake to recommend `common-repair-plan` for the COMMON-layout stage.
- Increased mandatory Python tests from 49 to 53.

## 0.10.0

- Added `frt project-init` to create a reviewable JSON project configuration for real legacy-code intake.
- Added `frt assess-project` for non-modifying source inventory, fparser parseability, INCLUDE resolution, compiler diagnostics, unsupported-construct inventory, and staged transformation readiness.
- Added `frt run-pipeline` to run the configured intake pipeline and optional explicit regression commands/comparisons.
- Added source, INCLUDE, syntax, program-unit capability, and transformation-readiness CSV reports.
- Added `assessment.json`, recommended pipeline Markdown/JSON, and source-free shareable summaries with no source body or absolute project path.
- Added support classification for risky legacy constructs: supported-with-review, analyze-only, parser-sensitive, and unsupported.
- Added configurable gfortran command, flags, fixed-line length, source globs, exclusions, INCLUDE directories, performance budget, and regression gates.
- Added a complete project configuration example for the journal-bearing sample.
- Added a mandatory 10,000+ line, 80-program-unit scale test; fparser parses all 80 units within the configured 60-second budget.
- Increased mandatory Python tests from 45 to 49.

## 0.9.0

- Added `frt procedure-domain-suggest` to propose functional domains from procedure names, comments, CALL relationships, COMMON blocks, and imported module state.
- Added deterministic semantic scores, confidence levels, alternatives, and conservative one-hop CALL-neighbour propagation.
- Preserved recursive and mutually recursive SCCs as atomic classification units.
- Added `classification_draft.json`, `domain_proposal.json`, `domain_evidence.csv`, `procedure_profiles.csv`, `relationship_evidence.csv`, `proposed_domain_graph.dot`, and `review_guide.md`.
- Generated drafts carry `reviewed=false`; `procedure-module-domain-plan` now rejects them until a human explicitly reviews and approves a copy.
- Extended the staged demo to generate, inspect, approve, and consume a classification proposal before procedure module migration.
- Increased mandatory Python tests from 39 to 45.

## 0.8.0

- Added `frt procedure-module-domain-plan` for user-defined functional grouping of external subroutines.
- Added JSON classification schema with explicit procedure assignments, regular-expression rules, per-domain module prefixes, and per-domain size targets.
- Explicit assignments take precedence over pattern rules; ambiguous and unclassified procedures are reported and blocked by default.
- Added conservative blockers when one recursive SCC spans multiple domains or when grouping would create cyclic generated-module dependencies.
- Added domain-specific module splitting while preserving SCC atomicity and explicit cross-module `USE ... ONLY` imports.
- Added `domain_assignment.json`, `domain_assignment.csv`, `domain_dependencies.dot`, and a frozen classification snapshot.
- Extended `frt apply` verification to functional procedure-module plans.
- Added a lubrication-domain example that separates geometry, solver, postprocessing, and output procedures.
- Extended the staged demo and acceptance gates through four named functional procedure modules.
- Increased mandatory Python tests from 32 to 39.

## 0.7.0

- Added `frt procedure-module-partition-plan` for call-graph-based migration into multiple generated procedure modules.
- Added Tarjan strongly connected components so recursive and mutually recursive procedures are never split.
- Added dependency-first SCC condensation ordering and deterministic contiguous packing with `--max-procedures-per-module`.
- Added module-level `USE ... ONLY` generation for cross-module CALL edges and caller-side imports for remaining programs or procedures.
- Added `module_partition.json`, `module_partition.csv`, and `module_dependencies.dot` reports.
- Extended `frt apply` to verify multiple generated procedure modules, per-procedure module mappings, and all cross-module explicit imports.
- Extended the staged demo to generate two procedure modules and compile them with implicit-interface warnings promoted to errors.
- Increased mandatory Python tests from 27 to 32.

## 0.6.0

- Added `frt procedure-module-plan` for conservative migration of top-level external subroutines into one generated module.
- Added fixed-form and free-form generated procedure modules with `PRIVATE`, explicit `PUBLIC` exports, and `CONTAINS`.
- Added caller-side `USE ... ONLY` insertion so migrated procedures have explicit interfaces.
- Added blockers for duplicate definitions, mixed source forms, risky constructs, EXTERNAL/INTERFACE/PROCEDURE declarations, CALL errors, and calls to non-migrated external subroutines.
- Extended `frt apply` to verify that external definitions are removed, generated module definitions exist, and every remaining caller imports the required procedures.
- Added dependency-aware ordering of generated modules before module consumers in gfortran checks.
- Extended the staged demo to compile with `-Werror=implicit-interface` and `-Werror=implicit-procedure`.
- Increased mandatory Python tests from 23 to 27.

## 0.5.0

- Added `frt common-module-plan` for migration of one centralized named COMMON block to generated module storage.
- Added shared shape-dependency INCLUDE detection and conservative blocking for unresolved dimensions.
- Added minimal per-program-unit `USE ... ONLY` lists.
- Added full-file replacement support for deactivating centralized COMMON INCLUDE files.
- Added verification that selected COMMON entries and active COMMON statements are completely removed.
- Extended the staged numerical demo through COMMON-to-module migration.
- Increased mandatory Python tests from 20 to 23.

## 0.4.0

- Added `frt common-include-plan` for compatible named COMMON blocks.
- Added canonical variable-name selection by storage position, preferring the most frequent name and source-order ties.
- Added conservative alias normalization across program units with local-name collision detection.
- Added generated fixed-form or free-form INCLUDE files containing one canonical declaration and COMMON sequence.
- Added blockers for blank COMMON, layout diagnostics, implicit COMMON declarations, mixed source forms, risky constructs, parse failures, continued declarations, and multi-block COMMON statements.
- Extended `frt apply` to support multi-file plans and generated files while retaining stale-plan SHA-256 protection.
- Added generated include directories automatically to fparser and gfortran verification.
- Extended the staged demo through typo repair, IMPLICIT NONE, COMMON INCLUDE centralization, compilation, execution, and golden-output comparison.
- Increased mandatory Python tests from 17 to 20.

## 0.3.0

- Added approval-driven `frt apply` that writes only to a copied source tree.
- Added source SHA-256 and exact-line stale-plan protection.
- Added selective suggestion IDs and `--all-automatic`.
- Added mandatory `--approve-review` for semantic transformations.
- Added post-application fparser verification and optional gfortran compile checking.
- Added program-unit-level `frt implicit-none-plan`.
- Added explicit declaration generation for resolved implicit arguments, COMMON entries, and local symbols.
- Blocked implicit-none automation for typo candidates, parser failures, risky constructs, unresolved types, continued/multiple IMPLICIT statements, and implicit function result typing.
- Added a complete staged demo: typo repair, re-analysis, IMPLICIT NONE migration, compilation, execution, and golden-output comparison.
- Increased mandatory Python tests from 13 to 17.
- Removed `.python-version` so WSL can use its installed Python 3.10+ selected explicitly by uv.

## 0.2.0

- Added CALL argument type, kind, and rank inference and diagnostics.
- Added conservative unresolved-argument reporting instead of speculative mismatches.
- Added procedure signature and typed call ledgers.
- Added the non-destructive `frt suggest` command.
- Limited automatic previews to narrowly proven one-character implicit typo assignments.
- Added 13 mandatory tests, including real fparser integration and numerical regression.

## 0.1.1

- Replaced pip/venv workflow with uv project management.
- Added `uv.lock` and mandatory fparser integration gates.
- Fixed the official fparser 0.2.4 wheel URL and SHA-256 digest.

## 0.1.0

- Initial phase 0–3 implementation.
