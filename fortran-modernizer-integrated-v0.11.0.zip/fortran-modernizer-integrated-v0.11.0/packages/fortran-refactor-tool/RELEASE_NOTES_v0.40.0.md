# Fortran Refactoring Tool v0.40.0

## Added

- Reviewed named-COMMON initialization and observation fixtures for `repeated-call-harness-suggest`.
- `--state-fixture` input with review, approval, source-hash, layout, member, and typed-value validation.
- COMMON state initialization, first-call snapshot, reset before the second call, and selected member comparison.
- Narrow support for same-type scalar EQUIVALENCE aliases connected to one named-COMMON object.
- `common_state_fixture.json` and `common_state_contracts.csv` evidence.

## Validation

- 192 Python tests pass.
- Synthetic fixed-form named-COMMON stateless fixture passes repeated-call comparison.
- Synthetic COMMON plus local SAVE state fails through an observed COMMON member as expected.
- Synthetic type-punning EQUIVALENCE remains blocked.
- Offline acceptance uses only the supplied fparser and findent wheels.
- No production Fortran code was used; real-code applicability remains unverified.

## Safety boundaries

- Blank COMMON is not supported.
- Type-punning, kind-changing, partial, multi-object, dynamic, or unresolved EQUIVALENCE layouts are not supported.
- COMMON storage used only in unresolved callees is not reconstructed automatically.
- Fixture values are deterministic test inputs and require domain review before adoption.
