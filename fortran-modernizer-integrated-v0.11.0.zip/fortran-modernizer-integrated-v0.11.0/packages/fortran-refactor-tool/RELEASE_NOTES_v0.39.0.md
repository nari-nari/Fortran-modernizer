# Fortran Refactoring Tool v0.39.0

## Added

- `frt determinism-matrix` for compiler × optimization × OpenMP thread-count evaluation.
- Safe argv template expansion for compiler commands, compiler flags, optimization flags, variant names, thread counts, and generated executable names.
- Per-variant build, repeated-run determinism, environment, cleanup, and evidence capture.
- Cross-variant comparison of run-1 artifacts against a selected or first successful baseline.
- JSON, CSV, and Markdown matrix summaries plus complete per-variant and per-artifact reports.
- Optional unavailable compiler profiles through `required: false`; required compilers still fail the gate.
- Project-pipeline integration through `regression.determinism_matrix`.

## Validation

- 188 Python tests pass.
- Synthetic OpenMP Fortran fixture passes with gfortran at O0/O2 and one/two threads.
- All four variants pass two-run internal determinism and cross-variant field comparison.
- An intentional compile-profile difference passes each internal determinism gate but fails the cross-variant numerical gate.
- Offline acceptance uses only the supplied fparser and findent wheels.
- No production Fortran code was used; real-code and multi-vendor compiler applicability remain unverified.

## Safety boundaries

- Commands are argv arrays and are never executed by a shell.
- Generated executables must remain inside the configured working directory.
- A matrix pass covers only configured artifacts, adapters, and tolerances.
- The tool does not prove determinism of unobserved internal state or all possible thread schedules.
